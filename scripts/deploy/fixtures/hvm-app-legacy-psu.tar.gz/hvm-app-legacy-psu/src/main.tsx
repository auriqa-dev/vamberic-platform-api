import { createOperatingGateway } from "./data/operating/gateway";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { App } from "./App";
import { configureAuth, parseConfig } from "./auth/config";
import { createHttpGateway } from "./data/http-gateway";
import { pendingGateway } from "./data/gateway";
import "./styles.css";

function getSession() {
  try {
    const config = parseConfig(import.meta.env, window.location.origin);
    const session = configureAuth(config);
    return {
      session,
      operating: createOperatingGateway(config.VITE_API_BASE_URL, session),
      gateway: createHttpGateway(
        config.VITE_API_BASE_URL,
        session,
        `https://cognito-idp.${config.VITE_COGNITO_REGION}.amazonaws.com/${config.VITE_COGNITO_USER_POOL_ID}`,
      ),
    };
  } catch {
    return null;
  } // Public UI does not print config values or provider errors.
}
const session = getSession();
const router = createBrowserRouter([
  {
    path: "*",
    element: (
      <App
        session={session?.session ?? null}
        gateway={session?.gateway ?? pendingGateway}
        operating={session?.operating}
      />
    ),
  },
]);
createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
);
