import { PsuPage } from "./pages/psu";
import { ClientOnboarding } from "./pages/client-onboarding";
import { areas } from "./components/operating/fields";
import { OperatingContext } from "./data/operating/context";
import type { OperatingGateway } from "./data/operating/gateway";
import { useRefreshingResource } from "./data/use-refreshing-resource";
import {
  Component,
  lazy,
  Suspense,
  useCallback,
  useEffect,
  useState,
  useSyncExternalStore,
  type ReactNode,
} from "react";
import {
  Link,
  Navigate,
  NavLink,
  Route,
  Routes,
  useLocation,
  useNavigate,
  useParams,
  useSearchParams,
} from "react-router-dom";
import type { AuthSession } from "./auth/session";
import { DataError, loadAccess, type HvmGateway } from "./data/gateway";
import {
  perspectives,
  workspaceFor,
  type Access,
  type Perspective,
} from "./data/model";
import { Empty, Failure, Loading, Logo } from "./components/ui";
import {
  clientSections,
  sections,
  WorkspaceCard,
  WorkspaceLoader,
  workspacePath,
  type Section,
} from "./components/workspace";

const QueenOperating = lazy(() =>
  import("./pages/queen-operating").then((module) => ({
    default: module.QueenOperating,
  })),
);
const EmpressRoutes = lazy(() =>
  import("./pages/empress").then((module) => ({
    default: module.EmpressRoutes,
  })),
);

export type Session = Pick<
  AuthSession,
  "subscribe" | "getSnapshot" | "start" | "signIn" | "signOut"
>;
export function App({
  session,
  gateway,
  operating,
}: {
  session: Session | null;
  gateway: HvmGateway;
  operating?: OperatingGateway;
}) {
  return (
    <OperatingContext.Provider value={operating}>
      <AppBoundary>
        <a className="skip-link" href="#main">
          Skip to content
        </a>
        {session ? (
          <AuthGate session={session} gateway={gateway} />
        ) : (
          <Welcome />
        )}
      </AppBoundary>
    </OperatingContext.Provider>
  );
}
function Welcome({
  session,
  status,
  message,
}: {
  session?: Session;
  status?: string;
  message?: string;
}) {
  return (
    <div className="welcome">
      <header className="public-header">
        <Logo />
        <span className="eyebrow">Client operations</span>
      </header>
      <main id="main" className="welcome-main">
        <div className="welcome-copy">
          <p className="eyebrow">One workspace. Shared ambition.</p>
          <h1>
            Good work starts
            <br />
            with strong
            <br />
            <em>foundations.</em>
          </h1>
          <p className="intro">
            Your brand, your people and the tools that bring it all together.
            Welcome to your HVM workspace.
          </p>
          {session ? (
            <div className="signin">
              <p role="status">
                {status === "loading"
                  ? "Checking your session…"
                  : (message ?? "Sign in to access your workspace.")}
              </p>
              <button
                className="button"
                disabled={status === "loading"}
                onClick={() => void session.signIn()}
              >
                Sign in to HVM <span aria-hidden="true">↗</span>
              </button>
            </div>
          ) : (
            <div className="signin" role="status">
              <strong>Sign-in is being prepared.</strong>
              <p>
                HVM needs to complete application setup before you can access
                your workspace.
              </p>
            </div>
          )}
        </div>
        <aside className="welcome-aside" aria-label="Working with HVM">
          <div className="orbital" aria-hidden="true">
            <span>HVM</span>
          </div>
          <p className="eyebrow">Built around your business</p>
          <ol>
            <li>
              <span>01</span>
              <div>
                <h2>Establish</h2>
                <p>Bring your identity and brand into focus.</p>
              </div>
            </li>
            <li>
              <span>02</span>
              <div>
                <h2>Connect</h2>
                <p>Align your people, access and tools.</p>
              </div>
            </li>
            <li>
              <span>03</span>
              <div>
                <h2>Operate</h2>
                <p>A shared foundation for your swarm.</p>
              </div>
            </li>
          </ol>
        </aside>
      </main>
      <footer className="public-footer">
        <span>HVM</span>
        <span>Human direction. Connected capability.</span>
      </footer>
    </div>
  );
}
function AuthGate({
  session,
  gateway,
}: {
  session: Session;
  gateway: HvmGateway;
}) {
  const state = useSyncExternalStore(session.subscribe, session.getSnapshot);
  useEffect(() => {
    void session.start(window.location.href);
  }, [session]);
  if (state.status !== "authenticated" || !state.subject)
    return (
      <Welcome
        session={session}
        status={state.status}
        message={state.message}
      />
    );
  // Subject changes clear all private state. Route resources own their identity;
  // an ordinary authority refresh must not remount an authorized editor.
  return (
    <Authenticated
      key={state.subject}
      subject={state.subject}
      session={session}
      gateway={gateway}
    />
  );
}
function Authenticated({
  subject,
  session,
  gateway,
}: {
  subject: string;
  session: Session;
  gateway: HvmGateway;
}) {
  const location = useLocation();
  const [revision, setRevision] = useState(0);
  const load = useCallback(
    (signal: AbortSignal) => {
      void revision;
      void location.key;
      return loadAccess(gateway, subject, signal);
    },
    [gateway, subject, revision, location.key],
  );
  const result = useRefreshingResource(load);
  // Revalidate in place; failure removes private content, revocation removes routes.
  useEffect(() => {
    const refresh = () => {
      if (document.visibilityState === "visible") setRevision((n) => n + 1);
    };
    window.addEventListener("focus", refresh);
    document.addEventListener("visibilitychange", refresh);
    return () => {
      window.removeEventListener("focus", refresh);
      document.removeEventListener("visibilitychange", refresh);
    };
  }, []);
  if (result.state !== "ready")
    return (
      <div>
        <header className="public-header">
          <Logo />
          <button
            className="text-button"
            onClick={() => void session.signOut()}
          >
            Sign out
          </button>
        </header>
        <main id="main" className="waiting-main">
          {result.state === "loading" ? (
            <Loading label="Checking workspace access…" />
          ) : (
            <Failure
              error={result.error}
              retry={() => setRevision((n) => n + 1)}
            />
          )}
        </main>
      </div>
    );
  return <Frame session={session} access={result.data} gateway={gateway} />;
}
const labels = {
  empress: "Empress",
  queen: "Queen view",
  client: "Client view",
};
type ViewProps = { access: Access; gateway: HvmGateway };
function Frame({ session, access, gateway }: ViewProps & { session: Session }) {
  const location = useLocation();
  const navigate = useNavigate();
  const choices = perspectives(access);
  const segment = location.pathname.split("/")[1];
  const perspective: Perspective =
    segment === "empress"
      ? "empress"
      : segment === "client"
        ? "client"
        : "queen";

  const allowed = choices.includes(perspective);
  const [search] = useSearchParams();
  const selectedClient =
    workspaceFor(access, "client", search.get("workspace") ?? "") ??
    access.client?.workspaces[0];
  const queenWorkspaceId = location.pathname.match(
    /^\/queen\/clients\/([^/]+)/,
  )?.[1];
  const selectedQueen = queenWorkspaceId
    ? workspaceFor(access, "queen", queenWorkspaceId)
    : undefined;
  const contextLabel =
    perspective === "empress"
      ? "Empress / Platform"
      : perspective === "queen"
        ? `Queen / ${selectedQueen?.name ?? "Partner"}`
        : `Client / ${selectedClient?.name ?? "Workspace"}`;
  useEffect(() => {
    document.title = `HVM · ${labels[perspective]}`;
    document.getElementById("main")?.focus();
  }, [perspective, location.pathname, location.search]);
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <Link to="/" aria-label="HVM home">
          <Logo />
        </Link>
        <p className="eyebrow sidebar-label">Your operating space</p>
        {choices.length > 1 ? (
          <label className="context-label">
            Perspective
            <select
              value={allowed ? perspective : choices[0]}
              onChange={(e) => navigate(`/${e.target.value}`)}
            >
              {choices.map((choice) => (
                <option key={choice} value={choice}>
                  {labels[choice]}
                </option>
              ))}
            </select>
          </label>
        ) : choices.length === 1 ? (
          <p className="context-name">{labels[choices[0]!]}</p>
        ) : null}
        <nav aria-label="Main navigation">
          {allowed &&
            (perspective === "empress" ? (
              <>
                <NavLink to="/empress" end>
                  Platform overview
                </NavLink>
                <NavLink to="/empress/agreement-approvals">
                  Agreement Approvals
                </NavLink>
                {areas.map((area) => (
                  <NavLink key={area.path} to={`/empress/${area.path}`}>
                    {area.label}
                  </NavLink>
                ))}
              </>
            ) : perspective === "queen" ? (
              <>
                <NavLink to="/queen" end>
                  Dashboard
                </NavLink>
                <NavLink to="/queen/clients">My Clients</NavLink>
              </>
            ) : (
              clientSections.map(([key, label]) => (
                <NavLink
                  key={key}
                  to={workspacePath("client", selectedClient?.id ?? "", key)}
                  end
                >
                  {key === "setup" ? "Setup" : label}
                </NavLink>
              ))
            ))}
        </nav>
        <div className="sidebar-footer">
          <span className="eyebrow">HVM</span>
          <p>
            Human direction.
            <br />
            Connected capability.
          </p>
        </div>
      </aside>
      <div className="app-body">
        <header className="app-header">
          <span>{allowed ? contextLabel : "Access unavailable"}</span>
          <button
            className="text-button"
            onClick={() => void session.signOut()}
          >
            Sign out <span aria-hidden="true">↗</span>
          </button>
        </header>
        <main id="main" tabIndex={-1}>
          <Routes>
            <Route
              path="/empress/*"
              element={
                <Suspense fallback={<Loading label="Loading platform area…" />}>
                  <EmpressRoutes access={access} />
                </Suspense>
              }
            />
            <Route path="/" element={<Home access={access} />} />
            <Route path="/auth/callback" element={<Home access={access} />} />
            <Route
              path="/queen"
              element={<Queen access={access} gateway={gateway} />}
            />
            <Route
              path="/queen/clients"
              element={<Queen access={access} gateway={gateway} list />}
            />
            <Route
              path="/queen/clients/new"
              element={
                <ClientOnboarding key={access.actor.subject} access={access} />
              }
            />
            <Route
              path="/queen/clients/:workspaceId"
              element={<QueenWorkspace access={access} gateway={gateway} />}
            />
            <Route
              path="/queen/clients/:workspaceId/swarm/*"
              element={
                <Suspense
                  fallback={<Loading label="Loading client operations…" />}
                >
                  <QueenOperating access={access} />
                </Suspense>
              }
            />
            <Route
              path="/queen/clients/:workspaceId/:section"
              element={<QueenWorkspace access={access} gateway={gateway} />}
            />
            <Route
              path="/client"
              element={<ClientWorkspace access={access} gateway={gateway} />}
            />
            <Route
              path="/client/:section"
              element={<ClientWorkspace access={access} gateway={gateway} />}
            />
            <Route
              path="*"
              element={
                <Empty title="Page not found">
                  Return to your <Link to="/">workspace home</Link>.
                </Empty>
              }
            />
          </Routes>
        </main>
        <footer className="app-footer">
          HVM ·{" "}
          {perspective === "empress"
            ? "Platform operations"
            : "Client operations"}
        </footer>
      </div>
    </div>
  );
}
function Home({ access }: { access: Access }) {
  const first = perspectives(access)[0];
  return first ? (
    <Navigate replace to={`/${first}`} />
  ) : (
    <Empty title="No workspace access yet">
      You do not currently have platform, Partner or client workspace access.
      Contact HVM to arrange access.
    </Empty>
  );
}
function Queen({
  access,
  gateway,
  list = false,
}: ViewProps & { list?: boolean }) {
  if (!access.queen) return <Failure error={new DataError("denied")} />;
  return (
    <>
      <div className="page-heading">
        <p className="eyebrow">
          {access.queen.partners.map((p) => p.displayName).join(" · ")}
        </p>
        <h1>{list ? "My Clients" : "A clear view of the work."}</h1>
        <p>
          {list
            ? "The client workspaces you are authorized to operate."
            : "Your clients, their foundations and what needs attention next."}
        </p>
      </div>
      <div className="section-heading">
        <h2>{list ? "Assigned workspaces" : "Your client workspaces"}</h2>
        <div className="client-entry-actions">
          {!list && (
            <Link className="text-link" to="/queen/clients">
              View all clients ↗
            </Link>
          )}
          {access.queen.partners.some((p) => p.role === "owner") && (
            <Link className="button" to="/queen/clients/new">
              Onboard client
            </Link>
          )}
        </div>
      </div>
      {access.queen.workspaces.length ? (
        <div className="card-grid">
          {access.queen.workspaces.map((workspace) => (
            <WorkspaceCard
              key={workspace.id}
              workspace={workspace}
              access={access}
              gateway={gateway}
            />
          ))}
        </div>
      ) : (
        <Empty title="Your first client starts here">
          {access.queen.partners.some((p) => p.role === "owner")
            ? "Select Onboard client to create your first client workspace."
            : "You have Partner access, but no client workspaces are assigned yet. Contact your Partner owner to arrange your first assignment."}
        </Empty>
      )}
    </>
  );
}
function QueenWorkspace({ access, gateway }: ViewProps) {
  const { workspaceId = "", section = "overview" } = useParams();
  const workspace = workspaceFor(access, "queen", workspaceId);
  if (!workspace) return <Failure error={new DataError("denied")} />;
  if (!sections.some(([key]) => key === section))
    return (
      <Empty title="Section not found">
        Choose a workspace section from My Clients.
      </Empty>
    );
  return (
    <>
      <Link className="text-link" to="/queen/clients">
        ← My Clients
      </Link>
      <div className="page-heading">
        <p className="eyebrow">
          Client workspace · {workspace.organisationName}
        </p>
        <h1>{workspace.name}</h1>
      </div>
      <nav className="tabs" aria-label="Client workspace sections">
        {sections.map(([key, label]) => (
          <NavLink end key={key} to={workspacePath("queen", workspace.id, key)}>
            {label}
          </NavLink>
        ))}
      </nav>
      {section === "understanding" ? (
        <PsuPage api={gateway.psu} workspaceId={workspace.id} queen />
      ) : (
        <WorkspaceLoader
          key={`queen:${workspace.id}`}
          access={access}
          gateway={gateway}
          perspective="queen"
          workspace={workspace}
          section={section as Section}
        />
      )}
    </>
  );
}
function ClientWorkspace({ access, gateway }: ViewProps) {
  const { section = "overview" } = useParams();
  const [search, setSearch] = useSearchParams();
  const id = search.get("workspace") ?? access.client?.workspaces[0]?.id ?? "";
  const workspace = workspaceFor(access, "client", id);
  if (!workspace) return <Failure error={new DataError("denied")} />;
  if (!clientSections.some(([key]) => key === section))
    return (
      <Empty title="Section not found">
        Choose a section from your workspace navigation.
      </Empty>
    );
  return (
    <>
      <div className="page-heading">
        <p className="eyebrow">
          Client workspace · {workspace.organisationName}
        </p>
        <h1>
          {section === "overview"
            ? workspace.name
            : clientSections.find(([key]) => key === section)?.[1]}
        </h1>
        {(access.client?.workspaces.length ?? 0) > 1 && (
          <label className="workspace-label">
            Workspace
            <select
              value={workspace.id}
              onChange={(e) => setSearch({ workspace: e.target.value })}
            >
              {access.client?.workspaces.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </select>
          </label>
        )}
      </div>
      {section === "understanding" ? (
        <PsuPage api={gateway.psu} workspaceId={workspace.id} queen={false} />
      ) : (
        <WorkspaceLoader
          key={`client:${workspace.id}`}
          access={access}
          gateway={gateway}
          perspective="client"
          workspace={workspace}
          section={section as Section}
        />
      )}
    </>
  );
}
class AppBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? (
      <main id="main" className="waiting-main">
        <Logo />
        <h1>Something went wrong.</h1>
        <p>Please reload HVM to continue.</p>
        <button className="button" onClick={() => window.location.reload()}>
          Reload
        </button>
      </main>
    ) : (
      this.props.children
    );
  }
}
