import { WorkspaceBilling } from "./workspace-billing";
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { DataError } from "../data/gateway";
import type { PsuGateway, PsuCase, PsuRun, PsuResult } from "../data/psu";
import { useRefreshingResource } from "../data/use-refreshing-resource";
import { Empty, Failure, Loading } from "../components/ui";
/** Values are always rendered as text; Result/provider content is never HTML. */
function Details({ value }: { value: unknown }): ReactNode {
  if (value === null || value === undefined) return <span>Not recorded</span>;
  if (Array.isArray(value))
    return value.length ? (
      <ul>
        {value.map((v, i) => (
          <li key={i}>
            <Details value={v} />
          </li>
        ))}
      </ul>
    ) : (
      <span>None</span>
    );
  if (typeof value === "object")
    return (
      <dl>
        {Object.entries(value).map(([k, v]) => (
          <div key={k}>
            <dt>{k.replace(/([A-Z])/g, " $1").replaceAll("_", " ")}</dt>
            <dd>
              <Details value={v} />
            </dd>
          </div>
        ))}
      </dl>
    );
  return <span>{String(value)}</span>;
}
export function PsuPage({
  api,
  workspaceId,
  queen,
}: {
  api?: PsuGateway;
  workspaceId: string;
  queen: boolean;
}) {
  return api ? (
    <PsuWorkspace
      key={workspaceId}
      api={api}
      workspaceId={workspaceId}
      queen={queen}
    />
  ) : (
    <Empty title="Product/Service Understanding unavailable">
      Execution configuration is not enabled.
    </Empty>
  );
}
function PsuWorkspace({
  api,
  workspaceId: w,
  queen,
}: {
  api: PsuGateway;
  workspaceId: string;
  queen: boolean;
}) {
  const [revision, setRevision] = useState(0),
    [selected, setSelected] = useState("");
  const load = useCallback(
    (s: AbortSignal) => {
      void revision;
      return Promise.all([
        api.options(w, s),
        api.brands(w, s),
        api.offerings(w, s),
        api.cases(w, s),
      ]);
    },
    [api, w, revision],
  );
  useEffect(() => {
    const refresh = () => setRevision((v) => v + 1);
    window.addEventListener("focus", refresh);
    return () => window.removeEventListener("focus", refresh);
  }, []);
  const state = useRefreshingResource(load);
  const [mode, setMode] = useState<"create" | "refresh">("create"),
    [source, setSource] = useState(""),
    [option, setOption] = useState(""),
    [label, setLabel] = useState(""),
    [orientation, setOrientation] = useState("");
  const [busy, setBusy] = useState(false),
    [error, setError] = useState<unknown>();
  const pending = useRef<AbortController | undefined>(undefined);
  const request = useRef<{ body: string; key: string } | undefined>(undefined);
  useEffect(() => () => pending.current?.abort(), []);
  if (state.state === "loading") return <Loading />;
  if (state.state === "error") return <Failure error={state.error} />;
  const [options, brands, offerings, cases] = state.data;
  const chosen = options.find((o) => o.target.id === option),
    target = offerings.find((o) => o.id === source && o.status === "draft");
  const refresh = () => setRevision((v) => v + 1);
  return (
    <>
      <h1>Product/Service Understanding</h1>
      {queen && <WorkspaceBilling key={w} workspaceId={w} />}
      <p>
        Understand the current facts, resolve gaps and review proposals.
        Effectiveness PASS does not approve canonical knowledge or enable
        marketing.
      </p>
      <form
        className="panel"
        onSubmit={async (e) => {
          e.preventDefault();
          if (pending.current || !chosen || !source) return;
          setBusy(true);
          setError(undefined);
          const c = new AbortController();
          pending.current = c;
          try {
            const input =
              mode === "create"
                ? { mode, brandId: source, workingLabel: label, orientation }
                : target
                  ? {
                      mode,
                      offeringId: target.id,
                      expectedUpdatedAt: target.updatedAt,
                      workingLabel: label,
                      orientation,
                    }
                  : undefined;
            if (!input) throw new DataError("invalid");
            const body = JSON.stringify({ target: chosen.target, input });
            if (!request.current || request.current.body !== body)
              request.current = { body, key: crypto.randomUUID() };
            await api.start(w, chosen, input, request.current.key, c.signal);
            if (!c.signal.aborted) {
              request.current = undefined;
              refresh();
            }
          } catch (e) {
            if (!c.signal.aborted) setError(e);
          } finally {
            pending.current = undefined;
            if (!c.signal.aborted) setBusy(false);
          }
        }}
      >
        <h2>Prepare understanding</h2>
        <fieldset disabled={busy}>
          <legend>Scope</legend>
          <label>
            Agent
            <select
              required
              value={option}
              onChange={(e) => setOption(e.target.value)}
            >
              <option value="">Select registered PSU</option>
              {options.map((o) => (
                <option key={o.target.id} value={o.target.id}>
                  {o.name} · version {o.target.definition.version}
                </option>
              ))}
            </select>
          </label>
          <label>
            Operation
            <select
              value={mode}
              onChange={(e) => {
                setMode(e.target.value as typeof mode);
                setSource("");
              }}
            >
              <option value="create">Create understanding</option>
              <option value="refresh">Refresh an existing draft</option>
            </select>
          </label>
          <label>
            {mode === "create" ? "Brand" : "Offering draft"}
            <select
              required
              value={source}
              onChange={(e) => setSource(e.target.value)}
            >
              <option value="">Select source</option>
              {mode === "create"
                ? brands.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))
                : offerings
                    .filter((o) => o.status === "draft")
                    .map((o) => (
                      <option key={o.id} value={o.id}>
                        {String(o.definition.name ?? o.id)} · revision{" "}
                        {o.revision}
                      </option>
                    ))}
            </select>
          </label>
          <label>
            Working label
            <input
              required
              maxLength={200}
              value={label}
              onChange={(e) => setLabel(e.target.value)}
            />
          </label>
          <label>
            Orientation
            <textarea
              maxLength={4000}
              value={orientation}
              onChange={(e) => setOrientation(e.target.value)}
            />
          </label>
          <p>
            Orientation guides questions. It is not automatically admitted as a
            factual assertion.
          </p>
        </fieldset>
        {!options.length && (
          <p>
            No authorized registered PSU implementation is available. A Client
            Agent configuration is not a prerequisite.
          </p>
        )}
        {chosen?.executionState === "busy" && (
          <p>PSU is busy. Please try again when the current work finishes.</p>
        )}
        {chosen?.executionState === "unavailable" && (
          <p>PSU is currently unavailable.</p>
        )}
        <button
          className="button"
          disabled={busy || !chosen?.executionAvailable || !source}
        >
          Start maker Run
        </button>
        {error ? <Failure error={error} /> : null}
      </form>
      <section className="panel">
        <h2>Effectiveness cases</h2>
        <button onClick={refresh}>Refresh</button>
        {cases.more && (
          <p>
            Showing the first 100 cases. Older cases are not included in this
            view.
          </p>
        )}
        <ul>
          {cases.items.map((c) => (
            <li key={c.id}>
              <button onClick={() => setSelected(c.id)}>
                {c.status} · {c.reason} · {c.id}
              </button>
            </li>
          ))}
        </ul>
      </section>
      {selected && (
        <CaseView
          key={selected}
          api={api}
          workspaceId={w}
          id={selected}
          queen={queen}
          onChanged={refresh}
        />
      )}
      <section className="panel">
        <h2>Canonical Offering review</h2>
        <p>
          Application creates or changes a draft. Approval is a separate
          authorized decision.
        </p>
        {offerings.map((o) => (
          <article key={o.id}>
            <h3>
              {String(o.definition.name ?? o.id)} · {o.status} · revision{" "}
              {o.revision}
            </h3>
            <Details value={o.definition} />
            {o.status === "draft" && (
              <Action
                label="Approve this exact draft"
                perform={(s) => api.approve(w, o, s)}
                onChanged={refresh}
              />
            )}
          </article>
        ))}
      </section>
    </>
  );
}
function Action({
  label,
  perform,
  onChanged,
}: {
  label: string;
  perform: (s: AbortSignal) => Promise<unknown>;
  onChanged: () => void;
}) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState<unknown>();
  const c = useRef<AbortController | undefined>(undefined);
  useEffect(() => () => c.current?.abort(), []);
  return (
    <>
      <button
        disabled={busy}
        onClick={async () => {
          if (c.current) return;
          const pending = new AbortController();
          c.current = pending;
          setBusy(true);
          setError(undefined);
          try {
            await perform(pending.signal);
            if (!pending.signal.aborted) onChanged();
          } catch (e) {
            if (!pending.signal.aborted) setError(e);
          } finally {
            c.current = undefined;
            if (!pending.signal.aborted) setBusy(false);
          }
        }}
      >
        {busy ? "Working…" : label}
      </button>
      {error ? <Failure error={error} /> : null}
    </>
  );
}
function CaseView({
  api,
  workspaceId: w,
  id,
  queen,
  onChanged,
}: {
  api: PsuGateway;
  workspaceId: string;
  id: string;
  queen: boolean;
  onChanged: () => void;
}) {
  const [revision, setRevision] = useState(0),
    [reason, setReason] = useState("");
  const keys = useRef(new Map<string, string>());
  const load = useCallback(
    async (s: AbortSignal) => {
      void revision;
      const c = await api.readCase(w, id, s);
      const runs = await Promise.all(
        c.case.allocations.map(async (a) => ({
          role: a.role,
          run: await api.run(w, a.runId, s),
          results: await api.results(a.runId, s),
        })),
      );
      return { ...c, runs };
    },
    [api, w, id, revision],
  );
  useEffect(() => {
    const refresh = () => setRevision((v) => v + 1);
    window.addEventListener("focus", refresh);
    return () => window.removeEventListener("focus", refresh);
  }, []);
  const state = useRefreshingResource(load);
  const refresh = () => {
    setRevision((v) => v + 1);
    onChanged();
  };
  if (state.state === "loading") return <Loading />;
  if (state.state === "error") return <Failure error={state.error} />;
  const { case: c, fresh, runs, clarification } = state.data;
  function followup(
    action: "revise" | "re-evaluate" | "hold" | "close",
    s: AbortSignal,
  ) {
    const pin = JSON.stringify({ revision: c.stateRevision, reason, action });
    if (!keys.current.has(pin)) keys.current.set(pin, crypto.randomUUID());
    return api.followup(c, action, reason, keys.current.get(pin)!, s);
  }
  return (
    <section className="panel">
      <h2>
        {c.status.toUpperCase()} — {c.reason}
      </h2>
      <p>
        {fresh
          ? "Sources are current at this read."
          : "Sources have changed. Do not rebase or substitute current versions silently."}
      </p>
      <Details
        value={{
          criteria: c.criteria,
          policy: c.policy,
          candidates: c.candidates,
          evaluations: c.evaluations,
          decisions: c.decisions,
        }}
      />
      {fresh && clarification && (
        <ClarificationReview
          api={api}
          c={c}
          view={clarification}
          onChanged={refresh}
        />
      )}
      <label>
        Reason for follow-up
        <textarea
          required
          maxLength={2000}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
        />
      </label>
      {!c.activeRunId && c.status !== "closed" && reason.trim() && (
        <>
          {fresh && c.candidates.length > 0 && (
            <>
              <Action
                label="Request independent re-evaluation"
                perform={(s) => followup("re-evaluate", s)}
                onChanged={refresh}
              />
              {c.allocations.filter((a) => a.role === "revision").length <
                2 && (
                <Action
                  label="Request separate revision Run"
                  perform={(s) => followup("revise", s)}
                  onChanged={refresh}
                />
              )}
            </>
          )}
          {queen && (
            <>
              <Action
                label="Hold for Queen review"
                perform={(s) => followup("hold", s)}
                onChanged={refresh}
              />
              <Action
                label="Close case"
                perform={(s) => followup("close", s)}
                onChanged={refresh}
              />
            </>
          )}
        </>
      )}
      <p>
        At most two revision Runs. Repeated content or defects may escalate.
        Manual Effectiveness overrides are unavailable.
      </p>
      {runs.map(({ role, run, results }) => (
        <article key={run.id}>
          <h3>
            {role} · {run.status}
          </h3>
          {run.terminalReason && <p>{run.terminalReason}</p>}
          {!["completed", "cancelled", "failed"].includes(run.status) && (
            <Action
              label={`Cancel ${role} Run`}
              perform={(s) => api.cancelRun(run, s)}
              onChanged={refresh}
            />
          )}
          {run.input && (
            <InputForm
              key={run.id + run.updatedAt}
              run={run}
              api={api}
              onChanged={refresh}
            />
          )}{" "}
          {results.map((r) => (
            <ResultView
              key={r.id}
              result={r}
              caseRecord={c}
              fresh={fresh}
              api={api}
              onChanged={refresh}
            />
          ))}
        </article>
      ))}
    </section>
  );
}
function ResultView({
  result: r,
  caseRecord: c,
  fresh,
  api,
  onChanged,
}: {
  result: PsuResult;
  caseRecord: PsuCase;
  fresh: boolean;
  api: PsuGateway;
  onChanged: () => void;
}) {
  return (
    <section>
      <h4>
        Result · {r.outcome} · {r.completeness.kind}
      </h4>
      <Details value={r.completeness} />
      <Details value={r.content} />
      <Details value={r.dispositions} />
      {r.content.proposals.map((p) => (
        <div key={p.id}>
          <strong>{p.id}</strong>
          {c.status === "passed" && fresh && (
            <Action
              label="Apply exact proposal to draft"
              perform={(s) => api.proposal(r, p.id, "apply", s)}
              onChanged={onChanged}
            />
          )}
          <Action
            label="Reject proposal"
            perform={(s) => api.proposal(r, p.id, "reject", s)}
            onChanged={onChanged}
          />
        </div>
      ))}
    </section>
  );
}
function InputForm({
  run,
  api,
  onChanged,
}: {
  run: PsuRun;
  api: PsuGateway;
  onChanged: () => void;
}) {
  const input = run.input!;
  const [values, setValues] = useState<
      Record<string, string | number | boolean>
    >(() =>
      Object.fromEntries(
        input.fields.map((f) => [f.key, f.type === "boolean" ? false : ""]),
      ),
    ),
    [reviewed, setReviewed] = useState(false),
    [ack, setAck] = useState(false);
  const facts = [
    "psu_revision_fact_submission",
    "psu_uncertainty_answer_v2",
    "psu_general_clarification_v1",
  ].includes(input.schemaKey);
  const change = (key: string, value: string | number | boolean) => {
    setValues((old) => {
      const next = { ...old, [key]: value };
      if (facts && (key.endsWith("_statement") || key.endsWith("_status"))) {
        const stem = key.replace(/_(statement|status)$/, "");
        next[stem + "_confirm"] = false;
        next[stem + "_include"] = false;
      }
      return next;
    });
    setReviewed(false);
    setAck(false);
  };
  const fieldsValid = input.fields.every((f) => {
    const v = values[f.key];
    return f.type === "boolean"
      ? typeof v === "boolean"
      : f.type === "choice"
        ? f.options.some((o) => o.value === v)
        : f.type === "number"
          ? typeof v === "number" && v >= f.minimum && v <= f.maximum
          : typeof v === "string" && v.length <= f.maxLength;
  });
  if (facts && !run.factReview)
    return <Failure error={new DataError("invalid")} />;
  const statements =
    run.factReview?.map((row) =>
      String(values[row.key + "_statement"] ?? ""),
    ) ?? [];
  const factsValid =
    !facts ||
    (run.factReview!.every((row) => {
      const statement = String(values[row.key + "_statement"] ?? "");
      const selected = values[row.key + "_include"] === true,
        confirmed = values[row.key + "_confirm"] === true;
      return (
        statement === statement.trim() &&
        ![...statement].some((c) => {
          const n = c.codePointAt(0)!;
          return (
            n <= 31 || (n >= 127 && n <= 159) || (n >= 0xd800 && n <= 0xdfff)
          );
        }) &&
        (statement.length > 0 || (!confirmed && !selected)) &&
        (!selected ||
          (confirmed && values[row.key + "_status"] === "current_claim"))
      );
    }) &&
      new Set(statements.filter(Boolean)).size ===
        statements.filter(Boolean).length);
  const valid = fieldsValid && factsValid;
  const expired = Date.parse(input.expiresAt) <= Date.now();
  return (
    <section className="panel">
      <h4>{input.question}</h4>
      <p>{input.reason}</p>
      <p>Expires {input.expiresAt}</p>
      <fieldset disabled={expired}>
        {input.fields.map((f) => (
          <label key={f.key}>
            {f.label}
            {f.type === "boolean" ? (
              <input
                type="checkbox"
                checked={values[f.key] === true}
                onChange={(e) => change(f.key, e.target.checked)}
              />
            ) : f.type === "choice" ? (
              <select
                value={String(values[f.key])}
                onChange={(e) => change(f.key, e.target.value)}
              >
                <option value="">Select</option>
                {f.options.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            ) : f.type === "number" ? (
              <input
                type="number"
                min={f.minimum}
                max={f.maximum}
                value={String(values[f.key])}
                onChange={(e) =>
                  change(
                    f.key,
                    e.target.value === "" ? "" : Number(e.target.value),
                  )
                }
              />
            ) : (
              <textarea
                required={f.required}
                maxLength={f.maxLength}
                value={String(values[f.key])}
                onChange={(e) => change(f.key, e.target.value)}
              />
            )}
          </label>
        ))}
      </fieldset>
      {facts && (
        <p>
          Only confirmed current claims can be included. Unknown or declined
          statements may remain empty and excluded.
        </p>
      )}
      <button disabled={!valid || expired} onClick={() => setReviewed(true)}>
        Review exact answers
      </button>
      {reviewed && (
        <>
          <Details
            value={input.fields.map((f) => ({
              question: f.label,
              answer: values[f.key],
            }))}
          />
          {run.factReview?.map((row) => {
            const selected = values[row.key + "_include"] === true;
            const after = !selected
              ? row.before
              : row.effect === "append"
                ? [
                    ...(Array.isArray(row.before) ? row.before : []),
                    values[row.key + "_statement"],
                  ]
                : values[row.key + "_statement"];
            return (
              <div key={row.key}>
                <h5>
                  {row.target} — {selected ? row.effect : "unchanged"}
                </h5>
                <Details value={{ before: row.before, after }} />
              </div>
            );
          })}
          <label>
            <input
              type="checkbox"
              checked={ack}
              onChange={(e) => setAck(e.target.checked)}
            />
            I have reviewed these exact answers and proposed changes.
          </label>
          {ack && !expired && (
            <Action
              label="Submit reviewed answers"
              perform={(s) =>
                api.answer(
                  run,
                  input.fields.map((f) => ({
                    key: f.key,
                    value: values[f.key]!,
                  })),
                  s,
                )
              }
              onChanged={onChanged}
            />
          )}
        </>
      )}
    </section>
  );
}

function ClarificationReview({
  api,
  c,
  view,
  onChanged,
}: {
  api: PsuGateway;
  c: PsuCase;
  view: import("../data/psu").PsuClarification;
  onChanged: () => void;
}) {
  const [targets, setTargets] = useState<string[]>([]),
    [support, setSupport] = useState<number[]>([]),
    [confirmed, setConfirmed] = useState(false);
  const keys = useRef(new Map<string, string>());
  const options = [
    {
      key: "what_customer_buys",
      target: "whatCustomerBuys",
      label: "What the customer buys or receives",
    },
    {
      key: "customer_role",
      target: "customerRole",
      label: "Customer responsibilities",
    },
    {
      key: "supplier_role",
      target: "supplierRole",
      label: "Supplier responsibilities",
    },
  ];
  return (
    <section className="panel">
      <h3>Review a general clarification</h3>
      <p>
        This creates a separate bounded maker Run. Review the exact Candidate
        evidence and unresolved criteria. A clarification is not a defect
        revision or approval.
      </p>
      <Details value={view.assessments} />
      {view.support.map((s, i) => (
        <label key={s.evidenceId + ":" + i}>
          <input
            type="checkbox"
            checked={support.includes(i)}
            onChange={(e) => {
              setConfirmed(false);
              setSupport(
                e.target.checked
                  ? [...support, i]
                  : support.filter((x) => x !== i),
              );
            }}
          />
          {s.excerpt}
        </label>
      ))}
      {options.map((o) => (
        <label key={o.key}>
          <input
            type="checkbox"
            checked={targets.includes(o.key)}
            onChange={(e) => {
              setConfirmed(false);
              setTargets(
                e.target.checked
                  ? [...targets, o.key]
                  : targets.filter((x) => x !== o.key),
              );
            }}
          />
          {o.label}
        </label>
      ))}
      <label>
        <input
          type="checkbox"
          checked={confirmed}
          onChange={(e) => setConfirmed(e.target.checked)}
        />
        I reviewed the selected exact evidence: it concerns this
        Product/Service, supports unresolved knowledge in the listed criteria,
        and makes the selected questions applicable.
      </label>
      {confirmed && targets.length > 0 && support.length > 0 && (
        <Action
          label="Request reviewed clarification"
          onChanged={onChanged}
          perform={(s) => {
            const slots = options
              .filter((o) => targets.includes(o.key))
              .map(({ key, target }) => ({
                key,
                target,
                gapId: "gap:product_knowledge",
              }));
            const pin = JSON.stringify({
              view,
              revision: c.stateRevision,
              slots,
              support,
            });
            if (!keys.current.has(pin))
              keys.current.set(pin, crypto.randomUUID());
            return api.clarify(
              c,
              view,
              slots,
              support,
              keys.current.get(pin)!,
              s,
            );
          }}
        />
      )}
      <p>
        Unknown answers remain unresolved. Unsupported questions require Queen
        review.
      </p>
    </section>
  );
}
