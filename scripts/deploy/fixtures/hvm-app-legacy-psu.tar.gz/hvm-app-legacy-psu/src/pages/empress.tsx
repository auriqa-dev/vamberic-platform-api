import { ClientOnboarding } from "./client-onboarding";
import { WorkspaceBilling } from "./workspace-billing";
import {
  AgreementApprovalQueue,
  AgreementApprovalPage,
} from "./agreement-approvals";
import { Link, Route, Routes } from "react-router-dom";
import type { Access } from "../data/model";
import { DataError } from "../data/gateway";
import { Empty, Failure } from "../components/ui";
import { areas } from "../components/operating/fields";
import { Catalogue } from "../components/operating/catalogue";
import { DefinitionPage } from "../components/operating/editor";
export function EmpressRoutes({ access }: { access: Access }) {
  if (!access.platform.empress)
    return <Failure error={new DataError("denied")} />;
  return (
    <Routes>
      <Route
        path="client-onboarding"
        element={<ClientOnboarding access={access} governance />}
      />
      <Route index element={<EmpressHome />} />
      <Route
        path="workspace-billing"
        element={<WorkspaceBilling governance />}
      />
      <Route path="agreement-approvals" element={<AgreementApprovalQueue />} />
      <Route
        path="agreement-approvals/:agreementId"
        element={<AgreementApprovalPage />}
      />
      {areas.flatMap((area) => [
        <Route
          key={area.path}
          path={area.path}
          element={<Catalogue resource={area.resource} />}
        />,
        <Route
          key={area.path + "/new"}
          path={area.path + "/new"}
          element={<DefinitionPage resource={area.resource} creating />}
        />,
        <Route
          key={area.path + "/:id"}
          path={area.path + "/:id"}
          element={<DefinitionPage resource={area.resource} />}
        />,
      ])}
      <Route
        path="*"
        element={
          <Empty title="Section not found">
            Choose Platform overview to return to Empress.
          </Empty>
        }
      />
    </Routes>
  );
}
function EmpressHome() {
  return (
    <>
      <div className="page-heading">
        <p className="eyebrow">Empress · Platform</p>
        <h1>HVM operating foundations.</h1>
        <p>Manage the reusable building blocks that define what HVM can do.</p>
      </div>
      <p>
        <Link to="/empress/client-onboarding">
          Pre-client exemption approvals
        </Link>{" "}
        ·
        <Link to="/empress/workspace-billing">
          Workspace billing exemptions
        </Link>{" "}
        ·<Link to="/empress/agreement-approvals">Agreement Approvals</Link> ·
        Review exceptional commercial arrangements.
      </p>
      <div className="card-grid empress-card-grid">
        {areas.map((area) => (
          <article className="panel" key={area.path}>
            <h2>
              <Link to={`/empress/${area.path}`}>{area.label}</Link>
            </h2>
            <p>{area.description}</p>
          </article>
        ))}
      </div>
      <p>
        Client configuration remains in the Queen perspective, within each
        assigned workspace.
      </p>
    </>
  );
}
