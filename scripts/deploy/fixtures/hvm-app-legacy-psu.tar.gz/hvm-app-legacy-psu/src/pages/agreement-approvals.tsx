import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { useOperating } from "../data/operating/context";
import {
  ApprovalRequest,
  type AgreementApprovalReview,
} from "../data/operating/approvals";
import { useOperatingRecord } from "../data/operating/use-record";
import { DataError } from "../data/gateway";
import { useResource } from "../data/use-resource";
import {
  paginationSchema,
  nextPage,
  previousPage,
} from "../data/operating/pagination";
import { useDraft } from "../forms/use-draft";
import { NavigationWarning } from "../forms/navigation-warning";
import { formatMoney, percentInput } from "../forms/commercial-values";
import { OperatingFailure } from "../components/operating/feedback";
import { Loading, Empty } from "../components/ui";
export function AgreementApprovalQueue() {
  const api = useOperating();
  const [search, setSearch] = useSearchParams();
  const parsed = paginationSchema.safeParse({
    limit: Number(search.get("limit") ?? 20),
    offset: Number(search.get("offset") ?? 0),
  });
  const { limit, offset } = parsed.success
    ? parsed.data
    : { limit: 20, offset: 0 };
  const [revision, setRevision] = useState(0);
  const load = useCallback(
    (signal: AbortSignal) => {
      void revision;
      return api
        ? api.approvalList({ limit, offset }, signal)
        : Promise.reject(new DataError("pending"));
    },
    [api, limit, offset, revision],
  );
  const result = useResource(load);
  return (
    <>
      <h1>Agreement Approvals</h1>
      <p>
        Review exceptional commercial arrangements. This does not grant
        workspace configuration access.
      </p>
      <button
        className="button secondary"
        onClick={() => setRevision((n) => n + 1)}
      >
        Refresh approvals
      </button>
      {result.state === "loading" ? (
        <Loading label="Loading approvals…" />
      ) : result.state === "error" ? (
        <OperatingFailure error={result.error} />
      ) : (
        <>
          {result.data.items.length === 0 ? (
            <Empty title="No Agreements currently require Empress approval">
              There are no pending Agreements on this page.
            </Empty>
          ) : (
            <ul className="catalogue-list">
              {result.data.items.map((row) => (
                <li className="panel" key={row.id}>
                  <h2>
                    <Link to={`/empress/agreement-approvals/${row.id}`}>
                      {row.swarm.name}
                    </Link>
                  </h2>
                  <p>Workspace: {row.workspaceId}</p>
                  <p>
                    {row.id} · {row.decision.treatment} · proposed
                  </p>
                  <p>
                    Recommended:{" "}
                    {formatMoney(
                      row.recommendedPeriodMinor,
                      row.recommendation.currency,
                    )}{" "}
                    · Agreed:{" "}
                    {formatMoney(
                      row.finalRecurringMinor,
                      row.recommendation.currency,
                    )}{" "}
                    / {row.decision.billingFrequency}
                  </p>
                  <p>Requires Empress approval</p>
                </li>
              ))}
            </ul>
          )}
          <nav className="form-actions" aria-label="Approvals pagination">
            <button
              disabled={!previousPage(result.data)}
              onClick={() =>
                setSearch({
                  limit: String(limit),
                  offset: String(previousPage(result.data)!.offset),
                })
              }
            >
              Previous page
            </button>
            <span>Page {Math.floor(offset / limit) + 1}</span>
            <button
              disabled={!nextPage(result.data)}
              onClick={() =>
                setSearch({
                  limit: String(limit),
                  offset: String(nextPage(result.data)!.offset),
                })
              }
            >
              Next page
            </button>
          </nav>
        </>
      )}
    </>
  );
}
export function AgreementApprovalPage() {
  const { agreementId = "" } = useParams();
  return <ApprovalResource key={agreementId} id={agreementId} />;
}
function ApprovalResource({ id }: { id: string }) {
  const api = useOperating();
  const load = useCallback(
    (signal: AbortSignal) =>
      api
        ? api.approvalDetail(id, signal)
        : Promise.reject(new DataError("pending")),
    [api, id],
  );
  const resource = useOperatingRecord(load);
  const [receipt, setReceipt] = useState<{ reason: string; at: string }>();
  if (receipt)
    return (
      <>
        <h1>Agreement approved</h1>
        <p role="status">
          Empress approval was recorded successfully. Commercial approval does
          not mean payment received or Swarm executing.
        </p>
        <p>
          {receipt.reason} · {receipt.at}
        </p>
        <Link to="/empress/agreement-approvals">
          Return to pending approvals
        </Link>
      </>
    );
  if (!resource.data)
    return resource.error ? (
      <OperatingFailure
        error={resource.error}
        retry={() => void resource.refresh()}
      />
    ) : (
      <Loading label="Loading approval review…" />
    );
  return (
    <ApprovalEditor
      approved={setReceipt}
      row={resource.data}
      refresh={resource.refresh}
      deny={resource.deny}
      readError={resource.error}
    />
  );
}
function ApprovalEditor({
  row,
  refresh,
  deny,
  readError,
  approved,
}: {
  row: AgreementApprovalReview;
  refresh: () => Promise<void>;
  deny: () => void;
  readError: unknown;
  approved: (receipt: { reason: string; at: string }) => void;
}) {
  const api = useOperating()!;
  const draft = useDraft({ expectedUpdatedAt: row.updatedAt, reason: "" });
  const [error, setError] = useState<unknown>();
  const [review, setReview] = useState(false);
  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState(false);
  const controller = useRef<AbortController | undefined>(undefined);
  useEffect(() => () => controller.current?.abort(), []);
  async function approve() {
    const parsed = ApprovalRequest.safeParse(draft.draft);
    if (!parsed.success) {
      setError(new DataError("invalid"));
      return;
    }
    setBusy(true);
    setError(undefined);
    const c = new AbortController();
    controller.current = c;
    try {
      const saved = await api.approveAgreement(row.id, parsed.data, c.signal);
      if (c.signal.aborted) return;
      if (saved.workspaceId !== row.workspaceId) throw new DataError("invalid");
      draft.saved({ expectedUpdatedAt: saved.updatedAt, reason: "" });
      setSuccess(true);
      setReview(false);
      // Successful detail is deliberately no longer readable. Refetch the pending queue.
      try {
        await api.approvalList({ limit: 20, offset: 0 }, c.signal);
      } finally {
        if (!c.signal.aborted) approved(saved.empressApproval);
      }
    } catch (e) {
      if (c.signal.aborted) return;
      if (e instanceof DataError && e.code === "denied") {
        deny();
        return;
      }
      setError(e);
      if (e instanceof DataError && e.code === "conflict") {
        draft.markConflict();
        void refresh();
      }
    } finally {
      if (!c.signal.aborted) setBusy(false);
    }
  }
  if (success)
    return (
      <>
        <h1>Agreement approved</h1>
        <p role="status">
          Empress approval was recorded successfully. Commercial approval does
          not mean payment received or Swarm executing.
        </p>
        {error && <OperatingFailure error={error} />}
        <Link to="/empress/agreement-approvals">
          Return to pending approvals
        </Link>
      </>
    );
  const money = (n: number) => formatMoney(n, row.recommendation.currency);
  return (
    <>
      <Link to="/empress/agreement-approvals">← Agreement Approvals</Link>
      <h1>Review {row.swarm.name}</h1>
      <p>Workspace: {row.workspaceId}</p>
      <p>
        {row.swarm.id} · configuration revision {row.swarm.revision}
      </p>
      <section className="panel">
        <h2>Recommendation</h2>
        <p>{row.recommendation.id}</p>
        <dl>
          {Object.entries({
            "Expected monthly operating cost":
              row.recommendation.expectedOperatingMonthlyMinor,
            "Recommended onboarding":
              row.recommendation.recommendedOnboardingMinor,
            "Recommended monthly": row.recommendation.recommendedMonthlyMinor,
            "Recommended annual": row.recommendation.recommendedAnnualMinor,
          }).map(([k, v]) => (
            <div key={k}>
              <dt>{k}</dt>
              <dd>{money(v)}</dd>
            </div>
          ))}
        </dl>
        <p>
          Recommended margin:{" "}
          {row.recommendation.monthlyMargin === null
            ? "Undefined"
            : `${row.recommendation.monthlyMargin * 100}%`}
        </p>
      </section>
      <section className="panel">
        <h2>Queen decision</h2>
        <p>Treatment: {row.decision.treatment}</p>
        <p>
          Adjustment: {row.decision.adjustment.kind.replaceAll("_", " ")}{" "}
          {row.decision.adjustment.percentage !== undefined
            ? `${percentInput(row.decision.adjustment.percentage)}%`
            : ""}
          {row.decision.adjustment.amountMinor !== undefined
            ? money(row.decision.adjustment.amountMinor)
            : ""}
        </p>
        <p>Reason: {row.decision.reason}</p>
        <p>Final onboarding: {money(row.decision.onboardingMinor)}</p>
        <p>
          Final recurring: {money(row.finalRecurringMinor)} /{" "}
          {row.decision.billingFrequency}
        </p>
        <p>Monthly equivalent: {money(row.finalMonthlyEquivalentMinor)}</p>
        <p>
          Commitment: {row.decision.commitment.kind} ·{" "}
          {row.decision.commitment.months} months · renewal{" "}
          {row.decision.commitment.renewal}
        </p>
        <p>
          Effective {row.decision.effectiveFrom} to{" "}
          {row.decision.effectiveUntil ?? "open-ended"}
        </p>
      </section>
      <section className="panel">
        <h2>Requires Empress approval</h2>
        <p>
          Policy {row.policy.id} · v{row.policy.version}
        </p>
        <ul>
          {row.policy.reasons.map((reason) => (
            <li key={reason}>{reason.replaceAll("_", " ")}</li>
          ))}
        </ul>
        <p>
          Minimum margin {percentInput(row.policy.limits.minimumMargin)}% ·
          Queen discount limit{" "}
          {percentInput(row.policy.limits.maximumQueenDiscount)}% · fixed
          discount limit{" "}
          {money(row.policy.limits.maximumQueenFixedDiscountMinor)}
        </p>
        <p>
          Minimum monthly price{" "}
          {money(row.policy.limits.minimumMonthlyPriceMinor)} · Custom price{" "}
          {row.policy.limits.allowCustomPrice ? "permitted" : "not permitted"} ·
          Treatments {row.policy.limits.permittedQueenTreatments.join(", ")}
        </p>
      </section>
      <NavigationWarning dirty={draft.dirty} />
      {(error || readError) && <OperatingFailure error={error ?? readError} />}
      {draft.conflict && (
        <p role="alert">
          Server state changed. Your reason is preserved. Discard to adopt the
          latest review before approving.
        </p>
      )}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (ApprovalRequest.safeParse(draft.draft).success) setReview(true);
          else setError(new DataError("invalid"));
        }}
      >
        <label>
          Approval reason
          <textarea
            required
            minLength={1}
            maxLength={2000}
            value={draft.draft.reason}
            onChange={(e) => {
              draft.edit({ ...draft.draft, reason: e.target.value });
              setReview(false);
            }}
          />
        </label>
        <div className="form-actions">
          <button className="button" disabled={busy || draft.conflict}>
            Review approval
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={() => {
              draft.reset();
              setReview(false);
              setError(undefined);
            }}
          >
            Discard reason
          </button>
          <button type="button" disabled={busy} onClick={() => void refresh()}>
            Refresh review
          </button>
        </div>
      </form>
      {review && (
        <section className="notice" aria-label="Confirm approval">
          <h2>Approve this exceptional Agreement?</h2>
          <p>{draft.draft.reason}</p>
          <p>This records commercial approval only.</p>
          <button
            className="button"
            disabled={busy || draft.conflict}
            onClick={() => void approve()}
          >
            Confirm Empress approval
          </button>
          <button disabled={busy} onClick={() => setReview(false)}>
            Cancel
          </button>
        </section>
      )}
    </>
  );
}
