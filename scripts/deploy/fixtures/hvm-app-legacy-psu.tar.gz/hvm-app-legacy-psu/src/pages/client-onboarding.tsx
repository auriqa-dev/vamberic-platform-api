import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useOperating } from "../data/operating/context";
import { DataError } from "../data/gateway";
import { Failure } from "../components/ui";
import type { Access } from "../data/model";
import {
  onboardingDetails,
  type OnboardingRecord,
  type OnboardingMutation,
} from "../data/client-onboarding";
export function ClientOnboarding({
  access,
  governance = false,
}: {
  access: Access;
  governance?: boolean;
}) {
  const owners = access.queen?.partners.filter((p) => p.role === "owner") ?? [];
  const [partner, setPartner] = useState(owners[0]?.id ?? "");
  if (
    (governance && !access.platform.empress) ||
    (!governance && !owners.some((p) => p.id === partner))
  )
    return <Failure error={new DataError("denied")} />;
  return (
    <section className="panel">
      <h1>
        {governance ? "Pre-client exemption approvals" : "Client onboarding"}
      </h1>
      {!governance && (
        <label>
          Partner
          <select value={partner} onChange={(e) => setPartner(e.target.value)}>
            {owners.map((p) => (
              <option key={p.id} value={p.id}>
                {p.displayName}
              </option>
            ))}
          </select>
        </label>
      )}
      <OnboardingFlow
        key={governance ? "empress" : partner}
        partner={governance ? undefined : partner}
      />
    </section>
  );
}
function OnboardingFlow({ partner }: { partner?: string }) {
  const gateway = useOperating()?.onboarding;
  const [items, setItems] = useState<OnboardingRecord[]>([]),
    [next, setNext] = useState<string | null>(null);
  const [needsRefresh, setNeedsRefresh] = useState(false);
  const [selected, setSelected] = useState<OnboardingRecord>();
  const [error, setError] = useState<unknown>(),
    [busy, setBusy] = useState(false),
    [reason, setReason] = useState("");
  const [values, setValues] = useState({
    organisationName: "",
    websiteUrl: "",
    workspaceName: "",
    brandName: "",
    brandSlug: "",
    currentMarketingPlatform: "",
    currentContactCount: "",
    contactCountDescription: "",
    growthExpectation: "",
    otherTools: "",
  });
  const [pending, setPending] = useState<{
    id?: string;
    body: OnboardingMutation;
  }>();
  const controller = useRef<AbortController | undefined>(undefined);
  useEffect(() => {
    const c = new AbortController();
    controller.current = c;
    if (gateway)
      gateway
        .list(partner, c.signal)
        .then((r) => {
          if (!c.signal.aborted) {
            setItems(r.items);
            setNext(r.next);
          }
        })
        .catch((e) => {
          if (!c.signal.aborted) setError(e);
        });
    return () => c.abort();
  }, [gateway, partner]);
  if (!gateway) return <Failure error={new DataError("pending")} />;
  async function send(request: { id?: string; body: OnboardingMutation }) {
    if (busy || !gateway) return;
    setBusy(true);
    setError(undefined);
    setPending(request);
    try {
      const r = await gateway.mutate(
        partner,
        request.id,
        request.body,
        controller.current!.signal,
      );
      if (controller.current?.signal.aborted) return;
      setSelected(r);
      setItems((old) => [r, ...old.filter((i) => i.id !== r.id)]);
      setPending(undefined);
    } catch (e) {
      if (!controller.current?.signal.aborted) {
        setError(e);
        // A definitive conflict did not apply this request. Require a fresh read
        // before another decision; transport/unknown outcomes keep exact retry.
        if (e instanceof DataError && e.code === "conflict") {
          setPending(undefined);
          setSelected(undefined);
          setItems([]);
          setNeedsRefresh(true);
        }
      }
    } finally {
      if (!controller.current?.signal.aborted) setBusy(false);
    }
  }
  function choose(row?: OnboardingRecord) {
    setSelected(row);
    setReason("");
    setError(undefined);
    setValues(
      row
        ? {
            ...row.details,
            organisationName: row.details.intake.organisationName,
            websiteUrl: row.details.intake.websiteUrl,
            currentMarketingPlatform:
              row.details.intake.currentMarketingPlatform ?? "",
            currentContactCount: String(
              row.details.intake.currentContactCount ?? "",
            ),
            contactCountDescription:
              row.details.intake.contactCountDescription ?? "",
            growthExpectation: row.details.intake.growthExpectation ?? "",
            otherTools: row.details.intake.otherTools.join("\n"),
          }
        : {
            organisationName: "",
            websiteUrl: "",
            workspaceName: "",
            brandName: "",
            brandSlug: "",
            currentMarketingPlatform: "",
            currentContactCount: "",
            contactCountDescription: "",
            growthExpectation: "",
            otherTools: "",
          },
    );
  }
  function mutate(action: OnboardingMutation["action"]) {
    try {
      const body: OnboardingMutation = {
        action,
        requestKey: crypto.randomUUID(),
        expectedRevision: selected?.revision ?? 0,
      };
      if (action === "save")
        body.details = onboardingDetails.parse({
          workspaceName: values.workspaceName,
          brandName: values.brandName,
          brandSlug: values.brandSlug,
          intake: {
            organisationName: values.organisationName,
            websiteUrl: values.websiteUrl,
            otherTools: values.otherTools
              .split("\n")
              .map((v) => v.trim())
              .filter(Boolean),
            ...Object.fromEntries(
              [
                "currentMarketingPlatform",
                "contactCountDescription",
                "growthExpectation",
              ]
                .filter((k) => values[k as keyof typeof values])
                .map((k) => [k, values[k as keyof typeof values]]),
            ),
            ...(values.currentContactCount
              ? { currentContactCount: Number(values.currentContactCount) }
              : {}),
          },
        });
      if (action === "approve" || action === "revoke") body.reason = reason;
      void send({ id: selected?.id, body });
    } catch {
      setError(new DataError("invalid"));
    }
  }
  const frozen = busy || !!pending || needsRefresh;
  return (
    <>
      <button
        disabled={busy || !!pending}
        onClick={async () => {
          try {
            const r = await gateway.list(partner, controller.current!.signal);
            if (!controller.current?.signal.aborted) {
              setItems(r.items);
              setNext(r.next);
              setSelected(undefined);
              setNeedsRefresh(false);
            }
          } catch (e) {
            if (!controller.current?.signal.aborted) setError(e);
          }
        }}
      >
        Refresh requests
      </button>
      <p>
        HVM Platform and Agent services: zero customer charge only after Empress
        approval. External services are excluded. Paid subscriptions are not
        available here. Marketing remains off.
      </p>
      <fieldset disabled={frozen}>
        <legend>Onboarding requests</legend>
        {partner && <button onClick={() => choose()}>New client intake</button>}
        {items.map((r) => (
          <button key={r.id} onClick={() => choose(r)}>
            {r.details.intake.organisationName} ·{" "}
            {r.result
              ? "Provisioned"
              : (r.approval?.status ?? "Awaiting approval")}
          </button>
        ))}
        {next && (
          <button
            onClick={async () => {
              try {
                const r = await gateway.list(
                  partner,
                  controller.current!.signal,
                  next,
                );
                if (!controller.current?.signal.aborted) {
                  setItems((old) => [...old, ...r.items]);
                  setNext(r.next);
                }
              } catch (e) {
                if (!controller.current?.signal.aborted) setError(e);
              }
            }}
          >
            More requests
          </button>
        )}
      </fieldset>
      {partner && !selected?.result && (
        <fieldset disabled={frozen}>
          <legend>Client declarations</legend>
          {Object.keys(values).map((key) => (
            <label key={key}>
              {
                {
                  organisationName: "Organisation name",
                  websiteUrl: "Website URL",
                  workspaceName: "Workspace name",
                  brandName: "Brand name",
                  brandSlug: "Brand URL name",
                  currentMarketingPlatform:
                    "Current marketing platform (optional)",
                  currentContactCount: "Current contact count (optional)",
                  contactCountDescription:
                    "Contact count description (optional)",
                  growthExpectation: "Growth expectation (optional)",
                  otherTools: "Other tools (one per line, optional)",
                }[key]
              }
              <textarea
                value={values[key as keyof typeof values]}
                onChange={(e) =>
                  setValues({ ...values, [key]: e.target.value })
                }
              />
            </label>
          ))}
          <button onClick={() => mutate("save")}>
            {selected
              ? "Save revised intake — new approval required"
              : "Request exempt onboarding"}
          </button>
        </fieldset>
      )}
      {selected && (
        <article>
          <h2>{selected.details.intake.organisationName}</h2>
          <p>
            Revision {selected.revision}; proposal{" "}
            {selected.binding.quoteRevision}. Website declaration:{" "}
            {selected.details.intake.websiteUrl}
          </p>
          <dl>
            {Object.entries(selected.details.intake).map(([key, value]) => (
              <div key={key}>
                <dt>{key}</dt>
                <dd>
                  {Array.isArray(value) ? value.join(", ") : String(value)}
                </dd>
              </div>
            ))}
          </dl>
          <p>
            Workspace: {selected.details.workspaceName}; Brand:{" "}
            {selected.details.brandName}; URL name: {selected.details.brandSlug}
          </p>
          {selected.approval && (
            <p>
              Approval {selected.approval.status}; valid until{" "}
              {selected.approval.validUntil}. {selected.approval.reason}
            </p>
          )}
          {selected.result ? (
            <>
              <p>
                Provisioned. Workspace exemption continues until Empress revokes
                it. Workspace: {selected.result.workspaceId}
              </p>
              {partner ? (
                <Link to={`/queen/clients/${selected.result.workspaceId}`}>
                  Open client workspace
                </Link>
              ) : (
                <Link to="/empress/workspace-billing">
                  Manage workspace exemption
                </Link>
              )}
            </>
          ) : partner ? (
            <button
              disabled={
                frozen ||
                selected.approval?.status !== "active" ||
                Date.parse(selected.approval.validUntil) <= Date.now()
              }
              onClick={() => mutate("provision")}
            >
              Provision approved client
            </button>
          ) : (
            <fieldset disabled={frozen}>
              <legend>Empress decision</legend>
              <label>
                Reason
                <textarea
                  value={reason}
                  maxLength={1000}
                  onChange={(e) => setReason(e.target.value)}
                />
              </label>
              <button
                disabled={!reason.trim()}
                onClick={() => mutate("approve")}
              >
                Approve exemption for seven days
              </button>
              <button
                disabled={
                  !reason.trim() || selected.approval?.status !== "active"
                }
                onClick={() => mutate("revoke")}
              >
                Revoke approval
              </button>
            </fieldset>
          )}
        </article>
      )}
      {error ? <Failure error={error} /> : null}
      {pending && (
        <>
          <p>
            Outcome is unresolved. Retry the exact request before changing
            details.
          </p>
          <button disabled={busy} onClick={() => void send(pending)}>
            Retry exact request
          </button>
        </>
      )}
    </>
  );
}
