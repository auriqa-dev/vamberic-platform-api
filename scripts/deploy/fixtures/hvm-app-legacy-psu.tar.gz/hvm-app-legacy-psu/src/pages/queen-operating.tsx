import { useCallback, useState } from "react";
import { Link, Route, Routes, useParams } from "react-router-dom";
import { useOperating } from "../data/operating/context";
import { useResource } from "../data/use-resource";
import { useOperatingRecord } from "../data/operating/use-record";
import { DataError } from "../data/gateway";
import { workspaceFor, type Access } from "../data/model";
import {
  ClientSwarmData,
  type ClientSwarm,
  type SwarmTemplate,
} from "../data/operating/models";
import { Loading, Failure } from "../components/ui";
import { OperatingFailure } from "../components/operating/feedback";
import {
  DraftForm,
  field,
  Lifecycle,
  EditorBoundary,
} from "../components/queen/shared";
import { CatalogueSelect, AgentInstances } from "../components/queen/selectors";
import { QueenAgentPage } from "../components/queen/agent";
import { QueenCommercial } from "../components/queen/commercial";
export function QueenOperating({ access }: { access: Access }) {
  const { workspaceId = "" } = useParams();
  const api = useOperating();
  const workspace = workspaceFor(access, "queen", workspaceId);
  if (!workspace) return <Failure error={new DataError("denied")} />;
  if (!api) return <OperatingFailure error={new DataError("pending")} />;
  const root = `/queen/clients/${workspaceId}/swarm`;
  return (
    <EditorBoundary key={workspaceId}>
      <div>
        <Link to={`/queen/clients/${workspaceId}`}>← Client workspace</Link>
        <p className="eyebrow">
          Queen · {workspace.organisationName} · {workspace.name}
        </p>
        <Routes>
          <Route
            index
            element={<SwarmList workspaceId={workspaceId} root={root} />}
          />
          <Route
            path="new"
            element={<SwarmCreate workspaceId={workspaceId} root={root} />}
          />
          <Route
            path=":swarmId/*"
            element={<SwarmResource workspaceId={workspaceId} root={root} />}
          />
        </Routes>
      </div>
    </EditorBoundary>
  );
}
function SwarmList({
  workspaceId,
  root,
}: {
  workspaceId: string;
  root: string;
}) {
  const api = useOperating();
  const [offset, setOffset] = useState(0),
    [revision, setRevision] = useState(0);
  const load = useCallback(
    (signal: AbortSignal) => {
      void revision;
      return api
        ? api.list(
            { resource: "client_swarms", workspaceId },
            { limit: 20, offset },
            signal,
          )
        : Promise.reject(new DataError("pending"));
    },
    [api, workspaceId, offset, revision],
  );
  const result = useResource(load);
  return (
    <>
      <h1>Client Swarms</h1>
      <p>
        A Swarm combines specialist Agents toward a client outcome.
        Configuration and commercial approval are separate from future
        execution.
      </p>
      <Link className="button" to={`${root}/new`}>
        Create Swarm
      </Link>
      <button onClick={() => setRevision((n) => n + 1)}>Refresh Swarms</button>
      {result.state === "loading" ? (
        <Loading label="Loading Client Swarms…" />
      ) : result.state === "error" ? (
        <OperatingFailure error={result.error} />
      ) : (
        <>
          {result.data.items.length === 0 ? (
            <p role="status">
              No Client Swarms on this page. Create a custom Swarm or start from
              an available template.
            </p>
          ) : (
            <ul className="catalogue-list">
              {result.data.items.map((row) => (
                <li className="panel" key={row.id}>
                  <h2>
                    <Link to={`${root}/${row.id}`}>{row.data.name}</Link>
                  </h2>
                  <p>{row.data.job}</p>
                  <p>
                    {row.status} · configuration revision {row.revision}
                  </p>
                  {row.data.template && (
                    <p>
                      Template {row.data.template.id} · v
                      {row.data.template.version}
                    </p>
                  )}
                </li>
              ))}
            </ul>
          )}
          <nav aria-label="Swarm pagination">
            <button
              disabled={!offset}
              onClick={() => setOffset((n) => Math.max(0, n - 20))}
            >
              Previous page
            </button>
            <span>Page {offset / 20 + 1}</span>
            <button
              disabled={!result.data.hasMore || offset >= 10000}
              onClick={() => setOffset((n) => n + 20)}
            >
              Next page
            </button>
          </nav>
        </>
      )}
    </>
  );
}
const swarmFields = [
  field("name", "Swarm name", { maxLength: 200 }),
  field("description", "Description", { kind: "textarea" }),
  field("job", "Job / intended outcome", { kind: "textarea" }),
  field("commercialNotes", "Commercial notes", { kind: "strings", max: 40 }),
];
const emptySwarm = {
  name: "",
  description: "",
  job: "",
  agentInstanceIds: [],
  configuration: [],
  commercialNotes: [],
};
function TemplateReview({
  row,
  workspaceId,
}: {
  row: SwarmTemplate;
  workspaceId: string;
}) {
  const api = useOperating()!;
  const load = useCallback(
    (signal: AbortSignal) =>
      api.catalogue(workspaceId, "agent_definitions", signal),
    [api, workspaceId],
  );
  const agents = useResource(load);
  return (
    <section className="panel">
      <h3>
        {row.data.name} · v{row.version}
      </h3>
      <p>{row.data.job}</p>
      <p>A starting configuration; Agent selections are reviewed separately.</p>
      {(["requiredAgents", "recommendedAgents", "optionalAgents"] as const).map(
        (k) => (
          <div key={k}>
            <h4>{k.replace("Agents", " Agents")}</h4>
            <ul>
              {row.data[k].map((ref) => (
                <li key={ref.id}>
                  {agents.state === "ready"
                    ? (agents.data.items.find(
                        (a) => a.id === ref.id && a.version === ref.version,
                      )?.data.name ?? ref.id)
                    : ref.id}{" "}
                  · v{ref.version}
                </li>
              ))}
            </ul>
          </div>
        ),
      )}
      <p>
        Integration capabilities:{" "}
        {row.data.integrationCapabilities.join(", ") || "None declared"}
      </p>
      {row.data.configurationGuidance.map((t) => (
        <p key={t}>{t}</p>
      ))}
      {row.data.commercialAssumptions.map((t) => (
        <p key={t}>{t}</p>
      ))}
    </section>
  );
}
function SwarmCreate({
  workspaceId,
  root,
}: {
  workspaceId: string;
  root: string;
}) {
  const api = useOperating()!;
  const [template, setTemplate] = useState<SwarmTemplate>();
  return (
    <>
      <Link to={root}>← Client Swarms</Link>
      <h1>Create Client Swarm</h1>
      <DraftForm
        initial={emptySwarm}
        schema={ClientSwarmData}
        fields={swarmFields}
        label="Create Swarm"
        save={async (data, signal) => {
          const row = await api.workspaceCreate(
            workspaceId,
            "client_swarms",
            data,
            signal,
          );
          return `${root}/${row.id}`;
        }}
      >
        {(value, change) => (
          <>
            <CatalogueSelect
              workspaceId={workspaceId}
              resource="swarm_templates"
              label="Swarm Templates"
              selected={
                value.template as { id: string; version: number } | undefined
              }
              choose={(row) => {
                setTemplate(row);
                change({
                  ...value,
                  template: { id: row.id, version: row.version },
                  name: row.data.name,
                  description: row.data.description,
                  job: row.data.job,
                });
              }}
            />
            {template && value.template && (
              <>
                <TemplateReview row={template} workspaceId={workspaceId} />
                <button
                  type="button"
                  onClick={() => {
                    setTemplate(undefined);
                    const next = { ...value };
                    delete next.template;
                    change(next);
                  }}
                >
                  Use custom Swarm
                </button>
              </>
            )}
            <AgentInstances
              workspaceId={workspaceId}
              selected={value.agentInstanceIds as string[]}
              change={(ids) => change({ ...value, agentInstanceIds: ids })}
            />
          </>
        )}
      </DraftForm>
    </>
  );
}
function SwarmResource({
  workspaceId,
  root,
}: {
  workspaceId: string;
  root: string;
}) {
  const { swarmId = "" } = useParams();
  return (
    <SwarmLoaded
      key={swarmId}
      workspaceId={workspaceId}
      root={root}
      id={swarmId}
    />
  );
}
function SwarmLoaded({
  workspaceId,
  root,
  id,
}: {
  workspaceId: string;
  root: string;
  id: string;
}) {
  const api = useOperating();
  const load = useCallback(
    (signal: AbortSignal) =>
      api
        ? api.detail({ resource: "client_swarms", workspaceId }, id, signal)
        : Promise.reject(new DataError("pending")),
    [api, workspaceId, id],
  );
  const resource = useOperatingRecord(load);
  if (!resource.data)
    return resource.error ? (
      <OperatingFailure error={resource.error} />
    ) : (
      <Loading label="Loading Client Swarm…" />
    );
  const row = resource.data,
    base = `${root}/${id}`;
  return (
    <>
      <Link to={root}>← Client Swarms</Link>
      <h1>{row.data.name}</h1>
      {row.data.template && (
        <p>
          Source template: {row.data.template.id} · v{row.data.template.version}
        </p>
      )}
      <p>
        {row.data.job} · {row.status} · revision {row.revision}
      </p>
      <nav className="tabs">
        <Link to={base}>Configuration</Link>
        <Link to={`${base}/agents/new`}>Add Client Agent</Link>
        <Link to={`${base}/commercial`}>Commercial & Agreements</Link>
      </nav>
      <Routes>
        <Route
          index
          element={
            <SwarmConfiguration
              row={row}
              refresh={resource.refresh}
              root={root}
              accept={resource.accept}
            />
          }
        />
        <Route
          path="agents/:agentId"
          element={
            <QueenAgentPage
              workspaceId={workspaceId}
              swarm={row}
              base={base}
              refreshSwarm={resource.refresh}
            />
          }
        />
        <Route
          path="commercial/*"
          element={
            <QueenCommercial
              workspaceId={workspaceId}
              swarm={row}
              base={`${base}/commercial`}
            />
          }
        />
      </Routes>
    </>
  );
}
function SwarmConfiguration({
  row,
  refresh,
  root,
  accept,
}: {
  row: ClientSwarm;
  refresh: () => Promise<void>;
  root: string;
  accept: (row: ClientSwarm) => void;
}) {
  const api = useOperating()!;
  const [tick, setTick] = useState(0);
  const load = useCallback(
    (signal: AbortSignal) => {
      void tick;
      void row.updatedAt;
      return api.readiness(row.workspaceId, row.id, signal);
    },
    [api, row.workspaceId, row.id, row.updatedAt, tick],
  );
  const readiness = useResource(load);
  return (
    <>
      {!row.archived && (
        <DraftForm
          initial={{ ...row.data, expectedUpdatedAt: row.updatedAt }}
          schema={ClientSwarmData.extend({
            expectedUpdatedAt: ClientSwarmData.shape.name,
          })}
          fields={swarmFields}
          save={async (value, signal) => {
            const { expectedUpdatedAt, ...data } = value;
            accept(
              await api.workspaceUpdate(
                row.workspaceId,
                "client_swarms",
                { id: row.id, expectedUpdatedAt, data },
                signal,
              ),
            );
            setTick((n) => n + 1);
          }}
        >
          {(value, change) => (
            <AgentInstances
              workspaceId={row.workspaceId}
              selected={value.agentInstanceIds as string[]}
              change={(ids) => change({ ...value, agentInstanceIds: ids })}
            />
          )}
        </DraftForm>
      )}
      <button onClick={() => void refresh()}>Refresh configuration</button>
      <h2>Configured Agents</h2>
      <SelectedAgents row={row} root={root} />
      <h2>Server configuration readiness</h2>
      {readiness.state === "loading" ? (
        <Loading label="Checking readiness…" />
      ) : readiness.state === "error" ? (
        <OperatingFailure error={readiness.error} />
      ) : (
        <>
          <p role="status">{readiness.data.ready ? "Ready" : "Not ready"}</p>
          <ul>
            {readiness.data.issues.map((issue) => (
              <li key={issue}>
                <ReadinessIssue issue={issue} root={`${root}/${row.id}`} />{" "}
              </li>
            ))}
          </ul>
        </>
      )}
      <p>Payment and execution are separate future concerns.</p>
      {!row.archived && (
        <Lifecycle
          actions={[...(row.status === "draft" ? ["configure"] : []), "retire"]}
          run={async (action, signal) => {
            accept(
              await api.workspaceLifecycle(
                row.workspaceId,
                "client_swarms",
                action as "configure" | "retire",
                { id: row.id, expectedUpdatedAt: row.updatedAt },
                signal,
              ),
            );
            setTick((n) => n + 1);
          }}
        />
      )}
    </>
  );
}

function ReadinessIssue({ issue, root }: { issue: string; root: string }) {
  const bits = issue.split(":");
  const agent = bits.find((x) => x.startsWith("clientagent_"));
  const code = bits[0]?.startsWith("clientagent_") ? bits[1] : bits[0];
  const labels: Record<string, string> = {
    no_agents: "No Agents selected",
    missing_agent: "Selected Agent is unavailable",
    template_unavailable: "Template is unavailable",
    required_agent: "Required template Agent is missing",
    agent_not_configured: "Agent is not configured",
    definition_unavailable: "Agent definition is unavailable",
    unknown_configuration: "Unknown configuration field",
    invalid_configuration: "Invalid configuration value",
    missing_configuration: "Required configuration is missing",
    dependency_missing: "Dependency is not selected in this Swarm",
    required_dependency: "Required dependency is not configured",
    required_capability: "Required capability is unavailable",
    duplicate_binding: "Duplicate account binding",
    incompatible_provider: "Provider does not support this requirement",
    provider_unavailable: "Provider is unavailable",
    connection_not_ready: "Account connection is not ready",
    integration_required: "Required integration needs a binding",
    template_integration: "Template integration requirement is unmet",
    dependency_cycle: "Dependencies contain a cycle",
  };
  return (
    <>
      <span>
        {labels[code ?? ""] ?? "Configuration issue"}:{" "}
        {bits.filter((b) => b !== code).join(" · ")}
      </span>{" "}
      <Link to={agent ? `${root}/agents/${agent}` : `${root}/agents/new`}>
        {agent ? "Review Client Agent" : "Review Agent requirements"}
      </Link>
    </>
  );
}

function SelectedAgents({ row, root }: { row: ClientSwarm; root: string }) {
  const api = useOperating()!;
  const ids = JSON.stringify(row.data.agentInstanceIds);
  const load = useCallback(
    (signal: AbortSignal) =>
      Promise.allSettled(
        (JSON.parse(ids) as string[]).map((id) =>
          api.detail(
            { workspaceId: row.workspaceId, resource: "client_agents" },
            id,
            signal,
          ),
        ),
      ),
    [api, ids, row.workspaceId],
  );
  const result = useResource(load);
  return result.state === "loading" ? (
    <Loading label="Loading selected Agents…" />
  ) : result.state === "error" ? (
    <OperatingFailure error={result.error} />
  ) : (
    <ul>
      {result.data.map((r, i) => (
        <li key={row.data.agentInstanceIds[i]}>
          <Link to={`${root}/${row.id}/agents/${row.data.agentInstanceIds[i]}`}>
            {r.status === "fulfilled"
              ? r.value.data.name
              : row.data.agentInstanceIds[i]}
          </Link>{" "}
          ·{" "}
          {r.status === "fulfilled"
            ? `${r.value.status} · revision ${r.value.revision} · definition v${r.value.data.definition.version}`
            : "Details unavailable"}
        </li>
      ))}
    </ul>
  );
}
