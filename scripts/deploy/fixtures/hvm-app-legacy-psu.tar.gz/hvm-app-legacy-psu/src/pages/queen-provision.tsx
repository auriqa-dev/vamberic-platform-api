import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { Access } from "../data/model";
import { DataError, type HvmGateway } from "../data/gateway";
import { provisionInput } from "../data/provisioning";
import { Failure } from "../components/ui";
export function QueenProvision({
  access,
  gateway,
}: {
  access: Access;
  gateway: HvmGateway;
}) {
  const owners = access.queen?.partners.filter((p) => p.role === "owner") ?? [];
  const [partnerId, setPartner] = useState(owners[0]?.id ?? "");
  const [values, setValues] = useState({
    organisationName: "",
    workspaceName: "",
    brandName: "",
    brandSlug: "",
  });
  const [requestKey] = useState(() => crypto.randomUUID());
  const [submitted, setSubmitted] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>();
  const pending = useRef<AbortController | undefined>(undefined);
  const navigate = useNavigate();
  useEffect(() => () => pending.current?.abort(), []);
  if (!owners.some((p) => p.id === partnerId))
    return <Failure error={new DataError("denied")} />;
  return (
    <section className="panel">
      <h1>Create client workspace</h1>
      <p>
        Create a new client under your existing Partner. Client membership,
        commercial approval and marketing activation remain separate.
      </p>
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          if (busy) return;
          setError(undefined);
          try {
            const body = provisionInput.parse({ ...values, requestKey });
            if (!gateway.provisionClient) throw new DataError("pending");
            setSubmitted(true);
            setBusy(true);
            const c = new AbortController();
            pending.current = c;
            const result = await gateway.provisionClient(
              partnerId,
              body,
              c.signal,
            );
            if (!c.signal.aborted)
              navigate(`/queen/clients/${result.workspaceId}`);
          } catch (e) {
            if (!pending.current?.signal.aborted)
              setError(e instanceof DataError ? e : new DataError("invalid"));
          } finally {
            if (!pending.current?.signal.aborted) setBusy(false);
          }
        }}
      >
        <fieldset disabled={busy || submitted}>
          <legend>New client details</legend>
          <label>
            Partner
            <select
              value={partnerId}
              onChange={(e) => setPartner(e.target.value)}
            >
              {owners.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.displayName}
                </option>
              ))}
            </select>
          </label>
          {(
            [
              ["organisationName", "Legal Organisation name"],
              ["workspaceName", "Workspace name"],
              ["brandName", "Brand name"],
              ["brandSlug", "Brand URL name"],
            ] as const
          ).map(([key, label]) => (
            <label key={key}>
              {label}
              <input
                required
                maxLength={key === "brandSlug" ? 100 : 200}
                value={values[key]}
                onChange={(e) =>
                  setValues({ ...values, [key]: e.target.value })
                }
              />
            </label>
          ))}
        </fieldset>
        {submitted && !!error && (
          <p>
            Retry uses the same request and details to avoid duplicate creation.
          </p>
        )}
        {error ? <Failure error={error} /> : null}
        <button className="button" disabled={busy || !gateway.provisionClient}>
          {busy
            ? "Creating…"
            : submitted
              ? "Retry creation"
              : "Create client workspace"}
        </button>
      </form>
    </section>
  );
}
