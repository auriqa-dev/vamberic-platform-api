import { useEffect, useState, useRef } from "react";
import { useOperating } from "../data/operating/context";
import { Failure } from "../components/ui";
export function WorkspaceBilling({
  workspaceId,
  governance = false,
}: {
  workspaceId?: string;
  governance?: boolean;
}) {
  const keys = useRef(new Map<string, string>());
  const api = useOperating();
  const [draft, setDraft] = useState(workspaceId ?? "");
  const [selected, setSelected] = useState(workspaceId ?? "");
  const [revision, setRevision] = useState(0),
    [reason, setReason] = useState("");
  const [record, setRecord] = useState<{
    revision: number;
    effective: { treatment: string };
  }>();
  const [error, setError] = useState<unknown>();
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!api || !selected) return;
    const c = new AbortController();
    setRecord(undefined);
    setError(undefined);
    api
      .workspaceBilling(selected, governance, c.signal)
      .then((v) => {
        if (!c.signal.aborted) setRecord(v);
      })
      .catch((e) => {
        if (!c.signal.aborted) setError(e);
      });
    return () => c.abort();
  }, [api, selected, governance, revision]);
  if (!api) return null;
  return (
    <section className="panel">
      <h2>Workspace billing treatment</h2>
      {governance && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setSelected(draft);
            setRevision((x) => x + 1);
          }}
        >
          <label>
            Client workspace ID
            <input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              required
            />
          </label>
          <button disabled={busy}>Read billing status</button>
        </form>
      )}
      {record && (
        <>
          <p>
            {record.effective.treatment === "internal"
              ? "Internal: HVM platform and Agent services are not invoiced."
              : "Existing commercial terms apply."}
          </p>
          <p>
            Provider usage and costs remain recorded. Budgets and direct
            third-party charges are unchanged. This does not enable marketing.
          </p>
        </>
      )}
      {governance && record && (
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            setError(undefined);
            try {
              const body = {
                action:
                  record.effective.treatment === "internal"
                    ? ("revoke" as const)
                    : ("approve" as const),
                expectedRevision: record.revision,
                reason,
              };
              const pin = JSON.stringify({ selected, ...body });
              if (!keys.current.has(pin))
                keys.current.set(pin, crypto.randomUUID());
              await api.setWorkspaceBilling(
                selected,
                { ...body, requestKey: keys.current.get(pin)! },
                new AbortController().signal,
              );
              setReason("");
              setRevision((x) => x + 1);
            } catch (e) {
              setError(e);
            } finally {
              setBusy(false);
            }
          }}
        >
          <label>
            Reason
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
              maxLength={1000}
            />
          </label>
          <button disabled={busy || !reason.trim()}>
            {record.effective.treatment === "internal"
              ? "Revoke exemption"
              : "Approve internal exemption"}
          </button>
        </form>
      )}
      {error ? <Failure error={error} /> : null}
    </section>
  );
}
