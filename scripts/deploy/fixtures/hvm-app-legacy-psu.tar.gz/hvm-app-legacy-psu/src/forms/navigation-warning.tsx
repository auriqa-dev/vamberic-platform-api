import { useEffect, useRef } from "react";
import { useBlocker } from "react-router-dom";
// Data-router blocker handles links, perspective navigation and browser history.
// Inline review region, not a modal: no focus trap or hidden background UI.
export function NavigationWarning({ dirty }: { dirty: boolean }) {
  const blocker = useBlocker(dirty);
  const stay = useRef<HTMLButtonElement>(null);
  const previousFocus = useRef<HTMLElement | null>(null);
  useEffect(() => {
    if (blocker.state === "blocked") {
      previousFocus.current = document.activeElement as HTMLElement;
      stay.current?.focus();
    }
  }, [blocker.state]);
  useEffect(() => {
    if (!dirty) return;
    const warn = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);
  if (blocker.state !== "blocked") return null;
  return (
    <section className="notice navigation-warning" aria-label="Unsaved changes">
      <h2>You have unsaved changes</h2>
      <p>Continue editing, or discard this draft and leave this record.</p>
      <div className="form-actions">
        <button
          type="button"
          className="button"
          ref={stay}
          onClick={() => {
            blocker.reset();
            previousFocus.current?.focus();
          }}
        >
          Continue editing
        </button>
        <button
          type="button"
          className="button secondary"
          onClick={() => blocker.proceed()}
        >
          Discard and leave
        </button>
      </div>
    </section>
  );
}
