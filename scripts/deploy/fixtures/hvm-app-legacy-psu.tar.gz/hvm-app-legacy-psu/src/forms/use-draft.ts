import { useState } from "react";

// JSON-shaped read models only. Mount/key the owner by resource ID, inside its
// authority boundary. No storage: unmounting discards all protected draft data.
export function useDraft<T>(serverValue: T) {
  const signature = JSON.stringify(serverValue);
  const [state, setState] = useState({
    signature,
    baseline: serverValue,
    draft: serverValue,
    conflict: false,
  });
  const dirty = JSON.stringify(state.draft) !== JSON.stringify(state.baseline);
  if (signature !== state.signature) {
    setState({
      signature,
      baseline: serverValue,
      draft: dirty ? state.draft : serverValue,
      conflict: state.conflict || dirty,
    });
  }
  return {
    draft: state.draft,
    dirty,
    conflict: state.conflict,
    edit: (draft: T) => setState((previous) => ({ ...previous, draft })),
    reset: () =>
      setState((previous) => ({
        ...previous,
        draft: previous.baseline,
        conflict: false,
      })),
    saved: (value: T) =>
      setState((previous) => ({
        ...previous,
        baseline: value,
        draft: value,
        conflict: false,
      })),
    markConflict: () =>
      setState((previous) => ({ ...previous, conflict: true })),
  };
}
