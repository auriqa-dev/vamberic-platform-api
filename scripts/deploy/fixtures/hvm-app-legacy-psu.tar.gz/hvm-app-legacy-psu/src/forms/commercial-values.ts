const currencies = new Set(Intl.supportedValuesOf("currency"));
export function currencyDigits(currency: string): number {
  if (!currencies.has(currency))
    throw new Error("Choose a supported ISO currency code.");
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency,
  }).resolvedOptions().maximumFractionDigits!;
}
export function parseMoney(text: string, currency: string): number {
  const digits = currencyDigits(currency);
  const match = /^(\d+)(?:\.(\d+))?$/.exec(text.trim());
  if (!match || (match[2]?.length ?? 0) > digits)
    throw new Error(
      `Enter a non-negative amount with at most ${digits} decimal places.`,
    );
  const value =
    BigInt(match[1]!) * 10n ** BigInt(digits) +
    BigInt((match[2] ?? "").padEnd(digits, "0") || "0");
  if (value > BigInt(Number.MAX_SAFE_INTEGER))
    throw new Error("Amount exceeds the supported limit.");
  return Number(value);
}
export function moneyInput(minor: number, currency: string): string {
  const digits = currencyDigits(currency);
  if (!Number.isSafeInteger(minor) || minor < 0)
    throw new Error("Invalid minor-unit amount.");
  const raw = String(minor).padStart(digits + 1, "0");
  return digits ? raw.slice(0, -digits) + "." + raw.slice(-digits) : raw;
}
export function formatMoney(minor: number, currency: string): string {
  const input = moneyInput(minor, currency),
    [whole, fraction] = input.split(".");
  return new Intl.NumberFormat("en-GB", { style: "currency", currency })
    .formatToParts(BigInt(whole!))
    .map((part) => (part.type === "fraction" ? fraction : part.value))
    .join("");
}
// Shift decimal text, including the scientific notation Number.toString may use.
function shift(text: string, places: number): string {
  const [mantissa, exponent = "0"] = text.toLowerCase().split("e");
  const [whole = "", fraction = ""] = mantissa!.split(".");
  const digits = whole + fraction;
  const point = whole.length + Number(exponent) + places;
  const result =
    point <= 0
      ? "0." + "0".repeat(-point) + digits
      : point >= digits.length
        ? digits + "0".repeat(point - digits.length)
        : digits.slice(0, point) + "." + digits.slice(point);
  return result
    .replace(/^0+(?=\d)/, "")
    .replace(/(\.\d*?)0+$/, "$1")
    .replace(/\.$/, "");
}
export function percentInput(fraction: number): string {
  if (!Number.isFinite(fraction) || fraction < 0 || fraction > 1)
    throw new Error("Invalid fraction.");
  return shift(String(fraction), 2);
}
export function parsePercent(text: string): number {
  if (!/^\d+(?:\.\d+)?$/.test(text.trim()))
    throw new Error("Enter a percentage from 0 to 100.");
  const value = Number(shift(text.trim(), -2));
  if (value < 0 || value > 1)
    throw new Error("Enter a percentage from 0 to 100.");
  return value;
}
