import { DataError } from "./gateway";
import type { AuthSession } from "../auth/session";

export type Query = Readonly<
  Record<string, string | number | boolean | undefined>
>;
export type RequestOptions = { query?: Query } & (
  { method?: never; body?: never } | { method: "POST"; body: unknown }
);
// Structured scalar queries only: no repeated/list values. Undefined is omitted.
function requestUrl(path: string, base: URL, query?: Query) {
  if (!/^\/api\/v1\/hvm\/[a-zA-Z0-9/_-]+$/.test(path) || path.includes("//"))
    throw new DataError("denied");
  const url = new URL(path, base);
  if (
    query !== undefined &&
    (query === null || typeof query !== "object" || Array.isArray(query))
  )
    throw new DataError("invalid");
  const entries = Object.entries(query ?? {});
  if (entries.length > 20) throw new DataError("invalid");
  for (const [key, value] of entries) {
    if (!key || key.length > 100) throw new DataError("invalid");
    if (value === undefined) continue;
    if (
      !["string", "number", "boolean"].includes(typeof value) ||
      (typeof value === "number" && !Number.isFinite(value)) ||
      String(value).length > 2000
    )
      throw new DataError("invalid");
    url.searchParams.set(key, String(value));
  }
  return url;
}

// Authenticated HVM-only transport; no raw provider errors escape.
// Does not import the Vapp generated client or allow arbitrary/internal API URLs.
export function createTransport(
  baseUrl: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const base = new URL(baseUrl);
  return async function read(
    path: string,
    signal: AbortSignal,
    options?: RequestOptions,
  ): Promise<unknown> {
    const url = requestUrl(path, base, options?.query);
    const token = await session.getAccessToken();
    if (!token) throw new DataError("denied");
    let response: Response;
    try {
      response = await request(url, {
        method: options?.method ?? "GET",
        ...(options?.method === "POST"
          ? { body: JSON.stringify(options.body) }
          : {}),
        headers: {
          Accept: "application/json",
          ...(options?.method === "POST"
            ? { "Content-Type": "application/json" }
            : {}),
          Authorization: `Bearer ${token}`,
        },
        signal: AbortSignal.any([signal, AbortSignal.timeout(15000)]),
        credentials: "omit",
        cache: "no-store",
        redirect: "error",
        referrerPolicy: "no-referrer",
      });
    } catch {
      throw new DataError("unavailable");
    }
    if (response.status === 401) {
      await session.invalidate("Your session expired. Please sign in again.");
      throw new DataError("denied");
    }
    if (response.status === 403 || response.status === 404)
      throw new DataError("denied");
    if (response.status === 409) throw new DataError("conflict");
    if (response.status === 400) throw new DataError("invalid");
    if (!response.ok) throw new DataError("unavailable");
    // No raw server errors or response objects escape this boundary.
    if (!response.headers.get("content-type")?.includes("application/json"))
      throw new DataError("invalid");
    try {
      return await response.json();
    } catch {
      throw new DataError("invalid");
    }
  };
}
