import {
  parseAccess,
  parseSnapshot,
  workspaceFor,
  type Access,
  type WorkspacePerspective,
  type Snapshot,
} from "./model";

export type FailureCode =
  "pending" | "denied" | "unavailable" | "invalid" | "conflict";
export class DataError extends Error {
  constructor(readonly code: FailureCode) {
    super(code);
  }
}
/** Adapter boundary only: no proposed HTTP endpoint is treated as deployed. */
export interface HvmGateway {
  psu?: import("./psu").PsuGateway;
  provisionClient?(
    partnerId: string,
    input: import("./provisioning").ProvisionInput,
    signal: AbortSignal,
  ): Promise<import("./provisioning").ProvisionResult>;

  readOnboarding?(
    workspaceId: string,
    signal: AbortSignal,
  ): Promise<{
    overview: { workspace: { id: string; name: string; updatedAt: string } };
    brands: {
      id: string;
      name: string;
      slug: string;
      primaryDomain?: string;
      updatedAt: string;
    }[];
  }>;
  write?(
    workspaceId: string,
    operation: import("./http-gateway").OnboardingOperation,
    payload: unknown,
    signal: AbortSignal,
  ): Promise<unknown>;
  readAccess(signal: AbortSignal): Promise<unknown>;
  readWorkspace(
    perspective: WorkspacePerspective,
    workspaceId: string,
    signal: AbortSignal,
  ): Promise<unknown>;
}
export const pendingGateway: HvmGateway = {
  async readAccess() {
    throw new DataError("pending");
  },
  async readWorkspace() {
    throw new DataError("pending");
  },
};
export async function loadAccess(
  gateway: HvmGateway,
  subject: string,
  signal: AbortSignal,
): Promise<Access> {
  const value = await gateway.readAccess(signal);
  try {
    return parseAccess(value, subject);
  } catch {
    throw new DataError("invalid");
  }
}
export async function loadWorkspace(
  gateway: HvmGateway,
  access: Access,
  perspective: WorkspacePerspective,
  id: string,
  signal: AbortSignal,
): Promise<Snapshot> {
  if (!workspaceFor(access, perspective, id)) throw new DataError("denied");
  const value = await gateway.readWorkspace(perspective, id, signal);
  try {
    return parseSnapshot(value, id);
  } catch {
    throw new DataError("invalid");
  }
}
