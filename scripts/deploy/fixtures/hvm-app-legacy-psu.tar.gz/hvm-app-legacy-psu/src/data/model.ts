import { z } from "zod";

// Safe presentation projections of existing domain concepts. This is NOT a
// persistence schema or a browser authorization resolver. See docs/api-contract.md.
const id = (prefix: string) =>
  z.string().regex(new RegExp(`^${prefix}_[a-zA-Z0-9]+$`));
const label = z.string().min(1).max(200);
export const perspectiveSchema = z.enum(["empress", "queen", "client"]);
export type Perspective = z.infer<typeof perspectiveSchema>;
export type WorkspacePerspective = Exclude<Perspective, "empress">;
export const workspaceSchema = z
  .object({
    id: id("workspace"),
    name: label,
    role: z.enum(["admin", "onboarder", "viewer"]),
    clientOrganisationId: id("org"),
    organisationName: label,
  })
  .strict();
export type Workspace = z.infer<typeof workspaceSchema>;
const partnerSchema = z
  .object({
    id: id("partner"),
    displayName: label,
    organisationId: id("org").optional(),
  })
  .strict();
// Each workspace below must already be authorized by the server. A Partner's
// presence is only a display projection, never an inferred grant.
export const accessSchema = z
  .object({
    application: z.literal("hvmapp"),
    actor: z.object({ type: z.literal("human"), subject: label }).strict(),
    platform: z.object({ empress: z.boolean() }).strict(),
    workspaces: z.array(workspaceSchema).max(200),
    queen: z
      .object({
        partners: z
          .array(
            partnerSchema
              .extend({
                role: z.enum(["owner", "member"]),
                workspaceIds: z.array(id("workspace")).max(200),
              })
              .strict(),
          )
          .min(1)
          .max(200),
        workspaces: z.array(workspaceSchema),
      })
      .strict()
      .nullable(),
    client: z
      .object({
        workspaces: z.array(workspaceSchema).min(1).max(200),
        memberships: z
          .array(
            z
              .object({
                workspaceId: id("workspace"),
                role: z.enum(["admin", "member"]),
              })
              .strict(),
          )
          .min(1)
          .max(200),
      })
      .strict()
      .nullable(),
  })
  .strict();
export type Access = z.infer<typeof accessSchema>;
export function parseAccess(value: unknown, subject: string): Access {
  const result = accessSchema.parse(value);
  if (result.actor.subject !== subject) throw new Error("Actor mismatch");
  for (const context of [result.queen, result.client]) {
    if (
      context &&
      new Set(context.workspaces.map((w) => w.id)).size !==
        context.workspaces.length
    )
      throw new Error("Duplicate workspace");
  }
  return result;
}
export function perspectives(access: Access): Perspective[] {
  return (["empress", "queen", "client"] as const).filter((p) =>
    p === "empress" ? access.platform.empress : access[p] !== null,
  );
}
export function workspaceFor(
  access: Access,
  perspective: WorkspacePerspective,
  workspaceId: string,
) {
  return access[perspective]?.workspaces.find((w) => w.id === workspaceId);
}

export const integrationSchema = z
  .object({
    id: id("integration"),
    workspaceId: id("workspace"),
    provider: z.string().regex(/^[a-z][a-z0-9_]{0,63}$/),
    displayName: label,
    status: z.enum(["pending", "connected", "error", "disconnected"]),
  })
  .strict();
export type Integration = z.infer<typeof integrationSchema>;
export const providers = [
  ["odyssiant", "Odyssiant"],
  ["lusha", "Lusha"],
  ["postmark", "Postmark"],
  ["hubspot", "HubSpot"],
  ["ga4", "GA4"],
  ["ahrefs", "Ahrefs"],
  ["google_ads", "Google Ads"],
  ["linkedin", "LinkedIn"],
] as const;

const text = z.string().min(1).max(10000);
const sectionSchema = z
  .object({
    title: label,
    entries: z.array(z.object({ label, value: text }).strict()).max(100),
  })
  .strict();
const kitSchema = z
  .object({
    id: id("brandkit"),
    workspaceId: id("workspace"),
    brandId: id("brand"),
    status: z.enum(["draft", "approved", "retired"]),
    readiness: z
      .object({
        logo: z.boolean(),
        colours: z.boolean(),
        typography: z.boolean(),
        voice: z.boolean(),
        descriptions: z.boolean(),
        emailDefaults: z.boolean(),
      })
      .strict(),
    // Server-rendered safe text projections; no object keys, URLs, binaries or credentials.
    sections: z.array(sectionSchema).max(12),
  })
  .strict();
export type BrandKit = z.infer<typeof kitSchema>;
const brandSchema = z
  .object({
    id: id("brand"),
    workspaceId: id("workspace"),
    organisationId: id("org"),
    name: label,
    primaryDomain: label.optional(),
    description: text.optional(),
    currentKit: kitSchema.nullable(),
  })
  .strict();

// unavailable is distinct from a successful empty list; absent APIs must never
// become "no records", complete onboarding, or a made-up readiness percentage.
export function collection<T extends z.ZodTypeAny>(item: T) {
  return z.discriminatedUnion("state", [
    z.object({ state: z.literal("unavailable") }).strict(),
    z
      .object({ state: z.literal("ready"), items: z.array(item).max(1000) })
      .strict(),
  ]);
}
export const checkSchema = z
  .object({
    key: z.enum(["identity", "brand", "team", "integrations", "swarm"]),
    status: z.enum(["complete", "needs_attention", "pending", "not_required"]),
    detail: text,
  })
  .strict();
export const snapshotSchema = z
  .object({
    workspaceId: id("workspace"),
    identity: z
      .object({
        primaryContact: label.nullable(),
        partners: z.array(partnerSchema),
      })
      .strict(),
    onboarding: z
      .object({
        state: z.enum(["unavailable", "not_started", "in_progress", "ready"]),
        checks: z.array(checkSchema).max(5),
      })
      .strict(),
    brands: collection(brandSchema),
    integrations: collection(integrationSchema),
    team: collection(
      z
        .object({
          id: label,
          workspaceId: id("workspace"),
          displayName: label,
          accessLabel: label,
          status: z.enum(["active", "invited", "ended"]),
        })
        .strict(),
    ),
    swarm: collection(
      z
        .object({
          id: id("capinstance"),
          workspaceId: id("workspace"),
          name: label,
          status: label,
          entitlement: z.enum(["enabled", "available", "unavailable"]),
        })
        .strict(),
    ),
    activity: collection(
      z
        .object({
          id: id("event"),
          workspaceId: id("workspace"),
          occurredAt: z.string().datetime(),
          summary: text,
        })
        .strict(),
    ),
  })
  .strict();
export type Snapshot = z.infer<typeof snapshotSchema>;
export function parseSnapshot(value: unknown, workspaceId: string): Snapshot {
  const snapshot = snapshotSchema.parse(value);
  if (snapshot.workspaceId !== workspaceId)
    throw new Error("Workspace mismatch");
  for (const resource of [
    snapshot.brands,
    snapshot.integrations,
    snapshot.team,
    snapshot.swarm,
    snapshot.activity,
  ]) {
    if (
      resource.state === "ready" &&
      resource.items.some((item) => item.workspaceId !== workspaceId)
    )
      throw new Error("Cross-workspace response");
  }
  if (snapshot.brands.state === "ready")
    for (const brand of snapshot.brands.items) {
      const kit = brand.currentKit;
      if (
        kit &&
        (kit.workspaceId !== workspaceId ||
          kit.brandId !== brand.id ||
          kit.status !== "approved")
      )
        throw new Error("Invalid current kit");
    }
  if (
    new Set(snapshot.onboarding.checks.map((c) => c.key)).size !==
    snapshot.onboarding.checks.length
  )
    throw new Error("Duplicate check");
  return snapshot;
}
export function kitStatus(snapshot: Snapshot) {
  if (snapshot.brands.state === "unavailable") return "Awaiting status";
  if (!snapshot.brands.items.length) return "No Brand Kit";
  return snapshot.brands.items.every((b) => b.currentKit)
    ? "Approved"
    : "Needs attention";
}
export function integrationStatus(snapshot: Snapshot) {
  if (snapshot.integrations.state === "unavailable") return "Awaiting status";
  const connections = snapshot.integrations.items;
  return connections.length
    ? `${connections.filter((i) => i.status === "connected").length} of ${connections.length} connected`
    : "No integrations";
}
export const onboardingLabels = {
  unavailable: "Awaiting status",
  not_started: "Not started",
  in_progress: "In progress",
  ready: "Ready",
} as const;
