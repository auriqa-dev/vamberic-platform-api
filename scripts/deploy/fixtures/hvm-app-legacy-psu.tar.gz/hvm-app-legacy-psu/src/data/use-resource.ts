import { useEffect, useState } from "react";

type Resource<T> =
  | { state: "loading" }
  | { state: "ready"; data: T }
  | { state: "error"; error: unknown };
export function useResource<T>(
  load: (signal: AbortSignal) => Promise<T>,
): Resource<T> {
  const [result, setResult] = useState<{
    load: typeof load;
    value: Resource<T>;
  }>({ load, value: { state: "loading" } });
  useEffect(() => {
    const controller = new AbortController();
    let current = true;
    void load(controller.signal).then(
      (data) => {
        if (current) setResult({ load, value: { state: "ready", data } });
      },
      (error) => {
        if (current) setResult({ load, value: { state: "error", error } });
      },
    );
    return () => {
      current = false;
      controller.abort();
    };
  }, [load]);
  // A changed context must never paint the previous workspace while effects run.
  return result.load === load ? result.value : { state: "loading" };
}
