import { z } from "zod";
export const paginationSchema = z
  .object({
    limit: z.number().int().min(1).max(100).default(20),
    offset: z.number().int().min(0).max(10000).default(0),
  })
  .strict();
export type Pagination = z.infer<typeof paginationSchema>;
export type Page<T> = Pagination & { items: T[]; hasMore: boolean };
export const firstPage = (limit = 20): Pagination =>
  paginationSchema.parse({ limit, offset: 0 });
export function nextPage(
  page: Pick<Page<unknown>, "hasMore" | "limit" | "offset">,
): Pagination | null {
  const { limit, offset } = paginationSchema.parse({
    limit: page.limit,
    offset: page.offset,
  });
  return page.hasMore && offset + limit <= 10000
    ? { limit, offset: offset + limit }
    : null;
}
export function previousPage(page: Pagination): Pagination | null {
  const { limit, offset } = paginationSchema.parse({
    limit: page.limit,
    offset: page.offset,
  });
  return offset > 0 ? { limit, offset: Math.max(0, offset - limit) } : null;
}
