import { useCallback, useEffect, useRef, useState } from "react";
import { DataError } from "../gateway";
// Owner must be keyed by scope/ID and mounted inside trusted authority guards.
export function useOperatingRecord<T>(
  load: (signal: AbortSignal) => Promise<T>,
) {
  const [data, setData] = useState<T>();
  const [error, setError] = useState<unknown>();
  const [loading, setLoading] = useState(true);
  const controller = useRef<AbortController | undefined>(undefined);
  const refresh = useCallback(async () => {
    controller.current?.abort();
    const c = new AbortController();
    controller.current = c;
    setLoading(true);
    try {
      const value = await load(c.signal);
      if (!c.signal.aborted) {
        setData(value);
        setError(undefined);
      }
    } catch (e) {
      if (!c.signal.aborted) {
        setError(e);
        if (e instanceof DataError && ["denied", "invalid"].includes(e.code))
          setData(undefined);
      }
    } finally {
      if (!c.signal.aborted) setLoading(false);
    }
  }, [load]);
  useEffect(() => {
    void refresh();
    const focus = () => {
      if (document.visibilityState === "visible") void refresh();
    };
    window.addEventListener("focus", focus);
    document.addEventListener("visibilitychange", focus);
    return () => {
      controller.current?.abort();
      window.removeEventListener("focus", focus);
      document.removeEventListener("visibilitychange", focus);
    };
  }, [refresh]);
  return {
    data,
    error,
    loading,
    refresh,
    accept: setData,
    deny: () => {
      setData(undefined);
      setError(new DataError("denied"));
    },
  };
}
