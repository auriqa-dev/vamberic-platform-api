import { onboardingGateway } from "../client-onboarding";
import {
  ClientAgentData,
  ClientSwarmData,
  RecommendationInput,
  DecisionInput,
} from "./models";
import {
  ApprovalQuery,
  ApprovalRequest,
  ApprovalReview,
  ApprovalPage,
  ApprovalSuccess,
} from "./approvals";
import {
  createSchema,
  controlSchema,
  globalDataSchemas,
  type CreateDefinition,
  type UpdateDefinition,
  type DefinitionControl,
} from "./mutations";
import { z } from "zod";
import { DataError } from "../gateway";
import { createTransport } from "../transport";
import type { AuthSession } from "../../auth/session";
import {
  canonicalId,
  globalResources,
  OPERATING_PREFIXES,
  operatingSchemas,
  readinessSchema,
  type GlobalResource,
  type WorkspaceResource,
  type OperatingResource,
  type OperatingModels,
} from "./models";
import { paginationSchema, type Page, type Pagination } from "./pagination";

type Filters<R extends OperatingResource> = R extends GlobalResource
  ? { key?: string }
  : R extends "client_agents"
    ? { agentDefinitionId?: string; integrationId?: string }
    : R extends "client_swarms"
      ? { agentInstanceId?: string }
      : { swarmId?: string };
export type ListQuery<R extends OperatingResource> = Partial<Pagination> &
  Filters<R>;
export type OperatingScope<R extends OperatingResource> =
  R extends GlobalResource
    ? { resource: R }
    : { resource: R; workspaceId: string };
const filterSchemas = {
  global: paginationSchema
    .extend({ key: z.string().max(2000).optional() })
    .strict(),
  client_agents: paginationSchema
    .extend({
      agentDefinitionId: canonicalId("agentdefinition").optional(),
      integrationId: canonicalId("integration").optional(),
    })
    .strict(),
  client_swarms: paginationSchema
    .extend({ agentInstanceId: canonicalId("clientagent").optional() })
    .strict(),
  commercial: paginationSchema
    .extend({ swarmId: canonicalId("clientswarm").optional() })
    .strict(),
};
const isGlobal = (resource: OperatingResource): resource is GlobalResource =>
  (globalResources as readonly string[]).includes(resource);
const pathName = (resource: OperatingResource) => resource.replaceAll("_", "-");
function root<R extends OperatingResource>(scope: OperatingScope<R>) {
  if (!Object.hasOwn(OPERATING_PREFIXES, scope.resource))
    throw new DataError("invalid");
  if (isGlobal(scope.resource)) {
    if ("workspaceId" in scope) throw new DataError("invalid");
    return `/api/v1/hvm/empress/${pathName(scope.resource)}`;
  }
  if (!("workspaceId" in scope)) throw new DataError("invalid");
  return `/api/v1/hvm/workspaces/${canonicalId("workspace").parse(scope.workspaceId)}/operating/${pathName(scope.resource)}`;
}
function parseRecord<R extends OperatingResource>(
  scope: OperatingScope<R>,
  value: unknown,
): OperatingModels[R] {
  // The cast preserves the resource/schema correlation; Zod validates at runtime.
  const parsed = operatingSchemas[scope.resource].parse(
    value,
  ) as OperatingModels[R];
  if (
    "workspaceId" in scope &&
    (!("workspaceId" in parsed) || parsed.workspaceId !== scope.workspaceId)
  )
    throw new DataError("invalid");
  return parsed;
}
async function boundary<T>(read: () => Promise<T>): Promise<T> {
  try {
    return await read();
  } catch (error) {
    if (error instanceof DataError) throw error;
    throw new DataError("invalid");
  }
}
export function createOperatingGateway(
  baseUrl: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(baseUrl, session, request);
  const approvalRoot = "/api/v1/hvm/empress/agreement-approvals";
  const workspaceData = {
    client_agents: ClientAgentData,
    client_swarms: ClientSwarmData,
    pricing_recommendations: RecommendationInput,
    swarm_agreements: DecisionInput,
  };
  return {
    onboarding: onboardingGateway(http),
    async workspaceBilling(
      workspaceId: string,
      governance: boolean,
      signal: AbortSignal,
    ) {
      const id = canonicalId("workspace").parse(workspaceId);
      const result = z
        .object({
          workspaceId: canonicalId("workspace"),
          revision: z.number().int().nonnegative(),
          exemption: z.unknown().nullable(),
          effective: z
            .object({
              treatment: z.enum(["internal", "existing_terms"]),
              executionAuthority: z.literal(false),
            })
            .passthrough(),
        })
        .parse(
          await http(
            `/api/v1/hvm/${governance ? "empress/workspace-billing/" : "workspaces/"}${id}${governance ? "" : "/billing-treatment"}`,
            signal,
          ),
        );
      if (result.workspaceId !== id) throw new DataError("invalid");
      return result;
    },
    async setWorkspaceBilling(
      workspaceId: string,
      body: {
        action: "approve" | "revoke";
        requestKey: string;
        expectedRevision: number;
        reason: string;
      },
      signal: AbortSignal,
    ) {
      return http(
        `/api/v1/hvm/empress/workspace-billing/${canonicalId("workspace").parse(workspaceId)}`,
        signal,
        { method: "POST", body },
      );
    },
    workspaceCreate<R extends WorkspaceResource>(
      workspaceId: string,
      resource: R,
      data: z.infer<(typeof workspaceData)[R]>,
      signal: AbortSignal,
    ): Promise<OperatingModels[R]> {
      return boundary(async () => {
        const scope = { resource, workspaceId } as OperatingScope<R>;
        const body = { data: workspaceData[resource].parse(data) };
        return parseRecord(
          scope,
          await http(`${root(scope)}/create`, signal, { method: "POST", body }),
        );
      });
    },
    workspaceUpdate<R extends "client_agents" | "client_swarms">(
      workspaceId: string,
      resource: R,
      input: {
        id: string;
        expectedUpdatedAt: string;
        data: z.infer<(typeof workspaceData)[R]>;
      },
      signal: AbortSignal,
    ): Promise<OperatingModels[R]> {
      return boundary(async () => {
        const scope = { resource, workspaceId } as OperatingScope<R>;
        const body = z
          .object({
            id: canonicalId(OPERATING_PREFIXES[resource]),
            expectedUpdatedAt: z.string().datetime(),
            data: workspaceData[resource],
          })
          .strict()
          .parse(input);
        const row = parseRecord(
          scope,
          await http(`${root(scope)}/update`, signal, { method: "POST", body }),
        );
        if (row.id !== body.id) throw new DataError("invalid");
        return row;
      });
    },
    workspaceLifecycle<R extends WorkspaceResource>(
      workspaceId: string,
      resource: R,
      operation: "configure" | "approve" | "supersede" | "retire",
      input: DefinitionControl,
      signal: AbortSignal,
    ): Promise<OperatingModels[R]> {
      return boundary(async () => {
        if (!(
          operation === "retire" ||
          (operation === "configure" &&
            ["client_agents", "client_swarms"].includes(resource)) ||
          (operation === "approve" && resource === "swarm_agreements") ||
          (operation === "supersede" &&
            ["pricing_recommendations", "swarm_agreements"].includes(resource))
        ))
          throw new DataError("invalid");
        const scope = { resource, workspaceId } as OperatingScope<R>;
        const body = z
          .object({
            id: canonicalId(OPERATING_PREFIXES[resource]),
            expectedUpdatedAt: z.string().datetime(),
          })
          .strict()
          .parse(input);
        const row = parseRecord(
          scope,
          await http(`${root(scope)}/${operation}`, signal, {
            method: "POST",
            body,
          }),
        );
        if (row.id !== body.id) throw new DataError("invalid");
        return row;
      });
    },
    connections(workspaceId: string, signal: AbortSignal) {
      return boundary(async () => {
        canonicalId("workspace").parse(workspaceId);
        return z
          .object({
            integrations: z
              .array(
                z.object({
                  id: canonicalId("integration"),
                  provider: z.string().min(1),
                  displayName: z.string().min(1),
                  status: z.enum([
                    "pending",
                    "connected",
                    "error",
                    "disconnected",
                  ]),
                }),
              )
              .max(100),
          })
          .parse(
            await http(
              `/api/v1/hvm/workspaces/${workspaceId}/integrations`,
              signal,
            ),
          );
      });
    },
    approvalList(query: Partial<Pagination>, signal: AbortSignal) {
      return boundary(async () => {
        const q = ApprovalQuery.parse(query);
        const page = ApprovalPage.parse(
          await http(approvalRoot, signal, { query: q }),
        );
        if (
          page.limit !== q.limit ||
          page.offset !== q.offset ||
          page.items.length > q.limit
        )
          throw new DataError("invalid");
        return page;
      });
    },
    approvalDetail(id: string, signal: AbortSignal) {
      return boundary(async () => {
        canonicalId("swarmagreement").parse(id);
        const row = ApprovalReview.parse(
          await http(`${approvalRoot}/${id}`, signal),
        );
        if (row.id !== id) throw new DataError("invalid");
        return row;
      });
    },
    approveAgreement(
      id: string,
      input: { expectedUpdatedAt: string; reason: string },
      signal: AbortSignal,
    ) {
      return boundary(async () => {
        canonicalId("swarmagreement").parse(id);
        const body = ApprovalRequest.parse(input);
        const row = ApprovalSuccess.parse(
          await http(`${approvalRoot}/${id}/approve`, signal, {
            method: "POST",
            body,
          }),
        );
        if (row.id !== id) throw new DataError("invalid");
        return row;
      });
    },
    create<R extends GlobalResource>(
      resource: R,
      input: CreateDefinition<R>,
      signal: AbortSignal,
    ): Promise<OperatingModels[R]> {
      return boundary(async () => {
        const scope = { resource } as OperatingScope<R>;
        const body = createSchema(resource).parse(input);
        return parseRecord(
          scope,
          await http(`${root(scope)}/create`, signal, { method: "POST", body }),
        );
      });
    },
    update<R extends GlobalResource>(
      resource: R,
      input: UpdateDefinition<R>,
      signal: AbortSignal,
    ): Promise<OperatingModels[R]> {
      return boundary(async () => {
        const scope = { resource } as OperatingScope<R>;
        const body = controlSchema(resource)
          .extend({ data: globalDataSchemas[resource] })
          .strict()
          .parse(input);
        const record = parseRecord(
          scope,
          await http(`${root(scope)}/update`, signal, { method: "POST", body }),
        );
        if (record.id !== body.id) throw new DataError("invalid");
        return record;
      });
    },
    lifecycle<R extends GlobalResource>(
      resource: R,
      operation: "publish" | "retire",
      input: DefinitionControl,
      signal: AbortSignal,
    ): Promise<OperatingModels[R]> {
      return boundary(async () => {
        if (!["publish", "retire"].includes(operation))
          throw new DataError("invalid");
        const scope = { resource } as OperatingScope<R>;
        const body = controlSchema(resource).parse(input);
        const record = parseRecord(
          scope,
          await http(`${root(scope)}/${operation}`, signal, {
            method: "POST",
            body,
          }),
        );
        if (record.id !== body.id) throw new DataError("invalid");
        return record;
      });
    },
    list<R extends OperatingResource>(
      scope: OperatingScope<R>,
      query: ListQuery<R>,
      signal: AbortSignal,
    ): Promise<Page<OperatingModels[R]>> {
      return boundary(async () => {
        const path = root(scope);
        const schema = isGlobal(scope.resource)
          ? filterSchemas.global
          : scope.resource === "client_agents"
            ? filterSchemas.client_agents
            : scope.resource === "client_swarms"
              ? filterSchemas.client_swarms
              : filterSchemas.commercial;
        const q = schema.parse(query);
        const raw = paginationSchema
          .extend({
            limit: z.number().int().min(1).max(100),
            offset: z.number().int().min(0).max(10000),
            items: z.array(z.unknown()).max(100),
            hasMore: z.boolean(),
          })
          .strict()
          .parse(await http(path, signal, { query: q }));
        if (
          raw.limit !== q.limit ||
          raw.offset !== q.offset ||
          raw.items.length > raw.limit
        )
          throw new DataError("invalid");
        return {
          ...raw,
          items: raw.items.map((item) => parseRecord(scope, item)),
        };
      });
    },
    detail<R extends OperatingResource>(
      scope: OperatingScope<R>,
      id: string,
      signal: AbortSignal,
    ): Promise<OperatingModels[R]> {
      return boundary(async () => {
        const path = root(scope);
        canonicalId(OPERATING_PREFIXES[scope.resource]).parse(id);
        const record = parseRecord(scope, await http(`${path}/${id}`, signal));
        if (record.id !== id) throw new DataError("invalid");
        return record;
      });
    },
    catalogue<R extends GlobalResource>(
      workspaceId: string,
      resource: R,
      signal: AbortSignal,
    ): Promise<{ items: OperatingModels[R][] }> {
      return boundary(async () => {
        canonicalId("workspace").parse(workspaceId);
        if (!isGlobal(resource)) throw new DataError("invalid");
        const raw = z
          .object({ items: z.array(z.unknown()).max(100) })
          .strict()
          .parse(
            await http(
              `/api/v1/hvm/workspaces/${workspaceId}/operating/catalogue/${pathName(resource)}`,
              signal,
            ),
          );
        const scope = { resource } as OperatingScope<R>;
        const items = raw.items.map((item) => parseRecord(scope, item));
        if (items.some((item) => item.status !== "active" || item.archived))
          throw new DataError("invalid");
        return { items };
      });
    },
    readiness(workspaceId: string, id: string, signal: AbortSignal) {
      return boundary(async () => {
        const path = root<WorkspaceResource>({
          resource: "client_swarms",
          workspaceId,
        });
        canonicalId("clientswarm").parse(id);
        return readinessSchema.parse(
          await http(`${path}/${id}/readiness`, signal),
        );
      });
    },
  };
}
export type OperatingGateway = ReturnType<typeof createOperatingGateway>;
