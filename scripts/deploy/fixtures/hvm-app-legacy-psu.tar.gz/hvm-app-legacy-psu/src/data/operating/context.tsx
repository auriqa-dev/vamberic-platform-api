import { createContext, useContext } from "react";
import type { OperatingGateway } from "./gateway";
export const OperatingContext = createContext<OperatingGateway | undefined>(
  undefined,
);
export const useOperating = () => useContext(OperatingContext);
