// Handwritten wire-contract mirror of backend domain/operating.ts (schema v9).
// Persistence Date fields serialize as ISO strings. No backend runtime imports.
import { z } from "zod";
export const canonicalId = (prefix: string) =>
  z
    .string()
    .regex(new RegExp(`^${prefix}_[0-7][0-9abcdefghjkmnpqrstvwxyz]{25}$`));
const platformIdSchema = canonicalId;
type PlatformIdPrefix = string;
const wireDate = z.string().datetime();
export const partnerHumanSchema = z
  .object({
    type: z.literal("human"),
    issuer: z
      .string()
      .url()
      .max(500)
      .regex(/^https?:\/\/[^\s]+$/),
    id: z
      .string()
      .trim()
      .min(1)
      .max(300)
      .refine((id) => !id.startsWith("partner_")),
  })
  .strict();
const billingTreatmentSchema = z.enum([
  "standard",
  "bundled",
  "waived",
  "internal",
  "promotional",
]);
const currency = z
  .string()
  .trim()
  .toUpperCase()
  .regex(/^[A-Z]{3}$/)
  .refine((value) => new Set(Intl.supportedValuesOf("currency")).has(value));
const basePersistenceSchema = z.object({
  id: z.string(),
  workspaceId: canonicalId("workspace").optional(),
  createdAt: wireDate,
  updatedAt: wireDate,
  schemaVersion: z.number().int().positive().default(1),
  archived: z.boolean().default(false),
  archivedAt: wireDate.optional(),
  source: z
    .object({
      system: z.string().trim().min(1).max(100),
      reference: z.string().trim().max(500).optional(),
      importedAt: wireDate.optional(),
    })
    .optional(),
});
const text = (max = 2000) => z.string().trim().min(1).max(max);
export const operatingKey = z.string().regex(/^[a-z][a-z0-9_]{0,63}$/);
const texts = z.array(text()).max(40);
const ids = (p: PlatformIdPrefix) =>
  z
    .array(platformIdSchema(p))
    .max(40)
    .refine((v) => new Set(v).size === v.length, "Duplicate references");
const fraction = z.number().min(0).max(1);
const minor = z.number().int().safe().nonnegative();
export const OperatingMoneySchema = z
  .object({ amountMinor: minor, currency })
  .strict();
export const VersionRefSchema = z
  .object({
    id: z.string().min(1).max(100),
    version: z.number().int().positive(),
  })
  .strict();
const ref = (p: PlatformIdPrefix) =>
  VersionRefSchema.extend({ id: platformIdSchema(p) }).strict();
const refs = (p: PlatformIdPrefix) =>
  z
    .array(ref(p))
    .max(40)
    .refine(
      (v) => new Set(v.map((r) => r.id)).size === v.length,
      "Duplicate references",
    );
export const ConfigFieldSchema = z
  .object({
    key: operatingKey,
    label: text(200),
    type: z.enum(["text", "number", "boolean", "choice"]),
    required: z.boolean(),
    choices: z.array(text(200)).max(30).default([]),
    guidance: text().optional(),
  })
  .strict();
export const ConfigValueSchema = z
  .object({
    key: operatingKey,
    text: text().optional(),
    number: z
      .number()
      .min(-Number.MAX_SAFE_INTEGER)
      .max(Number.MAX_SAFE_INTEGER)
      .optional(),
    boolean: z.boolean().optional(),
  })
  .strict()
  .refine(
    (v) =>
      [v.text, v.number, v.boolean].filter((x) => x !== undefined).length === 1,
    "Exactly one value required",
  );
export const ConfigurationSchema = z
  .array(ConfigValueSchema)
  .max(40)
  .refine(
    (v) => new Set(v.map((x) => x.key)).size === v.length,
    "Duplicate configuration key",
  );
const costDriver = z
  .object({
    key: operatingKey,
    name: text(200),
    unit: text(100),
    description: text(),
    expectedQuantity: z.number().min(0).max(Number.MAX_SAFE_INTEGER).optional(),
    unitCost: OperatingMoneySchema.optional(),
  })
  .strict();
const requirement = z
  .object({
    slot: operatingKey,
    operationalCapability: operatingKey,
    required: z.boolean(),
    minimumProviders: z.number().int().min(0).max(10),
    supportedProviderIds: ids("integrationprovider"),
  })
  .strict()
  .refine(
    (v) => !v.required || v.minimumProviders > 0,
    "Required slot needs a minimum provider",
  );
const base = basePersistenceSchema
  .omit({ workspaceId: true })
  .extend({
    referenceVersion: z.number().int().nonnegative().default(0),
    createdBy: partnerHumanSchema,
    updatedBy: partnerHumanSchema,
  })
  .strict();
const global = {
  key: operatingKey,
  version: z.number().int().positive(),
  status: z.enum(["draft", "active", "retired"]),
  availability: z.enum(["internal", "queens", "experimental"]),
};
const implementationIdentity = z
  .object({
    key: operatingKey,
    version: z.number().int().min(1).max(1_000_000),
    digest: z.string().regex(/^[a-f0-9]{64}$/),
  })
  .strict();
export const EffectivenessBinding = z
  .object({
    maker: operatingKey,
    evaluator: operatingKey,
    revision: operatingKey,
    profile: implementationIdentity,
    policy: implementationIdentity,
    required: z.literal(true),
    maxRevisions: z.number().int().min(0).max(2),
  })
  .strict()
  .refine(
    (v) => new Set([v.maker, v.evaluator, v.revision]).size === 3,
    "Roles require separate operations",
  );
export const AgentDefinitionData = z
  .object({
    name: text(200),
    description: text(),
    category: operatingKey,
    providesCapabilityIds: ids("capability"),
    requiresCapabilityIds: ids("capability"),
    requiredAgents: refs("agentdefinition"),
    recommendedAgents: refs("agentdefinition"),
    hiveAccess: z
      .object({
        readResources: z
          .array(
            z.enum([
              "brands",
              "brand_kits",
              "offerings",
              "ideal_customer_profiles",
              "buyer_profiles",
              "offer_designs",
              "offers",
              "people",
              "contact_points",
            ]),
          )
          .max(20),
        proposeResources: z
          .array(
            z.enum([
              "brands",
              "brand_kits",
              "offerings",
              "ideal_customer_profiles",
              "buyer_profiles",
              "offer_designs",
              "offers",
              "people",
              "contact_points",
            ]),
          )
          .max(20),
        approval: z.literal("human_only"),
        scope: z.literal("workspace"),
      })
      .strict(),
    configurationFields: z.array(ConfigFieldSchema).max(40),
    integrationRequirements: z.array(requirement).max(20),
    costDrivers: z.array(costDriver).max(40),
    executionImplementation: z
      .object({
        key: operatingKey,
        version: z.number().int().min(1).max(1_000_000),
        manifestDigest: z.string().regex(/^[a-f0-9]{64}$/),
        protocolVersion: z.enum(["1.1", "1.2", "2.0"]),
      })
      .strict()
      .optional(),
    effectiveness: z.array(EffectivenessBinding).max(6).optional(),
  })
  .strict();
export const IntegrationProviderData = z
  .object({
    name: text(200),
    description: text(),
    category: operatingKey,
    authentication: z.enum([
      "oauth",
      "api_key_reference",
      "external_account",
      "none",
    ]),
    operationalCapabilities: z.array(operatingKey).min(1).max(30),
    customerOwnedAccount: z.enum(["required", "supported", "unsupported"]),
    guidance: text(),
    documentationUrl: z.string().url().max(1000).optional(),
    costDrivers: z.array(costDriver).max(40),
  })
  .strict();
export const SwarmTemplateData = z
  .object({
    name: text(200),
    description: text(),
    job: text(),
    requiredAgents: refs("agentdefinition"),
    recommendedAgents: refs("agentdefinition"),
    optionalAgents: refs("agentdefinition"),
    integrationCapabilities: z.array(operatingKey).max(20),
    configurationGuidance: texts,
    commercialAssumptions: texts,
  })
  .strict();
export const CommercialPolicyData = z
  .object({
    name: text(200),
    description: text(),
    currency: OperatingMoneySchema.shape.currency,
    targetMargin: fraction,
    minimumMargin: fraction,
    defaultOnboardingTreatment: billingTreatmentSchema,
    annualDiscount: fraction,
    maximumQueenDiscount: fraction,
    maximumQueenFixedDiscountMinor: minor,
    minimumMonthlyPriceMinor: minor,
    allowCustomPrice: z.boolean(),
    permittedQueenTreatments: z.array(billingTreatmentSchema).min(1).max(5),
    usagePolicy: text(),
    overagePolicy: text(),
    serviceEffortAssumptions: texts,
    internalTreatmentGuidance: text(),
    promotionalTreatmentGuidance: text(),
    effectiveFrom: z.string().datetime(),
    effectiveUntil: z.string().datetime().optional(),
  })
  .strict()
  .superRefine((v, c) => {
    if (
      v.minimumMargin > v.targetMargin ||
      (v.effectiveUntil && v.effectiveUntil <= v.effectiveFrom)
    )
      c.addIssue({
        code: "custom",
        message: "Invalid policy margin or effective interval",
      });
  });
export const MethodologyAvailabilityData = z
  .object({
    name: text(200),
    description: text(),
    methodology: ref("offermethodology"),
    compatibleAgents: refs("agentdefinition"),
  })
  .strict();
export const BindingSchema = z
  .object({
    slot: operatingKey,
    integrationId: platformIdSchema("integration"),
    provider: ref("integrationprovider"),
    costTreatment: z.enum([
      "client_funded",
      "hvm_funded",
      "pass_through",
      "included_allowance",
    ]),
    expectedQuantity: z.number().min(0).max(Number.MAX_SAFE_INTEGER).optional(),
    unit: text(100).optional(),
    costAssumption: OperatingMoneySchema.optional(),
    allowance: z.number().min(0).max(Number.MAX_SAFE_INTEGER).optional(),
    overageAssumption: text().optional(),
  })
  .strict();
export const ClientAgentData = z
  .object({
    name: text(200),
    definition: ref("agentdefinition"),
    configuration: ConfigurationSchema,
    bindings: z.array(BindingSchema).max(40),
    dependencyInstanceIds: ids("clientagent"),
    capabilityInstanceIds: ids("capinstance"),
  })
  .strict();
export const ClientSwarmData = z
  .object({
    name: text(200),
    description: text(),
    job: text(),
    template: ref("swarmtemplate").optional(),
    agentInstanceIds: ids("clientagent"),
    configuration: ConfigurationSchema,
    commercialNotes: texts,
  })
  .strict();
const configurationSnapshot = z
  .object({
    swarmId: platformIdSchema("clientswarm"),
    swarmRevision: z.number().int().positive(),
    swarm: ClientSwarmData,
    agents: z
      .array(
        z
          .object({
            id: platformIdSchema("clientagent"),
            revision: z.number().int().positive(),
            configuration: ClientAgentData,
            definition: AgentDefinitionData,
            bindings: z
              .array(
                z
                  .object({
                    integrationId: platformIdSchema("integration"),
                    providerKey: operatingKey,
                    provider: IntegrationProviderData,
                  })
                  .strict(),
              )
              .max(40),
          })
          .strict(),
      )
      .max(40),
    template: SwarmTemplateData.optional(),
  })
  .strict();
export const RecommendationInput = z
  .object({
    swarmId: platformIdSchema("clientswarm"),
    policy: ref("commercialpolicy"),
    costInputs: z.array(costDriver).max(40),
    expectedOperatingMonthlyMinor: minor,
    recommendedOnboardingMinor: minor,
    recommendedMonthlyMinor: minor,
    recommendedAnnualMinor: minor,
    assumptions: texts,
    rationale: text(),
    uncertainty: texts,
    sourceReferences: z.array(text(1000)).max(30),
  })
  .strict();
export const RecommendationData = RecommendationInput.extend({
  configurationSnapshot,
  policySnapshot: CommercialPolicyData,
  monthlyMargin: z.number().min(-Number.MAX_SAFE_INTEGER).max(1).nullable(),
  currency: OperatingMoneySchema.shape.currency,
}).strict();
export const DecisionInput = z
  .object({
    recommendationId: platformIdSchema("pricingrecommendation"),
    treatment: billingTreatmentSchema,
    adjustment: z
      .object({
        kind: z.enum([
          "accept",
          "percentage_discount",
          "fixed_discount",
          "custom",
        ]),
        percentage: fraction.optional(),
        amountMinor: minor.optional(),
      })
      .strict(),
    reason: text(),
    onboardingMinor: minor,
    commitment: z
      .object({
        kind: z.enum(["monthly", "annual", "custom"]),
        months: z.number().int().min(1).max(120),
        renewal: z.enum(["none", "review", "renew"]),
      })
      .strict(),
    billingFrequency: z.enum(["monthly", "annual"]),
    effectiveFrom: z.string().datetime(),
    effectiveUntil: z.string().datetime().optional(),
    usageAllowances: texts,
    overageAssumptions: texts,
    commercialNotes: texts,
  })
  .strict()
  .superRefine((v, c) => {
    const a = v.adjustment;
    if (
      (a.kind === "percentage_discount") !== (a.percentage !== undefined) ||
      ["fixed_discount", "custom"].includes(a.kind) !==
        (a.amountMinor !== undefined) ||
      (v.commitment.kind === "monthly" && v.commitment.months !== 1) ||
      (v.commitment.kind === "annual" && v.commitment.months !== 12) ||
      (v.billingFrequency === "annual" && v.commitment.months < 12) ||
      (v.effectiveUntil && v.effectiveUntil <= v.effectiveFrom)
    )
      c.addIssue({
        code: "custom",
        message: "Inconsistent adjustment or term",
      });
  });
const agreementData = z
  .object({
    decision: DecisionInput,
    swarmId: platformIdSchema("clientswarm"),
    recommendationSnapshot: RecommendationData,
    recommendedPeriodMinor: minor,
    finalRecurringMinor: minor,
    finalMonthlyEquivalentMinor: minor,
    currency: OperatingMoneySchema.shape.currency,
    policyResult: z.enum([
      "within_policy",
      "requires_empress_approval",
      "approved_by_empress",
    ]),
    policyReasons: texts,
    decidedBy: partnerHumanSchema,
    decidedAt: wireDate,
    empressApproval: z
      .object({ actor: partnerHumanSchema, at: wireDate, reason: text() })
      .strict()
      .optional(),
    externalReferenceIds: ids("externalref").default([]),
  })
  .strict();

export const OPERATING_PREFIXES = {
  agent_definitions: "agentdefinition",
  integration_providers: "integrationprovider",
  swarm_templates: "swarmtemplate",
  commercial_policies: "commercialpolicy",
  methodology_availability: "methodologyavailability",
  client_agents: "clientagent",
  client_swarms: "clientswarm",
  pricing_recommendations: "pricingrecommendation",
  swarm_agreements: "swarmagreement",
} as const;
export type OperatingResource = keyof typeof OPERATING_PREFIXES;
export const globalResources = [
  "agent_definitions",
  "integration_providers",
  "swarm_templates",
  "commercial_policies",
  "methodology_availability",
] as const;
export type GlobalResource = (typeof globalResources)[number];
export type WorkspaceResource = Exclude<OperatingResource, GlobalResource>;
function checked<S extends z.ZodRawShape>(schema: z.ZodObject<S>) {
  return schema.superRefine((v, c) => {
    if (
      v.updatedAt! < v.createdAt! ||
      v.archived !== Boolean(v.archivedAt) ||
      (v.archivedAt &&
        (v.archivedAt < v.createdAt! || v.archivedAt > v.updatedAt!)) ||
      (v.status === "retired") !== v.archived
    )
      c.addIssue({ code: "custom", message: "Invalid lifecycle chronology" });
    if (new TextEncoder().encode(JSON.stringify(v)).length > 200000)
      c.addIssue({ code: "custom", message: "Operating record exceeds 200KB" });
  });
}
function globalRecord<S extends z.ZodTypeAny>(prefix: string, data: S) {
  return checked(
    base.extend({ id: canonicalId(prefix), ...global, data }).strict(),
  );
}
function workspaceRecord<
  S extends z.ZodTypeAny,
  const E extends [string, ...string[]],
>(prefix: string, data: S, statuses: E) {
  return checked(
    base
      .extend({
        id: canonicalId(prefix),
        workspaceId: canonicalId("workspace"),
        revision: z.number().int().positive(),
        status: z.enum(statuses),
        data,
      })
      .strict(),
  );
}
export const operatingSchemas = {
  agent_definitions: globalRecord("agentdefinition", AgentDefinitionData),
  integration_providers: globalRecord(
    "integrationprovider",
    IntegrationProviderData,
  ),
  swarm_templates: globalRecord("swarmtemplate", SwarmTemplateData),
  commercial_policies: globalRecord("commercialpolicy", CommercialPolicyData),
  methodology_availability: globalRecord(
    "methodologyavailability",
    MethodologyAvailabilityData,
  ),
  client_agents: workspaceRecord("clientagent", ClientAgentData, [
    "draft",
    "configured",
    "retired",
  ]),
  client_swarms: workspaceRecord("clientswarm", ClientSwarmData, [
    "draft",
    "configured",
    "retired",
  ]),
  pricing_recommendations: workspaceRecord(
    "pricingrecommendation",
    RecommendationData,
    ["recorded", "superseded", "retired"],
  ),
  swarm_agreements: workspaceRecord("swarmagreement", agreementData, [
    "proposed",
    "approved",
    "superseded",
    "retired",
  ]),
};
export type OperatingModels = {
  [R in OperatingResource]: z.infer<(typeof operatingSchemas)[R]>;
};
export type AgentDefinition = OperatingModels["agent_definitions"];
export type IntegrationProvider = OperatingModels["integration_providers"];
export type SwarmTemplate = OperatingModels["swarm_templates"];
export type CommercialPolicy = OperatingModels["commercial_policies"];
export type MethodologyAvailability =
  OperatingModels["methodology_availability"];
export type ClientAgent = OperatingModels["client_agents"];
export type ClientSwarm = OperatingModels["client_swarms"];
export type PricingRecommendation = OperatingModels["pricing_recommendations"];
export type SwarmAgreement = OperatingModels["swarm_agreements"];
// Readiness has no scope fields: it is bound to the requested scoped endpoint.
export const readinessSchema = z
  .object({ ready: z.boolean(), issues: z.array(z.string()) })
  .strict()
  .refine(
    (value) => value.ready === (value.issues.length === 0),
    "Inconsistent readiness",
  );
export type SwarmReadiness = z.infer<typeof readinessSchema>;
