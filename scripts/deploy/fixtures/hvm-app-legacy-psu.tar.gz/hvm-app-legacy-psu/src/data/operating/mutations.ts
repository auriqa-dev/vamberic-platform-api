import { z } from "zod";
import {
  AgentDefinitionData,
  IntegrationProviderData,
  SwarmTemplateData,
  CommercialPolicyData,
  MethodologyAvailabilityData,
  operatingKey,
  canonicalId,
  OPERATING_PREFIXES,
  type GlobalResource,
} from "./models";
export const globalDataSchemas = {
  agent_definitions: AgentDefinitionData,
  integration_providers: IntegrationProviderData,
  swarm_templates: SwarmTemplateData,
  commercial_policies: CommercialPolicyData,
  methodology_availability: MethodologyAvailabilityData,
};
export type GlobalData<R extends GlobalResource> = z.infer<
  (typeof globalDataSchemas)[R]
>;
export type CreateDefinition<R extends GlobalResource> = {
  key: string;
  version: number;
  availability: "internal" | "queens" | "experimental";
  data: GlobalData<R>;
};
export type DefinitionControl = { id: string; expectedUpdatedAt: string };
export type UpdateDefinition<R extends GlobalResource> = DefinitionControl & {
  data: GlobalData<R>;
};
export function createSchema<R extends GlobalResource>(resource: R) {
  return z
    .object({
      key: operatingKey,
      version: z.number().int().positive(),
      availability: z.enum(["internal", "queens", "experimental"]),
      data: globalDataSchemas[resource],
    })
    .strict();
}
export function controlSchema(resource: GlobalResource) {
  return z
    .object({
      id: canonicalId(OPERATING_PREFIXES[resource]),
      expectedUpdatedAt: z.string().datetime(),
    })
    .strict();
}
