import { z } from "zod";
import { canonicalId } from "./operating/models";
const label = z.string().trim().min(1).max(200);
export const provisionInput = z
  .object({
    requestKey: z
      .string()
      .min(1)
      .max(100)
      .regex(/^[A-Za-z0-9][A-Za-z0-9_.:-]*$/),
    organisationName: label,
    workspaceName: label,
    brandName: label,
    brandSlug: z.string().regex(/^[a-z0-9][a-z0-9-]{0,99}$/),
  })
  .strict();
export type ProvisionInput = z.infer<typeof provisionInput>;
export const provisionResult = z
  .object({
    workspaceId: canonicalId("workspace"),
    organisationId: canonicalId("org"),
    brandId: canonicalId("brand"),
    partnerId: canonicalId("partner"),
  })
  .strict();
export type ProvisionResult = z.infer<typeof provisionResult>;
