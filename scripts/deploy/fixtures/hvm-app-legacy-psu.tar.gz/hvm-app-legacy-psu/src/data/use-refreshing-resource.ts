import { useEffect, useState } from "react";

// Use only within a keyed authority/resource boundary. Retain mounted editors
// during an in-flight refresh, never after a failed authorization refresh.
export function useRefreshingResource<T>(
  load: (signal: AbortSignal) => Promise<T>,
) {
  const [result, setResult] = useState<
    | { state: "loading" }
    | { state: "ready"; data: T }
    | { state: "error"; error: unknown }
  >({ state: "loading" });
  useEffect(() => {
    const controller = new AbortController();
    let current = true;
    void load(controller.signal).then(
      (data) => {
        if (current)
          setResult((previous) =>
            previous.state === "ready" &&
            JSON.stringify(previous.data) === JSON.stringify(data)
              ? previous
              : { state: "ready", data },
          );
      },
      (error) => {
        if (current) setResult({ state: "error", error });
      },
    );
    return () => {
      current = false;
      controller.abort();
    };
  }, [load]);
  return result;
}
