import { createPsuGateway } from "./psu";
import { provisionInput, provisionResult } from "./provisioning";
import { z } from "zod";
import { DataError, type HvmGateway } from "./gateway";
import { parseAccess, parseSnapshot, type Snapshot } from "./model";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
const id = (p: string) =>
  z.string().regex(new RegExp(`^${p}_[0-7][0-9abcdefghjkmnpqrstvwxyz]{25}$`));
const label = z.string().min(1).max(200);
const workspaceId = id("workspace");
const partner = z.object({ id: id("partner"), displayName: label });
const contextSchema = z
  .object({
    application: z.literal("hvmapp"),
    platform: z.object({ empress: z.boolean() }).strict(),
    human: z.object({
      type: z.literal("human"),
      id: label,
      issuer: z.string().url(),
    }),
    partners: z
      .array(
        partner.extend({
          role: z.enum(["owner", "member"]),
          workspaceIds: z.array(workspaceId).max(200),
        }),
      )
      .max(200),
    clients: z
      .array(z.object({ workspaceId, role: z.enum(["admin", "member"]) }))
      .max(200),
    workspaces: z
      .array(
        z.object({
          id: workspaceId,
          name: label,
          role: z.enum(["admin", "onboarder", "viewer"]),
        }),
      )
      .max(200),
  })
  .strict();
const overviewSchema = z.object({
  workspace: z.object({
    id: workspaceId,
    name: label,
    kind: z.literal("client"),
    updatedAt: z.string().datetime(),
  }),
  organisation: z.object({ id: id("org"), name: label }).nullable(),
  partners: z.array(partner),
  readiness: z.object({ brands: z.number(), approvedBrandKits: z.number() }),
});
const brandSchema = z.object({
  id: id("brand"),
  workspaceId,
  organisationId: id("org"),
  name: label,
  slug: label,
  status: z.enum(["active", "retired"]),
  primaryDomain: label.optional(),
  description: z.string().optional(),
  updatedAt: z.string().datetime(),
});
const kitSchema = z.object({
  id: id("brandkit"),
  workspaceId,
  brandId: id("brand"),
  status: z.enum(["draft", "approved", "retired"]),
  assets: z.array(z.object({ type: z.string(), status: z.string() })),
  colours: z.array(z.object({ name: label, hex: label })),
  typography: z.array(z.object({ family: label })),
  voice: z.object({ descriptors: z.array(label).optional() }).optional(),
  descriptions: z
    .object({
      short: z.string().optional(),
      long: z.string().optional(),
      about: z.string().optional(),
    })
    .optional(),
  emailDefaults: z
    .object({
      fromDisplayName: label.optional(),
      footer: z.string().optional(),
    })
    .optional(),
});
export const operations = [
  "profile",
  "brand-create",
  "brand-update",
  "kit-create",
  "kit-update",
  "kit-approve",
  "kit-retire",
  "integration-create",
  "integration-update",
  "integration-disconnect",
  "member-provision",
  "member-revoke",
] as const;
export type OnboardingOperation = (typeof operations)[number];
export function createHttpGateway(
  baseUrl: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  issuer: string,
  request: typeof fetch = fetch,
): HvmGateway {
  const http = createTransport(baseUrl, session, request);
  const read = async (path: string, signal: AbortSignal) => http(path, signal);
  const root = (w: string) => `/api/v1/hvm/workspaces/${workspaceId.parse(w)}`;
  async function context(signal: AbortSignal) {
    const c = contextSchema.parse(await read("/api/v1/hvm/context", signal));
    if (c.human.issuer !== issuer) throw new DataError("invalid");
    if (new Set(c.workspaces.map((w) => w.id)).size !== c.workspaces.length)
      throw new DataError("invalid");
    return c;
  }
  async function overview(w: string, signal: AbortSignal) {
    const o = overviewSchema.parse(await read(root(w) + "/overview", signal));
    if (o.workspace.id !== w || !o.organisation) throw new DataError("invalid");
    return o;
  }
  async function allowed(
    w: string,
    p: "queen" | "client",
    signal: AbortSignal,
  ) {
    const c = await context(signal);
    const ids =
      p === "queen"
        ? c.partners.flatMap((p) => p.workspaceIds)
        : c.clients.map((c) => c.workspaceId);
    if (!ids.includes(w) || !c.workspaces.some((x) => x.id === w))
      throw new DataError("denied");
    return c;
  }
  return {
    async readAccess(signal) {
      try {
        const c = await context(signal);
        const workspaces = await Promise.all(
          c.workspaces.map(async (w) => {
            const o = await overview(w.id, signal);
            return {
              id: w.id,
              name: o.workspace.name,
              role: w.role,
              clientOrganisationId: o.organisation!.id,
              organisationName: o.organisation!.name,
            };
          }),
        );
        const choose = (ids: string[]) => {
          if (ids.some((id) => !workspaces.some((w) => w.id === id)))
            throw new DataError("invalid");
          return workspaces.filter((w) => ids.includes(w.id));
        };
        return parseAccess(
          {
            application: c.application,
            platform: c.platform,
            workspaces,
            actor: { type: "human", subject: c.human.id },
            queen: c.partners.length
              ? {
                  partners: c.partners,
                  workspaces: choose(c.partners.flatMap((p) => p.workspaceIds)),
                }
              : null,
            client: c.clients.length
              ? {
                  workspaces: choose(c.clients.map((x) => x.workspaceId)),
                  memberships: c.clients,
                }
              : null,
          },
          c.human.id,
        );
      } catch (e) {
        if (e instanceof DataError) throw e;
        throw new DataError("invalid");
      }
    },
    async readWorkspace(p, w, signal) {
      try {
        await allowed(w, p, signal);
        const [o, b, i, t, c] = await Promise.all(
          ["overview", "brands", "integrations", "team", "capabilities"].map(
            (view) => read(root(w) + "/" + view, signal),
          ),
        );
        const ov = overviewSchema.parse(o);
        if (ov.workspace.id !== w) throw new DataError("invalid");
        const brands = z
          .object({ brands: z.array(brandSchema) })
          .parse(b).brands;
        const projected = await Promise.all(
          brands.map(async (b) => {
            if (b.workspaceId !== w) throw new DataError("invalid");
            const kits = z
              .object({ kits: z.array(kitSchema) })
              .parse(await read(root(w) + `/brands/${b.id}/kits`, signal)).kits;
            if (kits.some((k) => k.workspaceId !== w || k.brandId !== b.id))
              throw new DataError("invalid");
            const approved = kits.filter((k) => k.status === "approved");
            if (approved.length > 1) throw new DataError("invalid");
            const k = approved[0];
            return {
              id: b.id,
              workspaceId: w,
              organisationId: b.organisationId,
              name: b.name,
              ...(b.primaryDomain ? { primaryDomain: b.primaryDomain } : {}),
              ...(b.description ? { description: b.description } : {}),
              currentKit: k
                ? {
                    id: k.id,
                    workspaceId: w,
                    brandId: b.id,
                    status: "approved",
                    readiness: {
                      logo: k.assets.some(
                        (a) => a.type === "logo" && a.status === "approved",
                      ),
                      colours: k.colours.length > 0,
                      typography: k.typography.length > 0,
                      voice: Boolean(k.voice),
                      descriptions: Boolean(k.descriptions),
                      emailDefaults: Boolean(k.emailDefaults),
                    },
                    sections: [
                      {
                        title: "Brand guidance",
                        entries: [
                          ...(k.descriptions?.short
                            ? [
                                {
                                  label: "Description",
                                  value: k.descriptions.short,
                                },
                              ]
                            : []),
                          ...k.colours.map((x) => ({
                            label: x.name,
                            value: x.hex,
                          })),
                          ...k.typography.map((x) => ({
                            label: "Typeface",
                            value: x.family,
                          })),
                        ],
                      },
                    ],
                  }
                : null,
            };
          }),
        );
        const integrations = z
          .object({
            integrations: z.array(
              z.object({
                id: id("integration"),
                provider: label,
                displayName: label,
                status: z.enum([
                  "pending",
                  "connected",
                  "error",
                  "disconnected",
                ]),
              }),
            ),
          })
          .parse(i)
          .integrations.map((i) => ({ ...i, workspaceId: w }));
        const team = z
          .object({
            memberships: z.array(
              z.object({
                id: id("workspacemembership"),
                role: z.enum(["admin", "member"]),
                status: z.enum(["active", "ended"]),
              }),
            ),
          })
          .parse(t)
          .memberships.map((m) => ({
            id: m.id,
            workspaceId: w,
            displayName: "Workspace member",
            accessLabel: m.role,
            status: m.status,
          }));
        const instances = z
          .object({
            instances: z.array(
              z.object({
                id: id("capinstance"),
                capabilityId: id("capability"),
                status: label,
                access: z.boolean(),
              }),
            ),
            entitlements: z.array(z.object({ id: id("entitlement") })),
          })
          .parse(c)
          .instances.map((c) => ({
            id: c.id,
            workspaceId: w,
            name: c.capabilityId,
            status: c.status,
            entitlement: c.access ? "enabled" : "unavailable",
          }));
        return parseSnapshot(
          {
            workspaceId: w,
            identity: { primaryContact: null, partners: ov.partners },
            onboarding: {
              state: "in_progress",
              checks: [
                {
                  key: "identity",
                  status: "complete",
                  detail: "Workspace identity is registered.",
                },
                {
                  key: "brand",
                  status: projected.some((b) => b.currentKit)
                    ? "complete"
                    : "needs_attention",
                  detail: projected.some((b) => b.currentKit)
                    ? "An approved Brand Kit is available."
                    : "Prepare and approve a Brand Kit.",
                },
                {
                  key: "team",
                  status: team.some((m) => m.status === "active")
                    ? "complete"
                    : "needs_attention",
                  detail: "Review active workspace memberships.",
                },
                {
                  key: "integrations",
                  status: integrations.some((i) => i.status === "connected")
                    ? "complete"
                    : "pending",
                  detail: "Review which connections this workspace needs.",
                },
                {
                  key: "swarm",
                  status: "pending",
                  detail: "Capability configuration is managed by HVM.",
                },
              ],
            },
            brands: { state: "ready", items: projected },
            integrations: { state: "ready", items: integrations },
            team: { state: "ready", items: team },
            swarm: { state: "ready", items: instances },
            activity: { state: "unavailable" },
          },
          w,
        ) satisfies Snapshot;
      } catch (e) {
        if (e instanceof DataError) throw e;
        throw new DataError("invalid");
      }
    },
    psu: createPsuGateway(baseUrl, session, request),
    async provisionClient(partnerId, input, signal) {
      const selected = id("partner").parse(partnerId);
      const body = provisionInput.parse(input);
      const c = await context(signal);
      if (!c.partners.some((p) => p.id === selected && p.role === "owner"))
        throw new DataError("denied");
      const result = provisionResult.parse(
        await http(`/api/v1/hvm/partners/${selected}/clients`, signal, {
          method: "POST",
          body,
        }),
      );
      if (result.partnerId !== selected) throw new DataError("invalid");
      return result;
    },
    async readOnboarding(w, signal) {
      const c = await context(signal);
      if (!c.workspaces.some((x) => x.id === w)) throw new DataError("denied");
      return {
        overview: await overview(w, signal),
        brands: z
          .object({ brands: z.array(brandSchema) })
          .parse(await read(root(w) + "/brands", signal)).brands,
      };
    },
    async write(w, operation, payload, signal) {
      if (!operations.includes(operation)) throw new DataError("denied");
      return http(root(w) + "/" + operation, signal, {
        method: "POST",
        body: payload,
      });
    },
  };
}
