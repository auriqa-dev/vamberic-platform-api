import { z } from "zod";
import { canonicalId as id, EffectivenessBinding } from "./operating/models";
import { createTransport } from "./transport";
import { DataError } from "./gateway";
import type { AuthSession } from "../auth/session";
const key = z.string().regex(/^[a-z][a-z0-9_]{0,63}$/),
  hash = z.string().regex(/^[a-f0-9]{64}$/),
  version = z.number().int().positive();
export const targetSchema = z
  .object({
    kind: z.literal("workspace_agent"),
    id: hash,
    revision: version,
    workspaceId: id("workspace"),
    definition: z.object({ id: id("agentdefinition"), key, version }).strict(),
    implementation: z
      .object({ key, version, manifestDigest: hash, buildDigest: hash })
      .strict(),
  })
  .strict();
const optionSchema = z
  .object({
    name: z.string(),
    target: targetSchema,
    operation: key,
    profile: EffectivenessBinding,
    executionAvailable: z.boolean(),
    executionState: z.enum(["idle", "busy", "unavailable"]).optional(),
  })
  .strict();
export type PsuOption = z.infer<typeof optionSchema>;
const fieldBase = { key, label: z.string(), required: z.boolean() };
const fieldSchema = z.discriminatedUnion("type", [
  z
    .object({
      ...fieldBase,
      type: z.literal("text"),
      maxLength: z.number().int().min(1).max(4000),
    })
    .strict(),
  z
    .object({
      ...fieldBase,
      type: z.literal("choice"),
      options: z
        .array(z.object({ value: key, label: z.string() }).strict())
        .min(2)
        .max(20),
    })
    .strict(),
  z.object({ ...fieldBase, type: z.literal("boolean") }).strict(),
  z
    .object({
      ...fieldBase,
      type: z.literal("number"),
      minimum: z.number(),
      maximum: z.number(),
    })
    .strict(),
]);
const runSchema = z.object({
  id: id("agentrun"),
  workspaceId: id("workspace"),
  operation: key,
  status: z.enum([
    "queued",
    "running",
    "awaiting_input",
    "completed",
    "failed",
    "cancelled",
  ]),
  updatedAt: z.string().datetime(),
  terminalReason: z.string().optional(),
  input: z
    .object({
      id: z.string(),
      schemaKey: key,
      schemaVersion: version,
      question: z.string(),
      reason: z.string(),
      fields: z.array(fieldSchema).max(12),
      expiresAt: z.string().datetime(),
    })
    .strict()
    .optional(),
  factReview: z
    .array(
      z
        .object({
          key,
          target: z.enum([
            "whatCustomerBuys",
            "customerRole",
            "supplierRole",
            "explicitExclusions",
          ]),
          before: z.union([z.string(), z.array(z.string()), z.null()]),
          effect: z.enum(["append", "replace"]),
        })
        .strict(),
    )
    .max(3)
    .optional(),
});
export type PsuRun = z.infer<typeof runSchema>;
const proposal = z
  .object({
    id: z.string(),
    targetKind: z.string(),
    candidate: z.record(z.unknown()),
  })
  .passthrough();
const resultSchema = z.object({
  id: id("agentresult"),
  runId: id("agentrun"),
  updatedAt: z.string().datetime(),
  outcome: z.string(),
  completeness: z.discriminatedUnion("kind", [
    z.object({ kind: z.literal("complete") }).strict(),
    z
      .object({
        kind: z.literal("partial"),
        omissions: z.array(z.string()).min(1).max(40),
        reason: z.string(),
      })
      .strict(),
  ]),
  content: z
    .object({
      proposals: z.array(proposal),
      knowledgeGaps: z.array(z.unknown()),
      warnings: z.array(z.unknown()),
      findings: z.array(z.unknown()),
    })
    .passthrough(),
  dispositions: z.array(z.unknown()),
});
export type PsuResult = z.infer<typeof resultSchema>;
const caseSchema = z.object({
  id: id("effectivenesscase"),
  workspaceId: id("workspace"),
  rootRunId: id("agentrun"),
  activeRunId: id("agentrun").optional(),
  status: z.enum([
    "pending",
    "evaluating",
    "revising",
    "passed",
    "held",
    "escalated",
    "closed",
  ]),
  reason: key,
  stateRevision: version,
  allocations: z
    .array(
      z.object({
        runId: id("agentrun"),
        role: z.enum(["maker", "evaluator", "revision"]),
      }),
    )
    .max(11),
  candidates: z.array(z.unknown()).max(3),
  evaluations: z.array(z.unknown()).max(8),
  decisions: z.array(z.unknown()).max(16),
  criteria: z.unknown(),
  policy: z.unknown(),
});
const clarificationSchema = z
  .object({
    target: targetSchema,
    operation: key,
    request: z.record(z.unknown()),
    contractDigest: hash,
    assessments: z
      .array(z.object({ criterionId: key, digest: hash }).strict())
      .min(1)
      .max(15),
    support: z
      .array(
        z
          .object({
            evidenceId: z.string(),
            evidenceDigest: hash,
            field: z.enum(["claim", "excerpt", "candidate.value"]),
            start: z.number().int().min(0),
            excerpt: z.string().min(1).max(1500),
          })
          .strict(),
      )
      .min(1)
      .max(4),
    allocation: z
      .object({
        deadline: z.string().datetime(),
        modelCalls: z.literal(16),
        toolCalls: z.literal(6),
        providerCalls: z.array(
          z.object({ provider: key, calls: z.number().int() }),
        ),
        cost: z.object({ currency: z.literal("GBP"), amount: z.literal("1") }),
      })
      .strict(),
  })
  .strict();
export type PsuClarification = z.infer<typeof clarificationSchema>;
export type PsuCase = z.infer<typeof caseSchema>;
const offeringSchema = z.object({
  id: id("offering"),
  workspaceId: id("workspace"),
  updatedAt: z.string().datetime(),
  revision: version,
  status: z.enum(["draft", "approved", "retired"]),
  definition: z.record(z.unknown()),
});
export type PsuOffering = z.infer<typeof offeringSchema>;
export type PsuPreparation =
  | {
      mode: "create";
      brandId: string;
      workingLabel: string;
      orientation: string;
    }
  | {
      mode: "refresh";
      offeringId: string;
      expectedUpdatedAt: string;
      workingLabel: string;
      orientation: string;
    };
export function createPsuGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request);
  const root = (w: string) =>
    `/api/v1/hvm/workspaces/${id("workspace").parse(w)}`;
  const runPath = (r: string) =>
    `/api/v1/hvm/agent-runs/${id("agentrun").parse(r)}`;
  const casePath = (c: string) =>
    `/api/v1/hvm/agent-effectiveness-cases/${id("effectivenesscase").parse(c)}`;
  const scoped = <T extends { workspaceId: string }>(w: string, v: T) => {
    if (v.workspaceId !== w) throw new DataError("invalid");
    return v;
  };
  return {
    async options(w: string, s: AbortSignal) {
      const r = z
        .object({
          workspaceId: id("workspace"),
          items: z.array(optionSchema).max(600),
        })
        .strict()
        .parse(await http(root(w) + "/psu-options", s));
      scoped(w, r);
      for (const o of r.items) scoped(w, o.target);
      return r.items;
    },
    async brands(w: string, s: AbortSignal) {
      return z
        .object({
          brands: z.array(
            z.object({
              id: id("brand"),
              workspaceId: id("workspace"),
              name: z.string(),
            }),
          ),
        })
        .parse(await http(root(w) + "/brands", s))
        .brands.map((b) => scoped(w, b));
    },
    async offerings(w: string, s: AbortSignal) {
      const r = z
        .object({ items: z.array(offeringSchema), hasMore: z.boolean() })
        .parse(
          await http(root(w) + "/offerings", s, { query: { limit: 100 } }),
        );
      if (r.hasMore) throw new DataError("unavailable");
      return r.items.map((o) => scoped(w, o));
    },
    async cases(w: string, s: AbortSignal) {
      const r = z
        .object({ items: z.array(caseSchema), next: z.string().optional() })
        .parse(
          await http(root(w) + "/agent-effectiveness-cases", s, {
            query: { limit: 100 },
          }),
        );
      return { items: r.items.map((c) => scoped(w, c)), more: !!r.next };
    },
    async start(
      w: string,
      option: PsuOption,
      input: PsuPreparation,
      requestKey: string,
      s: AbortSignal,
    ) {
      scoped(w, option.target);
      return http(root(w) + "/agent-effectiveness-cases", s, {
        method: "POST",
        body: {
          target: targetSchema.parse(option.target),
          operation: option.operation,
          input,
          requestKey,
        },
      });
    },
    async readCase(w: string, c: string, s: AbortSignal) {
      const r = z
        .object({
          case: caseSchema,
          fresh: z.boolean(),
          clarification: clarificationSchema.optional(),
        })
        .parse(await http(casePath(c), s));
      scoped(w, r.case);
      if (r.clarification) scoped(w, r.clarification.target);
      if (r.case.id !== c) throw new DataError("invalid");
      return r;
    },
    async clarify(
      c: PsuCase,
      v: PsuClarification,
      slots: { key: string; target: string; gapId: string }[],
      supportIndexes: number[],
      requestKey: string,
      s: AbortSignal,
    ) {
      scoped(c.workspaceId, v.target);
      return http(root(c.workspaceId) + "/agent-effectiveness-cases", s, {
        method: "POST",
        body: {
          target: v.target,
          operation: v.operation,
          requestKey,
          predecessorCaseId: c.id,
          input: {
            ...v.request,
            uncertainty: {
              expectedRevision: c.stateRevision,
              gapKey: "product_knowledge",
              criterionIds: v.assessments.map((a) => a.criterionId),
              allocation: v.allocation,
              applicability: {
                contractDigest: v.contractDigest,
                slots,
                support: v.support,
                assessments: v.assessments,
                confirmations: Object.fromEntries(
                  [
                    "productRelevance",
                    "unresolvedKnowledge",
                    "selectedTargets",
                  ].map((key) => [key, { confirmed: true, supportIndexes }]),
                ),
              },
            },
          },
        },
      });
    },
    async run(w: string, r: string, s: AbortSignal) {
      const v = scoped(w, runSchema.parse(await http(runPath(r), s)));
      if (v.id !== r) throw new DataError("invalid");
      return v;
    },
    async results(r: string, s: AbortSignal) {
      return z
        .array(resultSchema)
        .max(100)
        .parse(await http(runPath(r) + "/results", s))
        .map((v) => {
          if (v.runId !== r) throw new DataError("invalid");
          return v;
        });
    },
    async answer(
      r: PsuRun,
      values: { key: string; value: string | number | boolean }[],
      s: AbortSignal,
    ) {
      if (!r.input) throw new DataError("invalid");
      return http(runPath(r.id) + "/input", s, {
        method: "POST",
        body: {
          expectedUpdatedAt: r.updatedAt,
          response: { requestId: r.input.id, values },
        },
      });
    },
    async cancelRun(r: PsuRun, s: AbortSignal) {
      return http(runPath(r.id) + "/cancel", s, {
        method: "POST",
        body: { expectedUpdatedAt: r.updatedAt },
      });
    },
    async followup(
      c: PsuCase,
      action: "revise" | "re-evaluate" | "hold" | "close",
      reason: string,
      requestKey: string,
      s: AbortSignal,
    ) {
      return http(
        casePath(c.id) +
          (["hold", "close"].includes(action) ? "/review" : "/" + action),
        s,
        {
          method: "POST",
          body: {
            expectedRevision: c.stateRevision,
            requestKey,
            reason,
            ...(["hold", "close"].includes(action) ? { action } : {}),
          },
        },
      );
    },
    async proposal(
      r: PsuResult,
      proposalId: string,
      action: "apply" | "reject",
      s: AbortSignal,
    ) {
      return http(runPath(r.runId) + "/proposals/" + action, s, {
        method: "POST",
        body: { resultId: r.id, proposalId, expectedUpdatedAt: r.updatedAt },
      });
    },
    async approve(w: string, o: PsuOffering, s: AbortSignal) {
      scoped(w, o);
      return http(root(w) + "/offerings/approve", s, {
        method: "POST",
        body: { id: o.id, expectedUpdatedAt: o.updatedAt },
      });
    },
  };
}
export type PsuGateway = ReturnType<typeof createPsuGateway>;
