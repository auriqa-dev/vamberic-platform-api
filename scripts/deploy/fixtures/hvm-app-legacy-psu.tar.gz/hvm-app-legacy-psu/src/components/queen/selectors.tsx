import { useCallback, useState } from "react";
import { useOperating } from "../../data/operating/context";
import { useResource } from "../../data/use-resource";
import { DataError } from "../../data/gateway";
import type {
  GlobalResource,
  OperatingModels,
} from "../../data/operating/models";
import { Loading } from "../ui";
import { OperatingFailure } from "../operating/feedback";
export function CatalogueSelect<R extends GlobalResource>({
  workspaceId,
  resource,
  label,
  selected,
  choose,
}: {
  workspaceId: string;
  resource: R;
  label: string;
  selected?: { id: string; version: number };
  choose: (row: OperatingModels[R]) => void;
}) {
  const api = useOperating();
  const load = useCallback(
    (signal: AbortSignal) =>
      api
        ? api.catalogue(workspaceId, resource, signal)
        : Promise.reject(new DataError("pending")),
    [api, workspaceId, resource],
  );
  const result = useResource(load);
  return (
    <section>
      <h3>{label}</h3>
      {selected && (
        <p>
          Selected: {selected.id} · v{selected.version}
        </p>
      )}
      {result.state === "loading" ? (
        <Loading label={`Loading ${label}…`} />
      ) : result.state === "error" ? (
        <OperatingFailure error={result.error} />
      ) : (
        <>
          {result.data.items.length === 0 ? (
            <p role="status">
              No {label.toLowerCase()} available. Empress has not yet made these
              operating definitions available.
            </p>
          ) : (
            <>
              <p>Available catalogue, bounded to 100 records by the server.</p>
              <label>
                {label}
                <select
                  value={selected?.id ?? ""}
                  onChange={(e) => {
                    const row = result.data.items.find(
                      (r) => r.id === e.target.value,
                    );
                    if (row) choose(row);
                  }}
                >
                  <option value="">Choose a definition</option>
                  {selected &&
                    !result.data.items.some(
                      (r) =>
                        r.id === selected.id && r.version === selected.version,
                    ) && (
                      <option value={selected.id}>
                        Historical reference · v{selected.version} · unavailable
                        for new selection
                      </option>
                    )}
                  {result.data.items.map((row) => (
                    <option key={row.id} value={row.id}>
                      {row.data.name} · v{row.version} · {row.status} ·{" "}
                      {row.availability}
                    </option>
                  ))}
                </select>
              </label>
            </>
          )}
        </>
      )}
    </section>
  );
}
export function AgentInstances({
  workspaceId,
  selected,
  change,
  exclude,
}: {
  workspaceId: string;
  selected: string[];
  change: (ids: string[]) => void;
  exclude?: string;
}) {
  const api = useOperating();
  const [offset, setOffset] = useState(0);
  const load = useCallback(
    (signal: AbortSignal) =>
      api
        ? api.list(
            { resource: "client_agents", workspaceId },
            { limit: 20, offset },
            signal,
          )
        : Promise.reject(new DataError("pending")),
    [api, workspaceId, offset],
  );
  const result = useResource(load);
  return (
    <section>
      <h3>Select Client Agents</h3>
      <p>
        Selected references retain their exact configured definition version.
      </p>
      <ul>
        {selected.map((id) => (
          <li key={id}>
            {id}{" "}
            <button
              type="button"
              onClick={() => change(selected.filter((x) => x !== id))}
            >
              Remove {id}
            </button>
          </li>
        ))}
      </ul>
      {result.state === "loading" ? (
        <Loading label="Loading Client Agents…" />
      ) : result.state === "error" ? (
        <OperatingFailure error={result.error} />
      ) : (
        <>
          {result.data.items.length === 0 && (
            <p>No Client Agents on this page.</p>
          )}
          {result.data.items
            .filter((r) => r.id !== exclude)
            .map((row) => (
              <label key={row.id}>
                <input
                  type="checkbox"
                  checked={selected.includes(row.id)}
                  disabled={
                    row.archived ||
                    (!selected.includes(row.id) && selected.length >= 40)
                  }
                  onChange={(e) =>
                    change(
                      e.target.checked
                        ? [...selected, row.id]
                        : selected.filter((id) => id !== row.id),
                    )
                  }
                />
                {row.data.name} · {row.status} · definition v
                {row.data.definition.version}
              </label>
            ))}
          <div className="form-actions">
            <button
              type="button"
              disabled={!offset}
              onClick={() => setOffset((n) => Math.max(0, n - 20))}
            >
              Previous Agents
            </button>
            <button
              type="button"
              disabled={!result.data.hasMore || offset >= 10000}
              onClick={() => setOffset((n) => n + 20)}
            >
              Next Agents
            </button>
          </div>
        </>
      )}
    </section>
  );
}
