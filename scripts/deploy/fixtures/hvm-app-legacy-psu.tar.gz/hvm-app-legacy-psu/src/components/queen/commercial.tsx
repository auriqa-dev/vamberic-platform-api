import { useCallback, useState } from "react";
import { Link, Route, Routes, useParams } from "react-router-dom";
import { useOperating } from "../../data/operating/context";
import { useResource } from "../../data/use-resource";
import { useOperatingRecord } from "../../data/operating/use-record";
import { DataError } from "../../data/gateway";
import {
  RecommendationInput,
  DecisionInput,
  type ClientSwarm,
  type CommercialPolicy,
  type PricingRecommendation,
  type SwarmAgreement,
} from "../../data/operating/models";
import { Loading } from "../ui";
import { OperatingFailure } from "../operating/feedback";
import { DraftForm, field, Lifecycle, Fields } from "./shared";
import { CatalogueSelect } from "./selectors";
import {
  formatMoney,
  moneyInput,
  percentInput,
  parseMoney,
  parsePercent,
} from "../../forms/commercial-values";
import { resourceFields, type Field } from "../operating/fields";
import type { Values } from "../operating/form-fields";
import { z } from "zod";
const economicFields = [
  field("expectedOperatingMonthlyMinor", "Expected monthly operating cost", {
    kind: "money",
    currencyKey: "currency",
  }),
  field("recommendedOnboardingMinor", "Recommended onboarding", {
    kind: "money",
    currencyKey: "currency",
  }),
  field("recommendedMonthlyMinor", "Recommended monthly", {
    kind: "money",
    currencyKey: "currency",
  }),
  field("recommendedAnnualMinor", "Recommended annual", {
    kind: "money",
    currencyKey: "currency",
  }),
  {
    ...resourceFields.agent_definitions.find((f) => f.key === "costDrivers")!,
    key: "costInputs",
    label: "Economic cost inputs",
  },
  field("assumptions", "Assumptions", { kind: "strings", max: 40 }),
  field("rationale", "Recommendation rationale", { kind: "textarea" }),
  field("uncertainty", "Uncertainty", { kind: "strings", max: 40 }),
  field("sourceReferences", "Source references", {
    kind: "strings",
    max: 30,
    maxLength: 1000,
  }),
];
export function QueenCommercial({
  workspaceId,
  swarm,
  base,
}: {
  workspaceId: string;
  swarm: ClientSwarm;
  base: string;
}) {
  return (
    <>
      <h2>Commercial & Agreements</h2>
      <p>
        Explicit economic inputs → recommendation → Queen decision → Agreement →
        independent Empress approval where required.
      </p>
      <p>Payment and execution are separate future concerns.</p>
      <Routes>
        <Route
          index
          element={
            <CommercialList
              workspaceId={workspaceId}
              swarm={swarm}
              base={base}
            />
          }
        />
        <Route
          path="recommendations/new"
          element={
            <RecommendationCreate
              workspaceId={workspaceId}
              swarm={swarm}
              base={base}
            />
          }
        />
        <Route
          path="recommendations/:id"
          element={
            <CommercialDetail
              workspaceId={workspaceId}
              swarm={swarm}
              base={base}
              kind="pricing_recommendations"
            />
          }
        />
        <Route
          path="agreements/:id"
          element={
            <CommercialDetail
              workspaceId={workspaceId}
              swarm={swarm}
              base={base}
              kind="swarm_agreements"
            />
          }
        />
      </Routes>
    </>
  );
}
function CommercialList({
  workspaceId,
  swarm,
  base,
}: {
  workspaceId: string;
  swarm: ClientSwarm;
  base: string;
}) {
  return (
    <>
      <Link className="button" to={`${base}/recommendations/new`}>
        Record Pricing Recommendation
      </Link>
      <ArtifactList
        workspaceId={workspaceId}
        swarm={swarm}
        base={base}
        kind="pricing_recommendations"
      />
      <ArtifactList
        workspaceId={workspaceId}
        swarm={swarm}
        base={base}
        kind="swarm_agreements"
      />
    </>
  );
}
function ArtifactList({
  workspaceId,
  swarm,
  base,
  kind,
}: {
  workspaceId: string;
  swarm: ClientSwarm;
  base: string;
  kind: "pricing_recommendations" | "swarm_agreements";
}) {
  const api = useOperating()!;
  const [offset, setOffset] = useState(0);
  const load = useCallback(
    (signal: AbortSignal) =>
      api.list(
        { workspaceId, resource: kind },
        { swarmId: swarm.id, limit: 20, offset },
        signal,
      ),
    [api, workspaceId, kind, swarm.id, offset],
  );
  const result = useResource(load);
  const label =
    kind === "pricing_recommendations"
      ? "Pricing Recommendations"
      : "Swarm Agreements";
  return (
    <section>
      <h3>{label}</h3>
      {result.state === "loading" ? (
        <Loading label={`Loading ${label}…`} />
      ) : result.state === "error" ? (
        <OperatingFailure error={result.error} />
      ) : (
        <>
          {!result.data.items.length && (
            <p>No {label.toLowerCase()} on this page.</p>
          )}
          <ul>
            {result.data.items.map((row) => {
              const snapshot =
                "configurationSnapshot" in row.data
                  ? row.data.configurationSnapshot
                  : row.data.recommendationSnapshot.configurationSnapshot;
              return (
                <li key={row.id}>
                  <Link
                    to={`${base}/${kind === "pricing_recommendations" ? "recommendations" : "agreements"}/${row.id}`}
                  >
                    {row.id}
                  </Link>{" "}
                  · {row.status} · snapshot revision {snapshot.swarmRevision}
                  {snapshot.swarmRevision !== swarm.revision
                    ? " · Historical Swarm configuration"
                    : ""}
                </li>
              );
            })}
          </ul>
          <button
            disabled={!offset}
            onClick={() => setOffset((n) => Math.max(0, n - 20))}
          >
            Previous {label}
          </button>
          <button
            disabled={!result.data.hasMore || offset >= 10000}
            onClick={() => setOffset((n) => n + 20)}
          >
            Next {label}
          </button>
        </>
      )}
    </section>
  );
}
function RecommendationCreate({
  workspaceId,
  swarm,
  base,
}: {
  workspaceId: string;
  swarm: ClientSwarm;
  base: string;
}) {
  const api = useOperating()!;
  const [policy, setPolicy] = useState<CommercialPolicy>();
  return (
    <>
      <Link to={base}>← Commercial</Link>
      <h3>Record Pricing Recommendation</h3>
      <p>
        Enter reviewed economic assumptions and recommended prices. HVM does not
        generate an AI price. The server validates readiness and freezes the
        configuration and policy snapshots.
      </p>
      {swarm.status !== "configured" ? (
        <p>
          Configure the Swarm successfully before recording a recommendation.
        </p>
      ) : (
        <DraftForm
          initial={{
            swarmId: swarm.id,
            currency: "GBP",
            costInputs: [],
            expectedOperatingMonthlyMinor: "",
            recommendedOnboardingMinor: "",
            recommendedMonthlyMinor: "",
            recommendedAnnualMinor: "",
            assumptions: [],
            rationale: "",
            uncertainty: [],
            sourceReferences: [],
          }}
          schema={RecommendationInput.extend({ currency: z.string() })}
          fields={economicFields}
          label="Record recommendation"
          save={async (value, signal) => {
            if (!policy) throw new DataError("invalid");
            const { currency, ...data } = value;
            void currency;
            const row = await api.workspaceCreate(
              workspaceId,
              "pricing_recommendations",
              data,
              signal,
            );
            return `${base}/recommendations/${row.id}`;
          }}
        >
          {(value, change) => (
            <>
              <CatalogueSelect
                workspaceId={workspaceId}
                resource="commercial_policies"
                label="Commercial Policies"
                selected={
                  policy
                    ? { id: policy.id, version: policy.version }
                    : undefined
                }
                choose={(row) => {
                  setPolicy(row);
                  change({
                    ...value,
                    currency: row.data.currency,
                    policy: { id: row.id, version: row.version },
                  });
                }}
              />
              {policy && (
                <PolicyReview
                  policy={policy.data}
                  id={policy.id}
                  version={policy.version}
                />
              )}
            </>
          )}
        </DraftForm>
      )}
    </>
  );
}
function CommercialDetail({
  workspaceId,
  swarm,
  base,
  kind,
}: {
  workspaceId: string;
  swarm: ClientSwarm;
  base: string;
  kind: "pricing_recommendations" | "swarm_agreements";
}) {
  const { id = "" } = useParams();
  return (
    <ArtifactResource
      key={`${kind}:${id}`}
      {...{ workspaceId, swarm, base, kind, id }}
    />
  );
}
function ArtifactResource({
  workspaceId,
  swarm,
  base,
  kind,
  id,
}: {
  workspaceId: string;
  swarm: ClientSwarm;
  base: string;
  kind: "pricing_recommendations" | "swarm_agreements";
  id: string;
}) {
  const api = useOperating()!;
  const load = useCallback(
    async (signal: AbortSignal) => {
      const row = await api.detail({ workspaceId, resource: kind }, id, signal);
      if (row.data.swarmId !== swarm.id) throw new DataError("denied");
      return row;
    },
    [api, workspaceId, kind, id, swarm.id],
  );
  const resource = useOperatingRecord(load);
  if (!resource.data)
    return resource.error ? (
      <OperatingFailure error={resource.error} />
    ) : (
      <Loading label="Loading commercial artifact…" />
    );
  const row = resource.data;
  return (
    <>
      <Link to={base}>← Commercial</Link>
      <p>
        {row.id} · {row.status}
      </p>
      <button onClick={() => void resource.refresh()}>
        Refresh commercial state
      </button>
      {resource.error && <OperatingFailure error={resource.error} />}
      {kind === "pricing_recommendations" ? (
        <RecommendationReview
          row={row as PricingRecommendation}
          swarm={swarm}
        />
      ) : (
        <AgreementReview row={row as SwarmAgreement} swarm={swarm} />
      )}
      {kind === "pricing_recommendations" && row.status === "recorded" && (
        <DecisionForm
          row={row as PricingRecommendation}
          workspaceId={workspaceId}
          base={base}
        />
      )}
      {!row.archived && (
        <Lifecycle
          actions={[
            "retire",
            ...(["recorded", "approved"].includes(row.status)
              ? ["supersede"]
              : []),
            ...(kind === "swarm_agreements" &&
            row.status === "proposed" &&
            "policyResult" in row.data &&
            row.data.policyResult === "within_policy"
              ? ["approve"]
              : []),
          ]}
          run={async (action, signal) => {
            resource.accept(
              await api.workspaceLifecycle(
                workspaceId,
                kind,
                action as "retire" | "supersede" | "approve",
                { id: row.id, expectedUpdatedAt: row.updatedAt },
                signal,
              ),
            );
            await resource.refresh();
          }}
        />
      )}
    </>
  );
}
function Economics({ data }: { data: PricingRecommendation["data"] }) {
  return (
    <>
      <h3>Recorded recommendation</h3>
      <dl>
        {Object.entries({
          "Expected monthly operating cost": data.expectedOperatingMonthlyMinor,
          "Recommended onboarding": data.recommendedOnboardingMinor,
          "Recommended monthly": data.recommendedMonthlyMinor,
          "Recommended annual": data.recommendedAnnualMinor,
        }).map(([k, v]) => (
          <div key={k}>
            <dt>{k}</dt>
            <dd>{formatMoney(v, data.currency)}</dd>
          </div>
        ))}
      </dl>
      <p>
        Recommended margin:{" "}
        {data.monthlyMargin === null
          ? "Undefined"
          : `${data.monthlyMargin * 100}%`}
      </p>
      <p>{data.rationale}</p>
      {(["assumptions", "uncertainty", "sourceReferences"] as const).map(
        (k) => (
          <section key={k}>
            <h4>{k}</h4>
            <ul>
              {data[k].map((v, i) => (
                <li key={i}>{v}</li>
              ))}
            </ul>
          </section>
        ),
      )}
      <ul>
        {data.costInputs.map((c) => (
          <li key={c.key}>
            {c.name} · {c.description} · {c.expectedQuantity ?? "Unspecified"}{" "}
            {c.unit}{" "}
            {c.unitCost
              ? formatMoney(c.unitCost.amountMinor, c.unitCost.currency)
              : ""}
          </li>
        ))}
      </ul>
    </>
  );
}
function Lineage({
  snapshot,
  swarm,
}: {
  snapshot: PricingRecommendation["data"]["configurationSnapshot"];
  swarm: ClientSwarm;
}) {
  const api = useOperating()!;
  const ids = JSON.stringify(snapshot.agents.map((a) => a.id));
  const load = useCallback(
    async (signal: AbortSignal) => {
      const selected = JSON.parse(ids) as string[];
      return Promise.allSettled(
        selected.map((id) =>
          api.detail(
            { workspaceId: swarm.workspaceId, resource: "client_agents" },
            id,
            signal,
          ),
        ),
      );
    },
    [api, ids, swarm.workspaceId],
  );
  const current = useOperatingRecord(load);
  const changed = current.data?.some(
    (r, i) =>
      r.status === "fulfilled" &&
      (r.value.revision !== snapshot.agents[i]?.revision || r.value.archived),
  );
  return (
    <section className="notice">
      <h3>Frozen configuration</h3>
      {current.loading ? (
        <p role="status">Comparing current Agent revisions…</p>
      ) : current.error ||
        current.data?.some((r) => r.status === "rejected") ? (
        <p role="status">
          Current Agent revisions could not all be verified. These recorded
          economics refer only to the frozen configuration below.
        </p>
      ) : changed ? (
        <p role="status">
          Historical Agent configuration: at least one Agent changed or is no
          longer available. This artifact does not price the current
          configuration.
        </p>
      ) : (
        <p>Recorded Agent revisions match the current accessible records.</p>
      )}
      <p>
        {snapshot.swarm.name} · {snapshot.swarmId} · revision{" "}
        {snapshot.swarmRevision}
      </p>
      <p>
        {snapshot.swarmRevision !== swarm.revision
          ? "Historical Swarm configuration: the current Swarm revision differs."
          : "Swarm revision matches. Agent configuration revisions are recorded separately below; this snapshot remains historical economics."}
      </p>
      <ul>
        {snapshot.agents.map((a) => (
          <li key={a.id}>
            {a.configuration.name} · Agent revision {a.revision} · definition{" "}
            {a.configuration.definition.id} v
            {a.configuration.definition.version}
            <ul>
              {a.configuration.bindings.map((b) => (
                <li key={`${b.slot}:${b.integrationId}`}>
                  {b.slot} · {b.costTreatment.replaceAll("_", " ")} · provider{" "}
                  {b.provider.id} v{b.provider.version} ·{" "}
                  {b.expectedQuantity ?? "Unspecified quantity"} {b.unit ?? ""}
                  {b.costAssumption
                    ? ` · cost ${formatMoney(b.costAssumption.amountMinor, b.costAssumption.currency)}`
                    : ""}{" "}
                  · allowance {b.allowance ?? "unspecified"} ·{" "}
                  {b.overageAssumption ?? "No overage assumption"}
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </section>
  );
}
function RecommendationReview({
  row,
  swarm,
}: {
  row: PricingRecommendation;
  swarm: ClientSwarm;
}) {
  return (
    <>
      <Lineage snapshot={row.data.configurationSnapshot} swarm={swarm} />
      <Economics data={row.data} />
      <PolicyReview
        policy={row.data.policySnapshot}
        id={row.data.policy.id}
        version={row.data.policy.version}
      />
    </>
  );
}
function PolicyReview({
  policy,
  id,
  version,
}: {
  policy: CommercialPolicy["data"];
  id: string;
  version: number;
}) {
  const p = policy;
  return (
    <section className="panel">
      <h3>
        {p.name} · v{version}
      </h3>
      <p>
        {id} · {p.currency} · Effective {p.effectiveFrom} to{" "}
        {p.effectiveUntil ?? "open-ended"}
      </p>
      <p>
        Target margin {percentInput(p.targetMargin)}% · minimum{" "}
        {percentInput(p.minimumMargin)}% · annual discount guidance{" "}
        {percentInput(p.annualDiscount)}%
      </p>
      <p>
        Queen discount limit {percentInput(p.maximumQueenDiscount)}% · fixed{" "}
        {formatMoney(p.maximumQueenFixedDiscountMinor, p.currency)} · minimum
        monthly {formatMoney(p.minimumMonthlyPriceMinor, p.currency)}
      </p>
      <p>
        Custom price {p.allowCustomPrice ? "permitted" : "requires escalation"}{" "}
        · permitted treatments: {p.permittedQueenTreatments.join(", ")}
      </p>
      <p>{p.usagePolicy}</p>
      <p>{p.overagePolicy}</p>
      <p>{p.internalTreatmentGuidance}</p>
      <p>{p.promotionalTreatmentGuidance}</p>
    </section>
  );
}
function DecisionForm({
  row,
  workspaceId,
  base,
}: {
  row: PricingRecommendation;
  workspaceId: string;
  base: string;
}) {
  const api = useOperating()!;
  const [review, setReview] = useState(false);
  const initial = {
    recommendationId: row.id,
    treatment: "standard",
    adjustment: { kind: "accept" },
    reason: "",
    onboarding: moneyInput(
      row.data.recommendedOnboardingMinor,
      row.data.currency,
    ),
    commitment: { kind: "monthly", months: 1, renewal: "review" },
    billingFrequency: "monthly",
    effectiveFrom: "",
    effectiveUntil: "",
    usageAllowances: [],
    overageAssumptions: [],
    commercialNotes: [],
  };
  const fields: Field[] = [
    field("treatment", "Commercial treatment", {
      kind: "select",
      options: ["standard", "bundled", "promotional", "internal", "waived"],
    }),
    field("reason", "Commercial decision reason", { kind: "textarea" }),
    field("onboarding", "Final onboarding amount"),
    field("commitment", "Commitment", {
      kind: "group",
      fields: [
        field("kind", "Commitment term", {
          kind: "select",
          options: ["monthly", "annual", "custom"],
        }),
        field("months", "Commitment months", {
          kind: "number",
          min: 1,
          max: 120,
        }),
        field("renewal", "Renewal", {
          kind: "select",
          options: ["none", "review", "renew"],
        }),
      ],
    }),
    field("billingFrequency", "Billing frequency", {
      kind: "select",
      options: ["monthly", "annual"],
    }),
    field("effectiveFrom", "Effective from (UTC ISO date/time)"),
    field("effectiveUntil", "Effective until (UTC ISO date/time)", {
      optional: true,
    }),
    field("usageAllowances", "Usage allowances", { kind: "strings", max: 40 }),
    field("overageAssumptions", "Overage assumptions", {
      kind: "strings",
      max: 40,
    }),
    field("commercialNotes", "Commercial notes", { kind: "strings", max: 40 }),
  ];
  const schema = z
    .custom<Values>((v) => typeof v === "object" && v !== null)
    .transform((v, ctx) => {
      try {
        const { onboarding, ...data } = v;
        const a = v.adjustment as Values;
        return DecisionInput.parse({
          ...data,
          onboardingMinor: parseMoney(String(onboarding), row.data.currency),
          adjustment: {
            kind: a.kind,
            ...(a.kind === "percentage_discount"
              ? { percentage: parsePercent(String(a.percentage)) }
              : {}),
            ...(["fixed_discount", "custom"].includes(String(a.kind))
              ? {
                  amountMinor: parseMoney(
                    String(a.amountMinor),
                    row.data.currency,
                  ),
                }
              : {}),
          },
        });
      } catch {
        ctx.addIssue({
          code: "custom",
          message:
            "Check adjustment, money, term months and UTC effectivity. Internal/waived requires zero onboarding.",
        });
        return z.NEVER;
      }
    });
  return (
    <section>
      <h3>Queen commercial decision</h3>
      <p>
        The backend determines final amounts and whether independent Empress
        approval is required. Internal and waived preserve economic value and
        bill zero; enter zero onboarding. Promotional does not automatically
        mean free. Annual commitment can be billed monthly or annually.
      </p>
      <DraftForm
        onChange={() => setReview(false)}
        initial={initial}
        schema={schema}
        fields={fields}
        label="Propose Agreement"
        save={async (value, signal) => {
          if (!review) {
            throw new DataError("invalid");
          }
          const saved = await api.workspaceCreate(
            workspaceId,
            "swarm_agreements",
            value,
            signal,
          );
          return `${base}/agreements/${saved.id}`;
        }}
      >
        {(value, change) => (
          <>
            <Fields
              value={value}
              change={(v) => {
                setReview(false);
                change(v);
              }}
              fields={[
                field("adjustment", "Queen adjustment", {
                  kind: "group",
                  fields: [
                    field("kind", "Adjustment type", {
                      kind: "select",
                      options: [
                        "accept",
                        "percentage_discount",
                        "fixed_discount",
                        "custom",
                      ],
                    }),
                    ...((value.adjustment as Values).kind ===
                    "percentage_discount"
                      ? [field("percentage", "Discount percentage")]
                      : []),
                    ...(["fixed_discount", "custom"].includes(
                      String((value.adjustment as Values).kind),
                    )
                      ? [
                          field(
                            "amountMinor",
                            "Discount / custom recurring amount",
                          ),
                        ]
                      : []),
                  ],
                }),
              ]}
            />
            <p>
              Review the terms above before proposing. Recommendation {row.id}{" "}
              stays unchanged.
            </p>
            <label>
              <input
                type="checkbox"
                checked={review}
                onChange={(e) => setReview(e.target.checked)}
              />
              I have reviewed this commercial proposal.
            </label>
          </>
        )}
      </DraftForm>
    </section>
  );
}
function AgreementReview({
  row,
  swarm,
}: {
  row: SwarmAgreement;
  swarm: ClientSwarm;
}) {
  const d = row.data,
    decision = d.decision;
  return (
    <>
      <h3>Swarm Agreement</h3>
      <Lineage
        snapshot={d.recommendationSnapshot.configurationSnapshot}
        swarm={swarm}
      />
      <Economics data={d.recommendationSnapshot} />
      <p>Treatment: {decision.treatment}</p>
      <p>
        Queen adjustment: {decision.adjustment.kind.replaceAll("_", " ")}{" "}
        {decision.adjustment.percentage !== undefined
          ? `${percentInput(decision.adjustment.percentage)}%`
          : ""}{" "}
        {decision.adjustment.amountMinor !== undefined
          ? formatMoney(decision.adjustment.amountMinor, d.currency)
          : ""}
      </p>
      <p>Decision reason: {decision.reason}</p>
      <p>
        Final onboarding: {formatMoney(decision.onboardingMinor, d.currency)}
      </p>
      <p>
        Final recurring: {formatMoney(d.finalRecurringMinor, d.currency)} /{" "}
        {decision.billingFrequency}
      </p>
      <p>
        Monthly equivalent:{" "}
        {formatMoney(d.finalMonthlyEquivalentMinor, d.currency)}
      </p>
      <p>
        Commitment: {decision.commitment.kind} · {decision.commitment.months}{" "}
        months · renewal {decision.commitment.renewal}
      </p>
      <p>
        Effective {decision.effectiveFrom} to{" "}
        {decision.effectiveUntil ?? "open-ended"}
      </p>
      <p role="status">
        {d.policyResult === "requires_empress_approval"
          ? "Requires Empress approval — your decision is preserved awaiting independent review."
          : d.policyResult === "approved_by_empress"
            ? "Empress approved"
            : "Within policy"}
      </p>
      <ul>
        {d.policyReasons.map((r) => (
          <li key={r}>{r.replaceAll("_", " ")}</li>
        ))}
      </ul>
      {d.empressApproval && (
        <p>
          Empress approval: {d.empressApproval.reason} · {d.empressApproval.at}
        </p>
      )}
      {(
        ["usageAllowances", "overageAssumptions", "commercialNotes"] as const
      ).map((k) => (
        <section key={k}>
          <h4>{k}</h4>
          <ul>
            {decision[k].map((v, i) => (
              <li key={i}>{v}</li>
            ))}
          </ul>
        </section>
      ))}
      <p>
        Proposals are immutable. Retire a pending proposal to replace it;
        supersession applies to approved Agreements. The server prevents
        overlapping approved periods.
      </p>
      <p>Commercial approval does not record payment or start execution.</p>
    </>
  );
}
