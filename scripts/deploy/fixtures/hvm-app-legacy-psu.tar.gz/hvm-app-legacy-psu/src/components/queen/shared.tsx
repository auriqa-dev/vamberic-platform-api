import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { Link, useNavigate } from "react-router-dom";
import { z } from "zod";
import { DataError } from "../../data/gateway";
import { NavigationWarning } from "../../forms/navigation-warning";
import { useDraft } from "../../forms/use-draft";
import { OperatingFailure } from "../operating/feedback";
import {
  FormFields,
  toPayload,
  writePath,
  type Values,
} from "../operating/form-fields";
import type { Field } from "../operating/fields";
const DirtyContext = createContext<{
  dirty: boolean;
  setDirty: (dirty: boolean) => void;
}>({ dirty: false, setDirty: () => {} });
export function EditorBoundary({ children }: { children: ReactNode }) {
  const [dirty, setDirty] = useState(false);
  return (
    <DirtyContext.Provider value={{ dirty, setDirty }}>
      {children}
    </DirtyContext.Provider>
  );
}
export const field = (
  key: string,
  label: string,
  extra: Partial<Field> = {},
): Field => ({ key, label, ...extra });
export function Fields({
  fields,
  value,
  change,
  errors = {},
  scope,
}: {
  fields: Field[];
  value: Values;
  change: (value: Values) => void;
  errors?: Record<string, string>;
  scope?: string;
}) {
  return (
    <FormFields
      fields={fields}
      values={scope ? { [scope]: value } : value}
      prefix={scope ?? ""}
      errors={errors}
      change={(path, v) =>
        change(
          scope
            ? writePath({ [scope]: value }, path, v)[scope]!
            : writePath(value, path, v),
        )
      }
      choose={() => {}}
    />
  );
}
export function DraftForm<T>({
  initial,
  schema,
  fields = [],
  save,
  children,
  label = "Save configuration",
  onChange,
}: {
  initial: Values;
  schema: z.ZodType<T, z.ZodTypeDef, unknown>;
  fields?: Field[];
  save: (value: T, signal: AbortSignal) => Promise<void | string>;
  children?: (value: Values, change: (value: Values) => void) => ReactNode;
  label?: string;
  onChange?: () => void;
}) {
  const navigate = useNavigate();
  const [destination, setDestination] = useState<string>();
  useEffect(() => {
    if (destination) void navigate(destination);
  }, [destination, navigate]);
  const draft = useDraft(initial);
  const { setDirty } = useContext(DirtyContext);
  useEffect(() => {
    setDirty(draft.dirty);
    return () => setDirty(false);
  }, [draft.dirty, setDirty]);
  const [error, setError] = useState<unknown>();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);
  const [denied, setDenied] = useState(false);
  const controller = useRef<AbortController | undefined>(undefined);
  useEffect(() => () => controller.current?.abort(), []);
  if (denied) return <OperatingFailure error={new DataError("denied")} />;
  return (
    <>
      <NavigationWarning dirty={draft.dirty} />
      {error && <OperatingFailure error={error} />}{" "}
      {draft.conflict && (
        <p role="alert">
          Server state changed. Your draft is preserved. Discard to adopt the
          latest server baseline before saving.
        </p>
      )}
      {saved && <p role="status">Saved successfully.</p>}
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          if (busy || draft.conflict) return;
          const issues: Record<string, string> = {};
          const payload = toPayload(fields, draft.draft, "", issues);
          const result = schema.safeParse(payload);
          if (!result.success)
            for (const issue of result.error.issues)
              issues[issue.path.join(".")] = issue.message;
          if (!result.success || Object.keys(issues).length) {
            setErrors(issues);
            setError(new DataError("invalid"));
            return;
          }
          setErrors({});
          setBusy(true);
          setError(undefined);
          setSaved(false);
          const c = new AbortController();
          controller.current = c;
          try {
            const path = await save(result.data, c.signal);
            if (!c.signal.aborted) {
              draft.saved(draft.draft);
              setSaved(true);
              if (path) setDestination(path);
            }
          } catch (err) {
            if (c.signal.aborted) return;
            if (err instanceof DataError && err.code === "denied") {
              setDenied(true);
              return;
            }
            setError(err);
            if (err instanceof DataError && err.code === "conflict")
              draft.markConflict();
          } finally {
            if (!c.signal.aborted) setBusy(false);
          }
        }}
      >
        {Object.keys(errors).length > 0 && (
          <div role="alert">
            <p>Review these fields:</p>
            <ul>
              {Object.entries(errors).map(([k, v]) => (
                <li key={k}>
                  {k || "Form"}: {v}
                </li>
              ))}
            </ul>
          </div>
        )}
        <fieldset disabled={busy}>
          <Fields
            fields={fields}
            value={draft.draft}
            errors={errors}
            change={(v) => {
              onChange?.();
              draft.edit(v);
              setSaved(false);
            }}
          />
          {children?.(draft.draft, (v) => {
            onChange?.();
            draft.edit(v);
            setSaved(false);
          })}
        </fieldset>
        <div className="form-actions">
          <button className="button" disabled={busy || draft.conflict}>
            {label}
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={() => {
              draft.reset();
              setError(undefined);
              setErrors({});
            }}
          >
            Discard changes
          </button>
        </div>
      </form>
    </>
  );
}
export function Lifecycle({
  actions,
  run,
}: {
  actions: string[];
  run: (action: string, signal: AbortSignal) => Promise<void>;
}) {
  const { dirty } = useContext(DirtyContext);
  const [action, setAction] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState<unknown>(),
    [denied, setDenied] = useState(false),
    [saved, setSaved] = useState(false);
  const ref = useRef<AbortController | undefined>(undefined);
  useEffect(() => () => ref.current?.abort(), []);
  if (denied) return <OperatingFailure error={new DataError("denied")} />;
  return (
    <>
      {error && <OperatingFailure error={error} />}{" "}
      {saved && <p role="status">Lifecycle change saved.</p>}
      {dirty && (
        <p>
          Save or discard your draft before changing lifecycle or Swarm
          membership.
        </p>
      )}
      <div className="form-actions">
        {actions.map((a) => (
          <button
            className="button secondary"
            key={a}
            disabled={busy || dirty}
            onClick={() => {
              setAction(a);
              setSaved(false);
            }}
          >
            {a}
          </button>
        ))}
      </div>
      {action && (
        <section className="notice" aria-label="Confirm lifecycle change">
          <h2>Confirm {action}</h2>
          <p>
            {action === "configure"
              ? "The server will validate this configuration. Configuration does not start execution."
              : action === "approve"
                ? "Approve this commercial agreement. Payment and execution remain separate."
                : action === "retire"
                  ? "Retain history and make this record unavailable for new configuration."
                  : "Preserve this artifact as superseded history."}
          </p>
          <button
            autoFocus
            disabled={busy || dirty}
            onClick={async () => {
              setBusy(true);
              setError(undefined);
              const c = new AbortController();
              ref.current = c;
              try {
                await run(action, c.signal);
                if (!c.signal.aborted) {
                  setAction("");
                  setSaved(true);
                }
              } catch (e) {
                if (!c.signal.aborted) {
                  if (e instanceof DataError && e.code === "denied")
                    setDenied(true);
                  setError(e);
                }
              } finally {
                if (!c.signal.aborted) setBusy(false);
              }
            }}
          >
            Confirm {action}
          </button>
          <button disabled={busy || dirty} onClick={() => setAction("")}>
            Cancel
          </button>
        </section>
      )}
    </>
  );
}
export function Back({ root }: { root: string }) {
  return <Link to={root}>← Client Swarms</Link>;
}
