import { moneyInput, parseMoney } from "../../forms/commercial-values";
import { useCallback, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { z } from "zod";
import { useOperating } from "../../data/operating/context";
import { useOperatingRecord } from "../../data/operating/use-record";
import { useResource } from "../../data/use-resource";
import { DataError } from "../../data/gateway";
import {
  ClientAgentData,
  type ClientAgent,
  type ClientSwarm,
  type AgentDefinition,
  type IntegrationProvider,
} from "../../data/operating/models";
import { Loading } from "../ui";
import { OperatingFailure } from "../operating/feedback";
import { DraftForm, Fields, field, Lifecycle } from "./shared";
import { CatalogueSelect, AgentInstances } from "./selectors";
import type { Values } from "../operating/form-fields";
import type { Field } from "../operating/fields";
export function QueenAgentPage(props: {
  workspaceId: string;
  swarm: ClientSwarm;
  base: string;
  refreshSwarm: () => Promise<void>;
}) {
  const { agentId = "" } = useParams();
  return <AgentResource key={agentId} {...props} id={agentId} />;
}
function AgentResource({
  workspaceId,
  swarm,
  base,
  id,
  refreshSwarm,
}: {
  workspaceId: string;
  swarm: ClientSwarm;
  base: string;
  id: string;
  refreshSwarm: () => Promise<void>;
}) {
  const api = useOperating()!;
  const creating = id === "new";
  const load = useCallback(
    (signal: AbortSignal) =>
      creating
        ? Promise.resolve(null)
        : api.detail({ workspaceId, resource: "client_agents" }, id, signal),
    [api, workspaceId, id, creating],
  );
  const resource = useOperatingRecord(load);
  if (resource.data === undefined)
    return resource.error ? (
      <OperatingFailure error={resource.error} />
    ) : (
      <Loading label="Loading Client Agent…" />
    );
  return (
    <AgentEditor
      workspaceId={workspaceId}
      swarm={swarm}
      base={base}
      row={resource.data ?? undefined}
      accept={resource.accept}
      refresh={resource.refresh}
      refreshSwarm={refreshSwarm}
    />
  );
}
const agentFields = [field("name", "Client Agent name", { maxLength: 200 })];
function AgentEditor({
  workspaceId,
  swarm,
  base,
  row,
  accept,
  refresh,
  refreshSwarm,
}: {
  workspaceId: string;
  swarm: ClientSwarm;
  base: string;
  row?: ClientAgent;
  accept: (row: ClientAgent) => void;
  refresh: () => Promise<void>;
  refreshSwarm: () => Promise<void>;
}) {
  const api = useOperating()!;
  const [definition, setDefinition] = useState<AgentDefinition>();
  const load = useCallback(
    (signal: AbortSignal) =>
      api.catalogue(workspaceId, "agent_definitions", signal),
    [api, workspaceId],
  );
  const catalogue = useResource(load);
  const existing =
    catalogue.state === "ready"
      ? catalogue.data.items.find(
          (d) =>
            d.id === row?.data.definition.id &&
            d.version === row.data.definition.version,
        )
      : undefined;
  const selected = definition ?? existing;
  const initial = row
    ? {
        ...row.data,
        bindings: row.data.bindings.map((b) => ({
          ...b,
          ...(b.costAssumption
            ? {
                costAssumption: {
                  ...b.costAssumption,
                  amountMinor: moneyInput(
                    b.costAssumption.amountMinor,
                    b.costAssumption.currency,
                  ),
                },
              }
            : {}),
        })),
        expectedUpdatedAt: row.updatedAt,
      }
    : {
        name: "",
        configuration: [],
        bindings: [],
        dependencyInstanceIds: [],
        capabilityInstanceIds: [],
      };
  return (
    <>
      <h2>{row ? "Configure Client Agent" : "Add Client Agent"}</h2>
      <p>
        Select an exact specialist definition version. No Agent execution is
        started.
      </p>
      {catalogue.state === "error" && (
        <OperatingFailure error={catalogue.error} />
      )}
      {row && !existing && catalogue.state === "ready" && (
        <p role="status">
          The stored definition {row.data.definition.id} · v
          {row.data.definition.version} is unavailable in the Queen catalogue.
          Historical configuration is retained; no latest version is
          substituted.
        </p>
      )}
      {row && (row.archived || !existing) && (
        <section>
          <h3>Stored configuration</h3>
          <dl>
            {row.data.configuration.map((v) => (
              <div key={v.key}>
                <dt>{v.key}</dt>
                <dd>{String(v.text ?? v.number ?? v.boolean)}</dd>
              </div>
            ))}
          </dl>
          <ul>
            {row.data.bindings.map((b) => (
              <li key={`${b.slot}:${b.integrationId}`}>
                {b.slot} · {b.integrationId} · {b.provider.id} v
                {b.provider.version} · {b.costTreatment.replaceAll("_", " ")}
              </li>
            ))}
          </ul>
        </section>
      )}
      {!row?.archived && (
        <DraftForm
          initial={initial}
          schema={z.preprocess(
            (raw) => {
              const v = structuredClone(raw) as Values;
              for (const binding of (v.bindings ?? []) as Values[])
                if (binding.costAssumption) {
                  const cost = binding.costAssumption as Values;
                  try {
                    cost.amountMinor = parseMoney(
                      String(cost.amountMinor),
                      String(cost.currency),
                    );
                  } catch {
                    cost.amountMinor = NaN;
                  }
                }
              return v;
            },
            ClientAgentData.extend({
              expectedUpdatedAt: z.string().datetime().optional(),
            }),
          )}
          fields={agentFields}
          label={row ? "Save Client Agent" : "Create Client Agent"}
          save={async (value, signal) => {
            const { expectedUpdatedAt, ...data } = value;
            if (!selected) throw new DataError("invalid");
            const saved = row
              ? await api.workspaceUpdate(
                  workspaceId,
                  "client_agents",
                  { id: row.id, expectedUpdatedAt: expectedUpdatedAt!, data },
                  signal,
                )
              : await api.workspaceCreate(
                  workspaceId,
                  "client_agents",
                  data,
                  signal,
                );
            accept(saved);
            return row ? undefined : `${base}/agents/${saved.id}`;
          }}
        >
          {(value, change) => (
            <>
              {!row && (
                <CatalogueSelect
                  workspaceId={workspaceId}
                  resource="agent_definitions"
                  label="Agent Definitions"
                  selected={
                    value.definition as
                      { id: string; version: number } | undefined
                  }
                  choose={(d) => {
                    setDefinition(d);
                    change({
                      ...value,
                      name: d.data.name,
                      definition: { id: d.id, version: d.version },
                      configuration: [],
                      bindings: [],
                      dependencyInstanceIds: [],
                    });
                  }}
                />
              )}
              {selected && (
                <>
                  <p>
                    {selected.data.description} · v{selected.version} ·{" "}
                    {selected.availability}
                  </p>
                  <Configuration
                    definition={selected}
                    values={
                      value.configuration as ClientAgent["data"]["configuration"]
                    }
                    change={(configuration) =>
                      change({ ...value, configuration })
                    }
                  />
                  <section>
                    <h3>Dependencies</h3>
                    {(["requiredAgents", "recommendedAgents"] as const).map(
                      (kind) => (
                        <div key={kind}>
                          <h4>
                            {kind === "requiredAgents"
                              ? "Required Agents"
                              : "Recommended Agents"}
                          </h4>
                          <ul>
                            {selected.data[kind].map((ref) => (
                              <li key={ref.id}>
                                {catalogue.state === "ready"
                                  ? (catalogue.data.items.find(
                                      (a) =>
                                        a.id === ref.id &&
                                        a.version === ref.version,
                                    )?.data.name ?? ref.id)
                                  : ref.id}{" "}
                                · v{ref.version}{" "}
                                <Link to={`${base}/agents/new`}>
                                  Add a Client Agent
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ),
                    )}
                    <AgentInstances
                      workspaceId={workspaceId}
                      selected={value.dependencyInstanceIds as string[]}
                      exclude={row?.id}
                      change={(dependencyInstanceIds) =>
                        change({ ...value, dependencyInstanceIds })
                      }
                    />
                  </section>
                  <Bindings
                    workspaceId={workspaceId}
                    definition={selected}
                    bindings={value.bindings as ClientAgent["data"]["bindings"]}
                    change={(bindings) => change({ ...value, bindings })}
                  />
                  <p>
                    Declared Hive reads:{" "}
                    {selected.data.hiveAccess.readResources.join(", ") ||
                      "None"}{" "}
                    · proposals:{" "}
                    {selected.data.hiveAccess.proposeResources.join(", ") ||
                      "None"}{" "}
                    · human approval required.
                  </p>
                </>
              )}
            </>
          )}
        </DraftForm>
      )}
      {row && (
        <>
          <p>
            {row.status} · revision {row.revision} · definition{" "}
            {row.data.definition.id} · v{row.data.definition.version}
          </p>
          <button onClick={() => void refresh()}>Refresh Client Agent</button>
          {!row.archived && (
            <Lifecycle
              actions={[
                ...(row.status === "draft" ? ["configure"] : []),
                "retire",
                ...(!swarm.data.agentInstanceIds.includes(row.id)
                  ? ["Add to Swarm"]
                  : []),
              ]}
              run={async (action, signal) => {
                if (action === "Add to Swarm") {
                  await api.workspaceUpdate(
                    workspaceId,
                    "client_swarms",
                    {
                      id: swarm.id,
                      expectedUpdatedAt: swarm.updatedAt,
                      data: {
                        ...swarm.data,
                        agentInstanceIds: [
                          ...swarm.data.agentInstanceIds,
                          row.id,
                        ],
                      },
                    },
                    signal,
                  );
                  await refreshSwarm();
                } else {
                  accept(
                    await api.workspaceLifecycle(
                      workspaceId,
                      "client_agents",
                      action as "configure" | "retire",
                      { id: row.id, expectedUpdatedAt: row.updatedAt },
                      signal,
                    ),
                  );
                  await refreshSwarm();
                }
              }}
            />
          )}
          <p>
            Save the Client Agent, then add it to this Swarm explicitly.
            Existing Client Agents may be shared by Swarms within this
            workspace.
          </p>
        </>
      )}
      <Link to={base}>Return to Swarm and readiness</Link>
    </>
  );
}
function Configuration({
  definition,
  values,
  change,
}: {
  definition: AgentDefinition;
  values: ClientAgent["data"]["configuration"];
  change: (values: ClientAgent["data"]["configuration"]) => void;
}) {
  return (
    <section>
      <h3>Agent configuration</h3>
      {definition.data.configurationFields.map((f) => {
        const v = values.find((v) => v.key === f.key);
        function set(value: string) {
          const rest = values.filter((x) => x.key !== f.key);
          if (value === "") {
            change(rest);
            return;
          }
          change([
            ...rest,
            {
              key: f.key,
              ...(f.type === "boolean"
                ? { boolean: value === "true" }
                : f.type === "number"
                  ? { number: Number(value) }
                  : { text: value }),
            },
          ]);
        }
        return (
          <label key={f.key}>
            {f.label}
            {f.required ? " (required)" : " (optional)"}
            {f.type === "boolean" || f.type === "choice" ? (
              <select
                value={
                  f.type === "boolean"
                    ? v?.boolean === undefined
                      ? ""
                      : String(v.boolean)
                    : (v?.text ?? "")
                }
                onChange={(e) => set(e.target.value)}
              >
                <option value="">Not set</option>
                {(f.type === "boolean" ? ["true", "false"] : f.choices).map(
                  (x) => (
                    <option key={x} value={x}>
                      {x}
                    </option>
                  ),
                )}
              </select>
            ) : (
              <input
                type={f.type === "number" ? "number" : "text"}
                step="any"
                maxLength={2000}
                value={
                  f.type === "number" ? (v?.number ?? "") : (v?.text ?? "")
                }
                onChange={(e) => set(e.target.value)}
              />
            )}
            <small>{f.guidance}</small>
          </label>
        );
      })}
      {values
        .filter(
          (v) =>
            !definition.data.configurationFields.some((f) => f.key === v.key),
        )
        .map((v) => (
          <p key={v.key}>
            Historical field {v.key}{" "}
            <button
              type="button"
              onClick={() => change(values.filter((x) => x.key !== v.key))}
            >
              Remove field
            </button>
          </p>
        ))}
    </section>
  );
}
function Bindings({
  workspaceId,
  definition,
  bindings,
  change,
}: {
  workspaceId: string;
  definition: AgentDefinition;
  bindings: ClientAgent["data"]["bindings"];
  change: (bindings: ClientAgent["data"]["bindings"]) => void;
}) {
  const api = useOperating()!;
  const load = useCallback(
    (signal: AbortSignal) =>
      Promise.all([
        api.catalogue(workspaceId, "integration_providers", signal),
        api.connections(workspaceId, signal),
      ]),
    [api, workspaceId],
  );
  const result = useResource(load);
  return (
    <section>
      <h3>Integration bindings</h3>
      <p>
        Bind existing connected accounts to the Agent’s declared service
        requirements. Connection management remains in workspace Integrations.
      </p>
      <p>
        Client funded: client pays the provider. HVM funded: HVM bears the cost.
        Pass through: record the cost to pass on. Included allowance: record
        included usage and overage assumptions.
      </p>
      {result.state === "loading" ? (
        <Loading label="Loading compatible connections…" />
      ) : result.state === "error" ? (
        <OperatingFailure error={result.error} />
      ) : (
        definition.data.integrationRequirements.map((slot) => {
          const providers = result.data[0].items.filter(
            (p) =>
              slot.supportedProviderIds.includes(p.id) &&
              p.data.operationalCapabilities.includes(
                slot.operationalCapability,
              ),
          );
          const accounts = result.data[1].integrations.filter(
            (i) => i.status === "connected",
          );
          const candidates = providers.flatMap((p) =>
            accounts.filter((i) => i.provider === p.key).map((i) => ({ p, i })),
          );
          return (
            <fieldset key={slot.slot}>
              <legend>
                {slot.operationalCapability.replaceAll("_", " ")} ·{" "}
                {slot.required ? "Required" : "Optional"}
              </legend>
              <p>
                Slot {slot.slot} · minimum providers {slot.minimumProviders}
              </p>
              {!candidates.length && (
                <p>
                  No compatible connected account is available. Connect an
                  account through the supported workspace integration setup.
                </p>
              )}
              <label>
                Add connected account
                <select
                  value=""
                  disabled={bindings.length >= 40}
                  onChange={(e) => {
                    const c = candidates.find(
                      (c) => `${c.p.id}:${c.i.id}` === e.target.value,
                    );
                    if (c)
                      change([
                        ...bindings,
                        {
                          slot: slot.slot,
                          integrationId: c.i.id,
                          provider: { id: c.p.id, version: c.p.version },
                          costTreatment: "client_funded",
                        },
                      ]);
                  }}
                >
                  <option value="">Choose account</option>
                  {candidates
                    .filter(
                      (c) =>
                        !bindings.some(
                          (b) =>
                            b.slot === slot.slot && b.integrationId === c.i.id,
                        ),
                    )
                    .map((c) => (
                      <option
                        key={`${c.p.id}:${c.i.id}`}
                        value={`${c.p.id}:${c.i.id}`}
                      >
                        {c.p.data.name} · v{c.p.version} · {c.i.displayName}
                      </option>
                    ))}
                </select>
              </label>
            </fieldset>
          );
        })
      )}
      {bindings.map((binding, index) => (
        <BindingEditor
          key={`${binding.slot}:${binding.integrationId}`}
          binding={binding}
          providers={result.state === "ready" ? result.data[0].items : []}
          connections={
            result.state === "ready" ? result.data[1].integrations : []
          }
          change={(value) =>
            change(bindings.map((b, i) => (i === index ? value : b)))
          }
          remove={() => change(bindings.filter((_, i) => i !== index))}
        />
      ))}
    </section>
  );
}
function BindingEditor({
  binding,
  providers,
  connections,
  change,
  remove,
}: {
  binding: ClientAgent["data"]["bindings"][number];
  providers: IntegrationProvider[];
  connections: { id: string; displayName: string }[];
  change: (b: ClientAgent["data"]["bindings"][number]) => void;
  remove: () => void;
}) {
  const fields: Field[] = [
    field("costAssumption", "Cost assumption", {
      kind: "group",
      optional: true,
      initial: { currency: "GBP", amountMinor: 0 },
      fields: [
        field("currency", "Cost currency", { maxLength: 3 }),
        field("amountMinor", "Cost amount"),
      ],
    }),
    field("costTreatment", "Cost treatment", {
      kind: "select",
      options: [
        "client_funded",
        "hvm_funded",
        "pass_through",
        "included_allowance",
      ],
    }),
    field("expectedQuantity", "Expected quantity", {
      kind: "number",
      min: 0,
      optional: true,
    }),
    field("unit", "Usage unit", { optional: true, maxLength: 100 }),
    field("allowance", "Included allowance", {
      kind: "number",
      min: 0,
      optional: true,
    }),
    field("overageAssumption", "Overage assumption", {
      kind: "textarea",
      optional: true,
    }),
  ];
  return (
    <fieldset>
      <legend>
        {binding.slot} ·{" "}
        {connections.find((i) => i.id === binding.integrationId)?.displayName ??
          binding.integrationId}
      </legend>
      <p>
        {providers.find(
          (p) =>
            p.id === binding.provider.id &&
            p.version === binding.provider.version,
        )?.data.name ?? binding.provider.id}{" "}
        · v{binding.provider.version}
      </p>
      <Fields
        scope={`binding_${binding.slot}_${binding.integrationId}`}
        fields={fields}
        value={binding as unknown as Values}
        change={(v) => {
          const next = { ...v };
          for (const k of ["expectedQuantity", "allowance"]) {
            if (next[k] === "") delete next[k];
            else if (next[k] !== undefined) next[k] = Number(next[k]);
          }
          for (const k of ["unit", "overageAssumption"])
            if (next[k] === "") delete next[k];
          change(next as unknown as ClientAgent["data"]["bindings"][number]);
        }}
      />
      <button type="button" onClick={remove}>
        Remove binding
      </button>
    </fieldset>
  );
}
