import { DataError } from "../../data/gateway";
export function OperatingFailure({
  error,
  retry,
}: {
  error: unknown;
  retry?: () => void;
}) {
  const code = error instanceof DataError ? error.code : "unavailable";
  const messages = {
    denied: [
      "Access not available",
      "This platform resource is not available to your current account.",
    ],
    invalid: [
      "Information could not be verified",
      "Check the highlighted fields, or reload the record. The request could not be safely accepted.",
    ],
    conflict: [
      "Changes could not be applied",
      "The record changed, its key/version already exists, or a referenced definition or policy constraint prevents this operation. Your draft has been preserved. Reload the server value and review before retrying.",
    ],
    unavailable: [
      "Service unavailable",
      "The request could not be completed. Your draft has been preserved; check the server state before retrying a save.",
    ],
    pending: [
      "Operating service unavailable",
      "Platform configuration is not available in this environment.",
    ],
  }[code];
  return (
    <div className="notice" role="alert">
      <h2>{messages[0]}</h2>
      <p>{messages[1]}</p>
      {retry && (
        <button type="button" className="button secondary" onClick={retry}>
          Try again
        </button>
      )}
    </div>
  );
}
