import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { Link } from "react-router-dom";
import { useOperating } from "../../data/operating/context";
import type {
  GlobalResource,
  OperatingModels,
} from "../../data/operating/models";
import { useResource } from "../../data/use-resource";
import { nextPage, previousPage } from "../../data/operating/pagination";
import { DataError } from "../../data/gateway";
import { Loading, Empty, Status } from "../ui";
import { OperatingFailure } from "./feedback";
import { areaFor } from "./fields";
type RefResource = "agent_definitions" | "integration_providers";
const ReferenceContext = createContext<
  | ((
      resource: RefResource,
      id: string,
    ) => Promise<OperatingModels[GlobalResource]>)
  | null
>(null);
export function ReferenceScope({ children }: { children: ReactNode }) {
  const api = useOperating();
  const controller = useRef(new AbortController());
  const cache = useRef(
    new Map<string, Promise<OperatingModels[GlobalResource]>>(),
  );
  useEffect(
    () => () => {
      controller.current.abort();
      cache.current.clear();
    },
    [],
  );
  const read = useCallback(
    (resource: RefResource, id: string) => {
      if (controller.current.signal.aborted)
        controller.current = new AbortController();
      const key = resource + id;
      let result = cache.current.get(key);
      if (!result) {
        result = api
          ? api.detail({ resource }, id, controller.current.signal)
          : Promise.reject(new DataError("pending"));
        cache.current.set(key, result);
      }
      return result;
    },
    [api],
  );
  return (
    <ReferenceContext.Provider value={read}>
      {children}
    </ReferenceContext.Provider>
  );
}
export function ReferenceLabel({
  resource,
  id,
  version,
}: {
  resource: RefResource;
  id: string;
  version?: number;
}) {
  const read = useContext(ReferenceContext)!;
  const load = useCallback(() => read(resource, id), [read, resource, id]);
  const result = useResource(load);
  return (
    <span className="reference-label">
      <Link to={`/empress/${areaFor(resource).path}/${id}`}>
        {result.state === "ready" ? result.data.data.name : id}
        {version !== undefined
          ? ` · v${version}`
          : result.state === "ready"
            ? ` · v${result.data.version}`
            : ""}
      </Link>
      {result.state === "ready" ? (
        <>
          <Status>{result.data.status}</Status>
          <Status>{result.data.availability}</Status>
          {version !== undefined && version !== result.data.version && (
            <span role="alert">
              Stored version differs from returned record; reference needs
              review.
            </span>
          )}
        </>
      ) : (
        <span>
          {result.state === "loading"
            ? "Checking reference…"
            : "Reference unavailable; stored identity retained."}
        </span>
      )}
      <small>{id}</small>
    </span>
  );
}
export type ReferenceRequest = {
  path: string;
  resource: RefResource;
  idsOnly?: boolean;
  excluded: string[];
  capability?: string;
};
export function ReferencePicker({
  request,
  onPick,
  onClose,
}: {
  request: ReferenceRequest;
  onPick: (value: string | { id: string; version: number }) => void;
  onClose: () => void;
}) {
  const api = useOperating();
  const [key, setKey] = useState("");
  const [offset, setOffset] = useState(0);
  const [revision, setRevision] = useState(0);
  const heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => heading.current?.focus(), []);
  const load = useCallback(
    (signal: AbortSignal) => {
      void revision;
      return api
        ? api.list(
            { resource: request.resource },
            { limit: 20, offset, ...(key ? { key } : {}) },
            signal,
          )
        : Promise.reject(new DataError("pending"));
    },
    [api, request.resource, offset, key, revision],
  );
  const result = useResource(load);
  const excluded = useMemo(() => new Set(request.excluded), [request.excluded]);
  return (
    <section
      className="panel reference-picker"
      aria-label="Select registered reference"
    >
      <h3 tabIndex={-1} ref={heading}>
        Select {areaFor(request.resource).singular}
      </h3>
      <p>
        Choose an active registered definition. The selected record's identity
        and exact version are preserved.
      </p>
      <label>
        Exact reference key
        <input
          value={key}
          onChange={(e) => {
            setKey(e.target.value);
            setOffset(0);
          }}
          maxLength={64}
        />
      </label>
      {result.state === "loading" ? (
        <Loading label="Loading references…" />
      ) : result.state === "error" ? (
        <OperatingFailure
          error={result.error}
          retry={() => setRevision((n) => n + 1)}
        />
      ) : (
        <>
          {result.data.items.length === 0 && (
            <Empty title="No references on this page">
              Try another exact key.
            </Empty>
          )}
          <ul className="record-list">
            {result.data.items.map((row) => {
              const compatible =
                request.capability === undefined ||
                ("operationalCapabilities" in row.data &&
                  row.data.operationalCapabilities.includes(
                    request.capability,
                  ));
              const disabled =
                row.status !== "active" ||
                row.archived ||
                excluded.has(row.id) ||
                !compatible;
              return (
                <li key={row.id}>
                  <div>
                    <strong>
                      {row.data.name} · v{row.version}
                    </strong>
                    <p>{row.key}</p>
                    <Status>{row.status}</Status>{" "}
                    <Status>{row.availability}</Status>
                    {!compatible && (
                      <p>
                        Does not provide the required operational capability.
                      </p>
                    )}
                    {excluded.has(row.id) && <p>Already selected.</p>}
                  </div>
                  <button
                    type="button"
                    className="button secondary"
                    disabled={disabled}
                    onClick={() =>
                      onPick(
                        request.idsOnly
                          ? row.id
                          : { id: row.id, version: row.version },
                      )
                    }
                  >
                    Select {row.data.name} v{row.version}
                  </button>
                </li>
              );
            })}
          </ul>
          <div className="form-actions">
            <button
              type="button"
              disabled={!previousPage(result.data)}
              onClick={() => setOffset(previousPage(result.data)!.offset)}
            >
              Previous references
            </button>
            <button
              type="button"
              disabled={!nextPage(result.data)}
              onClick={() => setOffset(nextPage(result.data)!.offset)}
            >
              Next references
            </button>
          </div>
        </>
      )}
      <button type="button" className="text-button" onClick={onClose}>
        Close reference selector
      </button>
    </section>
  );
}
