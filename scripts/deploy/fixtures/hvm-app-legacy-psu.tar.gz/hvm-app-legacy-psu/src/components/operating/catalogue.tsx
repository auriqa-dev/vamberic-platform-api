import { useCallback, useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useOperating } from "../../data/operating/context";
import type { GlobalResource } from "../../data/operating/models";
import {
  paginationSchema,
  nextPage,
  previousPage,
} from "../../data/operating/pagination";
import { DataError } from "../../data/gateway";
import { useResource } from "../../data/use-resource";
import { Empty, Loading, Status } from "../ui";
import { areaFor } from "./fields";
import { OperatingFailure } from "./feedback";
export function Catalogue({ resource }: { resource: GlobalResource }) {
  const api = useOperating(),
    area = areaFor(resource);
  const [search, setSearch] = useSearchParams();
  const parsed = paginationSchema.safeParse({
    limit: Number(search.get("limit") ?? 20),
    offset: Number(search.get("offset") ?? 0),
  });
  const limit = parsed.success ? parsed.data.limit : 20,
    offset = parsed.success ? parsed.data.offset : 0;
  const key = search.get("key") ?? "";
  const [filterInput, setFilterInput] = useState(key);
  useEffect(() => setFilterInput(key), [key]);
  const [revision, setRevision] = useState(0);
  const load = useCallback(
    (signal: AbortSignal) => {
      void revision;
      return api
        ? api.list(
            { resource },
            { limit, offset, ...(key ? { key } : {}) },
            signal,
          )
        : Promise.reject(new DataError("pending"));
    },
    [api, resource, limit, offset, key, revision],
  );
  const result = useResource(load);
  const change = (keyValue: string, pageSize: number, pageOffset = 0) =>
    setSearch({
      ...(keyValue ? { key: keyValue } : {}),
      limit: String(pageSize),
      offset: String(pageOffset),
    });
  return (
    <>
      <div className="page-heading">
        <p className="eyebrow">Empress · Platform registry</p>
        <h1>{area.label}</h1>
        <p>{area.description}</p>
      </div>
      <div className="catalogue-toolbar">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            change(filterInput, limit);
          }}
        >
          <label>
            Exact stable key
            <input
              value={filterInput}
              maxLength={64}
              onChange={(e) => setFilterInput(e.target.value)}
            />
          </label>
          <button type="submit" className="button secondary">
            Apply key filter
          </button>
        </form>
        <label>
          Records per page
          <select
            value={limit}
            onChange={(e) => change(key, Number(e.target.value))}
          >
            {[10, 20, 50, 100].map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </label>
        <Link className="button" to={`/empress/${area.path}/new`}>
          {resource === "methodology_availability"
            ? "Register methodology availability"
            : `Create ${area.singular}`}
        </Link>
      </div>
      {result.state === "loading" ? (
        <Loading label={`Loading ${area.label.toLowerCase()}…`} />
      ) : result.state === "error" ? (
        <OperatingFailure
          error={result.error}
          retry={() => setRevision((n) => n + 1)}
        />
      ) : (
        <>
          {result.data.items.length === 0 ? (
            <Empty title={`No ${area.label.toLowerCase()} on this page`}>
              No records matched this page and exact key. Adjust the filter or
              register a draft.
            </Empty>
          ) : (
            <ul className="catalogue-list">
              {result.data.items.map((row) => (
                <li key={row.id} className="panel">
                  <div className="card-heading">
                    <span className="eyebrow">
                      {row.key} · v{row.version}
                    </span>
                    <div>
                      <Status>{row.status}</Status>{" "}
                      <Status>{row.availability}</Status>
                    </div>
                  </div>
                  <h2>
                    <Link to={`/empress/${area.path}/${row.id}`}>
                      {row.data.name}
                    </Link>
                  </h2>
                  <p>{row.data.description}</p>
                  {"category" in row.data && (
                    <p>Category: {row.data.category}</p>
                  )}
                  {"job" in row.data && <p>Job: {row.data.job}</p>}
                  {"currency" in row.data && (
                    <p>
                      {row.data.currency} · Effective {row.data.effectiveFrom}
                      {row.data.effectiveUntil
                        ? ` to ${row.data.effectiveUntil}`
                        : " onwards"}
                    </p>
                  )}
                  {"methodology" in row.data && (
                    <p>
                      Implementation:{" "}
                      {row.data.methodology.id ===
                        "offermethodology_00000000000000000000000001" &&
                      row.data.methodology.version === 1
                        ? "Value Equation"
                        : row.data.methodology.id}{" "}
                      · v{row.data.methodology.version}
                    </p>
                  )}
                </li>
              ))}
            </ul>
          )}
          <nav className="form-actions" aria-label={`${area.label} pagination`}>
            <button
              type="button"
              className="button secondary"
              disabled={!previousPage(result.data)}
              onClick={() =>
                change(key, limit, previousPage(result.data)!.offset)
              }
            >
              Previous page
            </button>
            <span role="status">
              Page {Math.floor(offset / limit) + 1} · {result.data.items.length}{" "}
              records
            </span>
            <button
              type="button"
              className="button secondary"
              disabled={!nextPage(result.data)}
              onClick={() => change(key, limit, nextPage(result.data)!.offset)}
            >
              Next page
            </button>
          </nav>
        </>
      )}
    </>
  );
}
