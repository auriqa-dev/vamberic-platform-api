import type { GlobalResource } from "../../data/operating/models";
export type Field = {
  key: string;
  label: string;
  kind?:
    | "text"
    | "textarea"
    | "number"
    | "percent"
    | "money"
    | "select"
    | "checkbox"
    | "strings"
    | "group"
    | "repeat"
    | "references"
    | "choices";
  help?: string;
  optional?: boolean;
  max?: number;
  min?: number;
  maxLength?: number;
  options?: readonly string[];
  fields?: Field[];
  initial?: unknown;
  resource?: "agent_definitions" | "integration_providers";
  idsOnly?: boolean;
  currencyKey?: string;
};
const t = (key: string, label: string, more: Partial<Field> = {}): Field => ({
  key,
  label,
  ...more,
});
const strs = (key: string, label: string, max = 40): Field =>
  t(key, label, { kind: "strings", max });
const refs = (key: string, label: string): Field =>
  t(key, label, { kind: "references", resource: "agent_definitions", max: 40 });
const hive = [
  "brands",
  "brand_kits",
  "offerings",
  "ideal_customer_profiles",
  "buyer_profiles",
  "offer_designs",
  "offers",
  "people",
  "contact_points",
];
const treatments = ["standard", "bundled", "waived", "internal", "promotional"];
const identity = [
  t("name", "Name", { maxLength: 200 }),
  t("description", "Description", { kind: "textarea" }),
];
const costDrivers: Field = t("costDrivers", "Cost drivers", {
  kind: "repeat",
  max: 40,
  help: "Usage and cost assumptions, not retail Agent prices.",
  initial: { key: "", name: "", unit: "", description: "" },
  fields: [
    t("key", "Driver key", { maxLength: 64 }),
    t("name", "Driver name", { maxLength: 200 }),
    t("unit", "Unit", { maxLength: 100 }),
    t("description", "Driver description", { kind: "textarea" }),
    t("expectedQuantity", "Expected quantity", {
      kind: "number",
      min: 0,
      optional: true,
    }),
    t("unitCost", "Unit cost assumption", {
      kind: "group",
      optional: true,
      initial: { amountMinor: 0, currency: "GBP" },
      fields: [
        t("currency", "Currency (ISO code)", { maxLength: 3 }),
        t("amountMinor", "Unit cost", {
          kind: "money",
          currencyKey: "currency",
        }),
      ],
    }),
  ],
});
export const resourceFields: Record<GlobalResource, Field[]> = {
  agent_definitions: [
    ...identity,
    t("category", "Category", { maxLength: 64 }),
    strs("providesCapabilityIds", "Provided capability IDs"),
    strs("requiresCapabilityIds", "Required capability IDs"),
    refs("requiredAgents", "Required Agents"),
    refs("recommendedAgents", "Recommended Agents"),
    t("hiveAccess", "Hive declarations", {
      kind: "group",
      help: "Declared intended access is metadata. It does not grant runtime permissions. Proposals require human approval within a workspace.",
      fields: [
        t("readResources", "Reads", { kind: "choices", options: hive }),
        t("proposeResources", "Proposes", { kind: "choices", options: hive }),
      ],
    }),
    t("configurationFields", "Configuration requirements", {
      kind: "repeat",
      max: 40,
      initial: {
        key: "",
        label: "",
        type: "text",
        required: false,
        choices: [],
      },
      fields: [
        t("key", "Configuration key", { maxLength: 64 }),
        t("label", "Field label", { maxLength: 200 }),
        t("type", "Value type", {
          kind: "select",
          options: ["text", "number", "boolean", "choice"],
        }),
        t("required", "Required value", { kind: "checkbox" }),
        strs("choices", "Choices", 30),
        t("guidance", "Field guidance", { kind: "textarea", optional: true }),
      ],
    }),
    t("integrationRequirements", "Integration requirements", {
      kind: "repeat",
      max: 20,
      help: "Define a provider-neutral capability slot and compatible providers. Client account binding happens later in Queen configuration.",
      initial: {
        slot: "",
        operationalCapability: "",
        required: false,
        minimumProviders: 0,
        supportedProviderIds: [],
      },
      fields: [
        t("slot", "Slot key", { maxLength: 64 }),
        t("operationalCapability", "Operational capability", { maxLength: 64 }),
        t("required", "Required slot", { kind: "checkbox" }),
        t("minimumProviders", "Minimum providers", {
          kind: "number",
          min: 0,
          max: 10,
        }),
        t("supportedProviderIds", "Compatible Providers", {
          kind: "references",
          resource: "integration_providers",
          idsOnly: true,
          max: 40,
        }),
      ],
    }),
    t("executionImplementation", "Reviewed implementation binding", {
      kind: "group",
      optional: true,
      initial: {
        key: "",
        version: 1,
        manifestDigest: "",
        protocolVersion: "2.0",
      },
      help: "Use the exact reviewed implementation manifest. Registration does not activate execution or grant workspace access.",
      fields: [
        t("key", "Implementation key"),
        t("version", "Implementation version", {
          kind: "number",
          min: 1,
          max: 1000000,
        }),
        t("manifestDigest", "Manifest SHA-256", { maxLength: 64 }),
        t("protocolVersion", "Protocol version", {
          kind: "select",
          options: ["1.1", "1.2", "2.0"],
        }),
      ],
    }),
    t("effectiveness", "Required Effectiveness bindings", {
      kind: "repeat",
      optional: true,
      max: 6,
      initial: {
        maker: "",
        evaluator: "",
        revision: "",
        profile: { key: "", version: 1, digest: "" },
        policy: { key: "", version: 1, digest: "" },
        required: true,
        maxRevisions: 2,
      },
      help: "Separate maker/evaluator/revision operations. PASS never replaces canonical approval or execution permission.",
      fields: [
        t("maker", "Maker operation"),
        t("evaluator", "Evaluator operation"),
        t("revision", "Revision operation"),
        ...["profile", "policy"].map((key) =>
          t(
            key,
            key === "profile" ? "Effectiveness profile" : "Decision policy",
            {
              kind: "group",
              fields: [
                t("key", "Key"),
                t("version", "Version", {
                  kind: "number",
                  min: 1,
                  max: 1000000,
                }),
                t("digest", "SHA-256", { maxLength: 64 }),
              ],
            },
          ),
        ),
        t("maxRevisions", "Maximum revision Runs", {
          kind: "number",
          min: 0,
          max: 2,
        }),
      ],
    }),
    costDrivers,
  ],
  integration_providers: [
    ...identity,
    t("category", "Category", { maxLength: 64 }),
    strs("operationalCapabilities", "Operational capabilities", 30),
    t("authentication", "Authentication metadata", {
      kind: "select",
      options: ["oauth", "api_key_reference", "external_account", "none"],
      help: "Describe the authentication method only. Do not enter credentials or client secrets.",
    }),
    t("customerOwnedAccount", "Customer-owned account", {
      kind: "select",
      options: ["required", "supported", "unsupported"],
    }),
    t("guidance", "Setup guidance", { kind: "textarea" }),
    t("documentationUrl", "Documentation URL", {
      optional: true,
      maxLength: 1000,
    }),
    costDrivers,
  ],
  swarm_templates: [
    ...identity,
    t("job", "Job / outcome", { kind: "textarea" }),
    refs("requiredAgents", "Required Agents"),
    refs("recommendedAgents", "Recommended Agents"),
    refs("optionalAgents", "Optional Agents"),
    strs(
      "integrationCapabilities",
      "Provider-neutral integration capabilities",
      20,
    ),
    strs("configurationGuidance", "Configuration guidance"),
    strs("commercialAssumptions", "Commercial assumptions"),
  ],
  methodology_availability: [
    ...identity,
    t("methodology", "Code-owned methodology", {
      kind: "group",
      help: "Reference an existing code-owned implementation. This does not create or edit its formula, learning content or stages. A global implementation lookup is not exposed by the API; use a verified canonical ID and version.",
      fields: [
        t("id", "Methodology ID", { maxLength: 100 }),
        t("version", "Implementation version", { kind: "number", min: 1 }),
      ],
    }),
    refs("compatibleAgents", "Compatible Agents"),
  ],
  commercial_policies: [
    ...identity,
    t("currency", "Currency (ISO code)", { maxLength: 3 }),
    t("targetMargin", "Target margin (%)", { kind: "percent" }),
    t("minimumMargin", "Minimum margin (%)", { kind: "percent" }),
    t("minimumMonthlyPriceMinor", "Minimum monthly price", {
      kind: "money",
      currencyKey: "currency",
    }),
    t("defaultOnboardingTreatment", "Default onboarding treatment", {
      kind: "select",
      options: treatments,
    }),
    t("annualDiscount", "Annual discount (%)", { kind: "percent" }),
    t("maximumQueenDiscount", "Maximum Queen discount (%)", {
      kind: "percent",
    }),
    t("maximumQueenFixedDiscountMinor", "Maximum Queen fixed discount", {
      kind: "money",
      currencyKey: "currency",
    }),
    t("allowCustomPrice", "Allow Queen custom price", { kind: "checkbox" }),
    t("permittedQueenTreatments", "Permitted Queen treatments", {
      kind: "choices",
      options: treatments,
    }),
    t("usagePolicy", "Usage policy", { kind: "textarea" }),
    t("overagePolicy", "Overage policy", { kind: "textarea" }),
    strs("serviceEffortAssumptions", "Service effort assumptions"),
    t("internalTreatmentGuidance", "Internal treatment guidance", {
      kind: "textarea",
    }),
    t("promotionalTreatmentGuidance", "Promotional treatment guidance", {
      kind: "textarea",
    }),
    t("effectiveFrom", "Effective from (UTC)", {
      help: "ISO timestamp, for example 2026-10-01T00:00:00.000Z",
    }),
    t("effectiveUntil", "Effective until (UTC)", {
      optional: true,
      help: "Leave empty for no end date. Must follow the start date.",
    }),
  ],
};
export const initialData: Record<GlobalResource, Record<string, unknown>> = {
  agent_definitions: {
    name: "",
    description: "",
    category: "",
    providesCapabilityIds: [],
    requiresCapabilityIds: [],
    requiredAgents: [],
    recommendedAgents: [],
    hiveAccess: {
      readResources: [],
      proposeResources: [],
      approval: "human_only",
      scope: "workspace",
    },
    configurationFields: [],
    integrationRequirements: [],
    costDrivers: [],
  },
  integration_providers: {
    name: "",
    description: "",
    category: "",
    authentication: "none",
    operationalCapabilities: [],
    customerOwnedAccount: "supported",
    guidance: "",
    costDrivers: [],
  },
  swarm_templates: {
    name: "",
    description: "",
    job: "",
    requiredAgents: [],
    recommendedAgents: [],
    optionalAgents: [],
    integrationCapabilities: [],
    configurationGuidance: [],
    commercialAssumptions: [],
  },
  methodology_availability: {
    name: "",
    description: "",
    methodology: { id: "", version: 1 },
    compatibleAgents: [],
  },
  commercial_policies: {
    name: "",
    description: "",
    currency: "GBP",
    targetMargin: 0,
    minimumMargin: 0,
    defaultOnboardingTreatment: "standard",
    annualDiscount: 0,
    maximumQueenDiscount: 0,
    maximumQueenFixedDiscountMinor: 0,
    minimumMonthlyPriceMinor: 0,
    allowCustomPrice: false,
    permittedQueenTreatments: ["standard"],
    usagePolicy: "",
    overagePolicy: "",
    serviceEffortAssumptions: [],
    internalTreatmentGuidance: "",
    promotionalTreatmentGuidance: "",
    effectiveFrom: "",
  },
};
export const areas: {
  resource: GlobalResource;
  path: string;
  label: string;
  singular: string;
  description: string;
}[] = [
  {
    resource: "agent_definitions",
    path: "agents",
    label: "Agents",
    singular: "Agent Definition",
    description:
      "Register specialist capabilities, dependencies and configuration requirements.",
  },
  {
    resource: "integration_providers",
    path: "integration-providers",
    label: "Integration Providers",
    singular: "Integration Provider",
    description:
      "Govern provider capabilities and setup metadata without client credentials.",
  },
  {
    resource: "methodology_availability",
    path: "methodologies",
    label: "Methodologies",
    singular: "Methodology Availability",
    description:
      "Govern availability and Agent compatibility for code-owned methodologies.",
  },
  {
    resource: "swarm_templates",
    path: "swarm-templates",
    label: "Swarm Templates",
    singular: "Swarm Template",
    description:
      "Compose reusable starting configurations for a job to be done.",
  },
  {
    resource: "commercial_policies",
    path: "commercial-policy",
    label: "Commercial Policy",
    singular: "Commercial Policy",
    description:
      "Set economic guardrails, Queen authority and effective policy versions.",
  },
];
export const areaFor = (resource: GlobalResource) =>
  areas.find((a) => a.resource === resource)!;
