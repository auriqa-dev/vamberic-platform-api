// Match the persisted brand domain contract; accept pasted website URLs in the UI.
const domainPattern =
  /^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$/;

export function normalisePrimaryDomain(input: string): string | undefined {
  const value = input.trim();
  if (!value || value.length > 2048 || /[\s\\]/.test(value)) return undefined;
  try {
    const url = new URL(value.includes("://") ? value : `https://${value}`);
    if (
      !["http:", "https:"].includes(url.protocol) ||
      url.username ||
      url.password
    )
      return undefined;
    const domain = url.hostname.toLowerCase();
    return domain.length <= 253 && domainPattern.test(domain)
      ? domain
      : undefined;
  } catch {
    return undefined;
  }
}
