import type { User, UserManager } from "oidc-client-ts";

export type SessionSnapshot = {
  status: "loading" | "authenticated" | "anonymous";
  subject?: string;
  message?: string;
};

type SessionManager = Pick<
  UserManager,
  | "getUser"
  | "signinSilent"
  | "removeUser"
  | "signinRedirect"
  | "signinRedirectCallback"
  | "clearStaleState"
  | "revokeTokens"
>;

/** Browser-independent session state; the provider owns protocol validation. */
export class AuthSession {
  private snapshot: SessionSnapshot = { status: "loading" };
  private listeners = new Set<() => void>();
  private user: User | null = null;
  private initialization?: Promise<void>;
  private expiration?: ReturnType<typeof setTimeout>;
  private generation = 0;
  private renewal?: Promise<void>;
  private retryAtExpiry = false;

  constructor(
    private readonly manager: SessionManager,
    private readonly navigation: {
      callbackUrl: string;
      logoutUrl: string;
      replace: (url: string) => void;
      assign: (url: string) => void;
    },
    private readonly clearPrivateData: () => void,
  ) {}

  getSnapshot = (): SessionSnapshot => this.snapshot;
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };

  private publish(snapshot: SessionSnapshot) {
    this.snapshot = snapshot;
    for (const listener of this.listeners) listener();
  }

  start(url: string): Promise<void> {
    // Callback codes must only be exchanged once, including React remounts.
    return (this.initialization ??= this.initialize(url));
  }

  private async initialize(url: string) {
    const generation = this.generation;
    const current = new URL(url);
    const callback =
      current.searchParams.has("code") || current.searchParams.has("error");
    try {
      const user = callback
        ? await this.manager.signinRedirectCallback(url)
        : await this.manager.getUser();
      if (generation !== this.generation) {
        // A completed callback may persist tokens after sign-out removed them.
        await this.manager.removeUser().catch(() => undefined);
        return;
      }
      if (!user?.access_token || !user.expires_at || !user.profile.sub) {
        await this.invalidate();
        return;
      }
      this.user = user;
      if (this.isExpired(user)) {
        await this.renew();
      } else {
        this.accept(user);
      }
      await this.manager.clearStaleState();
    } catch {
      await this.invalidate(
        "Sign-in could not be completed. Please try again.",
      );
    } finally {
      // Remove codes, state and provider errors from browser history.
      if (callback) this.navigation.replace(this.navigation.callbackUrl);
    }
  }

  signIn = async () => {
    this.publish({ status: "loading" });
    try {
      await this.manager.signinRedirect();
    } catch {
      await this.invalidate("Sign-in is unavailable. Please try again.");
    }
  };

  private isExpired(user: User) {
    return !user.expires_at || user.expires_at * 1000 <= Date.now() || user.expired;
  }

  private accept(user: User) {
    this.user = user;
    this.retryAtExpiry = false;
    this.publish({ status: "authenticated", subject: user.profile.sub });
    this.scheduleRenewal();
  }

  private scheduleRenewal() {
    clearTimeout(this.expiration);
    if (!this.user?.expires_at) return;
    const remaining = this.user.expires_at * 1000 - Date.now();
    // One scheduler owns renewal; oidc-client-ts automatic renewal stays off.
    const lead = this.user.refresh_token && !this.retryAtExpiry
      ? Math.min(60_000, Math.max(remaining / 2, 0)) : 0;
    this.expiration = setTimeout(() => { void this.renew(); },
      Math.min(Math.max(remaining - lead, 0), 2_147_483_647));
  }

  private renew(): Promise<void> {
    // Timer, restoration and concurrent API calls must share one token exchange.
    if (this.renewal) return this.renewal;
    this.renewal = this.performRenewal().finally(() => { this.renewal = undefined; });
    return this.renewal;
  }

  private async performRenewal() {
    const generation = this.generation;
    const previous = this.user;
    if (!previous?.refresh_token) {
      await this.invalidate("Your session expired. Please sign in again.");
      return;
    }
    try {
      const renewed = await this.manager.signinSilent({ silentRequestTimeoutInSeconds: 10 });
      if (generation !== this.generation) {
        // The library persists before resolving. A late exchange cannot undo logout.
        await this.manager.revokeTokens(["refresh_token"]).catch(() => undefined);
        await this.manager.removeUser().catch(() => undefined);
        return;
      }
      if (!renewed?.access_token || this.isExpired(renewed) ||
          renewed.profile.sub !== previous.profile.sub ||
          renewed.profile.iss !== previous.profile.iss) {
        await this.invalidate("Your session expired. Please sign in again.");
        return;
      }
      this.accept(renewed);
    } catch (error) {
      if (generation !== this.generation) return;
      const providerError = typeof error === "object" && error !== null && "error" in error;
      if (!providerError && !this.isExpired(previous)) {
        // A transient failure keeps the still-valid session, with one retry at expiry.
        this.retryAtExpiry = true;
        this.scheduleRenewal();
        return;
      }
      await this.invalidate("Your session expired. Please sign in again.");
    }
  }

  getAccessToken = async (): Promise<string | null> => {
    if (this.snapshot.status !== "authenticated") return null;
    if (this.renewal) await this.renewal;
    if (this.user && this.isExpired(this.user)) await this.renew();
    if (!this.user || this.isExpired(this.user)) return null;
    return this.user.access_token;
  };

  invalidate = async (message = "Please sign in to continue.") => {
    this.generation++;
    clearTimeout(this.expiration);
    this.user = null;
    this.publish({ status: "anonymous", message });
    this.clearPrivateData();
    await this.manager.removeUser().catch(() => undefined);
  };

  signOut = async () => {
    // Capture the refresh-token revocation before clearing persisted state.
    const revocation = this.manager
      .revokeTokens(["refresh_token"])
      .catch(() => undefined);
    await this.invalidate("You have signed out.");
    await revocation;
    await this.renewal;
    // oidc-client-ts persists the user again after successful revocation.
    await this.manager.removeUser().catch(() => undefined);
    this.navigation.assign(this.navigation.logoutUrl);
  };
}
