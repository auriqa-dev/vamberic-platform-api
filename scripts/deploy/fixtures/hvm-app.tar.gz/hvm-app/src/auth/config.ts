import {
  UserManager,
  WebStorageStateStore,
  type UserManagerSettings,
} from "oidc-client-ts";
import { z } from "zod";
import { AuthSession } from "./session";

function safeUrl(value: string) {
  try {
    const url = new URL(value);
    return (
      !url.username &&
      !url.password &&
      !url.search &&
      !url.hash &&
      (url.protocol === "https:" ||
        (url.protocol === "http:" &&
          ["localhost", "127.0.0.1"].includes(url.hostname)))
    );
  } catch {
    return false;
  }
}
const url = z.string().refine(safeUrl);
const schema = z.object({
  VITE_APP_ENV: z.enum(["development", "staging", "production"]),
  VITE_API_BASE_URL: url.refine((v) => new URL(v).pathname === "/"),
  VITE_COGNITO_REGION: z.string().regex(/^[a-z]{2}(?:-[a-z]+)+-\d$/),
  VITE_COGNITO_USER_POOL_ID: z
    .string()
    .regex(/^[a-z]{2}(?:-[a-z]+)+-\d_[A-Za-z0-9]+$/),
  VITE_COGNITO_CLIENT_ID: z.string().regex(/^[a-z0-9]+$/),
  VITE_COGNITO_DOMAIN: url.refine(
    (v) => new URL(v).protocol === "https:" && new URL(v).pathname === "/",
  ),
  VITE_AUTH_CALLBACK_URL: url,
  VITE_AUTH_LOGOUT_URL: url,
});

export function parseConfig(
  environment: Record<string, unknown>,
  origin: string,
) {
  const config = schema.parse(environment);
  if (
    !config.VITE_COGNITO_USER_POOL_ID.startsWith(
      `${config.VITE_COGNITO_REGION}_`,
    )
  )
    throw new Error("Invalid auth region");
  for (const key of [
    "VITE_AUTH_CALLBACK_URL",
    "VITE_AUTH_LOGOUT_URL",
  ] as const) {
    if (new URL(config[key]).origin !== origin)
      throw new Error("Invalid application origin");
  }
  if (
    new URL(config.VITE_AUTH_CALLBACK_URL).pathname !== "/auth/callback" ||
    new URL(config.VITE_AUTH_LOGOUT_URL).pathname !== "/"
  )
    throw new Error("Invalid auth route");
  if (
    config.VITE_APP_ENV === "production" &&
    [
      config.VITE_API_BASE_URL,
      config.VITE_AUTH_CALLBACK_URL,
      config.VITE_AUTH_LOGOUT_URL,
    ].some((v) => new URL(v).protocol !== "https:")
  )
    throw new Error("HTTPS required");
  const expectedOrigin =
    config.VITE_APP_ENV === "production"
      ? "https://app.h-v-m.net"
      : config.VITE_APP_ENV === "development"
        ? "http://localhost:5173"
        : undefined;
  if (
    expectedOrigin &&
    (origin !== expectedOrigin ||
      new URL(config.VITE_AUTH_CALLBACK_URL).origin !== expectedOrigin ||
      new URL(config.VITE_AUTH_LOGOUT_URL).origin !== expectedOrigin)
  )
    throw new Error("Auth URLs do not match selected environment");
  return config;
}
export type PublicConfig = ReturnType<typeof parseConfig>;

export function authSettings(config: PublicConfig): UserManagerSettings {
  const authority = `https://cognito-idp.${config.VITE_COGNITO_REGION}.amazonaws.com/${config.VITE_COGNITO_USER_POOL_ID}`;
  const domain = config.VITE_COGNITO_DOMAIN.replace(/\/$/, "");
  return {
    authority,
    client_id: config.VITE_COGNITO_CLIENT_ID,
    redirect_uri: config.VITE_AUTH_CALLBACK_URL,
    response_type: "code",
    scope: "openid email profile",
    disablePKCE: false,
    // AuthSession coordinates refresh with API requests and sign-out.
    automaticSilentRenew: false,
    loadUserInfo: false,
    monitorSession: false,
    revokeTokenTypes: ["refresh_token"],
    requestTimeoutInSeconds: 10,
    userStore: new WebStorageStateStore({
      store: window.sessionStorage,
      prefix: "hvm.oidc.",
    }),
    stateStore: new WebStorageStateStore({
      store: window.sessionStorage,
      prefix: "hvm.oidc.",
    }),
    metadata: {
      issuer: authority,
      authorization_endpoint: `${domain}/oauth2/authorize`,
      token_endpoint: `${domain}/oauth2/token`,
      revocation_endpoint: `${domain}/oauth2/revoke`,
      jwks_uri: `${authority}/.well-known/jwks.json`,
    },
  };
}
export function logoutUrl(config: PublicConfig) {
  const domain = config.VITE_COGNITO_DOMAIN.replace(/\/$/, "");
  const logout = new URL(`${domain}/logout`);
  logout.searchParams.set("client_id", config.VITE_COGNITO_CLIENT_ID);
  logout.searchParams.set("logout_uri", config.VITE_AUTH_LOGOUT_URL);
  return logout.href;
}
export function configureAuth(config: PublicConfig) {
  return new AuthSession(
    new UserManager(authSettings(config)),
    {
      callbackUrl: config.VITE_AUTH_CALLBACK_URL,
      logoutUrl: logoutUrl(config),
      replace: (value) => window.history.replaceState(null, "", value),
      assign: (value) => window.location.assign(value),
    },
    () => {
      /* Private data lives only in the authenticated React subtree, which unmounts. */
    },
  );
}
