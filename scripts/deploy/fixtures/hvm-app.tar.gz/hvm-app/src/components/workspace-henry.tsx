import "../styles/content-strategy.css";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { useNavigate } from "react-router-dom";
import type { HenryGateway } from "../data/henry";
import {
  henrySection,
  type HenryScreen,
  type HenryReply,
  type HenryTurn,
} from "../data/henry-model";
import { workspacePath, sections } from "./workspace";
import type { WorkspacePerspective } from "../data/model";

type Changes = { key: string; value: string; reason: string }[];
export type HenryBinding = {
  key: string;
  priority?: number;
  brandId?: string;
  summary: string;
  enabled?: boolean;
  editor?: {
    key: string;
    title: string;
    fields: { key: string; label: string; value: string }[];
  };
  apply?: (changes: Changes) => void;
  actions?: { id: string; label: string; run: (objective: string) => void }[];
};
type Registered = { binding: HenryBinding; section: string };
const HenryContext = createContext<{
  register: (id: symbol, b: HenryBinding, section: string) => () => void;
  section: string;
  objective: string;
  brandId: string;
  assist?: (screen: HenryScreen, instruction: string) => Promise<HenryReply>;
} | null>(null);
export function useHenryAssist() {
  return useContext(HenryContext)?.assist;
}
export function useHenryAvailable() {
  return !!useContext(HenryContext);
}
export function useHenryObjective() {
  return useContext(HenryContext)?.objective ?? "";
}
export function useHenryBrand() {
  return useContext(HenryContext)?.brandId ?? "";
}
export function useHenryBinding(binding: HenryBinding) {
  const context = useContext(HenryContext),
    latest = useRef(binding);
  latest.current = binding;
  const id = useRef(Symbol("henry-editor"));
  const serial = JSON.stringify({
    ...binding,
    actions: binding.actions?.map(({ id, label }) => ({ id, label })),
  });
  const register = context?.register,
    section = context?.section;
  useEffect(() => {
    if (!register || !section || latest.current.enabled === false) return;
    const b = latest.current;
    return register(
      id.current,
      {
        ...b,
        apply: (changes) => latest.current.apply?.(changes),
        actions: b.actions?.map((a) => ({
          ...a,
          run: (objective) =>
            latest.current.actions?.find((x) => x.id === a.id)?.run(objective),
        })),
      },
      section,
    );
  }, [register, section, serial]);
}
const sectionLabel = (key: string) =>
  sections.find(([id]) => id === key)?.[1] ?? key;
const label = (key: string) =>
  key
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/[._]/g, " ")
    .replace(/^./, (c) => c.toUpperCase());
/** Page adapters pass editable content only, never record metadata, permissions or credentials. */
export function henryFields(
  value: Record<string, unknown>,
  prefix = "",
): NonNullable<HenryBinding["editor"]>["fields"] {
  return Object.entries(value)
    .filter(
      ([key]) =>
        !/(^id$|Id$|Ids$|^revision$|^status$|^approvedRevision$)/.test(key),
    )
    .flatMap(([key, v]) => {
      const path = prefix ? `${prefix}.${key}` : key;
      if (v && typeof v === "object" && !Array.isArray(v))
        return henryFields(v as Record<string, unknown>, path);
      return [
        { key: path, label: label(path), value: JSON.stringify(v ?? null) },
      ];
    });
}
export function applyHenryFields<T extends object>(
  value: T,
  changes: Changes,
): T {
  const next = structuredClone(value),
    allowed = new Set(
      henryFields(value as Record<string, unknown>).map((f) => f.key),
    );
  for (const c of changes) {
    if (
      !allowed.has(c.key) ||
      c.key
        .split(".")
        .some((k) => ["__proto__", "prototype", "constructor"].includes(k))
    )
      throw new Error("This field is no longer editable.");
    const parts = c.key.split(".");
    let target = next as Record<string, unknown>;
    for (const p of parts.slice(0, -1))
      target = target[p] as Record<string, unknown>;
    target[parts.at(-1)!] = JSON.parse(c.value);
  }
  return next;
}
/** Compare the selected fields, not unrelated edits or JSON property order. */
export function canApplyHenryChanges(before: HenryScreen, current: HenryScreen, changes: Changes) {
  if (before.brandId !== current.brandId || before.section !== current.section ||
      !before.editor || !current.editor || before.editor.key !== current.editor.key) return false;
  return changes.every(change => {
    const previous = before.editor!.fields.find(field => field.key === change.key);
    const now = current.editor!.fields.find(field => field.key === change.key);
    return !!previous && !!now && (now.value === previous.value || now.value === change.value);
  });
}
export function WorkspaceHenry({
  api,
  workspaceId: w,
  section,
  perspective,
  children,
  header,
}: {
  api?: HenryGateway;
  workspaceId: string;
  section: string;
  perspective: WorkspacePerspective;
  children: ReactNode;
  header?: ReactNode;
}) {
  const [bindings, setBindings] = useState<Map<symbol, Registered>>(new Map());
  const register = useCallback(
    (id: symbol, binding: HenryBinding, section: string) => {
      setBindings((old) => new Map(old).set(id, { binding, section }));
      return () =>
        setBindings((old) => {
          const next = new Map(old);
          next.delete(id);
          return next;
        });
    },
    [],
  );
  const [brand, setBrand] = useState(""),
    [brands, setBrands] = useState<{ id: string; name: string }[]>([]);
  const pageBindings = [...bindings.values()].filter(
    (b) => b.section === section,
  );
  const pageBrands = [
    ...new Set(
      pageBindings
        .map((b) => b.binding.brandId)
        .filter((b): b is string => !!b),
    ),
  ];
  const pageBrand = pageBrands.length === 1 ? pageBrands[0] : undefined;
  useEffect(() => {
    if (pageBrand) setBrand(pageBrand);
  }, [pageBrand]);
  const effectiveBrand = pageBrand || brand;
  const active = pageBindings.filter(
    (b) => !b.binding.brandId || b.binding.brandId === effectiveBrand,
  );
  const [editorChoice, setEditorChoice] = useState("");
  const editors = active
    .filter((b) => b.binding.editor)
    .slice()
    .reverse()
    .sort((a, b) => (b.binding.priority ?? 0) - (a.binding.priority ?? 0));
  const focused =
    editors.find((b) => b.binding.key === editorChoice)?.binding ??
    editors[0]?.binding ??
    active.at(-1)?.binding;
  useEffect(() => setEditorChoice(""), [section, effectiveBrand]);
  const [turns, setTurns] = useState<HenryTurn[]>([]),
    [conversation, setConversation] = useState<string>(),
    [objective, setObjective] = useState("");
  const [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false),
    [available, setAvailable] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState("");
  const [expanded, setExpanded] = useState(false);
  const messageInput = useRef<HTMLTextAreaElement>(null);
  const [proposal, setProposal] = useState<{
    reply: HenryReply;
    screen: HenryScreen;
    selected: Set<string>;
  }>();
  const alive = useRef(true),
    request = useRef<AbortController | null>(null),
    lock = useRef(false),
    scopeRef = useRef(effectiveBrand);
  scopeRef.current = effectiveBrand;
  const navigate = useNavigate();
  useEffect(() => {
    setProposal(undefined);
    setNotice("");
    setError("");
  }, [section]);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
      request.current?.abort();
    };
  }, []);
  useEffect(() => {
    const c = new AbortController();
    setError("");
    setProposal(undefined);
    setTurns([]);
    setConversation(undefined);
    setObjective("");
    setMessage("");
    setNotice("");
    setAvailable(false);
    request.current?.abort();
    lock.current = false;
    setBusy(false);
    if (!api) return;
    void api
      .list(w, effectiveBrand, c.signal)
      .then((data) => {
        if (c.signal.aborted) return;
        setBrands(data.brands);
        setAvailable(data.available);
        setTurns(data.turns);
        if (!effectiveBrand && data.brands.length === 1)
          setBrand(data.brands[0]!.id);
        if (data.turns[0]) {
          setConversation(data.turns[0].conversationId);
          setObjective(data.turns[0].result.objective);
        }
      })
      .catch(() => {
        if (!c.signal.aborted) {
          setAvailable(false);
          setError(
            "Henry could not load this conversation. Refresh to retry; your records are unchanged.",
          );
        }
      });
    return () => c.abort();
  }, [api, w, effectiveBrand]);
  const safeSection = henrySection.safeParse(section);
  const actions = active
    .flatMap((b) => b.binding.actions ?? [])
    .filter((a, i, all) => all.findIndex((b) => b.id === a.id) === i)
    .slice(0, 80);
  const screen: HenryScreen = {
    section: safeSection.success ? safeSection.data : "overview",
    brandId: effectiveBrand,
    summary: active
      .map((b) => b.binding.summary)
      .join("\n")
      .slice(0, 18000),
    editor: focused?.editor ?? null,
    actions: actions.map(({ id, label }) => ({ id, label })),
  };
  const screenRef = useRef(screen);
  screenRef.current = screen;
  const visible = turns
    .filter(
      (t) => t.brandId === effectiveBrand && t.conversationId === conversation,
    )
    .slice()
    .reverse();
  const conversations = turns.filter(
    (t, i, all) =>
      t.brandId === effectiveBrand &&
      all.findIndex(
        (other) =>
          other.brandId === effectiveBrand &&
          other.conversationId === t.conversationId,
      ) === i,
  );
  const currentProposal =
    proposal &&
    proposal.screen.brandId === effectiveBrand &&
    proposal.screen.section === screen.section;
  const sameEditor =
    currentProposal &&
    canApplyHenryChanges(proposal.screen, screen, proposal.reply.changes.filter(c => proposal.selected.has(c.key)));
  const restore = (t: HenryTurn) => {
    setProposal({
      reply: t.result,
      screen: t.screen,
      selected: new Set(t.result.changes.map((c) => c.key)),
    });
    setNotice(
      "Review the proposal against the current editor. Nothing has been saved.",
    );
  };
  if (!api)
    return (
      <>
        {header}
        {children}
      </>
    );
  return (
    <HenryContext.Provider
      value={{
        register,
        section,
        objective,
        brandId: effectiveBrand,
        assist: available
          ? async (snapshot, instruction) => {
              if (!api || lock.current || snapshot.brandId !== effectiveBrand)
                throw new Error(
                  "Henry is busy or this brand changed. Try again.",
                );
              lock.current = true;
              setBusy(true);
              setError("");
              const c = new AbortController();
              request.current = c;
              const previous = turns.find(
                (t) =>
                  t.screen.editor?.key === snapshot.editor?.key &&
                  t.brandId === snapshot.brandId,
              );
              const recovered = turns.find(
                (t) =>
                  t.brandId === snapshot.brandId &&
                  t.instruction === instruction &&
                  JSON.stringify(t.screen) === JSON.stringify(snapshot),
              );
              const id = previous?.conversationId ?? crypto.randomUUID();
              try {
                if (recovered) return recovered.result;
                const result = await api.ask(
                  w,
                  {
                    screen: snapshot,
                    instruction,
                    objective,
                    conversationId: id,
                    requestKey: crypto.randomUUID(),
                  },
                  c.signal,
                );
                if (
                  !alive.current ||
                  c.signal.aborted ||
                  scopeRef.current !== snapshot.brandId
                )
                  throw new Error(
                    "The workspace changed. Reopen the offer to continue.",
                  );
                setTurns((old) => [
                  {
                    id: crypto.randomUUID(),
                    brandId: snapshot.brandId,
                    section: snapshot.section,
                    conversationId: id,
                    instruction,
                    result,
                    screen: snapshot,
                    createdAt: new Date().toISOString(),
                  },
                  ...old,
                ]);
                return result;
              } finally {
                if (request.current === c) {
                  lock.current = false;
                  if (alive.current) setBusy(false);
                }
              }
            }
          : undefined,
      }}
    >
      {header}
      <section
        className={`content-section workspace-henry ${expanded ? "is-open" : "is-compact"}`}
        aria-label="Ask Henry"
      >
        <header className="content-henry-header">
          <div>
            <h2>
              <button
                className="henry-heading-toggle"
                aria-label={expanded ? "Collapse Henry" : "Expand Henry"}
                aria-expanded={expanded}
                aria-controls="workspace-henry-panel"
                onClick={() => setExpanded(!expanded)}
              >
                {expanded ? "Close Henry" : "Ask Henry"}{" "}
                <span aria-hidden="true">{expanded ? "−" : "+"}</span>
              </button>
            </h2>
            <p
              role="status"
              className="henry-panel-status"
              hidden={!expanded && !busy && !error && !proposal}
            >
              {busy
                ? "Henry is working…"
                : error
                  ? "A request needs attention."
                  : proposal
                    ? "A reply is ready to review."
                    : "Your conversations are saved. Open Henry when you need him."}
            </p>
          </div>
          <button
            disabled={busy}
            onClick={() => {
              setExpanded(true);
              setConversation(crypto.randomUUID());
              requestAnimationFrame(() => messageInput.current?.focus());
              setObjective("");
              setMessage("");
              setProposal(undefined);
              setNotice("");
              setError("");
            }}
          >
            New conversation
          </button>
        </header>
        <div id="workspace-henry-panel" hidden={!expanded}>
          {conversations.length > 0 && (
            <label className="henry-conversation-picker">
              Conversation history
              <select
                value={conversation ?? ""}
                disabled={busy}
                onChange={(e) => {
                  const previous = conversations.find(
                    (t) => t.conversationId === e.target.value,
                  );
                  if (!previous) return;
                  setConversation(previous.conversationId);
                  setObjective(previous.result.objective);
                  setMessage("");
                  setProposal(undefined);
                  setNotice("");
                  setError("");
                }}
              >
                {!conversations.some(
                  (t) => t.conversationId === conversation,
                ) && (
                  <option value={conversation ?? ""}>New conversation</option>
                )}
                {conversations.map((t) => (
                  <option key={t.conversationId} value={t.conversationId}>
                    {new Date(t.createdAt).toLocaleDateString("en-GB")} ·{" "}
                    {t.result.objective || t.instruction}
                  </option>
                ))}
              </select>
            </label>
          )}
          {!pageBrand && brands.length > 1 && (
            <label>
              Brand
              <select value={brand} onChange={(e) => setBrand(e.target.value)}>
                <option value="">Choose a brand</option>
                {brands.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </label>
          )}
          {editors.length > 1 && (
            <label>
              Working on
              <select
                value={focused?.key ?? ""}
                onChange={(e) => {
                  setEditorChoice(e.target.value);
                  setProposal(undefined);
                  setNotice("");
                }}
              >
                {editors.map(({ binding: b }) => (
                  <option key={b.key} value={b.key}>
                    {b.editor!.title}
                  </option>
                ))}
              </select>
            </label>
          )}
          {effectiveBrand && (
            <p className="content-help">
              Working with{" "}
              {brands.find((b) => b.id === effectiveBrand)?.name ??
                "the selected brand"}
              . Context and suggestions stay within this client and brand.
            </p>
          )}
          {objective && (
            <p className="henry-objective">
              <strong>Current objective</strong>
              <br />
              {objective}
            </p>
          )}
          {visible.length > 0 && (
            <details className="henry-history" open>
              <summary>Conversation ({visible.length})</summary>
              <div
                role="log"
                aria-label="Conversation with Henry"
                className="content-conversation"
              >
                {visible.map((t) => (
                  <article className="content-turn" key={t.id}>
                    <p>
                      <strong>You</strong>
                      <br />
                      {t.instruction}
                    </p>
                    <p>
                      <strong>Henry</strong>
                      <br />
                      {t.result.reply}
                    </p>
                    <small>{sectionLabel(t.section)}</small>
                    {(t.result.changes.length > 0 ||
                      t.result.actionId ||
                      t.result.destination) && (
                      <button onClick={() => restore(t)}>
                        Review next step
                      </button>
                    )}
                  </article>
                ))}
              </div>
            </details>
          )}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (lock.current || !message.trim() || !effectiveBrand || !api)
                return;
              lock.current = true;
              setBusy(true);
              setError("");
              setNotice("");
              setProposal(undefined);
              const c = new AbortController();
              request.current = c;
              const snapshot = structuredClone(screen),
                id = conversation ?? crypto.randomUUID(),
                instruction = message.trim();
              setConversation(id);
              void api
                .ask(
                  w,
                  {
                    screen: snapshot,
                    instruction,
                    objective,
                    conversationId: id,
                    requestKey: crypto.randomUUID(),
                  },
                  c.signal,
                )
                .then((result) => {
                  if (
                    !alive.current ||
                    c.signal.aborted ||
                    scopeRef.current !== snapshot.brandId
                  )
                    return;
                  setTurns((old) => [
                    {
                      id: crypto.randomUUID(),
                      brandId: snapshot.brandId,
                      section: snapshot.section,
                      conversationId: id,
                      instruction,
                      result,
                      screen: snapshot,
                      createdAt: new Date().toISOString(),
                    },
                    ...old,
                  ]);
                  setObjective(result.objective);
                  setMessage("");
                  if (screenRef.current.section === snapshot.section)
                    setProposal({
                      reply: result,
                      screen: snapshot,
                      selected: new Set(result.changes.map((c) => c.key)),
                    });
                })
                .catch((e) => {
                  if (!c.signal.aborted) {
                    setError(
                      e instanceof Error &&
                        !["unavailable", "invalid", "conflict"].includes(
                          e.message,
                        )
                        ? e.message
                        : "Henry couldn’t complete this request. Your message and records are unchanged. Refresh to recover any completed reply before retrying.",
                    );
                  }
                })
                .finally(() => {
                  if (request.current === c) {
                    lock.current = false;
                    if (alive.current) setBusy(false);
                  }
                });
            }}
          >
            <label htmlFor="workspace-henry-message">Your message</label>
            <textarea
              ref={messageInput}
              id="workspace-henry-message"
              rows={3}
              value={message}
              maxLength={6000}
              disabled={busy}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tell Henry what you want to achieve or change…"
            />
            <div className="content-actions">
              <button
                className="button"
                disabled={
                  busy || !available || !effectiveBrand || !message.trim()
                }
              >
                {busy ? "Henry is working…" : "Ask Henry"}
              </button>
            </div>
          </form>
          {error && <p role="alert">{error}</p>}
          {notice && <p role="status">{notice}</p>}
          {!available && (
            <p>
              Henry is unavailable at present. The existing forms and records
              remain available.
            </p>
          )}
          {proposal && proposal.screen.brandId === effectiveBrand && (
            <section className="henry-review" aria-label="Henry proposal">
              {proposal.reply.changes.length > 0 && (
                <>
                  <h3>Suggested changes</h3>
                  <p>
                    Choose which suggestions to put into the editor. Review and
                    save there when ready.
                  </p>
                  {proposal.reply.changes.map((c) => (
                    <label className="henry-change" key={c.key}>
                      <input
                        type="checkbox"
                        checked={proposal.selected.has(c.key)}
                        onChange={(e) =>
                          setProposal({
                            ...proposal,
                            selected: new Set(
                              e.target.checked
                                ? [...proposal.selected, c.key]
                                : [...proposal.selected].filter(
                                    (k) => k !== c.key,
                                  ),
                            ),
                          })
                        }
                      />
                      <span>
                        <strong>
                          {
                            proposal.screen.editor?.fields.find(
                              (f) => f.key === c.key,
                            )?.label
                          }
                        </strong>
                        <span className="henry-change-value">
                          {displayValue(c.value)}
                        </span>
                        <small>{c.reason}</small>
                      </span>
                    </label>
                  ))}
                  <button
                    disabled={
                      !sameEditor ||
                      busy ||
                      !proposal.selected.size ||
                      !focused?.apply
                    }
                    onClick={() => {
                      try {
                        if (
                          !canApplyHenryChanges(proposal.screen, screenRef.current, proposal.reply.changes.filter(c => proposal.selected.has(c.key)))
                        )
                          throw new Error(
                            "The editor changed. Ask Henry to revise these suggestions.",
                          );
                        focused?.apply?.(
                          proposal.reply.changes.filter((c) =>
                            proposal.selected.has(c.key),
                          ),
                        );
                        setProposal(undefined);
                        setNotice(
                          "Suggestions added to the editor below. Review and save them there.",
                        );
                      } catch (e) {
                        setError(
                          e instanceof Error
                            ? e.message
                            : "Review these fields before continuing.",
                        );
                      }
                    }}
                  >
                    Use selected suggestions
                  </button>
                  {!sameEditor && (
                    <p>
                      A selected field has changed, or its editor is no longer open.
                      Deselect suggestions for fields you have edited, or ask Henry
                      to revise them. Your edits will not be overwritten.
                    </p>
                  )}
                </>
              )}
              <div className="content-actions">
                {currentProposal &&
                  proposal.reply.actionId &&
                  actions.find((a) => a.id === proposal.reply.actionId) && (
                    <button
                      disabled={
                        busy ||
                        JSON.stringify(proposal.screen) !==
                          JSON.stringify(screen)
                      }
                      onClick={() => {
                        actions
                          .find((a) => a.id === proposal.reply.actionId)
                          ?.run(objective);
                        setProposal(undefined);
                        setNotice(
                          "The relevant controls are ready below. Review them before continuing.",
                        );
                      }}
                    >
                      {
                        actions.find((a) => a.id === proposal.reply.actionId)
                          ?.label
                      }
                    </button>
                  )}
                {proposal.reply.destination &&
                  proposal.reply.destination !== section && (
                    <button
                      onClick={() => {
                        if (
                          screen.editor &&
                          !window.confirm(
                            "Continue to another function? Unsaved editor changes will be left behind.",
                          )
                        )
                          return;
                        setProposal(undefined);
                        navigate(
                          workspacePath(
                            perspective,
                            w,
                            proposal.reply.destination!,
                          ),
                        );
                      }}
                    >
                      Continue to {sectionLabel(proposal.reply.destination)}
                    </button>
                  )}
              </div>
            </section>
          )}
        </div>
      </section>
      {children}
    </HenryContext.Provider>
  );
}
function displayValue(value: string) {
  try {
    const v = JSON.parse(value);
    return typeof v === "string"
      ? v
      : Array.isArray(v)
        ? v
            .map((x) => (typeof x === "object" ? JSON.stringify(x) : String(x)))
            .join("\n")
        : JSON.stringify(v);
  } catch {
    return value;
  }
}
