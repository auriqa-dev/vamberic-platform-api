import { IcpDiscovery } from "./icp-discovery";
import { useEffect, useRef, useState } from "react";
import type { IcpGateway, IcpRecord, IcpOffer } from "../data/icp";
import type {
  IcpPolicy,
  PolicyDefinition,
  MarketResult,
} from "../data/icp-eligibility";
export function IcpEligibility({
  api,
  w,
  profiles,
  offers,
  readOnly = false,
}: {
  api: IcpGateway;
  w: string;
  profiles: IcpRecord[];
  offers: IcpOffer[];
  readOnly?: boolean;
}) {
  const [policies, setPolicies] = useState<IcpPolicy[]>([]),
    [selected, setSelected] = useState<IcpPolicy>();
  const [draft, setDraft] = useState<PolicyDefinition>({
    name: "",
    segments: [],
    offerPriority: [],
    exclusivity: "multiple_offers",
  });
  const [result, setResult] = useState<MarketResult>(),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [editing, setEditing] = useState(false);
  const [recordType, setRecordType] = useState<"organisations" | "people">(
    "organisations",
  );
  const [checked, setChecked] = useState<string[]>([]);
  const [deleting, setDeleting] = useState<IcpPolicy[]>([]);
  const [notice, setNotice] = useState("");
  const deleteDialog = useRef<HTMLDialogElement>(null);
  const requestDelete = (rows: IcpPolicy[]) => {
    setDeleting(rows);
    setError("");
    setNotice("");
    deleteDialog.current?.showModal();
  };
  const lock = useRef(false),
    key = useRef(crypto.randomUUID());
  useEffect(() => {
    const c = new AbortController();
    api
      .policies?.(w, c.signal)
      .then((rows) => {
        if (!c.signal.aborted) setPolicies(rows);
      })
      .catch(() => {
        if (!c.signal.aborted)
          setError("Eligibility policies could not be loaded.");
      });
    return () => c.abort();
  }, [api, w]);
  const change = (next: PolicyDefinition) => {
    setDraft(next);
    key.current = crypto.randomUUID();
    setError("");
  };
  async function run(work: () => Promise<void>) {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await work();
    } catch {
      setError(
        "This action could not be completed. Check that the profiles and offers still have current approvals. Your edits are retained.",
      );
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  async function findMatches(offset: number) {
    if (!selected) return;
    await run(async () => {
      setResult(undefined);
      setResult(
        await api.identify!(
          w,
          selected.id,
          offset,
          new AbortController().signal,
          recordType,
        ),
      );
    });
  }
  const name = (id: string) =>
    offers.find((o) => o.id === id)?.definition.name ??
    "Offer from another product";
  const eligible = profiles.filter(
    (p) =>
      p.approvedRevision &&
      p.offer &&
      p.offerLinkStatus !== "stale" &&
      p.status === "approved",
  );
  if (!api.policies) return null;
  return (
    <section className="panel icp-eligibility">
      <div className="card-heading">
        <div>
          <h2>
            {readOnly
              ? "Approved engagement constraints"
              : "Segments and offer eligibility"}
          </h2>
          <p>
            {readOnly
              ? "Contact Strategy uses the approved ICP policies below. Eligibility does not start outreach or select a campaign."
              : "Each approved ICP is a segment. Add explicit matching rules and decide what happens when an organisation fits more than one offer."}
          </p>
        </div>
        {!readOnly && (
          <button
            disabled={busy || editing}
            onClick={() => {
              setSelected(undefined);
              setResult(undefined);
              setDraft({
                name: "",
                segments: [],
                offerPriority: [],
                exclusivity: "multiple_offers",
              });
              setEditing(true);
              key.current = crypto.randomUUID();
            }}
          >
            Add policy
          </button>
        )}
      </div>
      {error && <p role="alert">{error}</p>}
      {notice && <p role="status">{notice}</p>}
      {!readOnly &&
        api.deletePolicyDrafts &&
        policies.some((p) => p.status === "draft") && (
          <div className="icp-actions">
            <label>
              <input
                type="checkbox"
                disabled={busy || editing}
                checked={policies
                  .filter((p) => p.status === "draft")
                  .every((p) => checked.includes(p.id))}
                onChange={(e) =>
                  setChecked(
                    e.target.checked
                      ? policies
                          .filter((p) => p.status === "draft")
                          .map((p) => p.id)
                      : [],
                  )
                }
              />
              Select all drafts
            </label>
            <button
              disabled={busy || editing || !checked.length}
              onClick={() =>
                requestDelete(
                  policies.filter(
                    (p) => p.status === "draft" && checked.includes(p.id),
                  ),
                )
              }
            >
              Delete selected drafts ({checked.length})
            </button>
          </div>
        )}
      {policies
        .filter((p) => !readOnly || p.status === "approved")
        .map((p) => (
          <div className="icp-policy-row" key={p.id}>
            {!readOnly && api.deletePolicyDrafts && p.status === "draft" && (
              <label className="icp-policy-select">
                <input
                  type="checkbox"
                  aria-label={`Select ${p.definition.name}`}
                  disabled={busy || editing}
                  checked={checked.includes(p.id)}
                  onChange={(e) =>
                    setChecked(
                      e.target.checked
                        ? [...checked, p.id]
                        : checked.filter((id) => id !== p.id),
                    )
                  }
                />
              </label>
            )}
            <button
              className="icp-record"
              disabled={busy || editing}
              onClick={() => {
                setSelected(p);
                setEditing(false);
                setResult(undefined);
              }}
            >
              <strong>{p.definition.name}</strong>
              <span>
                {p.status}
                {p.status === "approved"
                  ? p.active
                    ? " · Current"
                    : " · Superseded"
                  : ""}
                {p.stale ? " · Review required" : ""}
              </span>
            </button>
            {!readOnly && api.deletePolicyDrafts && p.status === "draft" && (
              <button
                disabled={busy || editing}
                aria-label={`Delete ${p.definition.name}`}
                onClick={() => requestDelete([p])}
              >
                Delete draft
              </button>
            )}
          </div>
        ))}
      {!policies.length && (
        <p>No eligibility policies yet. Approve offer-linked profiles first.</p>
      )}
      {selected && !editing && (
        <div>
          <h3>{selected.definition.name}</h3>
          <p>
            {selected.definition.exclusivity === "one_offer_per_organisation"
              ? "Only the highest-priority matching offer is permitted for an organisation and all its contacts. Consumer offer permission requires a revised policy."
              : selected.definition.exclusivity === "one_offer_per_customer"
                ? "Only the highest-priority matching offer is permitted per organisation (including its business contacts) or per person for consumer offers."
                : "Multiple matching offers are permitted. Campaign selection remains a separate decision."}
          </p>
          <ol>
            {selected.definition.offerPriority.map((id) => (
              <li key={id}>{name(id)}</li>
            ))}
          </ol>
          <p>
            {selected.definition.segments.length} approved profile{" "}
            {selected.definition.segments.length === 1 ? "segment" : "segments"}
            . Matching uses recorded industry, country, region and company-size
            values for organisations, and job title, department or seniority for
            contacts. Values must match exactly, ignoring capitalisation.
            Consumer segments use a person’s recorded preferred language and
            time zone. Missing facts are not inferred.
          </p>
          <details>
            <summary>Review the matching criteria</summary>
            {selected.definition.segments.map((segment) => (
              <section key={segment.icpId}>
                <h4>
                  {profiles.find((p) => p.id === segment.icpId)?.definition
                    .name ?? "Approved profile"}{" "}
                  · Version {segment.revision}
                </h4>
                <ul>
                  {segment.rules.map((rule, index) => (
                    <li key={index}>
                      {rule.field}:{" "}
                      {rule.effect === "include"
                        ? "must match"
                        : "must not match"}{" "}
                      {rule.values.join(", ")}
                    </li>
                  ))}
                </ul>
              </section>
            ))}
          </details>
          {selected.stale && (
            <p role="status">
              A profile or offer changed. Review and save a new policy before
              using it.
            </p>
          )}
          {selected.status === "approved" && selected.active && (
            <label className="icp-match-scope">
              Records to assess
              <select
                value={recordType}
                disabled={busy}
                onChange={(e) => {
                  setRecordType(e.target.value as "organisations" | "people");
                  setResult(undefined);
                  setError("");
                }}
              >
                <option value="organisations">
                  Organisations and business contacts
                </option>
                <option value="people">People — consumer profiles</option>
              </select>
            </label>
          )}
          <div className="icp-actions">
            {!readOnly && (
              <button
                disabled={busy}
                onClick={() => {
                  setDraft(structuredClone(selected.definition));
                  setEditing(true);
                  key.current = crypto.randomUUID();
                }}
              >
                {selected.status === "draft" && api.updatePolicy
                  ? "Edit draft"
                  : "Edit as new version"}
              </button>
            )}
            {!readOnly && selected.status === "draft" && (
              <button
                disabled={busy || selected.stale}
                onClick={() =>
                  void run(async () => {
                    const rows = await api.approvePolicy!(
                      w,
                      selected,
                      new AbortController().signal,
                    );
                    setPolicies(rows);
                    setSelected(rows.find((p) => p.id === selected.id));
                  })
                }
              >
                Approve policy
              </button>
            )}
            {selected.status === "approved" && selected.active && (
              <button
                disabled={busy || selected.stale}
                onClick={() => void findMatches(0)}
              >
                Find matching Hive records
              </button>
            )}
          </div>
        </div>
      )}
      {selected?.status === "approved" &&
        selected.active &&
        !selected.stale &&
        !readOnly && (
          <IcpDiscovery
            key={selected.id}
            api={api}
            w={w}
            policyId={selected.id}
          />
        )}
      {editing && !readOnly && (
        <fieldset disabled={busy}>
          <label>
            Policy name
            <input
              value={draft.name}
              maxLength={200}
              onChange={(e) => change({ ...draft, name: e.target.value })}
            />
          </label>
          <label>
            When offers overlap
            <select
              value={draft.exclusivity}
              onChange={(e) =>
                change({
                  ...draft,
                  exclusivity: e.target
                    .value as PolicyDefinition["exclusivity"],
                })
              }
            >
              <option value="multiple_offers">Permit multiple offers</option>
              <option value="one_offer_per_organisation">
                One offer per organisation (business only)
              </option>
              <option value="one_offer_per_customer">
                One offer per customer (organisation or consumer)
              </option>
            </select>
          </label>
          <label>
            Add an approved profile segment
            <select
              value=""
              onChange={(e) => {
                const p = eligible.find((p) => p.id === e.target.value);
                if (p?.offer && p.approvedRevision)
                  change({
                    ...draft,
                    segments: [
                      ...draft.segments,
                      { icpId: p.id, revision: p.approvedRevision, rules: [] },
                    ],
                    offerPriority: [
                      ...new Set([...draft.offerPriority, p.offer.id]),
                    ],
                  });
              }}
            >
              <option value="">Choose a profile</option>
              {eligible
                .filter((p) => !draft.segments.some((s) => s.icpId === p.id))
                .map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.definition.name}
                  </option>
                ))}
            </select>
          </label>
          {draft.segments.map((segment, index) => (
            <section className="icp-policy-segment" key={segment.icpId}>
              <h3>
                {profiles.find((p) => p.id === segment.icpId)?.definition
                  .name ?? "Previously selected profile"}{" "}
                · Version {segment.revision}
              </h3>
              <p>
                {profiles.find((p) => p.id === segment.icpId)?.definition
                  .profileType === "b2b"
                  ? "Use at least one organisation rule. Add contact rules to identify relevant people within matching organisations. Use two-letter country codes (for example GB) and the recorded company size band."
                  : "Consumer matching currently supports recorded preferred language (for example en-GB) and time zone (for example Europe/London). These do not establish location, buying needs or consent. Business fields cannot qualify a consumer."}
              </p>
              {segment.rules.map((rule, i) => (
                <div className="icp-grid" key={i}>
                  <label>
                    Recorded field
                    <select
                      value={rule.field}
                      onChange={(e) =>
                        change({
                          ...draft,
                          segments: draft.segments.map((s, n) =>
                            n !== index
                              ? s
                              : {
                                  ...s,
                                  rules: s.rules.map((r, j) =>
                                    j !== i
                                      ? r
                                      : {
                                          ...r,
                                          field: e.target
                                            .value as typeof r.field,
                                        },
                                  ),
                                },
                          ),
                        })
                      }
                    >
                      {[
                        ...new Set([
                          ...(profiles.find((p) => p.id === segment.icpId)
                            ?.definition.profileType === "b2b"
                            ? [
                                "industry",
                                "country",
                                "region",
                                "size",
                                "jobTitle",
                                "department",
                                "seniority",
                              ]
                            : [
                                "preferredLanguage",
                                "timezone",
                                "consumerCountry",
                                "consumerRegion",
                                "consumerNeeds",
                                "consumerInterests",
                                "purchaseStage",
                              ]),
                          rule.field,
                        ]),
                      ].map((f) => (
                        <option key={f} value={f}>
                          {(
                            {
                              size: "Company size band",
                              jobTitle: "Contact job title",
                              department: "Contact department",
                              seniority: "Contact seniority",
                              preferredLanguage: "Preferred language",
                              timezone: "Time zone",
                              consumerCountry: "Consumer country",
                              consumerRegion: "Consumer region",
                              consumerNeeds: "Recorded needs",
                              consumerInterests: "Recorded interests",
                              purchaseStage: "Purchase stage",
                            } as Record<string, string>
                          )[f] ?? f}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Rule
                    <select
                      value={rule.effect}
                      onChange={(e) =>
                        change({
                          ...draft,
                          segments: draft.segments.map((s, n) =>
                            n !== index
                              ? s
                              : {
                                  ...s,
                                  rules: s.rules.map((r, j) =>
                                    j !== i
                                      ? r
                                      : {
                                          ...r,
                                          effect: e.target
                                            .value as typeof r.effect,
                                        },
                                  ),
                                },
                          ),
                        })
                      }
                    >
                      <option value="include">Must match one of</option>
                      <option value="exclude">Must not match</option>
                    </select>
                  </label>
                  <label className="icp-wide">
                    Values (one per line)
                    {rule.field === "purchaseStage" && <small>Use exploring, comparing, ready_to_buy or existing_customer.</small>}
                    <textarea
                      rows={2}
                      value={rule.values.join("\n")}
                      onChange={(e) =>
                        change({
                          ...draft,
                          segments: draft.segments.map((s, n) =>
                            n !== index
                              ? s
                              : {
                                  ...s,
                                  rules: s.rules.map((r, j) =>
                                    j !== i
                                      ? r
                                      : {
                                          ...r,
                                          values: e.target.value.split("\n"),
                                        },
                                  ),
                                },
                          ),
                        })
                      }
                    />
                  </label>
                  <button
                    onClick={() =>
                      change({
                        ...draft,
                        segments: draft.segments.map((s, n) =>
                          n !== index
                            ? s
                            : {
                                ...s,
                                rules: s.rules.filter((_, j) => j !== i),
                              },
                        ),
                      })
                    }
                  >
                    Remove rule
                  </button>
                </div>
              ))}
              <div className="icp-actions">
                <button
                  onClick={() =>
                    change({
                      ...draft,
                      segments: draft.segments.map((s, n) =>
                        n !== index
                          ? s
                          : {
                              ...s,
                              rules: [
                                ...s.rules,
                                {
                                  field:
                                    profiles.find((p) => p.id === segment.icpId)
                                      ?.definition.profileType === "b2b"
                                      ? "industry"
                                      : "preferredLanguage",
                                  values: [""],
                                  effect: "include",
                                },
                              ],
                            },
                      ),
                    })
                  }
                >
                  Add matching rule
                </button>
                <button
                  onClick={() => {
                    const segments = draft.segments.filter(
                      (_, n) => n !== index,
                    );
                    const linked = new Set(
                      segments.map(
                        (s) =>
                          profiles.find((p) => p.id === s.icpId)?.offer?.id,
                      ),
                    );
                    change({
                      ...draft,
                      segments,
                      offerPriority: draft.offerPriority.filter((id) =>
                        linked.has(id),
                      ),
                    });
                  }}
                >
                  Remove segment
                </button>
              </div>
            </section>
          ))}
          <h3>Offer priority</h3>
          <p>
            Highest priority first. Move offers into your chosen order before
            approval.
          </p>
          {draft.offerPriority.map((id, i) => (
            <div className="icp-actions" key={id}>
              <span>
                {i + 1}. {name(id)}
              </span>
              <button
                disabled={!i}
                onClick={() => {
                  const ids = [...draft.offerPriority];
                  [ids[i - 1], ids[i]] = [ids[i]!, ids[i - 1]!];
                  change({ ...draft, offerPriority: ids });
                }}
              >
                Move up
              </button>
            </div>
          ))}
          <button
            className="button"
            disabled={
              !draft.name.trim() ||
              !draft.segments.length ||
              draft.segments.some(
                (s) =>
                  !s.rules.length ||
                  s.rules.some((r) => r.values.some((v) => !v.trim())),
              )
            }
            onClick={() =>
              void run(async () => {
                const row =
                  selected?.status === "draft" && api.updatePolicy
                    ? await api.updatePolicy(
                        w,
                        selected,
                        draft,
                        key.current,
                        new AbortController().signal,
                      )
                    : await api.savePolicy!(
                        w,
                        draft,
                        key.current,
                        new AbortController().signal,
                      );
                setPolicies([row, ...policies.filter((p) => p.id !== row.id)]);
                setSelected(row);
                setEditing(false);
                setNotice("Policy draft saved.");
              })
            }
          >
            {selected?.status === "draft" && api.updatePolicy
              ? "Save changes"
              : "Save policy draft"}
          </button>
          <button
            type="button"
            onClick={() => {
              setEditing(false);
              setError("");
            }}
          >
            Cancel editing
          </button>
        </fieldset>
      )}
      {result && (
        <section>
          <p role="status">{result.notice}</p>
          {!result.items.length && (
            <p>
              No {result.recordType === "people" ? "people" : "organisations"}{" "}
              to assess on this page.
            </p>
          )}
          <div
            className="table-scroll"
            tabIndex={0}
            role="region"
            aria-label="Strategic eligibility results"
          >
            <table>
              <thead>
                <tr>
                  <th>
                    {result.recordType === "people" ? "Person" : "Organisation"}
                  </th>
                  <th>Approved rule fit</th>
                  <th>Permitted offers</th>
                  <th>
                    {result.recordType === "people"
                      ? "Recorded person details"
                      : "Known contacts"}
                  </th>
                </tr>
              </thead>
              <tbody>
                {result.items.map((row) => (
                  <tr key={row.id}>
                    <td>{row.name}</td>
                    <td>
                      {row.fits.map((f) => (
                        <div key={f.icpId}>
                          {f.fit.replaceAll("_", " ")}
                          {f.reasons.length > 0 && (
                            <small> — {f.reasons.join("; ")}</small>
                          )}
                        </div>
                      ))}
                    </td>
                    <td>
                      {row.permittedOfferIds.map(name).join(", ") ||
                        "None confirmed"}
                    </td>
                    <td>
                      {row.contacts.map((c) => (
                        <div key={c.id}>
                          {c.name}
                          {c.jobTitle ? ` · ${c.jobTitle}` : ""} · Role fit:{" "}
                          {c.roleFit.replaceAll("_", " ")}
                          <small>
                            Permitted offers:{" "}
                            {c.permittedOfferIds.map(name).join(", ") ||
                              "None confirmed"}
                          </small>
                          {c.fits.map((f) => (
                            <small key={f.icpId}>
                              {name(f.offerId)}: {f.fit.replaceAll("_", " ")}
                              {f.reasons.length
                                ? ` — ${f.reasons.join("; ")}`
                                : ""}
                            </small>
                          ))}
                        </div>
                      ))}
                      {result.recordType === "people" ? (
                        <>
                          <div>
                            Preferred language:{" "}
                            {row.preferredLanguage || "Not recorded"}
                          </div>
                          <div>Time zone: {row.timezone || "Not recorded"}</div>
                          <div>
                            Characteristics recorded:{" "}
                            {row.consumerObservedOn || "Not recorded"}
                          </div>
                        </>
                      ) : (
                        !row.contacts.length && "No contacts recorded"
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="icp-actions">
            <button
              disabled={busy || result.offset === 0}
              onClick={() => void findMatches(Math.max(0, result.offset - 50))}
            >
              Previous records
            </button>
            <button
              disabled={busy || !result.hasMore}
              onClick={() => void findMatches(result.offset + 50)}
            >
              Next records
            </button>
          </div>
        </section>
      )}
      <dialog
        className="profile-delete-dialog icp-policy-dialog"
        style={{ margin: "auto" }}
        ref={deleteDialog}
        aria-label="Delete policy drafts"
        onCancel={(e) => {
          if (busy) e.preventDefault();
        }}
      >
        <h2>
          Delete{" "}
          {deleting.length === 1 ? "this draft?" : `${deleting.length} drafts?`}
        </h2>
        <p>
          These drafts will be removed from the policy list. Approved policies
          and audit history are preserved.
        </p>
        <ul>
          {deleting.map((p) => (
            <li key={p.id}>{p.definition.name}</li>
          ))}
        </ul>
        {error && <p role="alert">{error}</p>}
        <div className="icp-actions">
          <button disabled={busy} onClick={() => deleteDialog.current?.close()}>
            Cancel
          </button>
          <button
            className="button"
            disabled={busy}
            onClick={() =>
              void run(async () => {
                const response = await api.deletePolicyDrafts!(
                  w,
                  deleting,
                  new AbortController().signal,
                );
                const deleted = new Set(
                  response.results
                    .filter((r) => r.status === "deleted")
                    .map((r) => r.id),
                );
                setPolicies((rows) => rows.filter((p) => !deleted.has(p.id)));
                setChecked((ids) => ids.filter((id) => !deleted.has(id)));
                if (selected && deleted.has(selected.id)) {
                  setSelected(undefined);
                  setResult(undefined);
                }
                const failures = response.results.filter(
                  (r) => r.status !== "deleted",
                );
                setNotice(
                  `${deleted.size} draft${deleted.size === 1 ? "" : "s"} deleted.`,
                );
                if (failures.length)
                  setError(
                    failures
                      .map(
                        (r) =>
                          `${deleting.find((p) => p.id === r.id)?.definition.name ?? "Draft"}: ${r.status === "protected" ? "now approved and cannot be deleted" : r.status === "changed" ? "changed since selection; reload before deleting" : "no longer available"}.`,
                      )
                      .join(" "),
                  );
                deleteDialog.current?.close();
              })
            }
          >
            {busy ? "Deleting…" : "Delete drafts"}
          </button>
        </div>
      </dialog>
    </section>
  );
}
