import { useHenryBinding, henryFields, applyHenryFields } from "./workspace-henry";
import {
  useCallback,
  useEffect,
  useId,
  useRef,
  useState,
  type FormEvent,
} from "react";
import { z } from "zod";
import { DataError, type HvmGateway } from "../data/gateway";
import { useRefreshingResource } from "../data/use-refreshing-resource";
import { useDraft } from "../forms/use-draft";
import { normalisePrimaryDomain } from "../forms/primary-domain";
import { Failure, Loading } from "./ui";

type Editable = {
  id: string;
  name: string;
  updatedAt: string;
  primaryDomain?: string;
};
export function OnboardingEditor({
  gateway,
  workspaceId,
  refresh,
  onSaved,
}: {
  gateway: HvmGateway;
  workspaceId: string;
  refresh: unknown;
  onSaved: () => void;
}) {
  const load = useCallback(
    (signal: AbortSignal) => {
      void refresh;
      return gateway.readOnboarding!(workspaceId, signal);
    },
    [gateway, workspaceId, refresh],
  );
  const result = useRefreshingResource(load);
  if (result.state === "loading") return <Loading />;
  if (result.state === "error") return <Failure error={result.error} />;
  return (
    <section className="panel">
      <h2>Update workspace details</h2>
      <p>
        Details entered during onboarding are already saved. Only edit and save
        them here if something has changed.
      </p>
      <DetailsForm
        key={workspaceId}
        gateway={gateway}
        workspaceId={workspaceId}
        value={result.data.overview.workspace}
        onSaved={onSaved}
      />
      {result.data.brands.map((b) => (
        <DetailsForm
          key={b.id}
          gateway={gateway}
          workspaceId={workspaceId}
          value={{
            id: b.id,
            name: b.name,
            primaryDomain: b.primaryDomain ?? "",
            updatedAt: b.updatedAt,
          }}
          brand
          onSaved={onSaved}
        />
      ))}
    </section>
  );
}
function DetailsForm({
  gateway,
  workspaceId,
  value,
  brand = false,
  onSaved,
}: {
  gateway: HvmGateway;
  workspaceId: string;
  value: Editable;
  brand?: boolean;
  onSaved: () => void;
}) {
  const editor = useDraft(value);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>();
  const [message, setMessage] = useState("");
  const [domainError, setDomainError] = useState("");
  const domainHelpId = useId();
  const domainErrorId = useId();
  const controller = useRef(new AbortController());
  const saving = useRef(false);
  useEffect(() => {
    controller.current = new AbortController();
    return () => controller.current.abort();
  }, []);
  const henryDetails={name:editor.draft.name,...(brand?{primaryDomain:editor.draft.primaryDomain??""}:{})};
  useHenryBinding({key:`setup:${value.id}`,brandId:brand?value.id:undefined,priority:brand?10:0,summary:JSON.stringify({type:brand?"Brand":"Workspace",...henryDetails}),
    editor:!busy&&!editor.conflict?{key:`setup:${value.id}:${value.updatedAt}`,title:brand?"Brand details":"Workspace details",fields:henryFields(henryDetails)}:undefined,
    apply:changes=>{editor.edit({...editor.draft,...applyHenryFields(henryDetails,changes)});setDomainError("");},
  });
  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (saving.current || !editor.dirty || editor.conflict) return;
    const domain = brand
      ? normalisePrimaryDomain(editor.draft.primaryDomain ?? "")
      : undefined;
    setError(undefined);
    setMessage("");
    if (brand && !domain) {
      setDomainError(
        "Enter a valid website URL or domain, for example https://www.example.com or example.com.",
      );
      return;
    }
    setDomainError("");
    saving.current = true;
    setBusy(true);
    setError(undefined);
    setMessage("");
    const draft = brand
      ? { ...editor.draft, primaryDomain: domain }
      : editor.draft;
    try {
      const raw = await gateway.write!(
        workspaceId,
        brand ? "brand-update" : "profile",
        brand
          ? {
              id: draft.id,
              expectedUpdatedAt: draft.updatedAt,
              changes: { name: draft.name, primaryDomain: draft.primaryDomain },
            }
          : { name: draft.name, expectedUpdatedAt: draft.updatedAt },
        controller.current.signal,
      );
      const saved = z
        .object({ id: z.literal(draft.id), updatedAt: z.string().datetime() })
        .parse(raw);
      if (!controller.current.signal.aborted) {
        editor.saved({ ...draft, updatedAt: saved.updatedAt });
        setMessage("Changes saved.");
        onSaved();
      }
    } catch (e) {
      if (!controller.current.signal.aborted) {
        setError(e);
        if (e instanceof DataError && e.code === "conflict") {
          editor.markConflict();
          onSaved();
        }
      }
    } finally {
      if (!controller.current.signal.aborted) {
        saving.current = false;
        setBusy(false);
      }
    }
  }
  return (
    <form onSubmit={(e) => void save(e)} className="details-form">
      {brand && <h3>{value.name}</h3>}
      {error instanceof DataError && error.code === "invalid" ? (
        <p role="alert">
          We couldn’t save these details. Check the name
          {brand ? " and website domain" : ""} and try again. Your changes are
          still here.
        </p>
      ) : error ? (
        <Failure error={error} />
      ) : null}
      {editor.conflict && (
        <p role="alert">
          The server value changed or a save conflicted. Your draft is
          preserved. Discard changes to use the latest loaded value before
          editing again.
        </p>
      )}
      <label>
        {brand ? "Brand name" : "Workspace name"}
        <input
          required
          maxLength={200}
          disabled={busy}
          value={editor.draft.name}
          onChange={(e) =>
            editor.edit({ ...editor.draft, name: e.target.value })
          }
        />
      </label>
      {brand && (
        <div>
          <label>
            Primary domain
            <input
              required
              maxLength={2048}
              aria-invalid={Boolean(domainError)}
              aria-describedby={
                domainError ? `${domainHelpId} ${domainErrorId}` : domainHelpId
              }
              disabled={busy}
              value={editor.draft.primaryDomain ?? ""}
              onChange={(e) => {
                editor.edit({ ...editor.draft, primaryDomain: e.target.value });
                setDomainError("");
                setError(undefined);
              }}
            />
          </label>
          <span id={domainHelpId} className="muted small">
            Your saved website domain. To change it, paste a website URL or
            enter a domain.
          </span>
          {domainError && (
            <span id={domainErrorId} role="alert">
              {domainError}
            </span>
          )}
        </div>
      )}
      <div className="form-actions">
        <button
          className="button"
          disabled={busy || editor.conflict || !editor.dirty}
        >
          Save {brand ? "brand" : "workspace"}
        </button>
        <button
          type="button"
          className="button secondary"
          disabled={busy || (!editor.dirty && !editor.conflict)}
          onClick={() => {
            editor.reset();
            setError(undefined);
            setDomainError("");
            setMessage("Changes discarded.");
          }}
        >
          Discard changes
        </button>
      </div>
      <p role="status">
        {busy
          ? "Saving…"
          : editor.dirty
            ? "Unsaved changes"
            : message || "Saved — no changes to save."}
      </p>
    </form>
  );
}
