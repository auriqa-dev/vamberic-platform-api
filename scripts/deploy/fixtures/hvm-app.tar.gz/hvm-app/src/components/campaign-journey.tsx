import { useEffect, useRef, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import type {
  Campaign,
  CampaignGateway,
  CampaignJourney as Journey,
  RecipientReview,
} from "../data/campaigns";
import { useHenryBinding } from "./workspace-henry";

export function CampaignJourney({
  api,
  workspaceId: w,
  campaign,
  onEdit,
}: {
  api: CampaignGateway;
  workspaceId: string;
  campaign: Campaign;
  onEdit: () => void;
}) {
  const location = useLocation(),
    navigate = useNavigate();
  const path = (section: string) =>
    location.pathname.replace(/\/campaigns(?:\/.*)?$/, `/${section}`);
  const link = (section: string) =>
    `${path(section)}?${new URLSearchParams({ ...Object.fromEntries(new URLSearchParams(location.search)), campaign: campaign.id })}`;
  const [data, setData] = useState<Journey>(),
    [recipients, setRecipients] = useState<RecipientReview[]>([]),
    [exclusions, setExclusions] = useState("");
  const [candidates, setCandidates] = useState<RecipientReview[]>([]),
    [search, setSearch] = useState(""),
    [offset, setOffset] = useState(0),
    [more, setMore] = useState(false);
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [confirmed, setConfirmed] = useState(false),
    [reason, setReason] = useState("");
  const [step, setStep] = useState("prepare"),
    [dirty, setDirty] = useState(false),
    [checked, setChecked] = useState<string[]>([]),
    [bulkReason, setBulkReason] = useState("");
  const epoch = useRef(0),
    locked = useRef(false),
    requestKey = useRef(crypto.randomUUID());
  const accept = (d: Journey) => {
    setData(d);
    setRecipients(d.recipients);
    setExclusions(d.excludedOrganisations.join("\n"));
    setConfirmed(false);
    setDirty(false);
    requestKey.current = crypto.randomUUID();
  };
  useEffect(() => {
    const controller = new AbortController();
    const generation = ++epoch.current;
    setData(undefined);
    setRecipients([]);
    setCandidates([]);
    setChecked([]);
    setError("");
    setDirty(false);
    setConfirmed(false);
    if (api.journey)
      void api
        .journey(w, campaign.id, controller.signal)
        .then((d) => {
          if (!controller.signal.aborted) accept(d);
        })
        .catch(() => {
          if (!controller.signal.aborted)
            setError(
              "Campaign preparation could not be loaded. Reopen the campaign to retry.",
            );
        });
    return () => {
      controller.abort();
      epoch.current = generation + 1;
    };
  }, [api, w, campaign.id, campaign.version]);
  const changed = () => {
    setDirty(true);
    setConfirmed(false);
    requestKey.current = crypto.randomUUID();
  };
  function updateRecipient(id: string, patch: Partial<RecipientReview>) {
    setRecipients((rs) =>
      rs.map((r) => (r.personId === id ? { ...r, ...patch } : r)),
    );
    changed();
  }
  async function find(page = 0) {
    if (locked.current) return;
    locked.current = true;
    setBusy(true);
    setError("");
    const e = epoch.current;
    try {
      const result = await api.recipients(
        w,
        campaign.id,
        search,
        page,
        new AbortController().signal,
      );
      if (e === epoch.current) {
        setCandidates(result.items);
        setOffset(page);
        setMore(result.more);
      }
    } catch (err) {
      if (e === epoch.current)
        setError(
          err instanceof Error ? err.message : "Contacts could not be loaded.",
        );
    } finally {
      locked.current = false;
      if (e === epoch.current) setBusy(false);
    }
  }
  async function save(action: "save" | "approve_launch" | "stop") {
    if (!data || locked.current) return;
    locked.current = true;
    setBusy(true);
    setError("");
    setNotice("");
    const e = epoch.current;
    try {
      const result = await api.saveJourney(w, campaign.id, {
        requestKey: requestKey.current,
        expectedVersion: data.version,
        campaignVersion: campaign.version,
        action,
        ...(action === "save"
          ? {
              excludedOrganisations: exclusions
                .split("\n")
                .map((x) => x.trim())
                .filter(Boolean),
              recipients: recipients.map(
                ({
                  personId,
                  contactPointId,
                  decision,
                  reason,
                  contextRevision,
                }) => ({
                  personId,
                  contactPointId,
                  decision,
                  reason,
                  contextRevision,
                }),
              ),
            }
          : {}),
        reason:
          reason.trim() ||
          (action === "save"
            ? "Campaign preparation reviewed"
            : "Campaign launch stopped"),
        confirmed,
        reviewFingerprint: data.reviewFingerprint,
      });
      if (e === epoch.current) {
        accept(result);
        setNotice(
          action === "approve_launch"
            ? "Launch approved for this audience. Review exact emails in Communications before delivery."
            : action === "stop"
              ? "Launch permission withdrawn. Pending deliveries must pass the campaign gate again."
              : "Preparation saved. No emails queued.",
        );
      }
    } catch (err) {
      if (e === epoch.current)
        setError(
          err instanceof Error
            ? err.message
            : "Could not save. Your edits are retained.",
        );
    } finally {
      locked.current = false;
      if (e === epoch.current) setBusy(false);
    }
  }
  useHenryBinding({
    key: "campaign-journey",
    priority: 20,
    brandId: campaign.setup.brandId,
    summary: JSON.stringify({
      campaign: campaign.setup.name,
      objective: campaign.setup.objective,
      campaignId: campaign.id,
      step,
      setupStatus: campaign.status,
      journey: data
        ? {
            status: data.status,
            blockers: data.blockers,
            recipientCount: data.recipients.length,
            included: data.recipients.filter((r) => r.decision === "include")
              .length,
            tracking: data.tracking,
            notice: data.notice,
          }
        : null,
      instructions:
        "Guide preparation using current approved context. Never infer eligibility, consent or launch approval. Use review controls for approvals. Campaign traffic tags are automatic; signup measurement is separate. Preserve campaign context across functions.",
    }),
    editor: {
      key: `campaign-journey:${campaign.id}:${data?.version ?? 0}`,
      title: "Campaign preparation",
      fields: [
        {
          key: "excludedOrganisations",
          label: "Excluded organisation names, one per line",
          value: exclusions,
        },
        { key: "reason", label: "Review notes", value: reason },
      ],
    },
    apply: (changes) => {
      for (const c of changes) {
        if (c.key === "excludedOrganisations") setExclusions(c.value);
        if (c.key === "reason") setReason(c.value);
      }
      changed();
    },
    actions: [
      {
        id: "campaign.review_setup",
        label: "Review campaign setup",
        run: onEdit,
      },
      {
        id: "campaign.review_recipients",
        label: "Review recipients",
        run: () => setStep("recipients"),
      },
      {
        id: "campaign.review_tracking",
        label: "Review tracking",
        run: () => setStep("tracking"),
      },
      {
        id: "campaign.review_launch",
        label: "Open launch review (does not approve)",
        run: () => setStep("launch"),
      },
      ...(
        [
          "offers",
          "contact-strategy",
          "content-strategy",
          "email-content",
          "communications",
          "performance",
          "integrations",
        ] as const
      ).map((section) => ({
        id: `campaign.open_${section}`,
        label: `Continue to ${section.replaceAll("-", " ")}`,
        run: () => navigate(link(section)),
      })),
    ],
  });
  if (!api.journey) return null;
  return (
    <section
      className="panel campaign-journey"
      aria-label="Guided campaign preparation"
    >
      <h3>Prepare your campaign with Henry</h3>
      <p>
        Ask Henry to guide the next step, then review the saved preparation
        here. Campaign setup, launch approval and individual delivery approval
        are distinct.
      </p>
      <nav className="campaign-tabs" aria-label="Preparation steps">
        {[
          ["prepare", "1. Offer and purpose"],
          ["recipients", "2. Recipients"],
          ["tracking", "3. Tracking"],
          ["launch", "4. Launch review"],
        ].map(([key, label]) => (
          <button
            key={key}
            aria-current={step === key ? "step" : undefined}
            onClick={() => setStep(key!)}
          >
            {label}
          </button>
        ))}
      </nav>
      {!data && !error && <p role="status">Loading preparation…</p>}
      {data && (
        <>
          <p>
            <strong>
              {data.status === "approved"
                ? "Launch approved"
                : data.status === "review_required"
                  ? "Changed since approval — review again"
                  : data.status === "stopped"
                    ? "Launch stopped"
                    : "Campaign launch is off"}
            </strong>
            {dirty ? " · Unsaved preparation" : ""}
          </p>
          {step === "prepare" && (
            <>
              <p>{campaign.setup.objective}</p>
              <p>
                Success measure:{" "}
                {campaign.setup.goal || "Choose what success means."}
              </p>
              <p>
                Setup:{" "}
                {campaign.status === "ready" ? "Approved" : "Needs review"}.{" "}
                {data.recipients.filter((r) => r.decision === "include").length}{" "}
                recipients included in the saved preparation.
              </p>
              <div className="campaign-actions">
                <button onClick={onEdit}>Review setup</button>
                <Link to={link("offers")}>Review offer</Link>
                <Link to={link("content-strategy")}>Prepare content brief</Link>
              </div>
            </>
          )}
          {step === "recipients" && (
            <>
              <p>
                Review fit and evidence for each person. Including someone does
                not establish sending permission; Contact Strategy and delivery
                checks still apply.
              </p>
              <label>
                Excluded organisations
                <textarea
                  value={exclusions}
                  onChange={(e) => {
                    setExclusions(e.target.value);
                    changed();
                  }}
                  rows={3}
                />
              </label>
              <p>
                Use exact organisation names, one per line. Matching current
                organisation relationships are blocked. Review missing or
                uncertain relationships before including anyone.
              </p>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  void find();
                }}
                className="campaign-actions"
              >
                <label>
                  Find contacts by name
                  <input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </label>
                <button disabled={busy}>Find contacts</button>
              </form>
              {candidates.map((r) => (
                <article key={r.personId}>
                  <strong>{r.name}</strong>
                  <p>
                    {r.organisations.join(", ") ||
                      "Organisation not established"}{" "}
                    · {r.lifecycle}
                  </p>
                  <p>{r.blockers.join(". ")}</p>
                  <button
                    disabled={
                      busy || recipients.some((x) => x.personId === r.personId)
                    }
                    onClick={() => {
                      setRecipients((rs) => [
                        ...rs,
                        {
                          ...r,
                          contactPointId: r.points[0]?.id ?? "",
                          decision: "review",
                          reason: "",
                        },
                      ]);
                      changed();
                    }}
                  >
                    Add for review
                  </button>
                </article>
              ))}
              {!!candidates.length && (
                <div className="campaign-actions">
                  <button
                    disabled={busy || offset === 0}
                    onClick={() => void find(Math.max(0, offset - 25))}
                  >
                    Previous contacts
                  </button>
                  <button
                    disabled={busy || !more}
                    onClick={() => void find(offset + 25)}
                  >
                    Next contacts
                  </button>
                </div>
              )}
              <h4>Recipient review ({recipients.length})</h4>
              {!recipients.length && (
                <p>
                  Find contacts to create a review list. No contacts are
                  enrolled automatically.
                </p>
              )}
              {!!recipients.length && (
                <div className="campaign-actions">
                  <label className="campaign-check">
                    <input
                      type="checkbox"
                      checked={checked.length === recipients.length}
                      onChange={(e) =>
                        setChecked(
                          e.target.checked
                            ? recipients.map((r) => r.personId)
                            : [],
                        )
                      }
                    />
                    Select all review rows
                  </label>
                  <label>
                    Reason for selected exclusions
                    <input
                      value={bulkReason}
                      onChange={(e) => setBulkReason(e.target.value)}
                    />
                  </label>
                  <button
                    disabled={!checked.length || !bulkReason.trim()}
                    onClick={() => {
                      setRecipients((rs) =>
                        rs.map((r) =>
                          checked.includes(r.personId)
                            ? { ...r, decision: "exclude", reason: bulkReason }
                            : r,
                        ),
                      );
                      setChecked([]);
                      changed();
                    }}
                  >
                    Exclude selected ({checked.length})
                  </button>
                  <button
                    disabled={!checked.length}
                    onClick={() => {
                      if (
                        window.confirm(
                          `Remove ${checked.length} selected recipients from this review? Contacts and saved history are retained.`,
                        )
                      ) {
                        setRecipients((rs) =>
                          rs.filter((r) => !checked.includes(r.personId)),
                        );
                        setChecked([]);
                        changed();
                      }
                    }}
                  >
                    Remove selected from review
                  </button>
                </div>
              )}
              {recipients.map((r) => (
                <article className="campaign-recipient" key={r.personId}>
                  <label className="campaign-check">
                    <input
                      type="checkbox"
                      checked={checked.includes(r.personId)}
                      onChange={(e) =>
                        setChecked((ids) =>
                          e.target.checked
                            ? [...ids, r.personId]
                            : ids.filter((id) => id !== r.personId),
                        )
                      }
                    />
                    Select {r.name}
                  </label>
                  <h4>{r.name}</h4>
                  <p>
                    {r.organisations.join(", ") ||
                      "Organisation not established"}
                  </p>
                  {r.stale && (
                    <p role="status">
                      Evidence changed. Find this contact again and replace the
                      review before including them.
                    </p>
                  )}
                  {!!r.blockers.length && <p>{r.blockers.join(". ")}</p>}
                  <label>
                    Email address
                    <select
                      value={r.contactPointId}
                      onChange={(e) =>
                        updateRecipient(r.personId, {
                          contactPointId: e.target.value,
                        })
                      }
                    >
                      <option value="">Choose email</option>
                      {r.points.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.value}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Review decision
                    <select
                      value={r.decision}
                      onChange={(e) =>
                        updateRecipient(r.personId, {
                          decision: e.target
                            .value as RecipientReview["decision"],
                        })
                      }
                    >
                      <option value="review">Needs review</option>
                      <option value="include">
                        Include after reviewing evidence
                      </option>
                      <option value="exclude">Exclude</option>
                    </select>
                  </label>
                  <label>
                    Evidence and reason
                    <textarea
                      value={r.reason}
                      onChange={(e) =>
                        updateRecipient(r.personId, { reason: e.target.value })
                      }
                    />
                  </label>
                  <button
                    onClick={() => {
                      setRecipients((rs) =>
                        rs.filter((x) => x.personId !== r.personId),
                      );
                      changed();
                    }}
                  >
                    Remove from this review
                  </button>
                  {r.decision === "include" && (
                    <Link
                      to={`${link("email-content")}&contact=${encodeURIComponent(r.personId)}`}
                    >
                      Prepare this person’s email
                    </Link>
                  )}
                </article>
              ))}
              <Link to={link("contact-strategy")}>
                Review contact rules and permissions
              </Link>
            </>
          )}
          {step === "tracking" && (
            <>
              <h4>Automatic email campaign tags</h4>
              <p>
                HVM adds campaign and email identifiers to CTA links in email
                previews and delivery. Test emails use separate test tags. No
                personal details are placed in these campaign tags.
              </p>
              <p>
                {data.tracking.ready
                  ? "GA4 property linked to this campaign."
                  : data.tracking.connectedProperty
                    ? "Save preparation to link the current GA4 property."
                    : "Connect GA4 in Integrations to measure campaign traffic."}
              </p>
              <p>
                Completed signups require a reliable event in your analytics.
                Traffic and generic key events are not confirmed signups. Signup
                measurement is not configured by this journey.
              </p>
              <div className="campaign-actions">
                <Link to={link("integrations")}>Review integrations</Link>
                <Link to={link("performance")}>Open campaign report</Link>
              </div>
            </>
          )}
          {step === "launch" && (
            <>
              <h4>Review launch approval</h4>
              <p>
                Sender: {data.sender || "Not connected"}. Included recipients:{" "}
                {data.recipients.filter((r) => r.decision === "include").length}
                .
              </p>
              <ul>
                {data.blockers.map((b) => (
                  <li key={b}>{b}</li>
                ))}
              </ul>
              <p>{data.notice}</p>
              <p>
                Changes to the campaign, audience, contact evidence, policies,
                mailbox or email drafts require fresh review.
              </p>
              <ul>
                {data.emails.map((e) => (
                  <li key={e.id}>
                    {e.subject} — {e.status}
                  </li>
                ))}
              </ul>
              <label>
                Launch review reason
                <textarea
                  value={reason}
                  onChange={(e) => {
                    setReason(e.target.value);
                    setConfirmed(false);
                    requestKey.current = crypto.randomUUID();
                  }}
                />
              </label>
              <label className="campaign-check">
                <input
                  type="checkbox"
                  checked={confirmed}
                  onChange={(e) => setConfirmed(e.target.checked)}
                />
                I approve launch preparation for this exact campaign and saved
                audience. Individual emails still require delivery approval.
              </label>
              <div className="campaign-actions">
                <button
                  className="button"
                  disabled={
                    busy ||
                    dirty ||
                    !!data.blockers.length ||
                    !confirmed ||
                    !reason.trim() ||
                    data.status === "approved"
                  }
                  onClick={() => void save("approve_launch")}
                >
                  Approve campaign launch
                </button>
                {data.status === "approved" && (
                  <button disabled={busy} onClick={() => void save("stop")}>
                    Stop campaign launch
                  </button>
                )}
                <Link to={link("communications")}>
                  Review exact emails and delivery
                </Link>
              </div>
            </>
          )}
          {step !== "launch" && (
            <div className="campaign-actions">
              <button
                className="button"
                disabled={busy || recipients.some((r) => !r.reason.trim())}
                onClick={() => void save("save")}
              >
                {busy ? "Saving…" : "Save preparation — keep launch off"}
              </button>
            </div>
          )}
        </>
      )}
      {notice && <p role="status">{notice}</p>}
      {error && <p role="alert">{error}</p>}
    </section>
  );
}
