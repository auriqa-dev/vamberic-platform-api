import { useHenryBinding, useHenryObjective, henryFields, applyHenryFields } from "./workspace-henry";
import { ResearchDocuments } from "./research-documents";
import type { ResearchSelection } from "../data/research-documents";
import { useEffect, useRef, useState } from "react";
import type {
  IcpDefinition,
  IcpExample,
  IcpGateway,
  IcpGeneration,
  IcpSetupInput,
} from "../data/icp";
export function IcpGenerationPanel({
  api,
  w,
  product,
  offer,
  onUse,
  initialType,
}: {
  api: IcpGateway;
  w: string;
  product: string;
  offer: { id: string; revision: number };
  initialType?: string;
  onUse: (d: IcpDefinition, id: string) => void;
}) {
  const carriedObjective=useHenryObjective();
  const [type, setType] = useState<"b2b" | "b2c" | "d2c" | null>(
    ["b2b", "b2c", "d2c"].includes(initialType?.toLowerCase() ?? "")
      ? initialType!.toLowerCase() as "b2b" | "b2c" | "d2c" : null,
  ),
    [instructions, setInstructions] = useState(carriedObjective);
  const [exampleType, setExampleType] = useState<"company" | "contact">(
      "company",
    ),
    [search, setSearch] = useState("");
  const [options, setOptions] = useState<IcpExample[]>([]),
    [examples, setExamples] = useState<(IcpExample & { reason: string })[]>([]);
  const [job, setJob] = useState<IcpGeneration>(),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [customerUrls, setCustomerUrls] = useState("");
  const [researchDocuments, setResearchDocuments] = useState<ResearchSelection>(
    [],
  );
  const [setupReady,setSetupReady]=useState(false), [saveMessage,setSaveMessage]=useState("");
  useHenryBinding({key:"icp-generation",priority:60,summary:JSON.stringify({product,offer,type,instructions,customerUrls}),
    editor:!busy && setupReady?{key:`icp-generation:${product}:${offer.id}`,title:"Customer profile generation instructions",fields:henryFields({instructions,customerUrls})}:undefined,
    apply:changes=>{const next=applyHenryFields({instructions,customerUrls},changes);setInstructions(next.instructions);setCustomerUrls(next.customerUrls);key.current=crypto.randomUUID();},
  });
  useEffect(() => { setResearchDocuments([]); }, [w]);
  const [saveEpoch,setSaveEpoch]=useState(0);
  const setupRevision=useRef(0), savedSetup=useRef(""), setupSaving=useRef(false);
  const setup:IcpSetupInput={offeringId:product,offer,profileType:type,instructions,customerUrls:customerUrls.split("\n").map(v=>v.trim()).filter(Boolean),researchDocuments,examples};
  const setupText=JSON.stringify(setup);
  const latestSetup=useRef(setup); latestSetup.current=setup;
  function restore(input:IcpSetupInput) {
    setType(input.profileType);setInstructions(input.instructions);setCustomerUrls((input.customerUrls??[]).join("\n"));setResearchDocuments(input.researchDocuments??[]);setExamples(input.examples);
    savedSetup.current=JSON.stringify({...input,customerUrls:input.customerUrls??[],researchDocuments:input.researchDocuments??[]});
  }
  useEffect(()=>{
    const controller=new AbortController();
    void (async()=>{
      try {
        const saved=api.readSetup ? await api.readSetup(w,product,offer.id,controller.signal) : null;
        if(controller.signal.aborted)return;
        if(saved){setupRevision.current=saved.revision;restore(saved.input);setSaveMessage("Setup saved");}
        else {
          const old=await api.latestGeneration(w,product,controller.signal,offer.id);
          if(controller.signal.aborted)return;
          if(old?.input) {restore({...old.input,offer:old.input.offer??offer,examples:old.input.examples.map(e=>({...e,name:e.name??"Previously selected "+e.type}))});savedSetup.current="";setSaveMessage("Recovered your previous generation setup");}
        }
        setSetupReady(true);
      } catch {if(!controller.signal.aborted)setSaveMessage("Could not restore your setup. Reload to recover it before making changes.");}
    })();
    return ()=>controller.abort();
  },[api,w,product,offer.id]);
  async function persistSetup() {
    if(!api.saveSetup || savedSetup.current===JSON.stringify(latestSetup.current)) return;
    if(setupSaving.current) throw new Error("Setup saving");
    setupSaving.current=true;setSaveMessage("Saving setup…");
    const input=latestSetup.current, snapshot=JSON.stringify(input);
    try {const saved=await api.saveSetup(w,input,setupRevision.current,new AbortController().signal);setupRevision.current=saved.revision;savedSetup.current=snapshot;setSaveMessage("Setup saved");setSaveEpoch(v=>v+1);}
    catch(error){setSaveMessage("Setup could not be saved. Your edits are still here. Retry saving; if another session changed the setup, reload before continuing.");throw error;}
    finally{setupSaving.current=false;}
  }
  useEffect(()=>{
    if(!setupReady || !api.saveSetup || savedSetup.current===setupText)return;
    setSaveMessage("Unsaved changes");
    const timer=setTimeout(()=>{if(!setupSaving.current)void persistSetup().catch(()=>{});},700);
    return ()=>clearTimeout(timer);
  },[setupReady,setupText,api,saveEpoch]);
  const openedReview = useRef<string | undefined>(undefined);
  const recoveryVersion = useRef(0);
  const key = useRef(crypto.randomUUID()),
    lock = useRef(false);
  useEffect(() => {
    const controller = new AbortController();
    const version = recoveryVersion.current;
    api
      .latestGeneration(w, product, controller.signal, offer.id)
      .then((result) => {
        if (
          !controller.signal.aborted &&
          version === recoveryVersion.current &&
          result
        ) {
          // A recovered preview must not pull the user away from setup again.
          // Keep it available through Review and edit; new/running work still opens on completion.
          if (result.status === "review") openedReview.current = result.id;
          setJob(
            result,
          );
          setBusy(result.status === "generating");
        }
      })
      .catch(() => {
        if (!controller.signal.aborted)
          setError(
            "The previous generation could not be recovered. You can try again.",
          );
      });
    return () => controller.abort();
  }, [api, w, product, offer.id]);
  useEffect(() => {
    const controller = new AbortController();
    const timer = setTimeout(() => {
      api
        .examples(w, exampleType, search, controller.signal)
        .then((rows) => {
          if (!controller.signal.aborted) setOptions(rows);
        })
        .catch(() => {
          if (!controller.signal.aborted)
            setError(
              "Examples could not be loaded. Change your search to try again.",
            );
        });
    }, 250);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [api, w, exampleType, search]);
  useEffect(() => {
    if (job?.status !== "generating") return;
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout>;
    const poll = () => {
      timer = setTimeout(() => {
        api
          .generation(w, job.id, controller.signal)
          .then((next) => {
            if (controller.signal.aborted) return;
            setJob(next);
            if (next.status === "generating") poll();
            else setBusy(false);
          })
          .catch(() => {
            if (!controller.signal.aborted) {
              setError(
                "Connection interrupted. Check generation status to recover this request.",
              );
              setBusy(false);
            }
          });
      }, 1500);
    };
    poll();
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [api, w, job?.id, job?.status, busy]);
  async function generate() {
    if (lock.current) return;
    if (!type) { setError("Choose whether this profile targets businesses or consumers before generating."); return; }
    const urls = [
      ...new Set(
        customerUrls
          .split("\n")
          .map((url) => url.trim())
          .filter(Boolean),
      ),
    ];
    if (
      urls.length > 6 ||
      urls.some((value) => {
        try {
          return new URL(value).protocol !== "https:";
        } catch {
          return true;
        }
      })
    ) {
      setError("Enter up to six public HTTPS customer URLs, one per line.");
      return;
    }
    lock.current = true;
    recoveryVersion.current++;
    setBusy(true);
    setError("");
    try {
      await persistSetup();
      if (job?.status === "generating")
        setJob(await api.generation(w, job.id, new AbortController().signal));
      else {
        setJob(undefined);
        setJob(
          await api.generate(
            w,
            {
              requestKey: key.current,
              offeringId: product,
              offer,
              profileType: type,
              instructions,
              customerUrls: urls,
              researchDocuments,
              examples: examples.map(({ id, type, reason }) => ({
                id,
                type,
                reason,
              })),
            },
            new AbortController().signal,
          ),
        );
      }
    } catch {
      setError(
        "Could not start generation. Check that the product and selected offer are approved, the optional website URL is valid and, for a business profile, each selected contact has one current company (or select the company instead). Consumer examples do not need an employer. Your instructions and examples are retained.",
      );
      setBusy(false);
    } finally {
      lock.current = false;
    }
  }
  useEffect(() => {
    if (job && job.status !== "generating") setBusy(false);
  }, [job]);
  useEffect(() => {
    if (
      job?.status === "review" &&
      job.definition &&
      !job.savedId &&
      openedReview.current !== job.id
    ) {
      openedReview.current = job.id;
      onUse(job.definition as IcpDefinition, job.id);
    }
  }, [job, onUse]);
  const terminal = job && job.status !== "generating";
  return (
    <section className="panel">
      <h2>Generate a customer profile</h2>
      <p>
        Start with your selected approved offer and product. Add examples and
        describe any audience you want to target.
      </p>
      <ResearchDocuments
        api={api.research}
        w={w}
        selected={researchDocuments}
        onSelect={(value) => {
          setResearchDocuments(value);
          key.current = crypto.randomUUID();
        }}
        disabled={busy}
      />
      <fieldset disabled={busy || !setupReady}>
        <div className="icp-grid">
          <label>
            Customer type
            <select
              value={type ?? ""}
              onChange={(e) => {
                setType((e.target.value || null) as typeof type);
                key.current = crypto.randomUUID();
              }}
            >
              <option value="">Choose a customer type</option>
              <option value="b2b">Businesses (B2B)</option>
              <option value="b2c">Consumers (B2C)</option>
              <option value="d2c">Direct to consumers (D2C)</option>
            </select>
          </label>
          <label className="icp-wide">
            Targeting instructions
            <textarea
              rows={3}
              aria-label="Targeting instructions"
              maxLength={4000}
              placeholder="Describe the customers you want to reach, their needs and any exclusions."
              value={instructions}
              onChange={(e) => {
                setInstructions(e.target.value);
                key.current = crypto.randomUUID();
              }}
            />
            <small>{instructions.length}/4,000 characters. These instructions are included in generation.</small>
          </label>
        </div>
        <label>
          Existing customer websites (optional)
          <textarea
            rows={3}
            placeholder={"https://customer-one.com\nhttps://customer-two.com"}
            value={customerUrls}
            onChange={(e) => {
              setCustomerUrls(e.target.value);
              key.current = crypto.randomUUID();
            }}
          />
          <small>
            Add up to six public company URLs, one per line. No contact or
            company record is required.
          </small>
        </label>
        <details className="icp-existing-examples" open={examples.length > 0 || undefined}>
          <summary>Use existing contacts or organisations (optional)</summary>
          <h3>Examples from your Hive</h3>
          <div className="icp-grid">
            <label>
              Example type
              <select
                value={exampleType}
                onChange={(e) =>
                  setExampleType(e.target.value as typeof exampleType)
                }
              >
                <option value="company">Company</option>
                <option value="contact">Contact</option>
              </select>
            </label>
            <label>
              Search your records
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </label>
          </div>
          <label>
            Add an example
            <select
              value=""
              disabled={examples.length >= 10}
              onChange={(e) => {
                const item = options.find((o) => o.id === e.target.value);
                if (item) {
                  setExamples([...examples, { ...item, reason: "" }]);
                  key.current = crypto.randomUUID();
                }
              }}
            >
              <option value="">Choose a record…</option>
              {options
                .filter((o) => !examples.some((e) => e.id === o.id))
                .map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.name}
                  </option>
                ))}
            </select>
          </label>
          {examples.map((item) => (
            <div key={item.id} className="icp-example">
              <label>
                {item.name}
                <input
                  aria-label={`Why ${item.name} is a good example`}
                  maxLength={500}
                  placeholder="Why is this a good example? (optional)"
                  value={item.reason}
                  onChange={(e) => {
                    setExamples(
                      examples.map((v) =>
                        v.id === item.id ? { ...v, reason: e.target.value } : v,
                      ),
                    );
                    key.current = crypto.randomUUID();
                  }}
                />
              </label>
              <button
                type="button"
                onClick={() => {
                  setExamples(examples.filter((v) => v.id !== item.id));
                  key.current = crypto.randomUUID();
                }}
              >
                Remove
              </button>
            </div>
          ))}
        </details>
      </fieldset>
      <p role="status">{saveMessage}</p>
      {error && <p role="alert">{error}</p>}
      {job?.status === "generating" && (
        <p role="status">Preparing your customer profile…</p>
      )}
      {!busy && terminal && job.status !== "review" && (
        <p role="alert">
          Generation did not finish. Your setup is retained and your saved profiles are unchanged. {job.failure && <>Stage: {job.failure.stage}. {job.failure.code}. Reference: {job.failure.correlationId}.</>}
        </p>
      )}
      <div className="icp-actions">
      {setupReady && api.saveSetup && <button type="button" disabled={busy || setupSaving.current} onClick={()=>void persistSetup().catch(()=>{})}>Save setup</button>}

        <button
          className="button"
          type="button"
          disabled={busy || !product || !setupReady || setupSaving.current}
          onClick={() => {
            if (terminal) {
              key.current = crypto.randomUUID();
              setJob(undefined);
            }
            void generate();
          }}
        >
          {busy
            ? "Generating…"
            : job?.status === "generating"
              ? "Check generation status"
              : "Generate ICP"}
        </button>
        {job?.status === "review" && job.definition && !job.savedId && (
          <button
            type="button"
            onClick={() => onUse(job.definition as IcpDefinition, job.id)}
          >
            Review and edit profile
          </button>
        )}
      </div>
      {job?.savedId && (
        <p>
          This generated profile has been saved. Open it from your profile list
          to make further changes.
        </p>
      )}
      {job?.rationale && <p>{job.rationale}</p>}
    </section>
  );
}
