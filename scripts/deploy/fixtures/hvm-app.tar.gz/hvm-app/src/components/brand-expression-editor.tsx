import { useHenryBinding, henryFields, applyHenryFields } from "./workspace-henry";
import { contentSchema } from "../data/brand-expression";
import { useEffect, useState, useRef } from "react";
import { DataError } from "../data/gateway";
import {
  defaults,
  dimensions,
  formats,
  type BrandExpressionGateway,
  type Dimension,
  type ExpressionContent,
  type ExpressionKit,
} from "../data/brand-expression";
export type ExpressionTab = Dimension | "voicePreview";
export const expressionTabs = [
  { key: "personality" as const, label: "Brand personality" },
  { key: "tone" as const, label: "Tone of voice" },
  { key: "writingStyle" as const, label: "Writing style" },
  { key: "voicePreview" as const, label: "Test our voice" },
];
const fields: Record<Dimension, [string, string, string][]> = {
  personality: [
    [
      "attributes",
      "Core personality (one per line)",
      "Intelligent\nCurious\nConfident\nPragmatic",
    ],
    [
      "character",
      "If your brand were a person…",
      "Describe its character in your own words.",
    ],
    [
      "values",
      "What you stand for",
      "Values and beliefs that should come through.",
    ],
    [
      "perception",
      "How people should feel",
      "What should your audience think or feel?",
    ],
    [
      "boundaries",
      "What you never want to sound like",
      "For example, arrogant, pushy or impersonal.",
    ],
  ],
  tone: [
    [
      "defaultTone",
      "Your default tone",
      "For example, clear and confident without arrogance.",
    ],
    [
      "attributes",
      "Tone words (one per line)",
      "Helpful\nDirect\nConversational",
    ],
    ["boundaries", "Tone boundaries", "How should the brand avoid sounding?"],
  ],
  writingStyle: [
    [
      "characteristics",
      "How your writing should feel",
      "Analytical clarity with engaging storytelling.",
    ],
    [
      "structure",
      "Sentences and structure",
      "Sentence length, paragraph rhythm, openings, endings, headings and lists.",
    ],
    ["narrative", "Stories and narrative", "When and how to use storytelling."],
    [
      "evidence",
      "Evidence and examples",
      "How to use evidence, examples and analogies.",
    ],
    [
      "conventions",
      "Vocabulary and conventions",
      "Complexity, questions and other writing preferences.",
    ],
    [
      "exclusions",
      "Writing habits to avoid",
      "Phrases, conventions or stylistic habits to avoid.",
    ],
  ],
};
const labels = {
  personality: "Brand personality",
  tone: "Tone of voice",
  writingStyle: "Writing style",
};
export function BrandExpressionEditor({
  api,
  workspaceId,
  brandId,
  active,
  canEdit,
  tabId,
}: {
  api: BrandExpressionGateway;
  workspaceId: string;
  brandId: string;
  active: ExpressionTab | undefined;
  canEdit: boolean;
  tabId: string;
}) {
  const requestIdentity = useRef<
    { signature: string; key: string } | undefined
  >(undefined);
  const [pollEpoch, setPollEpoch] = useState(0);
  const [kit, setKit] = useState<ExpressionKit>(),
    [loaded, setLoaded] = useState(false);
  const [values, setValues] = useState<ExpressionContent>(() =>
    structuredClone(defaults),
  );
  const [dirty, setDirty] = useState<Set<Dimension>>(new Set());
  const [sources, setSources] = useState<
    Partial<
      Record<
        Dimension,
        { originalDescription: string; sourceGenerationId?: string }
      >
    >
  >({});
  const [description, setDescription] = useState(""),
    [topic, setTopic] = useState("");
  const [format, setFormat] = useState<(typeof formats)[number]>("website"),
    [useDrafts, setUseDrafts] = useState(false);
  const [busy, setBusy] = useState(false),
    [job, setJob] = useState<string>(),
    [sample, setSample] = useState("");
  const [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [reload, setReload] = useState(0);
  const henryDimension = active && ["personality","tone","writingStyle"].includes(active) ? active as Dimension : undefined;
  useHenryBinding({key:"brand-expression",brandId,enabled:!!active,summary:`Brand expression: ${active??""}`,
    editor:henryDimension&&canEdit&&!busy?{key:`expression:${brandId}:${henryDimension}:${reload}`,title:"Brand expression",fields:henryFields({[henryDimension]:values[henryDimension]})}:undefined,
    apply:changes=>{const next=contentSchema.parse(applyHenryFields(values,changes));setValues(next);if(henryDimension)setDirty(old=>new Set([...old,henryDimension]));},
  });
  function adopt(next: ExpressionKit | undefined, only?: Dimension) {
    setKit(next);
    const keys = only ? [only] : dimensions;
    setValues((previous) => {
      const copy = structuredClone(previous);
      for (const key of keys) {
        const entry =
          next?.expression[key]?.draft ?? next?.expression[key]?.approved;
        Object.assign(copy, {
          [key]: entry?.content ?? structuredClone(defaults[key]),
        });
        if (!entry && !next?.expression[key] && next?.legacyVoice) {
          if (key === "tone")
            copy.tone.defaultTone =
              next.legacyVoice.descriptors?.join(", ") ?? "";
          if (key === "writingStyle")
            copy.writingStyle.characteristics =
              next.legacyVoice.writingStyle ?? "";
        }
      }
      return copy;
    });
    setSources((previous) => {
      const copy = { ...previous };
      for (const key of keys) {
        const entry =
          next?.expression[key]?.draft ?? next?.expression[key]?.approved;
        copy[key] = {
          originalDescription: entry?.originalDescription ?? "",
          sourceGenerationId: entry?.sourceGenerationId,
        };
      }
      return copy;
    });
    setDirty(
      (previous) => new Set([...previous].filter((k) => !keys.includes(k))),
    );
  }
  useEffect(() => {
    const controller = new AbortController();
    setLoaded(false);
    setKit(undefined);
    setDirty(new Set());
    setError("");
    void api
      .load(workspaceId, brandId, controller.signal)
      .then((next) => {
        if (!controller.signal.aborted) {
          adopt(next);
          setLoaded(true);
        }
      })
      .catch(() => {
        if (!controller.signal.aborted)
          setError("We couldn’t load the Brand Kit. Reload to try again.");
      });
    return () => controller.abort();
    // Reload is explicit so unsaved edits survive switching tabs.
  }, [api, workspaceId, brandId, reload]);
  useEffect(() => {
    if (!job) return;
    let failures = 0;
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout>;
    const poll = async () => {
      try {
        const result = await api.result(
          workspaceId,
          brandId,
          job,
          controller.signal,
        );
        if (controller.signal.aborted) return;
        if (result.status === "generating") {
          timer = setTimeout(() => void poll(), 1500);
          return;
        }
        setJob(undefined);
        requestIdentity.current = undefined;
        if (result.status !== "completed") {
          setError(
            "Henry couldn’t complete this request. Your saved Brand Kit is unchanged. You can try again.",
          );
          return;
        }
        if (result.result?.settings) {
          setValues(result.result.settings);
          setDirty(new Set(dimensions));
          setSources(
            Object.fromEntries(
              dimensions.map((key) => [
                key,
                {
                  originalDescription: result.input.description,
                  sourceGenerationId: job,
                },
              ]),
            ),
          );
          setNotice(
            "Suggestions are ready. Review each of the three tabs, save its draft, then approve when you’re happy.",
          );
        }
        if (result.result?.sample) setSample(result.result.sample);
      } catch {
        if (!controller.signal.aborted) {
          if (++failures < 3) {
            timer = setTimeout(() => void poll(), 3000);
            return;
          }
          setError(
            "We couldn’t check the request. Use Check request again to retrieve its result without generating another example.",
          );
        }
      }
    };
    void poll();
    return () => {
      controller.abort();
      clearTimeout(timer);
    };
  }, [job, api, workspaceId, brandId, pollEpoch]);
  function edit(key: Dimension, field: string, value: unknown) {
    setValues((previous) => ({
      ...previous,
      [key]: { ...previous[key], [field]: value },
    }));
    setDirty((previous) => new Set([...previous, key]));
    setNotice("");
    setError("");
  }
  const [removal, setRemoval] = useState<{key: Dimension; target: "draft" | "approved"}>();
  async function remove() {
    if (!kit || !removal || busy) return;
    setBusy(true); setError(""); setNotice("");
    try {
      await api.remove(workspaceId, brandId, kit, removal.key, removal.target, new AbortController().signal);
      adopt(await api.load(workspaceId, brandId, new AbortController().signal), removal.key);
      setNotice(`${labels[removal.key]} ${removal.target === "draft" ? "draft discarded" : "approved settings withdrawn"}.`);
      setRemoval(undefined);
    } catch { setError("We couldn’t confirm the deletion. Reload saved Brand Kit to check before retrying."); }
    finally { setBusy(false); }
  }
  async function save(key: Dimension, approve = false) {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await api.save(
        workspaceId,
        brandId,
        kit,
        key,
        {
          content: values[key],
          originalDescription: sources[key]?.originalDescription ?? "",
          sourceGenerationId: sources[key]?.sourceGenerationId,
        },
        approve,
        new AbortController().signal,
      );
      const next = await api.load(
        workspaceId,
        brandId,
        new AbortController().signal,
      );
      adopt(next, key);
      setNotice(
        labels[key] +
          (approve
            ? " approved. Future content will use these settings."
            : " draft saved. Your approved settings are unchanged."),
      );
    } catch (e) {
      setError(
        e instanceof DataError && e.code === "conflict"
          ? "The Brand Kit changed. Copy unsaved edits before reloading, then review the latest settings."
          : "We couldn’t save this change. Your entries are still here.",
      );
    } finally {
      setBusy(false);
    }
  }
  async function generate(mode: "interpret" | "preview") {
    setBusy(true);
    setError("");
    setNotice("");
    setSample("");
    try {
      const signature = JSON.stringify({
        mode,
        description: mode === "interpret" ? description : topic,
        format,
        useDrafts,
      });
      if (requestIdentity.current?.signature !== signature)
        requestIdentity.current = { signature, key: crypto.randomUUID() };
      const result = await api.generate(
        workspaceId,
        brandId,
        {
          mode,
          requestKey: requestIdentity.current.key,
          description: mode === "interpret" ? description : topic,
          format,
          useDrafts,
        },
        new AbortController().signal,
      );
      setJob(result.id);
    } catch {
      setError(
        "We couldn’t start Henry’s request. Check your description and try again.",
      );
    } finally {
      setBusy(false);
    }
  }
  if (!loaded)
    return (
      <div hidden={!active}>
        {error ? (
          <>
            <p role="alert">{error}</p>
            <button onClick={() => setReload((v) => v + 1)}>
              Reload Brand Kit
            </button>
          </>
        ) : (
          <p role="status">Loading brand settings…</p>
        )}
      </div>
    );
  const locked = busy || Boolean(job) || !canEdit;
  return (
    <div className="brand-expression" hidden={!active}>
      {error && (
        <div>
          <p role="alert">{error}</p>
          {job && (
            <button
              onClick={() => {
                setError("");
                setPollEpoch((v) => v + 1);
              }}
            >
              Check request again
            </button>
          )}
          <button disabled={busy} onClick={() => setReload((v) => v + 1)}>
            Reload saved Brand Kit
          </button>
          <p className="muted">Copy any unsaved edits before reloading.</p>
        </div>
      )}
      {notice && <p role="status">{notice}</p>}
      {job && (
        <p role="status">
          Henry is preparing your{" "}
          {active === "voicePreview" ? "sample" : "suggestions"}…
        </p>
      )}
      {dimensions.map((key) => (
        <section
          key={key}
          id={tabId + "-panel-" + key}
          role="tabpanel"
          aria-labelledby={tabId + "-tab-" + key}
          hidden={active !== key}
        >
          <h3>{labels[key]}</h3>
          <p>
            {key === "personality"
              ? "Who we are."
              : key === "tone"
                ? "How we sound."
                : "How we write."}
          </p>
          <p className="muted">
            {dirty.has(key)
              ? "Unsaved changes"
              : kit?.expression[key]?.draft
                ? "Draft awaiting approval"
                : kit?.expression[key]?.approved
                  ? "Approved"
                  : "Not configured"}
            {kit?.expression[key]?.draft && kit.expression[key]?.approved
              ? " · Previous approved settings remain active."
              : ""}
          </p>
          {key === "personality" && (
            <details className="brand-expression-helper">
              <summary>Let Henry help describe your brand</summary>
              <label>
                Describe your brand and the writing you admire
                <textarea
                  maxLength={4000}
                  value={description}
                  disabled={locked}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="We are confident and curious. Analytical but engaging. We like clear explanations and thoughtful storytelling."
                />
              </label>
              <p className="muted">
                You can include authors or publications as inspiration. Henry
                will suggest general characteristics for you to review.
              </p>
              <button
                disabled={locked || !description.trim() || dirty.size > 0}
                onClick={() => void generate("interpret")}
              >
                Suggest brand settings
              </button>
              {dirty.size > 0 && (
                <p>
                  Save your current drafts before asking for new suggestions.
                </p>
              )}
            </details>
          )}
          {sources[key]?.originalDescription && (
            <details>
              <summary>Your original instructions</summary>
              <p>{sources[key]?.originalDescription}</p>
            </details>
          )}
          <fieldset disabled={locked} className="brand-expression-fields">
            <legend>{labels[key]} settings</legend>
            {fields[key].map(([field, label, hint]) => (
              <label key={field}>
                {label}
                <textarea
                  rows={3}
                  maxLength={field === "attributes" ? 10000 : 2000}
                  value={
                    field === "attributes"
                      ? (
                          values[key] as { attributes: string[] }
                        ).attributes.join("\n")
                      : String(
                          (values[key] as Record<string, unknown>)[field] ?? "",
                        )
                  }
                  placeholder={hint}
                  onChange={(e) =>
                    edit(
                      key,
                      field,
                      field === "attributes"
                        ? e.target.value.split("\n")
                        : e.target.value,
                    )
                  }
                />
              </label>
            ))}
            {key === "personality" && (
              <div className="brand-traits">
                {[
                  "Intelligent",
                  "Curious",
                  "Confident",
                  "Pragmatic",
                  "Reassuring",
                  "Challenging",
                ].map((trait) => (
                  <button
                    type="button"
                    key={trait}
                    aria-pressed={values.personality.attributes.includes(trait)}
                    onClick={() =>
                      edit(
                        "personality",
                        "attributes",
                        values.personality.attributes.includes(trait)
                          ? values.personality.attributes.filter(
                              (v) => v !== trait,
                            )
                          : [...values.personality.attributes, trait],
                      )
                    }
                  >
                    {trait}
                  </button>
                ))}
              </div>
            )}
            {key === "tone" && (
              <div className="brand-expression-wide">
                <h4>Optional variations</h4>
                <p>
                  Your default tone is enough. Add a variation only where it
                  helps.
                </p>
                {values.tone.variations.map((v, i) => (
                  <div className="brand-expression-row" key={i}>
                    <label>
                      Context
                      <select
                        value={v.context}
                        onChange={(e) =>
                          edit(
                            "tone",
                            "variations",
                            values.tone.variations.map((old, j) =>
                              i === j
                                ? { ...old, context: e.target.value }
                                : old,
                            ),
                          )
                        }
                      >
                        {formats.map((f) => (
                          <option
                            key={f}
                            value={f}
                            disabled={values.tone.variations.some(
                              (other, j) => j !== i && other.context === f,
                            )}
                          >
                            {f}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      How the tone changes
                      <textarea
                        maxLength={2000}
                        value={v.guidance}
                        onChange={(e) =>
                          edit(
                            "tone",
                            "variations",
                            values.tone.variations.map((old, j) =>
                              i === j
                                ? { ...old, guidance: e.target.value }
                                : old,
                            ),
                          )
                        }
                      />
                    </label>
                    <button
                      type="button"
                      onClick={() =>
                        edit(
                          "tone",
                          "variations",
                          values.tone.variations.filter((_, j) => i !== j),
                        )
                      }
                    >
                      Remove variation
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  disabled={values.tone.variations.length >= 6}
                  onClick={() =>
                    edit("tone", "variations", [
                      ...values.tone.variations,
                      {
                        context:
                          formats.find(
                            (f) =>
                              !values.tone.variations.some(
                                (v) => v.context === f,
                              ),
                          ) ?? "website",
                        guidance: "",
                      },
                    ])
                  }
                >
                  Add variation
                </button>
              </div>
            )}
            {key === "writingStyle" && (
              <div className="brand-expression-wide">
                <h4>Writing inspiration</h4>
                <p>
                  Keep the reference, then describe the general characteristics
                  you want. Approval includes your interpretation; Henry will
                  not imitate the named author.
                </p>
                {values.writingStyle.inspirations.map((v, i) => (
                  <div className="brand-expression-row" key={i}>
                    <label>
                      Author, publication or style
                      <input
                        maxLength={300}
                        value={v.reference}
                        onChange={(e) =>
                          edit(
                            "writingStyle",
                            "inspirations",
                            values.writingStyle.inspirations.map((old, j) =>
                              i === j
                                ? { ...old, reference: e.target.value }
                                : old,
                            ),
                          )
                        }
                      />
                    </label>
                    <label>
                      Characteristics to use
                      <textarea
                        maxLength={1000}
                        value={v.interpretation}
                        onChange={(e) =>
                          edit(
                            "writingStyle",
                            "inspirations",
                            values.writingStyle.inspirations.map((old, j) =>
                              i === j
                                ? { ...old, interpretation: e.target.value }
                                : old,
                            ),
                          )
                        }
                      />
                    </label>
                    <button
                      type="button"
                      onClick={() =>
                        edit(
                          "writingStyle",
                          "inspirations",
                          values.writingStyle.inspirations.filter(
                            (_, j) => i !== j,
                          ),
                        )
                      }
                    >
                      Remove reference
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  disabled={values.writingStyle.inspirations.length >= 10}
                  onClick={() =>
                    edit("writingStyle", "inspirations", [
                      ...values.writingStyle.inspirations,
                      { reference: "", interpretation: "" },
                    ])
                  }
                >
                  Add inspiration
                </button>
              </div>
            )}
          </fieldset>
          {canEdit && removal?.key === key && <div role="alert"><p>{removal.target === "draft" ? "Discard this saved draft? Approved settings stay active." : "Withdraw these approved settings? Future content will no longer use them. Any saved draft is retained."} Unsaved edits in this tab will be discarded.</p><button disabled={locked} onClick={() => void remove()}>Confirm delete</button><button disabled={locked} onClick={() => setRemoval(undefined)}>Cancel</button></div>}
          {canEdit && (
            <div className="form-actions">
              {kit?.expression[key]?.draft && <button disabled={locked} onClick={() => setRemoval({key,target:"draft"})}>Discard draft</button>}
              {kit?.expression[key]?.approved && <button disabled={locked} onClick={() => setRemoval({key,target:"approved"})}>Withdraw approved settings</button>}
              <button
                className="button"
                disabled={locked || !dirty.has(key)}
                onClick={() => void save(key)}
              >
                Save draft
              </button>
              <button
                disabled={
                  locked || dirty.has(key) || !kit?.expression[key]?.draft
                }
                onClick={() => void save(key, true)}
              >
                Approve {labels[key].toLowerCase()}
              </button>
            </div>
          )}
        </section>
      ))}
      <section
        id={tabId + "-panel-voicePreview"}
        role="tabpanel"
        aria-labelledby={tabId + "-tab-voicePreview"}
        hidden={active !== "voicePreview"}
      >
        <h3>Test our voice</h3>
        <p>Generate a short example. Nothing is published, sent or approved.</p>
        <label>
          Format
          <select
            value={format}
            disabled={locked}
            onChange={(e) => setFormat(e.target.value as typeof format)}
          >
            {formats.map((f) => (
              <option key={f} value={f}>
                {f === "linkedin"
                  ? "LinkedIn post"
                  : f === "website"
                    ? "Website introduction"
                    : f === "email"
                      ? "Short outreach email"
                      : f}
              </option>
            ))}
          </select>
        </label>
        <label>
          What should the sample be about?
          <textarea
            maxLength={4000}
            disabled={locked}
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="Add a topic and a few true facts about your business."
          />
        </label>
        <label>
          <input
            type="checkbox"
            checked={useDrafts}
            disabled={locked}
            onChange={(e) => setUseDrafts(e.target.checked)}
          />
          Preview saved drafts instead of approved settings
        </label>
        <button
          className="button"
          disabled={locked || !kit || !topic.trim() || dirty.size > 0}
          onClick={() => void generate("preview")}
        >
          Generate example
        </button>
        {dirty.size > 0 && (
          <p>Save your draft changes before previewing them.</p>
        )}
        {sample && (
          <article className="brand-voice-sample">
            <h4>
              Example — {useDrafts ? "draft settings" : "approved settings"}
            </h4>
            <p className="preserve-lines">{sample}</p>
            <button type="button" disabled={locked} onClick={() => setSample("")}>Clear example</button>
          </article>
        )}
        <label>
          How should Henry refine the brand settings?
          <textarea
            maxLength={4000}
            disabled={locked}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Too corporate. Make it more direct and a little more challenging."
          />
        </label>
        <button
          disabled={locked || !description.trim() || dirty.size > 0}
          onClick={() => void generate("interpret")}
        >
          Suggest refinements
        </button>
      </section>
    </div>
  );
}
