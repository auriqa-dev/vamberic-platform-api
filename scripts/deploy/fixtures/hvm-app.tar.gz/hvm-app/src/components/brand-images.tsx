import { useCallback, useRef, useState } from "react";
import { useResource } from "../data/use-resource";
import { DataError } from "../data/gateway";
import { imageTypes, type BrandImagesGateway, type ImageKit, type ImageType } from "../data/brand-images";
import { Failure, Loading } from "./ui";
export function BrandImages({ api, workspaceId, brandId, canEdit, onSaved }: { api: BrandImagesGateway; workspaceId: string; brandId: string; canEdit: boolean; onSaved?: () => void }) {
  const [revision, setRevision] = useState(0);
  const load = useCallback((signal: AbortSignal) => { void revision; return api.list(workspaceId, brandId, signal); }, [api, workspaceId, brandId, revision]);
  const result = useResource(load);
  if (result.state === "loading") return <Loading label="Loading brand images…" />;
  if (result.state === "error") return <Failure error={result.error} retry={() => setRevision(v => v+1)} />;
  return <ImageEditor key={`${workspaceId}:${brandId}`} api={api} workspaceId={workspaceId} brandId={brandId} kit={result.data.find(k => k.status === "approved")} canEdit={canEdit} refresh={() => { setRevision(v => v+1); onSaved?.(); }} />;
}
function ImageEditor({ api, workspaceId, brandId, kit, canEdit, refresh }: { api: BrandImagesGateway; workspaceId: string; brandId: string; kit?: ImageKit; canEdit: boolean; refresh: () => void }) {
  const [busy, setBusy] = useState(false), [error, setError] = useState("");
  const [file, setFile] = useState<File>(), [name, setName] = useState(""), [type, setType] = useState<ImageType>("logo"), [altText,setAltText] = useState("");
  const input = useRef<HTMLInputElement>(null);
  async function upload() {
    if (busy || !file) return;
    setBusy(true); setError("");
    try {
      await api.upload(workspaceId,brandId,kit,{file,name,type,altText},new AbortController().signal);
      setFile(undefined); setName(""); setAltText(""); if (input.current) input.current.value="";
      refresh();
    } catch (e) { setError(e instanceof DataError && e.code === "invalid" ? "Choose a valid PNG, JPEG or WebP image up to 5 MB and 16 megapixels. Animated images are not supported." : e instanceof DataError && e.code === "conflict" ? "The Brand Kit has changed or is full. Refresh it before trying again." : e instanceof DataError && e.code === "denied" ? "You do not have permission to change this Brand Kit. Contact your workspace administrator." : "We could not confirm the upload. Refresh the Brand Kit to check before trying again."); }
    finally { setBusy(false); }
  }
  return <section className="kit-section">
    <h3>Logos & images</h3>
    {kit?.assets.length ? <ImageList api={api} workspaceId={workspaceId} brandId={brandId} kit={kit} canEdit={canEdit} refresh={refresh} /> : <p>No images added yet.</p>}
    {canEdit && <form className="operating-form brand-image-upload" onSubmit={e => { e.preventDefault(); void upload(); }}>
      <fieldset disabled={busy}>
        <legend>Upload an image</legend>
        <div className="brand-image-upload-help">
          <p>Uploaded images are added to your Brand Kit straight away.</p>
          <p className="small muted">PNG, JPEG or WebP · up to 5 MB · maximum 16 megapixels. Images are saved as PNG; transparency is preserved.</p>
        </div>
        <label className="field">Image file<input ref={input} type="file" accept="image/png,image/jpeg,image/webp" onChange={e => { const next=e.target.files?.[0]; setFile(next); if (next) setName(next.name.replace(/\.[^.]+$/, "").slice(0,200)); }} /></label>
        <label className="field">Image name<input value={name} maxLength={200} required onChange={e => setName(e.target.value)} /></label>
        <label className="field">Image type<select value={type} onChange={e => setType(e.target.value as ImageType)}>{imageTypes.map(([value,label]) => <option key={value} value={value}>{label}</option>)}</select></label>
        <label className="field">Image description (optional)<input value={altText} maxLength={1000} onChange={e => setAltText(e.target.value)} /></label>
        <button className="button" disabled={!file || !name.trim() || (kit?.assets.length ?? 0) >= 100}>{busy ? "Uploading…" : "Upload image"}</button>
      </fieldset>
    </form>}
    {(kit?.assets.length ?? 0) >= 100 && <p>This Brand Kit has reached its 100-image limit.</p>}
    {error && <div role="alert"><p>{error}</p><button disabled={busy} onClick={refresh}>Refresh Brand Kit</button></div>}
  </section>;
}
function ImageList({ api, workspaceId, brandId, kit, canEdit, refresh }: { api: BrandImagesGateway; workspaceId: string; brandId: string; kit: ImageKit; canEdit: boolean; refresh: () => void }) {
  const [selected, setSelected] = useState<string[]>([]), [type,setType] = useState<ImageType>("logo");
  const [confirm,setConfirm] = useState(false), [busy,setBusy] = useState(false), [error,setError] = useState("");
  async function bulk(remove: boolean) {
    setBusy(true); setError("");
    try { await api.bulk(workspaceId,brandId,kit,selected,remove ? undefined : type,new AbortController().signal); refresh(); }
    catch { setError("We couldn’t confirm the change. Refresh the Brand Kit to check before retrying."); }
    finally { setBusy(false); }
  }
  return <div>
    {canEdit && kit.assets.length > 1 && <fieldset disabled={busy} className="brand-image-bulk"><legend>Manage selected images</legend>
      <label><input type="checkbox" checked={selected.length === kit.assets.filter(a=>a.imageId).length && selected.length>0} onChange={e=>{setSelected(e.target.checked ? kit.assets.flatMap(a=>a.imageId ? [a.imageId] : []) : []);setConfirm(false);}} /> Select all images</label>
      <label>Image type for selected<select value={type} onChange={e=>setType(e.target.value as ImageType)}>{imageTypes.map(([value,label])=><option key={value} value={value}>{label}</option>)}</select></label>
      <button type="button" disabled={!selected.length} onClick={()=>void bulk(false)}>Update selected ({selected.length})</button>
      <button type="button" disabled={!selected.length} onClick={()=>setConfirm(true)}>Delete selected ({selected.length})</button>
      {confirm && <div role="alert"><p>Delete {selected.length} selected images from the Brand Kit?</p><button type="button" onClick={()=>void bulk(true)}>Confirm delete selected</button><button type="button" onClick={()=>setConfirm(false)}>Cancel</button></div>}
    </fieldset>}
    {error && <div role="alert"><p>{error}</p><button type="button" disabled={busy} onClick={refresh}>Refresh Brand Kit</button></div>}
    <ul className="brand-image-gallery">{kit.assets.map((asset, index) => <li key={`${asset.imageId ?? index}:${index}`}>
    {canEdit && kit.assets.length > 1 && asset.imageId && <label><input type="checkbox" disabled={busy} checked={selected.includes(asset.imageId)} onChange={e=>{setSelected(old=>e.target.checked ? [...old,asset.imageId!] : old.filter(id=>id!==asset.imageId));setConfirm(false);}} /> Select {asset.name}</label>}
    <ImagePreview api={api} workspaceId={workspaceId} brandId={brandId} kitId={kit.id} asset={asset} />
    {canEdit && asset.imageId && !busy && <ImageActions key={`${kit.id}:${index}`} api={api} workspaceId={workspaceId} brandId={brandId} kit={kit} asset={asset} refresh={refresh} />}
  </li>)}</ul></div>;
}

function ImagePreview({ api, workspaceId, brandId, kitId, asset }: { api: BrandImagesGateway; workspaceId: string; brandId: string; kitId: string; asset: ImageKit["assets"][number] }) {
  const [revision, setRevision] = useState(0);
  const load = useCallback((signal: AbortSignal) => {
    void revision;
    return asset.imageId ? api.image(workspaceId, brandId, kitId, asset.imageId, signal) : Promise.resolve(null);
  }, [api, workspaceId, brandId, kitId, asset.imageId, revision]);
  const result = useResource(load);
  return <figure className="brand-image-card">
    <div className="brand-image-thumbnail">
      {result.state === "loading" && <span role="status">Loading image…</span>}
      {result.state === "ready" && (result.data ? <img src={result.data} alt={asset.altText || asset.name} className="brand-image-preview" /> : <span>Preview unavailable</span>)}
      {result.state === "error" && <div role="alert"><p>This image could not be loaded.</p><button type="button" onClick={() => setRevision(v => v + 1)}>Retry {asset.name}</button></div>}
    </div>
    <figcaption><strong>{asset.name}</strong><span className="small muted">{imageTypes.find(([type]) => type === asset.type)?.[1] ?? "Image"}</span></figcaption>
  </figure>;
}

function ImageActions({ api, workspaceId, brandId, kit, asset, refresh }: { api: BrandImagesGateway; workspaceId: string; brandId: string; kit: ImageKit; asset: ImageKit["assets"][number]; refresh: () => void }) {
  const [mode, setMode] = useState<"view" | "edit" | "delete">("view");
  const [busy, setBusy] = useState(false), [error, setError] = useState("");
  const [name, setName] = useState(asset.name), [type, setType] = useState(asset.type as ImageType), [altText, setAltText] = useState(asset.altText ?? "");
  const [file, setFile] = useState<File>();
  async function save() {
    if (busy) return;
    setBusy(true); setError("");
    try {
      if (mode === "delete") await api.remove(workspaceId, brandId, kit, asset.imageId!, new AbortController().signal);
      else await api.update(workspaceId, brandId, kit, asset.imageId!, { name, type, altText, file }, new AbortController().signal);
      refresh();
    } catch (e) {
      setError(e instanceof DataError && e.code === "conflict" ? "The Brand Kit has changed. Refresh before trying again." : e instanceof DataError && e.code === "invalid" ? "Check the image details. Replacement images must be PNG, JPEG or WebP, up to 5 MB and 16 megapixels." : "We couldn’t confirm the change. Refresh to check the saved image before trying again.");
    } finally { setBusy(false); }
  }
  return <div className="brand-image-actions">
    {mode === "view" ? <div className="form-actions"><button type="button" onClick={() => { setName(asset.name); setType(asset.type as ImageType); setAltText(asset.altText ?? ""); setFile(undefined); setMode("edit"); }}>Edit image</button><button type="button" onClick={() => setMode("delete")}>Delete image</button></div> : mode === "delete" ? <div>
      <p>Delete “{asset.name}” from the Brand Kit? It will no longer be available for future use.</p>
      <div className="form-actions"><button type="button" disabled={busy} onClick={() => void save()}>{busy ? "Deleting…" : "Confirm delete"}</button><button type="button" disabled={busy} onClick={() => {setMode("view"); setError("");}}>Cancel</button></div>
    </div> : <form className="operating-form" onSubmit={e => { e.preventDefault(); void save(); }}>
      <fieldset disabled={busy}><legend>Edit {asset.name}</legend>
        <label className="field">Image name<input required maxLength={200} value={name} onChange={e => setName(e.target.value)} /></label>
        <label className="field">Image type<select value={type} onChange={e => setType(e.target.value as ImageType)}>{imageTypes.map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
        <label className="field">Image description (optional)<input maxLength={1000} value={altText} onChange={e => setAltText(e.target.value)} /></label>
        <label className="field">Replace image (optional)<input type="file" accept="image/png,image/jpeg,image/webp" onChange={e => setFile(e.target.files?.[0])} /></label>
        <p className="small muted">Leave empty to keep the current image. PNG, JPEG or WebP, up to 5 MB and 16 megapixels.</p>
        <div className="form-actions"><button className="button" disabled={!name.trim()}>{busy ? "Saving…" : "Save changes"}</button><button type="button" onClick={() => {setMode("view"); setError("");}}>Cancel</button></div>
      </fieldset>
    </form>}
    {error && <div role="alert"><p>{error}</p><button type="button" disabled={busy} onClick={refresh}>Refresh Brand Kit</button></div>}
  </div>;
}
