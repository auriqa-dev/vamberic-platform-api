import { useCallback } from "react";
import { Link } from "react-router-dom";
import { useOperating } from "../../data/operating/context";
import { useResource } from "../../data/use-resource";
import type { Access } from "../../data/model";
import type { OnboardingRecord } from "../../data/client-onboarding";

export function onboardingStatus(row: OnboardingRecord) {
  if (row.result) return "Onboarded";
  if (row.approval?.status === "active")
    return "Approved — ready to create workspace";
  return row.approval?.status === "revoked"
    ? "Approval revoked"
    : "Awaiting exemption approval";
}
export function OnboardingRequests({ access }: { access: Access }) {
  return (
    <>
      {access.queen?.partners
        .filter((p) => p.role === "owner")
        .map((p) => (
          <PartnerRequests
            key={p.id}
            partner={p.id}
            name={p.displayName}
            workspaceIds={access.queen!.workspaces.map((w) => w.id)}
          />
        ))}
    </>
  );
}
function PartnerRequests({
  partner,
  name,
  workspaceIds,
}: {
  partner: string;
  name: string;
  workspaceIds: string[];
}) {
  const api = useOperating();
  const load = useCallback(
    async (signal: AbortSignal) => {
      if (!api) throw new Error("Onboarding unavailable");
      const rows: OnboardingRecord[] = [],
        seen = new Set<string>();
      let after: string | undefined;
      do {
        const page = await api.onboarding.list(partner, signal, after);
        rows.push(...page.items);
        after = page.next ?? undefined;
        if (after && seen.has(after)) throw new Error("Repeated page");
        if (after) seen.add(after);
      } while (after);
      return rows;
    },
    [api, partner],
  );
  const result = useResource(load);
  if (result.state === "loading")
    return <p role="status">Loading onboarding requests for {name}…</p>;
  if (result.state === "error")
    return (
      <p role="alert">
        Couldn’t load onboarding requests for {name}.{" "}
        <Link to={`/queen/clients/new?partner=${partner}`}>
          Open onboarding requests
        </Link>
      </p>
    );
  return (
    <div className="card-grid">
      {result.data
        .filter(
          (r) => !r.result || !workspaceIds.includes(r.result.workspaceId),
        )
        .map((row) => (
          <article className="panel" key={row.id}>
            <p className="eyebrow">{name}</p>
            <h3>{row.details.intake.organisationName}</h3>
            <p>{onboardingStatus(row)}</p>
            <Link
              className="button"
              to={`/queen/clients/new?partner=${partner}&request=${row.id}`}
            >
              Continue onboarding
            </Link>
          </article>
        ))}
    </div>
  );
}
