import { paintEmailPreview } from "./email-preview-document";
import {
  useHenryBinding,
  henryFields,
  applyHenryFields,
} from "./workspace-henry";
import { settings } from "../data/email-templates";
import { useEffect, useState, useRef } from "react";
import type {
  TemplateGateway,
  EmailTemplate,
  TemplateSettings,
  RenderedEmail,
} from "../data/email-templates";
import "../styles/email-templates.css";
export function EmailPreview({ rendered }: { rendered: RenderedEmail }) {
  const [mode, setMode] = useState("desktop");
  const frame=useRef<HTMLIFrameElement>(null);
  const html=(rendered.inlineImages || []).reduce((value,image)=>value.replace("cid:"+image.cid,"data:image/png;base64,"+image.base64),rendered.html);
  function paint(){if(frame.current?.contentDocument)paintEmailPreview(frame.current.contentDocument,html);}
  useEffect(()=>{paint();},[html,mode]);
  return (
    <section className="email-render" aria-label="Rendered email">
      <div className="email-actions" aria-label="Preview size">
        {["desktop", "mobile", "text"].map((m) => (
          <button
            key={m}
            type="button"
            aria-pressed={mode === m}
            onClick={() => setMode(m)}
          >
            {m === "text"
              ? "Plain text"
              : m === "mobile"
                ? "Mobile"
                : "Desktop"}
          </button>
        ))}
      </div>
      <h3>{rendered.subject}</h3>
      {mode === "text" ? (
        <pre>{rendered.text}</pre>
      ) : (
        <iframe
          title="Rendered email preview"
          ref={frame}
          sandbox="allow-same-origin"
          referrerPolicy="no-referrer"
          srcDoc="<!doctype html><html lang='en-GB'><head><meta charset='utf-8'></head><body></body></html>"
          onLoad={paint}
          style={{ maxWidth: mode === "mobile" ? 375 : "100%" }}
        />
      )}
      {rendered.notice && <p className="muted">{rendered.notice}</p>}
    </section>
  );
}
const initial: TemplateSettings = {
  name: "",
  layout: "personal",
  accentRole: "primary",
  includeLogo: false,
  logoAlignment: "left",
  logoWidth: 160,
  logoSpacing: 24,
  includeSignature: true,
  includeFooter: true,
};
export function EmailPresentation({
  api,
  workspaceId: w,
  brandId,
  draftId,
  draftVersion,
  disabled = false,
  initialChoice = "",
  onSelect,
}: {
  api: TemplateGateway;
  workspaceId: string;
  brandId: string;
  draftId: string;
  draftVersion: number;
  disabled?: boolean;
  initialChoice?: string;
  onSelect?: (id: string) => void;
}) {
  const [managerOpen, setManagerOpen] = useState(!draftId),
    [showRetired, setShowRetired] = useState(false),
    [sampleRender, setSampleRender] = useState<RenderedEmail>(),
    [rows, setRows] = useState<EmailTemplate[]>([]),
    [choice, setChoice] = useState(initialChoice),
    [render, setRender] = useState<RenderedEmail>(),
    [editing, setEditing] = useState<EmailTemplate>(),
    [form, setForm] = useState(initial),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [checked, setChecked] = useState<string[]>([]);
  useHenryBinding({
    key: "email-template-editor",
    priority: 20,
    enabled: managerOpen,
    brandId,
    summary:
      "Configure email presentation using approved Brand Kit roles. Personal is restrained; branded allows a logo and accent. Changes are unsaved suggestions. Saving or approving a template never authorises delivery. No copy rewriting.",
    editor: {
      key: editing?.id || "new-template",
      title: "Email template",
      fields: henryFields(form),
    },
    apply: (changes) => {
      const parsed = settings.safeParse(applyHenryFields(form, changes));
      if (parsed.success) setForm(parsed.data);
      else setError("Check the proposed layout and colour role before saving.");
    },
  });
  useEffect(() => { setSampleRender(undefined); }, [form]);
  async function load(s: AbortSignal) {
    const saved = await api.list(w, brandId, s);
    if (!s.aborted) setRows(saved);
    return saved;
  }
  useEffect(() => {
    const c = new AbortController();
    setRows([]); setEditing(undefined); setForm(initial); setChecked([]); setError(""); setSampleRender(undefined);
    setRender(undefined);
    setChoice(initialChoice);
    onSelect?.(initialChoice);
    void load(c.signal).catch(() => {
      if (!c.signal.aborted) setError("Could not load templates.");
    });
    return () => c.abort();
  }, [w, brandId]);
  useEffect(() => {
    const c = new AbortController();
    setRender(undefined);
    setError("");
    if (!disabled)
      void api
        .preview(w, { draftId, draftVersion, templateId: choice }, c.signal)
        .then((p) => {
          if (!c.signal.aborted) setRender(p.rendered);
        })
        .catch(() => {
          if (!c.signal.aborted)
            setError(
              "Could not render the saved email. Refresh the preview to retry.",
            );
        });
    return () => c.abort();
  }, [w, draftId, draftVersion, disabled, choice]);
  async function run(fn: () => Promise<void>) {
    if (busy) return;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await fn();
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "Could not save template. Refresh and retry.",
      );
    } finally {
      setBusy(false);
    }
  }
  const attempt = useRef<{ signature: string; key: string } | undefined>(
    undefined,
  );
  async function change(operation: string, row = editing) {
    await run(async () => {
      const signature = JSON.stringify([operation, editing, form, row]);
      if (attempt.current?.signature !== signature)
        attempt.current = { signature, key: crypto.randomUUID() };
      const result = await api.change(
        w,
        {
          requestKey: attempt.current.key,
          id: row?.id || "",
          expectedVersion: row?.version || 0,
          brandId,
          operation,
          ...(operation === "save" ? { settings: form } : {}),
        },
        new AbortController().signal,
      );
      const saved = await load(new AbortController().signal);
      attempt.current = undefined;
      const current = saved.find((r) => r.id === (result as {id?:string}).id);
      if (current && ["save", "duplicate"].includes(operation)) { setEditing(current); setForm(current.settings); }
      else if (editing?.id === row?.id) { setEditing(current); if(current) setForm(current.settings); }
      setRender(undefined);
      setNotice("Template saved. Delivery approval is separate.");
    });
  }
  return (
    <section className="email-template-panel">
      <h3>{draftId ? "Email presentation" : "Email template designs"}</h3>
      {draftId && <>
      <label>
        Template
        <select
          value={choice}
          onChange={(e) => {
            setChoice(e.target.value);
            onSelect?.(e.target.value);
          }}
        >
          <option value="">Workspace default (or personal email)</option>
          <option value="personal">Personal email</option>
          <option value="branded">Branded email</option>
          {rows
            .filter((r) => r.status === "approved")
            .map((r) => (
              <option key={r.id} value={r.id}>
                {r.settings.name}
              </option>
            ))}
        </select>
      </label>
      <button
        disabled={busy || disabled}
        onClick={() =>
          void run(async () =>
            setRender(
              (
                await api.preview(
                  w,
                  { draftId, draftVersion, templateId: choice },
                  new AbortController().signal,
                )
              ).rendered,
            ),
          )
        }
      >
        Preview saved email
      </button>
      {disabled && (
        <p>
          {draftId
            ? "Save your changes to preview the current email."
            : "Create or open an email draft to preview these templates."}
        </p>
      )}
      </>}
      {error && <p role="alert">{error}</p>}
      {notice && <p role="status">{notice}</p>}
      {render && <EmailPreview rendered={render} />}
      <details open={managerOpen} onToggle={(e) => setManagerOpen(e.currentTarget.open)}>
        <summary>Manage templates</summary>
        <p>
          Templates use the approved Brand Kit. Editing creates a new draft
          version; previous delivery snapshots are retained.
        </p>
        <h4>{editing ? `Editing: ${editing.settings.name} · ${editing.status} · version ${editing.version}` : "Create a new template"}</h4>
        <button type="button" onClick={() => { if (JSON.stringify(form) === JSON.stringify(editing?.settings ?? initial) || confirm("Start a new template? Unsaved edits will be discarded.")) {setEditing(undefined);setForm(initial);setSampleRender(undefined);} }}>New template</button>
        <div className="email-template-fields">
          <label>
            Template name
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          </label>
          <label>
            Layout
            <select
              value={form.layout}
              onChange={(e) =>
                setForm({
                  ...form,
                  layout: e.target.value as TemplateSettings["layout"],
                })
              }
            >
              <option value="personal">Personal email</option>
              <option value="branded">Branded email</option>
            </select>
          </label>
          <label>
            Brand colour role
            <select
              value={form.accentRole}
              onChange={(e) =>
                setForm({
                  ...form,
                  accentRole: e.target.value as TemplateSettings["accentRole"],
                })
              }
            >
              {["primary", "secondary", "accent"].map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
          </label>
          <div className="template-options"><label>
            <input
              type="checkbox"
              disabled={form.layout === "personal"}
              checked={form.includeLogo}
              onChange={(e) =>
                setForm({ ...form, includeLogo: e.target.checked })
              }
            />{" "}
            Include approved logo (branded layout)
          </label>
          <label>
            <input
              type="checkbox"
              checked={form.includeSignature}
              onChange={(e) =>
                setForm({ ...form, includeSignature: e.target.checked })
              }
            />{" "}
            Include approved signature
          </label>
          <label>
            <input
              type="checkbox"
              checked={form.includeFooter}
              onChange={(e) =>
                setForm({ ...form, includeFooter: e.target.checked })
              }
            />{" "}
            Include approved footer
          </label></div>
          {form.layout === "personal" && <p className="email-wide muted">Personal emails omit the header logo. Your logo setting is retained for the branded layout.</p>}
          <label>Logo alignment<select value={form.logoAlignment} onChange={(e)=>setForm({...form,logoAlignment:e.target.value as TemplateSettings["logoAlignment"]})}>
            {["left","centre","right"].map((v)=><option key={v}>{v}</option>)}
          </select></label>
          <label>Logo width (px)<input type="number" min={48} max={320} value={form.logoWidth} onChange={(e)=>setForm({...form,logoWidth:Number(e.target.value)})}/></label>
          <label>Logo spacing (px)<input type="number" min={8} max={64} value={form.logoSpacing} onChange={(e)=>setForm({...form,logoSpacing:Number(e.target.value)})}/></label>
        </div>
        <div className="email-actions">
          <button
            disabled={busy || !form.name.trim()}
            onClick={() => void change("save")}
          >
            {editing ? "Save template" : "Create template"}
          </button>
          {editing && (
            <button
              onClick={() => {
                setEditing(undefined);
                setForm(initial);
              }}
            >
              Cancel edit
            </button>
          )}
        </div>
        <div className="email-actions">
          {["retire", "delete"].map((op) => (
            <button
              key={op}
              disabled={busy || !checked.length}
              onClick={() => {
                if (
                  confirm(
                    `${op === "delete" ? "Delete" : "Retire"} ${checked.length} selected templates? Approved or referenced templates cannot be deleted.`,
                  )
                )
                  void run(async () => {
                    const failures: string[] = [];
                    for (const r of rows.filter((r) => checked.includes(r.id)))
                      try {
                        await api.change(
                          w,
                          {
                            requestKey: crypto.randomUUID(),
                            id: r.id,
                            expectedVersion: r.version,
                            brandId,
                            operation: op,
                          },
                          new AbortController().signal,
                        );
                      } catch {
                        failures.push(r.settings.name);
                      }
                    await load(new AbortController().signal);
                    setChecked([]);
                    setNotice(
                      failures.length
                        ? "Not changed: " + failures.join(", ")
                        : "Selected templates updated.",
                    );
                  });
              }}
            >
              {op === "delete" ? "Delete selected" : "Retire selected"}
            </button>
          ))}
        </div>
        <div className="email-actions">
          <button type="button" disabled={busy} onClick={()=>void run(async()=>setSampleRender((await api.sample(w,{brandId,settings:{...form,name:form.name.trim() || "Design preview"}},new AbortController().signal)).rendered))}>Preview design with sample text</button>
        </div>
        {sampleRender && <EmailPreview rendered={sampleRender}/>}
        <h4>Saved templates</h4>
        <label><input type="checkbox" checked={showRetired} onChange={(e)=>{setShowRetired(e.target.checked);setChecked([]);}}/>Show retired templates</label>
        {rows.filter((r)=>showRetired || r.status !== "retired").map((r) => (
          <article key={r.id} className="email-template-row">
            <label>
              <input
                type="checkbox"
                checked={checked.includes(r.id)}
                onChange={(e) =>
                  setChecked(
                    e.target.checked
                      ? [...checked, r.id]
                      : checked.filter((id) => id !== r.id),
                  )
                }
              />
              {r.settings.name} · {r.status}
              {r.isDefault ? " · default" : ""}
            </label>
            <div className="email-actions">
              <button
                disabled={busy}
                onClick={() => {
                  setEditing(r);
                  setForm(r.settings);
                }}
              >
                Edit
              </button>
              <button
                disabled={busy}
                onClick={() => void change("duplicate", r)}
              >
                Duplicate
              </button>
              {r.status === "draft" && (
                <button
                  disabled={busy}
                  onClick={() => void change("approve", r)}
                >
                  Approve template
                </button>
              )}
              {r.status === "approved" && (
                <button
                  disabled={busy}
                  onClick={() => void change("default", r)}
                >
                  Use as default
                </button>
              )}
            </div>
          </article>
        ))}
      </details>
    </section>
  );
}
