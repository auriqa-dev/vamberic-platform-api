import { useEffect, useRef, useState } from "react";
import { DataError } from "../data/gateway";
import {
  hubspotKind,
  mappingFields,
  readUpload,
  suggestMapping,
  type UploadSheet,
} from "../data/hive-upload";
import {
  prepareImport,
  isEsos,
  batches,
  batchKey,
  contentKey,
  type ImportPlan,
  type PreparedRow,
} from "../data/hive-import-plan";
import type { IcpGateway, ImportPreview } from "../data/icp";

import { esosReview } from "../data/esos-review";

type Progress = {
  index: number;
  importId: string;
  verified: true;
  counts: {
    total: number;
    created: number;
    duplicate: number;
    rejected: number;
    updated: number;
  };
};
export function HiveImport({
  api,
  w,
  onImported,
  onFileSelected,
}: {
  api: IcpGateway;
  w: string;
  onImported?: (summary: { checkedRows: number }) => void;
  onFileSelected?: () => void;
}) {
  const [sheets, setSheets] = useState<UploadSheet[]>([]),
    [selected, setSelected] = useState(0),
    [workbook, setWorkbook] = useState(false);
  const [mapping, setMapping] = useState<Record<string, string>>({}),
    [filename, setFilename] = useState(""),
    [fingerprint, setFingerprint] = useState("");
  const [plan, setPlan] = useState<ImportPlan>(),
    [job, setJob] = useState(""),
    [chunks, setChunks] = useState<PreparedRow[][]>([]);
  const [progress, setProgress] = useState<Progress[]>([]),
    [current, setCurrent] = useState(0),
    [preview, setPreview] = useState<ImportPreview>();
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [reviewed, setReviewed] = useState(false),
    [complete, setComplete] = useState(false),
    [interrupted, setInterrupted] = useState(false);
  const [page, setPage] = useState(0),
    [skip, setSkip] = useState<number[]>([]);
  const replacesJob = useRef<string | undefined>(undefined);
  const lock = useRef(false),
    pause = useRef(false);
  useEffect(
    () => () => {
      pause.current = true;
    },
    [],
  );
  const notifiedJob = useRef("");
  useEffect(() => {
    if (complete && job && notifiedJob.current !== job) {
      notifiedJob.current = job;
      onImported?.({
        checkedRows: progress.reduce(
          (count, receipt) => count + receipt.counts.total,
          0,
        ),
      });
    }
  }, [complete, job, progress, onImported]);
  const sheet = sheets[selected];
  const detected = sheet ? hubspotKind(sheet.headers) : undefined;
  const [associateByName, setAssociateByName] = useState(false);
  const [resolutions, setResolutions] = useState<
    Record<number, { action: "match" | "create"; id?: string }>
  >({});
  const [timezone, setTimezone] = useState("");
  const [lifecycleMapping, setLifecycleMapping] = useState<
    Record<string, string>
  >({});
  const lifecycleValues = sheet
    ? [
        ...new Set(
          sheet.rows
            .map((r) => r[sheet.headers.indexOf("Lifecycle Stage")] ?? "")
            .filter(Boolean),
        ),
      ]
    : [];
  const [showAllRows, setShowAllRows] = useState(false);
  const reviewRows = preview?.rows.filter((r) => showAllRows || r.status === "review" || r.status === "skip") ?? [];
  const roles = workbook ? esosReview(sheets) : undefined;
  const clearReview = () => {
    replacesJob.current = undefined;
    setPlan(undefined);
    setPreview(undefined);
    setReviewed(false);
    setComplete(false);
    setInterrupted(false);
    setProgress([]);
    setSkip([]);
    setResolutions({});
  };
  const body = async (index: number, rows: PreparedRow[], jobId = job) => ({
    ...(detected
      ? {
          hubspot: {
            timezone,
            kind: detected,
            lifecycleMapping,
            associateByName,
          },
        }
      : {}),
    requestKey: await batchKey(jobId, index),
    filename,
    fieldMapping: workbook ? {} : mapping,
    jobId,
    ...(replacesJob.current ? { replacesJobId: replacesJob.current } : {}),
    batchIndex: index,
    rows: rows.map((r) => ({
      ...r,
      ...(resolutions[r.row] ? { resolution: resolutions[r.row] } : {}),
    })),
  });
  const prepare = async () => {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError("");
    try {
      if (detected) {
        try {
          if (!timezone) throw new Error();
          new Intl.DateTimeFormat("en-GB", { timeZone: timezone });
        } catch {
          throw new Error("Choose the timezone used in your HubSpot export.");
        }
      }
      const next = prepareImport(sheets, selected, mapping, workbook),
        parts = batches(next);
      if (!parts.length)
        throw new Error("No records found in the selected data.");
      const id = await contentKey(
        JSON.stringify({
          version: workbook ? 3 : 2,
          file: fingerprint,
          selected,
          workbook,
          mapping,
          ...(detected
            ? {
                matchingVersion: 2,
                timezone,
                lifecycleMapping,
                associateByName,
              }
            : {}),
        }),
      );
      if (workbook && api.importProgress) {
        const legacyId = await contentKey(
          JSON.stringify({
            version: 2,
            file: fingerprint,
            selected,
            workbook,
            mapping,
          }),
        );
        const legacy = await api.importProgress(
          w,
          legacyId,
          new AbortController().signal,
        );
        if (legacy.batches.length && !legacy.reconciled)
          throw new Error(
            "This workbook has an earlier import that needs reconciliation. Keep it paused; support must reconcile the saved accounts before starting the corrected import.",
          );
        replacesJob.current = legacy.batches.length ? legacyId : undefined;
      }
      const saved = api.importProgress
        ? await api.importProgress(w, id, new AbortController().signal)
        : { batches: [] };
      if (
        saved.batches.some(
          (b) => !b.verified || b.counts.total !== parts[b.index]?.length,
        ) ||
        new Set(saved.batches.map((b) => b.index)).size !== saved.batches.length
      )
        throw new Error(
          "Saved batch receipts do not match this file. Contact support before continuing.",
        );
      setPlan(next);
      setChunks(parts);
      setJob(id);
      setProgress(saved.batches);
      setPage(0);
      setReviewed(false);
      const first = parts.findIndex(
        (_, i) => !saved.batches.some((b) => b.index === i),
      );
      if (first < 0) {
        setComplete(true);
        setPreview(undefined);
        return;
      }
      setCurrent(first);
      const result = await api.previewImport(
        w,
        await body(first, parts[first]!, id),
        new AbortController().signal,
      );
      setPreview(result);
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Unable to prepare the import.",
      );
    } finally {
      setBusy(false);
      lock.current = false;
    }
  };
  const run = async () => {
    if (lock.current || !reviewed) return;
    lock.current = true;
    pause.current = false;
    setBusy(true);
    setError("");
    let done = [...progress];
    try {
      // A response may have been lost after commit. Recover receipts before retrying.
      if (api.importProgress) {
        const saved = await api.importProgress(
          w,
          job,
          new AbortController().signal,
        );
        if (
          saved.batches.some(
            (b) => !b.verified || b.counts.total !== chunks[b.index]?.length,
          ) ||
          new Set(saved.batches.map((b) => b.index)).size !==
            saved.batches.length
        )
          throw new Error(
            "Saved batch receipts do not match the prepared import.",
          );
        done = saved.batches;
        setProgress(done);
      }
      for (let i = 0; i < chunks.length; i++) {
        if (done.some((p) => p.index === i)) continue;
        if (pause.current) break;
        setCurrent(i);
        const rows = chunks[i]!.map((r) => ({
          ...r,
          skip: skip.includes(r.row),
        }));
        const input = await body(i, rows);
        const check = await api.previewImport(
          w,
          input,
          new AbortController().signal,
        );
        setPreview(check);
        setPage(0);
        if (check.rows.some((r) => r.status === "review")) {
          setError(
            "This batch needs your review. Earlier batches are safely saved. Choose an existing match, confirm a separate record, or skip the affected rows below.",
          );
          break;
        }
        const receipt = await api.commitImport(
          w,
          { ...input, digest: check.digest },
          new AbortController().signal,
        );
        done = [
          ...done,
          {
            index: i,
            importId: receipt.importId,
            verified: receipt.verified,
            counts: receipt.counts,
          },
        ];
        setProgress(done);
      }
      if (done.length === chunks.length) {
        const reconciled = api.importProgress
          ? await api.importProgress(w, job, new AbortController().signal)
          : { batches: done };
        if (
          reconciled.batches.length !== chunks.length ||
          reconciled.batches.some(
            (b) => !b.verified || b.counts.total !== chunks[b.index]?.length,
          )
        )
          throw new Error(
            "The final receipt does not match the prepared rows. Resume to check the saved batches.",
          );
        setProgress(reconciled.batches);
        setComplete(true);
        setPreview(undefined);
      }
    } catch (e) {
      setInterrupted(true);
      const reason = e instanceof DataError && e.code === "invalid"
        ? "HVM could not validate the import. Contact support if this persists."
        : e instanceof DataError && e.code === "denied"
          ? "Your session or permissions could not be verified. Sign in again before resuming."
          : e instanceof DataError && e.code === "conflict"
            ? "The import data changed or needs review. Resume to check it again."
            : "HVM could not confirm that the batch was saved.";
      setError(`${reason} Your file and selections are retained. Resume import checks saved batches before continuing, without duplicating them.`);
    } finally {
      setBusy(false);
      lock.current = false;
    }
  };
  const total = progress.reduce((n, p) => n + p.counts.total, 0);
  return (
    <section className="panel hive-import">
      <h2>Upload records and email history</h2>
      <p>
        Choose CSV, Excel or a HubSpot ZIP up to 50 MB. Review the records and
        additional fields before importing. Existing records are not overwritten
        and marketing permissions are unchanged.
      </p>
      <label className="field">
        Choose a file
        <input
          type="file"
          accept=".csv,.xlsx,.zip"
          disabled={busy}
          onChange={async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            onFileSelected?.();
            setBusy(true);
            setError("");
            clearReview();
            setSheets([]);
            try {
              const parsed = await readUpload(file);
              if (!parsed.length) throw new Error("No worksheets found.");
              setFingerprint(await contentKey(await file.arrayBuffer()));
              setFilename(file.name);
              setSheets(parsed);
              setSelected(0);
              setWorkbook(isEsos(parsed));
              setMapping(suggestMapping(parsed[0]!.headers));
            } catch (e) {
              setError(
                e instanceof Error ? e.message : "Unable to read this file.",
              );
            } finally {
              setBusy(false);
            }
          }}
        />
      </label>
      {busy && !plan && <p role="status">Reading and preparing your file…</p>}
      {error && <p role="alert">{error}</p>}
      {sheet && (
        <>
          {detected && (
            <section aria-label="HubSpot import settings">
              <h3>HubSpot {detected}</h3>
              <p>
                {sheet.rows.length.toLocaleString()} records detected. Source
                IDs, lifecycle, restrictions and original dates are preserved.
                Importing never sends messages or enrols contacts.
              </p>
              <label className="field">
                Export timezone
                <input
                  list="hubspot-timezones"
                  value={timezone}
                  placeholder="Europe/London"
                  disabled={busy || progress.length > 0}
                  onChange={(e) => {
                    setTimezone(e.target.value);
                    clearReview();
                  }}
                />
                <datalist id="hubspot-timezones">
                  <option value="Europe/London" />
                  <option value="UTC" />
                  <option value="America/New_York" />
                  <option value="America/Los_Angeles" />
                </datalist>
                <small>
                  Check the timezone used by HubSpot for this export. Dates
                  without an offset use this value.
                </small>
              </label>
              {detected === "contacts" && (
                <label className="icp-check">
                  <input
                    type="checkbox"
                    checked={associateByName}
                    disabled={busy || progress.length > 0}
                    onChange={(e) => {
                      setAssociateByName(e.target.checked);
                      clearReview();
                    }}
                  />
                  Link employment when Company Name exactly matches one existing
                  organisation. Review these proposed links; this never merges
                  people or organisations.
                </label>
              )}
              {lifecycleValues.length > 0 && (
                <details>
                  <summary>Review lifecycle mapping</summary>
                  <p>
                    Standard HubSpot stages are recognised automatically.
                    Unknown stages remain unresolved; choose an override where
                    appropriate.
                  </p>
                  <div className="icp-grid">
                    {lifecycleValues.map((value) => (
                      <label className="field" key={value}>
                        {value}
                        <select
                          value={lifecycleMapping[value] ?? ""}
                          disabled={busy || progress.length > 0}
                          onChange={(e) => {
                            setLifecycleMapping(
                              e.target.value
                                ? {
                                    ...lifecycleMapping,
                                    [value]: e.target.value,
                                  }
                                : Object.fromEntries(
                                    Object.entries(lifecycleMapping).filter(
                                      ([k]) => k !== value,
                                    ),
                                  ),
                            );
                            clearReview();
                          }}
                        >
                          <option value="">Automatic mapping</option>
                          {[
                            "subscriber",
                            "lead",
                            "marketing_qualified",
                            "sales_qualified",
                            "opportunity",
                            "customer",
                            "advocate",
                            "other",
                            "unknown",
                          ].map((stage) => (
                            <option key={stage} value={stage}>
                              {stage.replaceAll("_", " ")}
                            </option>
                          ))}
                        </select>
                      </label>
                    ))}
                  </div>
                </details>
              )}
              {detected === "emails" && (
                <p>
                  Import contacts first. Unmatched emails remain available as
                  unlinked history; forwarded messages do not count as direct
                  engagement.
                </p>
              )}
            </section>
          )}
          {isEsos(sheets) && (
            <label className="icp-check">
              <input
                type="checkbox"
                checked={workbook}
                disabled={busy || progress.length > 0}
                onChange={(e) => {
                  setWorkbook(e.target.checked);
                  clearReview();
                }}
              />
              Combine the ESOS workbook: companies, group membership and
              notification evidence
            </label>
          )}
          {!workbook && (
            <>
              <label className="field">
                Worksheet
                <select
                  value={selected}
                  disabled={busy || progress.length > 0}
                  onChange={(e) => {
                    const i = Number(e.target.value);
                    setSelected(i);
                    setMapping(suggestMapping(sheets[i]!.headers));
                    clearReview();
                  }}
                >
                  {sheets.map((s, i) => (
                    <option key={i} value={i}>
                      {s.name} ({s.rows.length.toLocaleString()} rows)
                    </option>
                  ))}
                </select>
              </label>
              {!detected && (
                <details>
                  <summary>Match columns to company and contact fields</summary>
                  <div className="icp-grid">
                    {sheet.headers.map((h) => (
                      <label className="field" key={h}>
                        {h}
                        <select
                          value={mapping[h] ?? ""}
                          disabled={busy || progress.length > 0}
                          onChange={(e) => {
                            setMapping({ ...mapping, [h]: e.target.value });
                            clearReview();
                          }}
                        >
                          <option value="">Additional source field</option>
                          {Object.entries(mappingFields)
                            .filter(
                              ([k]) =>
                                mapping[h] === k ||
                                !Object.values(mapping).includes(k),
                            )
                            .map(([k, v]) => (
                              <option key={k} value={k}>
                                {v}
                              </option>
                            ))}
                        </select>
                      </label>
                    ))}
                  </div>
                </details>
              )}
            </>
          )}
          {workbook && (
            <p>
              All notification sheets will be retained. Companies are matched by
              UK registration number where available. Group-level energy totals
              stay attached to their ESOS notification, not each subsidiary. The
              table of contents is not imported as company data.
            </p>
          )}
          <button
            className="button"
            type="button"
            disabled={busy}
            onClick={() => void prepare()}
          >
            Review import
          </button>
        </>
      )}
      {plan && (
        <>
          <h3>Review your import</h3>
          <p>
            {plan.sourceRows.toLocaleString()} source rows
            {workbook
              ? ` · ${plan.companies.toLocaleString()} responsible-undertaking candidates (not verified ICP accounts)`
              : ""}{" "}
            · {chunks.length.toLocaleString()} recoverable batches.
          </p>
          {roles && (
            <p>
              Source records: {roles.responsibleRows.toLocaleString()}{" "}
              responsible undertakings;{" "}
              {roles.nonQualifyingRows.toLocaleString()} reporting entries
              marked not qualifying for ESOS;{" "}
              {roles.coveredRows.toLocaleString()} covered organisation entries
              (including responsible undertakings);{" "}
              {roles.excludedRows.toLocaleString()} excluded entries. These
              categories describe notification records, overlap across companies
              and are not counts of qualified ICP accounts. Energy totals belong
              to the notification, not each group member.
            </p>
          )}
          <details>
            <summary>
              Source fields, mappings and proposed data types (
              {plan.fields.length})
            </summary>
            <p>
              Mapped fields populate the corresponding company or contact
              fields. Additional values are retained as source-linked
              observations. They do not overwrite company facts or create global
              database fields. Original text, dates and units are retained.
            </p>
            <div className="table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>Source field</th>
                    <th>Detected type</th>
                    <th>Use</th>
                  </tr>
                </thead>
                <tbody>
                  {plan.fields.map((f) => (
                    <tr key={f.name}>
                      <td>{f.name}</td>
                      <td>{f.type}</td>
                      <td>
                        {detected &&
                        [
                          "Record ID",
                          "Lifecycle Stage",
                          "Current Customer",
                          "Subscription Status",
                          "Lead Status",
                          "Marketing contact status",
                          "Email Direction",
                          "Email body",
                          "Email subject",
                          "Activity date",
                          "Last Engagement Date",
                          "Last Contacted",
                          "Unsubscribed from all email",
                          "Opted out of email: Marketing Information",
                          "Opted out of email: One to One",
                        ].includes(f.name)
                          ? "HubSpot identity, lifecycle, restriction or interaction context"
                          : f.mappedTo.length
                            ? `Mapped to ${f.mappedTo.join(", ")}`
                            : "Additional source information"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </details>
          {plan.notes.length > 0 && (
            <details>
              <summary>{plan.notes.length} identities need review</summary>
              {plan.notes.slice(0, 100).map((n, i) => (
                <p key={i}>{n}</p>
              ))}
              <p>
                All source rows are retained, including unresolved identities.
              </p>
            </details>
          )}
          <p role="status">
            {total.toLocaleString()} of {plan.rows.length.toLocaleString()}{" "}
            prepared rows verified in Hive · {progress.length} of{" "}
            {chunks.length} batches.
          </p>
          {!complete && (
            <>
              <label className="icp-check">
                <input
                  type="checkbox"
                  checked={reviewed}
                  disabled={busy}
                  onChange={(e) => setReviewed(e.target.checked)}
                />
                I have reviewed the mapping and additional fields. Import these
                records and their source observations.
              </label>
              <div className="icp-actions">
                <button
                  type="button"
                  className="button"
                  disabled={busy || !reviewed}
                  onClick={() => void run()}
                >
                  {progress.length || interrupted
                    ? "Resume import"
                    : "Confirm import into Hive"}
                </button>
                {busy && (
                  <button
                    type="button"
                    onClick={() => {
                      pause.current = true;
                    }}
                  >
                    Pause after this batch
                  </button>
                )}
              </div>
            </>
          )}
          {complete && (
            <div role="status">
              <h3>Import checked and complete</h3>
              <p>
                All prepared rows have verified receipts. Original source rows
                and additional observations are retained. Saved contacts and
                companies are now available in contact management.
              </p>
            </div>
          )}
          {preview && !busy && (
            <>
              <h3>Batch {current + 1}: review records</h3>
              <p>
                New: {preview.counts.created} · Existing/source-only:{" "}
                {preview.counts.duplicate} · Needs attention:{" "}
                {preview.rows.filter((r) => r.status === "review" && !skip.includes(r.row)).length}
                {" · Skipped: "}
                {preview.rows.filter((r) => r.status === "skip" || skip.includes(r.row)).length}
              </p>
              <label className="icp-check">
                <input type="checkbox" checked={showAllRows} onChange={(e) => { setShowAllRows(e.target.checked); setPage(0); }} />
                Show all records in this batch
              </label>
              {!reviewRows.length && <p>No rows need attention in this batch.</p>}
              <div className="table-scroll">
                <table className="hive-match-review">
                  <thead>
                    <tr>
                      <th>Record</th>
                      <th>Status</th>
                      <th>Review</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reviewRows.slice(page * 20, page * 20 + 20).map((r) => (
                      <tr key={r.row}>
                        <td>
                          {String(
                            r.values.company ||
                              r.values.firstName ||
                              "Source observation",
                          )}
                          <small> Row {r.row}</small>
                          {typeof r.values.lifecycle === "string" && (
                            <p>
                              Lifecycle:{" "}
                              {r.values.lifecycle === "unknown" && r.values.originalLifecycle ? String(r.values.originalLifecycle) : r.values.lifecycle.replaceAll("_", " ")}
                            </p>
                          )}
                          {Array.isArray(r.values.restrictions) &&
                            r.values.restrictions.length > 0 && (
                              <p>
                                Restrictions: {r.values.restrictions.join(", ")}
                              </p>
                            )}
                        </td>
                        <td>
                          {r.status === "existing"
                            ? r.unchanged
                              ? "Unchanged — skip"
                              : "Existing match — retain source history"
                            : r.status === "create"
                              ? "New record"
                              : r.status}
                        </td>
                        <td>
                          {r.issues.map((x) => (
                            <p key={x}>{x}</p>
                          ))}
                          {r.status === "review" &&
                            detected &&
                            !!r.candidates?.length && (
                              <label className="field">
                                Resolve possible match
                                <select
                                  disabled={busy}
                                  value={
                                    resolutions[r.row]?.action === "create"
                                      ? "create"
                                      : (resolutions[r.row]?.id ?? "")
                                  }
                                  onChange={(e) =>
                                    setResolutions({
                                      ...resolutions,
                                      [r.row]:
                                        e.target.value === "create"
                                          ? { action: "create" }
                                          : {
                                              action: "match",
                                              id: e.target.value,
                                            },
                                    })
                                  }
                                >
                                  <option value="">
                                    Choose a match or skip
                                  </option>
                                  {r.candidates.map((c) => (
                                    <option key={c.id} value={c.id}>
                                      Use existing: {c.name}
                                    </option>
                                  ))}
                                  <option value="create">
                                    This is a separate record — create new
                                  </option>
                                </select>
                                <small>
                                  Existing values are kept. The match is checked
                                  again before saving.
                                </small>
                              </label>
                            )}
                          {(r.status === "review" || r.status === "skip") && (
                            <label className="icp-check">
                              <input
                                type="checkbox"
                                checked={skip.includes(r.row)}
                                onChange={(e) =>
                                  setSkip(
                                    e.target.checked
                                      ? [...skip, r.row]
                                      : skip.filter((x) => x !== r.row),
                                  )
                                }
                              />
                              Skip this row
                            </label>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="icp-actions">
                <button disabled={page === 0} onClick={() => setPage(page - 1)}>
                  Previous
                </button>
                <span>Page {page + 1}</span>
                <button
                  disabled={(page + 1) * 20 >= reviewRows.length}
                  onClick={() => setPage(page + 1)}
                >
                  Next
                </button>
              </div>
            </>
          )}
          {progress.length > 0 && (
            <details>
              <summary>Verified batch receipts</summary>
              {progress.map((p) => (
                <p key={p.index}>
                  Batch {p.index + 1}: {p.counts.total} rows verified ·{" "}
                  {p.importId}
                </p>
              ))}
            </details>
          )}
        </>
      )}
      <ImportedObservations api={api} w={w} />
    </section>
  );
}
function ImportedObservations({ api, w }: { api: IcpGateway; w: string }) {
  const [query, setQuery] = useState(""),
    [records, setRecords] = useState<{ id: string; name: string }[]>([]),
    [selected, setSelected] = useState("");
  const [recordType, setRecordType] = useState<"company" | "contact">(
    "company",
  );
  const [notification, setNotification] = useState("");
  const [items, setItems] = useState<
      Awaited<
        ReturnType<NonNullable<IcpGateway["importObservations"]>>
      >["items"]
    >([]),
    [offset, setOffset] = useState(0),
    [more, setMore] = useState(false),
    [error, setError] = useState("");
  const load = async (id: string, start: number, noc = "") => {
    try {
      if (!api.importObservations) return;
      const data = await api.importObservations(
        w,
        {
          ...(noc
            ? { notification: noc }
            : recordType === "company"
              ? { companyId: id }
              : { personId: id }),
          offset: start,
        },
        new AbortController().signal,
      );
      setNotification(noc);
      setItems(data.items);
      setMore(data.hasMore);
      setOffset(start);
      setError("");
    } catch {
      setError("Could not load saved source details.");
    }
  };
  return (
    <details className="hive-observations">
      <summary>Review saved source details</summary>
      <label className="field">
        Record type
        <select
          value={recordType}
          onChange={(e) => {
            setRecordType(e.target.value as "company" | "contact");
            setSelected("");
            setItems([]);
            setRecords([]);
          }}
        >
          <option value="company">Company</option>
          <option value="contact">Contact</option>
        </select>
      </label>
      <label className="field">
        Find a record
        <input value={query} onChange={(e) => setQuery(e.target.value)} />
      </label>
      <button
        type="button"
        onClick={() =>
          void api
            .examples(w, recordType, query, new AbortController().signal)
            .then(setRecords)
            .catch(() => setError("Could not find companies."))
        }
      >
        Search records
      </button>
      <label className="field">
        Record
        <select
          value={selected}
          onChange={(e) => {
            setSelected(e.target.value);
            void load(e.target.value, 0);
          }}
        >
          <option value="">Choose a record</option>
          {records.map((r) => (
            <option key={r.id} value={r.id}>
              {r.name}
            </option>
          ))}
        </select>
      </label>
      {error && <p role="alert">{error}</p>}
      {items.map((item) => (
        <section key={item.id}>
          <h4>
            {item.origin.sheet} · row {item.origin.row}
          </h4>
          <p>
            {item.origin.scope}
            {item.origin.notification
              ? ` · Notification ${item.origin.notification}`
              : ""}
            {item.origin.relatedName
              ? ` · Reported with ${item.origin.relatedName}`
              : ""}
          </p>
          {item.origin.notification && !notification && (
            <button
              type="button"
              onClick={() => void load(selected, 0, item.origin.notification)}
            >
              View this notification’s group evidence
            </button>
          )}
          <dl>
            {item.fields.map((f, i) => (
              <div key={i}>
                <dt>{f.label}</dt>
                <dd>{f.raw || "Not supplied"}</dd>
              </div>
            ))}
          </dl>
        </section>
      ))}
      {notification && (
        <p>
          Showing group evidence for {notification}. These are
          notification-level values, not individual company totals.{" "}
          <button type="button" onClick={() => void load(selected, 0)}>
            Back to company details
          </button>
        </p>
      )}
      {selected && (
        <div className="icp-actions">
          <button
            disabled={offset === 0}
            onClick={() =>
              void load(selected, Math.max(0, offset - 50), notification)
            }
          >
            Previous details
          </button>
          <button
            disabled={!more}
            onClick={() => void load(selected, offset + 50, notification)}
          >
            More details
          </button>
        </div>
      )}
    </details>
  );
}
