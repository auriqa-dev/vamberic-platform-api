import { BusinessOutcomesCard } from "./business-outcomes";
import { WebsiteTrackingCard } from "./website-tracking";
import { Ga4ConnectionCard } from "./ga4-connection";
import { MailboxConnectionCard } from "./mailbox-connection";
import { LushaConnectionCard } from "./lusha-connection";
import { useHenryBinding } from "./workspace-henry";
import { WorkspaceAccessEditor } from "./workspace-access";
import { BrandKitEditor } from "./brand-kit-editor";
import { useRefreshingResource } from "../data/use-refreshing-resource";
import { OnboardingEditor } from "./onboarding";
import { useCallback, useState } from "react";
import { Link } from "react-router-dom";
import { loadWorkspace, type HvmGateway } from "../data/gateway";
import { useResource } from "../data/use-resource";
import {
  integrationStatus,
  kitStatus,
  onboardingLabels,
  providers,
  type Access,
  type WorkspacePerspective,
  type Snapshot,
  type Workspace,
} from "../data/model";
import { Empty, Failure, Loading, Status } from "./ui";

export const sections = [
  ["overview", "Overview"],
  ["understanding", "Company & products"],
  ["offers", "Offer Architecture"],
  ["icp", "Ideal customer profiles"],
  ["contact-strategy", "Contact Strategy"],
  ["content-strategy", "Content Strategy"],
  ["library", "Library"],
  ["email-content", "Email Content Creation"],
  ["communications", "Communications"],
  ["interactions", "Interaction"],
  ["research", "Research"],
  ["campaigns", "Campaigns"],
  ["performance", "Performance"],
  ["nba", "Next Best Action"],
  ["contacts", "Contact management"],
  ["activity", "Activity"],
  ["setup", "Setup"],
  ["brand", "Brand Kit"],
  ["integrations", "Integrations"],
  ["team", "Team"],
  ["billing", "Billing & usage"],
] as const;
export type Section = (typeof sections)[number][0];
export const clientSections = sections;
export function workspacePath(
  p: WorkspacePerspective,
  id: string,
  section: Section = "overview",
) {
  return p === "queen"
    ? `/queen/clients/${encodeURIComponent(id)}${section === "overview" ? "" : `/${section}`}`
    : `/client${section === "overview" ? "" : `/${section}`}?workspace=${encodeURIComponent(id)}`;
}
export function WorkspaceCard({
  workspace,
  access,
  gateway,
}: {
  workspace: Workspace;
  access: Access;
  gateway: HvmGateway;
}) {
  const load = useCallback(
    (signal: AbortSignal) =>
      loadWorkspace(gateway, access, "queen", workspace.id, signal),
    [gateway, access, workspace.id],
  );
  const result = useResource(load);
  return (
    <article className="workspace-card">
      <div className="card-heading">
        <span className="eyebrow">Client workspace</span>
        <span aria-hidden="true">↗</span>
      </div>
      <h3>
        <Link to={workspacePath("queen", workspace.id)}>{workspace.organisationName}</Link>
      </h3>
      {result.state === "loading" ? (
        <Loading label="Checking setup…" />
      ) : result.state === "error" ? (
        <p role="status">
          Setup status unavailable. Open this workspace to check again.
        </p>
      ) : (
        <>
          <dl className="facts">
            <div>
              <dt>Onboarding</dt>
              <dd>{onboardingLabels[result.data.onboarding.state]}</dd>
            </div>
            <div>
              <dt>Brand Kit</dt>
              <dd>{kitStatus(result.data)}</dd>
            </div>
            <div>
              <dt>Integrations</dt>
              <dd>{integrationStatus(result.data)}</dd>
            </div>
          </dl>
          <p className="next-action">
            {result.data.onboarding.checks.find(
              (c) => c.status === "needs_attention" || c.status === "pending",
            )?.detail ?? "Review workspace setup and readiness."}
          </p>
        </>
      )}
      <Link
        className="text-link"
        to={workspacePath("queen", workspace.id, "setup")}
      >
        Review setup <span aria-hidden="true">↗</span>
      </Link>
    </article>
  );
}

export function WorkspaceContent({
  section,
  workspace,
  snapshot,
  perspective,
  gateway,
  onChanged,
}: {
  onChanged?: () => void;
  gateway?: HvmGateway;
  section: Section;
  workspace: Workspace;
  snapshot: Snapshot;
  perspective: WorkspacePerspective;
}) {
  useHenryBinding({key:"workspace-status",summary:JSON.stringify({section,workspaceName:workspace.organisationName,role:workspace.role,onboarding:snapshot.onboarding.state,
    integrations:snapshot.integrations.state==="ready"?snapshot.integrations.items.map(i=>({provider:i.provider,status:i.status,name:i.displayName})):"unavailable",
    instruction:section==="team"?"Explain workspace roles. Use the visible access controls for changes; never grant access from conversation.":section==="integrations"?"Connection status only. External permissions and budgets are separate. Never request API keys in chat.":"Help with this workspace using its existing forms."})});
  if (section === "setup")
    return (
      <Setup
        snapshot={snapshot}
        workspace={workspace}
        perspective={perspective}
      />
    );
  if (section === "brand") return <BrandKits snapshot={snapshot} workspace={workspace} gateway={gateway} onChanged={onChanged} />;
  if (section === "integrations") return <Integrations snapshot={snapshot} gateway={gateway} workspaceId={workspace.id} />;
  if (section === "team") return gateway?.workspaceAccess ? <WorkspaceAccessEditor key={workspace.id} api={gateway.workspaceAccess} workspaceId={workspace.id}/> : <Team snapshot={snapshot} />;
  if (section === "activity") return <Activity snapshot={snapshot} />;
  return (
    <>
      <div className="summary-grid">
        {(
          [
            ["Setup", onboardingLabels[snapshot.onboarding.state], "setup"],
            ["Brand Kit", kitStatus(snapshot), "brand"],
            ["Integrations", integrationStatus(snapshot), "integrations"],
          ] as const
        ).map(([label, value, target]) => (
          <Link
            className="summary-card"
            key={label}
            to={workspacePath(perspective, workspace.id, target)}
          >
            <span className="eyebrow">{label}</span>
            <strong>{value}</strong>
            <span className="text-link">
              Review <span aria-hidden="true">↗</span>
            </span>
          </Link>
        ))}
      </div>
      <div className="two-columns">
        <section className="panel">
          <p className="eyebrow">Your workspace</p>
          <h2>Ready to work together.</h2>
          <p>
            Technical onboarding brings your brand, people and connections into
            one place.
          </p>
          <dl className="facts">
            <div>
              <dt>Organisation</dt>
              <dd>{workspace.organisationName}</dd>
            </div>
            <div>
              <dt>Primary contact</dt>
              <dd>{snapshot.identity.primaryContact ?? "Not recorded"}</dd>
            </div>
            <div>
              <dt>Queen / Partner</dt>
              <dd>
                {snapshot.identity.partners
                  .map((p) => p.displayName)
                  .join(", ") || "Not assigned"}
              </dd>
            </div>
            <div>
              <dt>Team</dt>
              <dd>
                {snapshot.team.state === "ready"
                  ? `${snapshot.team.items.filter((m) => m.status === "active").length} active members`
                  : "Awaiting access setup"}
              </dd>
            </div>
          </dl>
          <Link
            className="button"
            to={workspacePath(perspective, workspace.id, "setup")}
          >
            Continue setup <span aria-hidden="true">↗</span>
          </Link>
        </section>
        <section className="panel">
          <p className="eyebrow">Next steps</p>
          <h2>Make the foundations count.</h2>
          <Readiness
            snapshot={snapshot}
            workspace={workspace}
            perspective={perspective}
          />
          <p className="muted small">
            Approvals and ongoing client actions will appear here in a later
            phase.
          </p>
        </section>
      </div>

    </>
  );
}
const checklist = [
  ["identity", "Client identity", "overview"],
  ["brand", "Brand & Brand Kit", "brand"],
  ["team", "Team & access", "team"],
  ["integrations", "Workspace integrations", "integrations"],
] as const;
const checkLabels = {
  complete: "Complete",
  needs_attention: "Needs attention",
  pending: "Pending",
  not_required: "Not required",
};
function Readiness({
  snapshot,
  workspace,
  perspective,
}: {
  snapshot: Snapshot;
  workspace: Workspace;
  perspective: WorkspacePerspective;
}) {
  return (
    <ol className="checklist">
      {checklist.map(([key, label, target], index) => {
        const check = snapshot.onboarding.checks.find((c) => c.key === key);
        return (
          <li key={key}>
            <span className="step-number" aria-hidden="true">
              {check?.status === "complete" ? "✓" : `0${index + 1}`}
            </span>
            <div>
              <Link to={workspacePath(perspective, workspace.id, target)}>
                {label}
              </Link>
              <p>{check?.detail ?? "Awaiting verified setup information."}</p>
            </div>
            <Status>
              {check ? checkLabels[check.status] : "Awaiting status"}
            </Status>
          </li>
        );
      })}
    </ol>
  );
}
function Setup(props: {
  snapshot: Snapshot;
  workspace: Workspace;
  perspective: WorkspacePerspective;
}) {
  return (
    <section className="panel">
      <div className="section-heading">
        <div>
          <p className="eyebrow">Technical onboarding</p>
          <h2>Can HVM operate for you?</h2>
        </div>
        <Status>{onboardingLabels[props.snapshot.onboarding.state]}</Status>
      </div>
      <p>
        Confirm the practical foundations for your workspace. Strategic
        discovery and Mission are separate.
      </p>
      <Readiness {...props} />
      <p className="muted small">
        Readiness reflects verified requirements. The presence of a Brand Kit or
        connection alone does not mean setup is complete.
      </p>
    </section>
  );
}
function BrandIdentity({ snapshot }: { snapshot: Snapshot }) {
  if (snapshot.brands.state === "unavailable")
    return (
      <Empty title="Brand setup is not available yet">
        Your brand details will be available when workspace setup is enabled.
      </Empty>
    );
  if (!snapshot.brands.items.length)
    return (
      <Empty title="No brand added yet">
        HVM needs to register your brand and primary domain for this workspace.
      </Empty>
    );
  return (
    <div className="card-grid">
      {snapshot.brands.items.map((brand) => (
        <section className="panel" key={brand.id}>
          <p className="eyebrow">Brand identity</p>
          <h2>{brand.name}</h2>
          <p>{brand.description ?? "No description recorded."}</p>
          <dl className="facts">
            <div>
              <dt>Primary domain</dt>
              <dd>{brand.primaryDomain ?? "Not recorded"}</dd>
            </div>
          </dl>
          <p className="muted small">Update brand details from Setup.</p>
        </section>
      ))}
    </div>
  );
}
const kitCategories = [
  "Logos & images",
  "Colours",
  "Typography",
  "Visual rules",
  "Tone & voice",
  "Terminology",
  "Approved descriptions",
  "Imagery guidance",
  "Email defaults",
];
function BrandKits({ snapshot, workspace, gateway }: { snapshot: Snapshot; workspace: Workspace; gateway?: HvmGateway; onChanged?: () => void }) {
  return (
    <>
      <BrandIdentity snapshot={snapshot} />
      <section className="panel">
        <p className="eyebrow">Shared brand source</p>
        <h2>Your Brand Kit</h2>
        <p>
          Your Brand Kit keeps every channel working from the
          same identity.
        </p>
        {snapshot.brands.state === "ready" &&
          snapshot.brands.items.map((brand) => (
            <div className="kit" key={brand.id}>
              <h3>{brand.name}</h3>
              {gateway?.brandKit ? <BrandKitEditor api={gateway.brandKit} images={gateway.brandImages} workspaceId={workspace.id} brandId={brand.id} canEdit={workspace.role === "admin"} /> : <>
              {brand.currentKit ? (
                <>
                  <Status>Current Brand Kit</Status>
                  <dl className="facts">
                    {Object.entries(brand.currentKit.readiness).map(
                      ([key, present]) => (
                        <div key={key}>
                          <dt>
                            {key === "emailDefaults"
                              ? "Email defaults"
                              : key.charAt(0).toUpperCase() + key.slice(1)}
                          </dt>
                          <dd>{present ? "Present" : "Missing"}</dd>
                        </div>
                      ),
                    )}
                  </dl>
                  {brand.currentKit.sections.map((section, index) => (
                    <section
                      className="kit-section"
                      key={`${section.title}-${index}`}
                    >
                      <h3>{section.title}</h3>
                      <dl className="facts">
                        {section.entries.map((entry, i) => (
                          <div key={i}>
                            <dt>{entry.label}</dt>
                            <dd className="preserve-lines">{entry.value}</dd>
                          </div>
                        ))}
                      </dl>
                    </section>
                  ))}
                </>
              ) : (
                <p>
                  Upload a logo or image to start your Brand Kit.
                </p>
              )}
              </>}
            </div>
          ))}
        {(!gateway?.brandKit || snapshot.brands.state !== "ready" || !snapshot.brands.items.length) && <div className="category-grid">
          {kitCategories.map((category) => (
            <div key={category}>
              <span aria-hidden="true">＋</span>
              {category}
            </div>
          ))}
        </div>}
      </section>
    </>
  );
}
function Integrations({ snapshot, gateway, workspaceId }: { snapshot: Snapshot; gateway?:HvmGateway; workspaceId:string }) {
  // Keep provider metadata and saved connections intact; only show supported cards here.
  const hiddenProviders = new Set<string>(["postmark", "hubspot", "odyssiant", "ahrefs", "google_ads", "linkedin"]);
  const integrations =
    snapshot.integrations.state === "ready"
      ? snapshot.integrations.items
      : null;
  const additional =
    integrations?.filter(
      (i) => i.provider !== "google_workspace" && !providers.some(([provider]) => provider === i.provider),
    ) ?? [];
  return (
    <>
      <div className="section-heading">
        <div>
          <p className="eyebrow">Connected to your workspace</p>
          <h2>The tools behind the work.</h2>
        </div>
      </div>
      <p>
        Connections stay with your workspace when your Queen or Partner changes.
      </p>
      <div className="card-grid integrations-list">
        {gateway?.outcomes && <BusinessOutcomesCard key={`outcomes-${workspaceId}`} api={gateway.outcomes} workspaceId={workspaceId} />}
        {gateway?.tracking && <WebsiteTrackingCard key={`tracking-${workspaceId}`} api={gateway.tracking} workspaceId={workspaceId}/>}
        {gateway?.mailbox && <MailboxConnectionCard key={`mailbox-${workspaceId}`} api={gateway.mailbox} workspaceId={workspaceId}/>}
        {providers.filter(([provider]) => !hiddenProviders.has(provider)).map(([provider, name]) => {
          if(provider==="ga4" && gateway?.ga4)return <Ga4ConnectionCard key={`ga4-${workspaceId}`} api={gateway.ga4} workspaceId={workspaceId}/>;
          if(provider==="lusha" && gateway?.lusha)return <LushaConnectionCard key={workspaceId} api={gateway.lusha} workspaceId={workspaceId}/>;
          const records =
            integrations?.filter((i) => i.provider === provider) ?? [];
          return (
            <article className="panel integration-card" key={provider}>
              <div className="provider-monogram" aria-hidden="true">
                {name.slice(0, 2)}
              </div>
              <h3>{name}</h3>
              {provider === "odyssiant" ? (
                <>
                  <Status>Future integration</Status>
                  <p>Connection support is planned. No API is available yet.</p>
                </>
              ) : (
                <>
                  {records.length ? (
                    records.map((record) => (
                      <div className="connection" key={record.id}>
                        <p>{record.displayName}</p>
                        <Status>{record.status}</Status>
                      </div>
                    ))
                  ) : (
                    <Status>
                      {integrations ? "Not configured" : "Status unavailable"}
                    </Status>
                  )}
                  <p>Connection management is not available yet.</p>
                </>
              )}
            </article>
          );
        })}
        {additional.map((record) => (
          <article className="panel" key={record.id}>
            <h3>{record.displayName}</h3>
            <Status>{record.status}</Status>
            <p>Connection management is not available yet.</p>
          </article>
        ))}
      </div>
      <p className="small muted">
        Use only the dedicated connection controls for credentials. Never send
        passwords or API keys through workspace notes.
      </p>
    </>
  );
}
function Team({ snapshot }: { snapshot: Snapshot }) {
  return (
    <section className="panel">
      <p className="eyebrow">People & access</p>
      <h2>Your workspace team</h2>
      <p>Client access and Queen / Partner access are managed separately.</p>
      {snapshot.team.state === "unavailable" ? (
        <Empty title="Team access is being prepared">
          Workspace membership management is not available yet.
        </Empty>
      ) : snapshot.team.items.length === 0 ? (
        <Empty title="No team members listed">
          Contact HVM to review workspace membership.
        </Empty>
      ) : (
        <ul className="record-list">
          {snapshot.team.items.map((member) => (
            <li key={member.id}>
              <div>
                <strong>{member.displayName}</strong>
                <p>{member.accessLabel}</p>
              </div>
              <Status>{member.status}</Status>
            </li>
          ))}
        </ul>
      )}
      <p className="small muted">
        Invitations and access changes are not available yet.
      </p>
    </section>
  );
}
function Activity({ snapshot }: { snapshot: Snapshot }) {
  return (
    <section className="panel">
      <p className="eyebrow">Workspace history</p>
      <h2>Activity</h2>
      {snapshot.activity.state === "unavailable" ? (
        <Empty title="Activity is not available yet">
          Workspace activity will appear here when the authorized activity feed
          is enabled.
        </Empty>
      ) : snapshot.activity.items.length === 0 ? (
        <Empty title="No activity to show">
          There are no recorded events in this workspace feed.
        </Empty>
      ) : (
        <ol className="record-list">
          {snapshot.activity.items.map((event) => (
            <li key={event.id}>
              <p>{event.summary}</p>
              <time dateTime={event.occurredAt}>
                {new Date(event.occurredAt).toLocaleString("en-GB")}
              </time>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}
export function WorkspaceLoader({
  access,
  gateway,
  perspective,
  workspace,
  section,
}: {
  access: Access;
  gateway: HvmGateway;
  perspective: WorkspacePerspective;
  workspace: Workspace;
  section: Section;
}) {
  const [revision, setRevision] = useState(0);
  const load = useCallback(
    (signal: AbortSignal) => {
      void revision;
      return loadWorkspace(gateway, access, perspective, workspace.id, signal);
    },
    [gateway, access, perspective, workspace.id, revision],
  );
  const result = useRefreshingResource(load);
  if (result.state === "loading") return <Loading />;
  if (result.state === "error") return <Failure error={result.error} />;
  return (
    <>
      {section === "setup" &&
      workspace.role !== "viewer" &&
      gateway.readOnboarding &&
      gateway.write ? (
        <OnboardingEditor
          key={workspace.id}
          refresh={JSON.stringify([revision, access])}
          gateway={gateway}
          workspaceId={workspace.id}
          onSaved={() => setRevision((n) => n + 1)}
        />
      ) : null}
      <WorkspaceContent
        section={section}
        gateway={gateway}
        onChanged={() => setRevision(v => v+1)}
        workspace={workspace}
        snapshot={result.data}
        perspective={perspective}
      />
    </>
  );
}
