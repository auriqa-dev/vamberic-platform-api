import { useEffect, useState } from "react";
import type { OfferGateway } from "../data/offer";
import type { BriefJob } from "../data/offer/brief";

export function OfferMethodologyChoice({
  api,
  w,
  job,
  index,
  pending,
  researching = false,
  run,
  onGenerate,
}: {
  api: OfferGateway;
  w: string;
  job: BriefJob;
  index: number;
  pending: boolean;
  researching?: boolean;
  run: (action: () => Promise<BriefJob>) => Promise<void>;
  onGenerate: (
    value: { id: string; index: number; existingOfferId?: string },
    allowCommercialChanges: boolean,
  ) => void;
}) {
  const offer = job.interpretation!.offers[index]!;
  const recommendation = offer.methodologyRecommendation;
  const approved = job.methodologyApprovals?.[String(index)];
  const [methods, setMethods] = useState<
    { id: string; version: number; name: string }[]
  >([]);
  const [error, setError] = useState(false);
  const [allowCommercialChanges, setAllowCommercialChanges] = useState(false);
  const [choice, setChoice] = useState("");
  const key = (m: { id: string; version: number }) => `${m.id}:${m.version}`;
  useEffect(() => {
    const c = new AbortController();
    void api
      .methodologies(w, c.signal)
      .then((m) => {
        if (!c.signal.aborted) {
          setMethods(m);
          setError(false);
        }
      })
      .catch(() => {
        if (!c.signal.aborted) setError(true);
      });
    return () => c.abort();
  }, [api, w]);
  const selected =
    choice ||
    (approved ? key(approved) : recommendation ? key(recommendation) : "");
  const ready = approved && selected === key(approved);
  return (
    <section
      className="offer-methodology-choice"
      aria-label={`Methodology for ${offer.brief.name}`}
    >
      <h5>How we’ll develop this offer</h5>
      {recommendation ? (
        <p>
          <strong>
            Henry’s recommendation:{" "}
            {methods.find((m) => key(m) === key(recommendation))?.name ??
              "Saved methodology"}{" "}
            v{recommendation.version}
          </strong>
          <br />
          {recommendation.rationale}
        </p>
      ) : (
        <p>
          Ask Henry to recommend an approach using this offer’s objectives,
          customer needs and buying process, or select one below.
        </p>
      )}
      {error && (
        <p role="alert">
          The available methodologies could not be loaded. Reopen this brief to
          try again.
        </p>
      )}
      <label className="offer-field">
        Methodology for {offer.brief.name}
        <select
          value={selected}
          disabled={pending || error}
          onChange={(e) => {
            setChoice(e.target.value);
            setAllowCommercialChanges(false);
          }}
        >
          <option value="">Select a methodology</option>
          {methods.map((m) => (
            <option key={key(m)} value={key(m)}>
              {m.name} v{m.version}
            </option>
          ))}
        </select>
      </label>
      <p className="muted">
        Changing a saved offer’s methodology starts a new design. Previous
        decisions and approval history are retained.
      </p>
      {ready && (
        <p role="status">
          Brief and methodology approved. The generated offer will still need
          review and approval.
        </p>
      )}
      {ready && offer.existingOfferId && (
        <label className="checkbox-label">
          <input
            type="checkbox"
            checked={allowCommercialChanges}
            disabled={pending}
            onChange={(e) => setAllowCommercialChanges(e.target.checked)}
          />
          Allow changes to pricing, packaging and commercial terms. Leave off to
          refine messaging only.
        </label>
      )}
      <div className="offer-toolbar">
        {!recommendation && (
          <button
            disabled={pending || error}
            onClick={() =>
              void run(() =>
                api.chooseBriefMethodology(
                  w,
                  { id: job.id, index, expectedUpdatedAt: job.updatedAt },
                  new AbortController().signal,
                ),
              )
            }
          >
            Ask Henry to recommend
          </button>
        )}
        {!ready && (
          <button
            className="button"
            disabled={pending || !selected || error}
            onClick={() =>
              void run(() =>
                api.chooseBriefMethodology(
                  w,
                  {
                    id: job.id,
                    index,
                    expectedUpdatedAt: job.updatedAt,
                    selection: {
                      id: selected.split(":")[0],
                      version: Number(selected.split(":")[1]),
                    },
                  },
                  new AbortController().signal,
                ),
              )
            }
          >
            Approve Brief
          </button>
        )}
        {ready && (
          <button
            className="button"
            disabled={pending}
            onClick={() =>
              onGenerate(
                {
                  id: job.id,
                  index,
                  ...(offer.existingOfferId
                    ? { existingOfferId: offer.existingOfferId }
                    : {}),
                },
                allowCommercialChanges,
              )
            }
          >
            {researching && (
              <span className="offer-working-spinner" aria-hidden="true" />
            )}
            {researching
              ? "Researching your offer…"
              : "Research & Generate Offer"}
          </button>
        )}
      </div>
      {researching && (
        <p role="status" className="offer-working-message">
          Henry is researching public sources and preparing your offer. Your
          draft will appear here when it is ready.
        </p>
      )}
    </section>
  );
}
