import { useRef, useState } from "react";
import { useOperating } from "../../data/operating/context";
import type { AgentDefinition } from "../../data/operating/models";
import { createSchema } from "../../data/operating/mutations";
import nbaDefinition from "./nba-definition.json";
import interactionDefinition from "./interaction-definition.json";

// Versioned release data only; registration and publication remain Empress-authorised.
export function NbaRegistration({ registered, interaction = false }: { registered: () => void; interaction?: boolean }) {
  const definition = interaction ? interactionDefinition : nbaDefinition;
  const label = interaction ? "Website Interaction" : "Next Best Action";
  const short = interaction ? "Interaction" : "NBA";
  const api = useOperating();
  const [record, setRecord] = useState<AgentDefinition>();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const pending = useRef(false);
  async function apply(publish: boolean) {
    if (!api || pending.current) return;
    pending.current = true; setBusy(true); setMessage("");
    try {
      const signal = new AbortController().signal;
      const input = createSchema("agent_definitions").parse(definition);
      const rows = await api.list({ resource: "agent_definitions" }, { key: input.key, limit: 100 }, signal);
      const existing = rows.items.find(r => r.version === input.version);
      if (existing?.archived || (existing && existing.status !== "draft" && existing.status !== "active"))
        throw new Error("This version is retired or archived. Review its history before proceeding.");
      const saved = existing ?? await api.create("agent_definitions", input, signal);
      // The server checks the complete canonical definition before publication.
      const result = publish && saved.status === "draft"
        ? await api.lifecycle("agent_definitions", "publish", { id: saved.id, expectedUpdatedAt: saved.updatedAt }, signal)
        : saved;
      setRecord(result); registered();
      setMessage(result.status === "active" ? `${label} v1 is published. Workspace execution still requires its own approval.` : `${label} v1 draft is saved below. Review the definition before publishing.`);
    } catch { setMessage(`Could not register or publish this ${short} version. Refresh the catalogue and check the definition before retrying.`); }
    finally { pending.current = false; setBusy(false); }
  }
  return <section className="panel"><h2>{label} foundation</h2>
    <p>{interaction ? "Register the reviewed client-bound website chat and enquiry implementation. Each website installation remains separately controlled." : "Register the reviewed v1 implementation for decision review, durable waits and internal Research. This does not start campaigns or send messages."}</p>
    <div className="form-actions">
      {record?.status !== "active" && <button disabled={busy || !api} onClick={() => void apply(false)}>{busy ? "Working…" : `Prepare ${short} definition`}</button>}
      {record?.status === "draft" && <button disabled={busy || !api} onClick={() => void apply(true)}>Publish {short} definition</button>}
    </div>{message && <p role="status">{message}</p>}
  </section>;
}
