import { NbaRegistration } from "./nba-registration";
import { MethodologyRegistration } from "./methodology-registration";
import { useCallback, useEffect, useState } from "react";
import { Link, useSearchParams, useLocation } from "react-router-dom";
import { useOperating } from "../../data/operating/context";
import type { GlobalResource } from "../../data/operating/models";
import {
  paginationSchema,
  nextPage,
  previousPage,
} from "../../data/operating/pagination";
import { DataError } from "../../data/gateway";
import { useResource } from "../../data/use-resource";
import { Empty, Loading, Status } from "../ui";
import { areaFor, historicalRegistry } from "./fields";
import { OperatingFailure } from "./feedback";
export function Catalogue({ resource }: { resource: GlobalResource }) {
  const api = useOperating(),
    area = areaFor(resource);
  const [search, setSearch] = useSearchParams();
  const location = useLocation();
  const parsed = paginationSchema.safeParse({
    limit: Number(search.get("limit") ?? 20),
    offset: Number(search.get("offset") ?? 0),
  });
  const limit = parsed.success ? parsed.data.limit : 20,
    offset = parsed.success ? parsed.data.offset : 0;
  const key = search.get("key") ?? "";
  const archived =
    search.get("archived") === "archived" ? "archived" : "active";
  const [filterInput, setFilterInput] = useState(key);
  useEffect(() => setFilterInput(key), [key]);
  const [revision, setRevision] = useState(0);
  const load = useCallback(
    (signal: AbortSignal) => {
      void revision;
      return api
        ? api.list(
            { resource },
            {
              limit,
              offset,
              ...(key ? { key } : {}),
              ...(resource === "agent_definitions" ? { archived } : {}),
            },
            signal,
          )
        : Promise.reject(new DataError("pending"));
    },
    [api, resource, limit, offset, key, revision, archived],
  );
  const result = useResource(load);
  const change = (keyValue: string, pageSize: number, pageOffset = 0) =>
    setSearch({
      ...(keyValue ? { key: keyValue } : {}),
      ...(resource === "agent_definitions" ? { archived } : {}),
      limit: String(pageSize),
      offset: String(pageOffset),
    });
  return (
    <>
      <div className="page-heading">
        <p className="eyebrow">Empress · Platform registry</p>
        <h1>{area.label}</h1>
        <p>{area.description}</p>
      </div>
      {location.state?.deleted && (
        <p role="status">Unused draft deleted. Audit history is retained.</p>
      )}
      {resource === "methodology_availability" && (
        <MethodologyRegistration
          onRegistered={() => setRevision((n) => n + 1)}
        />
      )}
      {resource==="integration_providers"&&<LushaRegistration registered={()=>setRevision(v=>v+1)}/>}
      {resource === "agent_definitions" && <><NbaRegistration registered={() => setRevision(n => n + 1)} /><NbaRegistration interaction registered={() => setRevision(n => n + 1)} /></>}
      <div className="catalogue-toolbar">
        {resource === "agent_definitions" && (
          <label>
            Show definitions
            <select
              value={archived}
              onChange={(e) =>
                setSearch({
                  archived: e.target.value,
                  limit: String(limit),
                  offset: "0",
                  ...(key ? { key } : {}),
                })
              }
            >
              <option value="active">Current</option>
              <option value="archived">Archived</option>
            </select>
          </label>
        )}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            change(filterInput, limit);
          }}
        >
          <label>
            Exact stable key
            <input
              value={filterInput}
              maxLength={64}
              onChange={(e) => setFilterInput(e.target.value)}
            />
          </label>
          <button type="submit" className="button secondary">
            Apply key filter
          </button>
        </form>
        <label>
          Records per page
          <select
            value={limit}
            onChange={(e) => change(key, Number(e.target.value))}
          >
            {[10, 20, 50, 100].map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </label>
        {!historicalRegistry(resource) && (
          <Link className="button" to={`/empress/${area.path}/new`}>
            {resource === "methodology_availability"
              ? "Register methodology availability"
              : `Create ${area.singular}`}
          </Link>
        )}
      </div>
      {result.state === "loading" ? (
        <Loading label={`Loading ${area.label.toLowerCase()}…`} />
      ) : result.state === "error" ? (
        <OperatingFailure
          error={result.error}
          retry={() => setRevision((n) => n + 1)}
        />
      ) : (
        <>
          {result.data.items.length === 0 ? (
            <Empty title={`No ${area.label.toLowerCase()} on this page`}>
              No records matched this page and exact key. Adjust the filter.
            </Empty>
          ) : (
            <ul className="catalogue-list">
              {result.data.items.map((row) => (
                <li key={row.id} className="panel">
                  <div className="card-heading">
                    <span className="eyebrow">
                      {row.key} · v{row.version}
                    </span>
                    <div>
                      <Status>{row.status}</Status>{" "}
                      <Status>{row.availability}</Status>
                    </div>
                  </div>
                  <h2>
                    <Link to={`/empress/${area.path}/${row.id}`}>
                      {row.data.name}
                    </Link>
                  </h2>
                  <p>{row.data.description}</p>
                  {"category" in row.data && (
                    <p>Category: {row.data.category}</p>
                  )}
                  {"job" in row.data && <p>Job: {row.data.job}</p>}
                  {"currency" in row.data && (
                    <p>
                      {row.data.currency} · Effective {row.data.effectiveFrom}
                      {row.data.effectiveUntil
                        ? ` to ${row.data.effectiveUntil}`
                        : " onwards"}
                    </p>
                  )}
                  {"methodology" in row.data && (
                    <p>
                      Implementation: {row.data.name} · v
                      {row.data.methodology.version}
                    </p>
                  )}
                </li>
              ))}
            </ul>
          )}
          <nav className="form-actions" aria-label={`${area.label} pagination`}>
            <button
              type="button"
              className="button secondary"
              disabled={!previousPage(result.data)}
              onClick={() =>
                change(key, limit, previousPage(result.data)!.offset)
              }
            >
              Previous page
            </button>
            <span role="status">
              Page {Math.floor(offset / limit) + 1} · {result.data.items.length}{" "}
              records
            </span>
            <button
              type="button"
              className="button secondary"
              disabled={!nextPage(result.data)}
              onClick={() => change(key, limit, nextPage(result.data)!.offset)}
            >
              Next page
            </button>
          </nav>
        </>
      )}
    </>
  );
}

function LushaRegistration({registered}:{registered:()=>void}) {
 const api=useOperating(),[busy,setBusy]=useState(false),[message,setMessage]=useState("");
 return <section className="panel"><h2>Lusha Research connection</h2><p>Prepare the supported provider definition, then review and publish it in the catalogue. Each client connects their own account.</p><div className="form-actions"><button disabled={busy||!api} onClick={async()=>{if(!api)return;setBusy(true);setMessage("");try{await api.registerLusha(new AbortController().signal);registered();setMessage("Lusha definition is available below. Review the draft and publish it when ready.");}catch{setMessage("Could not prepare the Lusha definition. Refresh the catalogue and retry.");}finally{setBusy(false);}}}>{busy?"Preparing…":"Prepare Lusha definition"}</button></div>{message&&<p role="status">{message}</p>}</section>;
}
