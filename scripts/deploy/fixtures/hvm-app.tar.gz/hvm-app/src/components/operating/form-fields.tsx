import { CurrencySelect } from "../currency-select";
import type { Field } from "./fields";
import { ReferenceLabel, type ReferenceRequest } from "./references";
import {
  moneyInput,
  parseMoney,
  parsePercent,
  percentInput,
  formatMoney,
} from "../../forms/commercial-values";
export type Values = Record<string, unknown>;
export function readPath(value: unknown, path: string): unknown {
  return path
    .split(".")
    .reduce<unknown>(
      (part, key) =>
        part && typeof part === "object" ? (part as Values)[key] : undefined,
      value,
    );
}
export function writePath<T>(value: T, path: string, next: unknown): T {
  const clone = structuredClone(value);
  const keys = path.split(".");
  let parent = clone as Values;
  for (const key of keys.slice(0, -1)) parent = parent[key] as Values;
  parent[keys.at(-1)!] = next;
  return clone;
}
export const fieldId = (path: string) =>
  "operating-" + path.replaceAll(".", "-");
export function toForm(fields: Field[], value: Values): Values {
  const output = structuredClone(value);
  for (const f of fields) {
    const v = value[f.key];
    if (v === undefined) continue;
    if (f.kind === "money")
      output[f.key] = moneyInput(v as number, String(value[f.currencyKey!]));
    if (f.kind === "percent") output[f.key] = percentInput(v as number);
    if (f.kind === "group") output[f.key] = toForm(f.fields!, v as Values);
    if (f.kind === "repeat")
      output[f.key] = (v as Values[]).map((x) => toForm(f.fields!, x));
  }
  return output;
}
export function toPayload(
  fields: Field[],
  value: Values,
  prefix = "data",
  errors: Record<string, string> = {},
): Values {
  const output = structuredClone(value);
  for (const f of fields) {
    const v = value[f.key],
      path = `${prefix}.${f.key}`;
    if (f.optional && (v === "" || v === undefined)) {
      delete output[f.key];
      continue;
    }
    try {
      if (f.kind === "money")
        output[f.key] = parseMoney(String(v), String(value[f.currencyKey!]));
      if (f.kind === "percent") output[f.key] = parsePercent(String(v));
      if (f.kind === "number") output[f.key] = v === "" ? NaN : Number(v);
      if (f.kind === "group" && v !== undefined)
        output[f.key] = toPayload(f.fields!, v as Values, path, errors);
      if (f.kind === "repeat")
        output[f.key] = (v as Values[]).map((x, i) =>
          toPayload(f.fields!, x, `${path}.${i}`, errors),
        );
    } catch (e) {
      errors[path] = e instanceof Error ? e.message : "Invalid value.";
    }
  }
  return output;
}
function displayAmount(value: unknown, currency: unknown) {
  try {
    return formatMoney(
      parseMoney(String(value), String(currency)),
      String(currency),
    );
  } catch {
    return "Enter a valid amount and currency.";
  }
}
export function FormFields({
  fields,
  values,
  errors,
  change,
  choose,
  prefix = "data",
}: {
  fields: Field[];
  values: Values;
  errors: Record<string, string>;
  change: (path: string, value: unknown) => void;
  choose: (request: ReferenceRequest) => void;
  prefix?: string;
}) {
  return (
    <>
      {fields.map((f) => {
        const path = prefix ? `${prefix}.${f.key}` : f.key,
          id = fieldId(path),
          value = readPath(values, path),
          error = errors[path];
        const array = Array.isArray(value) ? value : [];
        const input = {
          id,
          "aria-invalid": !!error,
          "aria-describedby": `${id}-help ${id}-error`,
        };
        const feedback = (
          <>
            <small id={`${id}-help`}>{f.help}</small>
            <span id={`${id}-error`} className="field-error">
              {error}
            </span>
          </>
        );
        if (f.kind === "group")
          return (
            <fieldset key={path} className="field-group" id={id} tabIndex={-1}>
              <legend>{f.label}</legend>
              {feedback}
              {f.optional && (
                <label>
                  <input
                    type="checkbox"
                    checked={value !== undefined}
                    onChange={(e) =>
                      change(
                        path,
                        e.target.checked
                          ? toForm(
                              f.fields!,
                              structuredClone(f.initial) as Values,
                            )
                          : undefined,
                      )
                    }
                  />
                  Include {f.label.toLowerCase()}
                </label>
              )}
              {value !== undefined && (
                <FormFields
                  {...{ fields: f.fields!, values, errors, change, choose }}
                  prefix={path}
                />
              )}
            </fieldset>
          );
        if (
          f.kind === "repeat" ||
          f.kind === "strings" ||
          f.kind === "references"
        )
          return (
            <fieldset key={path} className="field-group" id={id} tabIndex={-1}>
              <legend>{f.label}</legend>
              {feedback}
              <ol className="editor-rows">
                {array.map((item: unknown, i: number) => (
                  <li key={i}>
                    {f.kind === "repeat" ? (
                      <fieldset>
                        <legend>
                          {f.label} {i + 1}
                        </legend>
                        <FormFields
                          {...{
                            fields: f.fields!,
                            values,
                            errors,
                            change,
                            choose,
                          }}
                          prefix={`${path}.${i}`}
                        />
                      </fieldset>
                    ) : f.kind === "references" ? (
                      <ReferenceLabel
                        resource={f.resource!}
                        id={
                          typeof item === "string"
                            ? item
                            : String((item as Values).id)
                        }
                        version={
                          typeof item === "string"
                            ? undefined
                            : Number((item as Values).version)
                        }
                      />
                    ) : (
                      <label>
                        {f.label} {i + 1}
                        <input
                          id={fieldId(`${path}.${i}`)}
                          value={String(item)}
                          maxLength={2000}
                          aria-invalid={!!errors[`${path}.${i}`]}
                          aria-describedby={fieldId(`${path}.${i}`) + "-error"}
                          onChange={(e) =>
                            change(`${path}.${i}`, e.target.value)
                          }
                        />
                        <span
                          className="field-error"
                          id={fieldId(`${path}.${i}`) + "-error"}
                        >
                          {errors[`${path}.${i}`]}
                        </span>
                      </label>
                    )}
                    <button
                      type="button"
                      className="text-button"
                      onClick={() =>
                        change(
                          path,
                          array.filter((_, index) => index !== i),
                        )
                      }
                    >
                      Remove {f.label} {i + 1}
                    </button>
                  </li>
                ))}
              </ol>
              <button
                type="button"
                className="button secondary"
                disabled={array.length >= (f.max ?? 40)}
                onClick={() => {
                  if (f.kind === "references") {
                    // Dependencies/template roles are mutually exclusive selections in this UI.
                    const data = values.data as Values;
                    const linked =
                      f.resource === "agent_definitions"
                        ? [
                            "requiredAgents",
                            "recommendedAgents",
                            "optionalAgents",
                            "compatibleAgents",
                          ].flatMap((key) =>
                            Array.isArray(data[key])
                              ? (data[key] as { id: string }[])
                              : [],
                          )
                        : [];
                    choose({
                      path,
                      resource: f.resource!,
                      idsOnly: f.idsOnly,
                      excluded: [
                        ...array.map((x) =>
                          typeof x === "string" ? x : String((x as Values).id),
                        ),
                        ...linked.map((x) => x.id),
                      ],
                      ...(f.resource === "integration_providers"
                        ? {
                            capability: String(
                              readPath(
                                values,
                                prefix + ".operationalCapability",
                              ) ?? "",
                            ),
                          }
                        : {}),
                    });
                  } else
                    change(path, [
                      ...array,
                      f.kind === "strings"
                        ? ""
                        : toForm(
                            f.fields!,
                            structuredClone(f.initial) as Values,
                          ),
                    ]);
                }}
              >
                Add {f.label}
              </button>
              <small>
                {array.length} / {f.max ?? 40}
              </small>
            </fieldset>
          );
        if (f.kind === "choices")
          return (
            <fieldset key={path} id={id} className="field-group" tabIndex={-1}>
              <legend>{f.label}</legend>
              {feedback}
              <div className="choice-grid">
                {f.options!.map((option) => (
                  <label key={option}>
                    <input
                      type="checkbox"
                      checked={array.includes(option)}
                      onChange={(e) =>
                        change(
                          path,
                          e.target.checked
                            ? [...array, option]
                            : array.filter((x) => x !== option),
                        )
                      }
                    />
                    {option.replaceAll("_", " ")}
                  </label>
                ))}
              </div>
            </fieldset>
          );
        if (f.kind === "checkbox")
          return (
            <div key={path} className="field">
              <label htmlFor={id}>
                <input
                  {...input}
                  type="checkbox"
                  checked={Boolean(value)}
                  onChange={(e) => change(path, e.target.checked)}
                />
                {f.label}
              </label>
              {feedback}
            </div>
          );
        return (
          <div key={path} className="field">
            <label htmlFor={id}>
              {f.label}
              {f.optional ? " (optional)" : ""}
            </label>
            {f.key === "currency" ? (
              <CurrencySelect
                {...input}
                value={String(value ?? "")}
                onChange={(e) => change(path, e.target.value)}
              />
            ) : f.kind === "textarea" ? (
              <textarea
                {...input}
                rows={3}
                maxLength={f.maxLength ?? 2000}
                value={String(value ?? "")}
                onChange={(e) => change(path, e.target.value)}
              />
            ) : f.kind === "select" ? (
              <select
                {...input}
                value={String(value ?? "")}
                onChange={(e) => change(path, e.target.value)}
              >
                {f.options!.map((option) => (
                  <option key={option} value={option}>
                    {option.replaceAll("_", " ")}
                  </option>
                ))}
              </select>
            ) : (
              <input
                {...input}
                type={f.kind === "number" ? "number" : "text"}
                inputMode={
                  f.kind === "money" || f.kind === "percent"
                    ? "decimal"
                    : undefined
                }
                min={f.min}
                max={f.max}
                step="any"
                maxLength={f.maxLength ?? 2000}
                value={String(value ?? "")}
                onChange={(e) => change(path, e.target.value)}
              />
            )}
            {feedback}
            {f.kind === "money" && (
              <small>
                {displayAmount(
                  value,
                  readPath(values, prefix + "." + f.currencyKey),
                )}
              </small>
            )}
          </div>
        );
      })}
    </>
  );
}
