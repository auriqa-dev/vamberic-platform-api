import { useCallback, useEffect, useRef, useState } from "react";
import {
  Link,
  useLocation,
  useNavigate,
  useParams,
  useSearchParams,
} from "react-router-dom";
import { z } from "zod";
import { useOperating } from "../../data/operating/context";
import {
  type GlobalResource,
  type OperatingModels,
} from "../../data/operating/models";
import {
  createSchema,
  globalDataSchemas,
  type CreateDefinition,
} from "../../data/operating/mutations";
import { DataError } from "../../data/gateway";
import { useDraft } from "../../forms/use-draft";
import { NavigationWarning } from "../../forms/navigation-warning";
import { Loading, Status } from "../ui";
import { OperatingFailure } from "./feedback";
import { areaFor, historicalRegistry, initialData, resourceFields, type Field } from "./fields";
import {
  FormFields,
  fieldId,
  readPath,
  toForm,
  toPayload,
  writePath,
  type Values,
} from "./form-fields";
import {
  ReferencePicker,
  ReferenceScope,
  type ReferenceRequest,
} from "./references";
type RecordValue = OperatingModels[GlobalResource];
type Draft = {
  key: string;
  version: number | string;
  availability: string;
  data: Values;
  expectedUpdatedAt?: string;
};
function draftFor(
  resource: GlobalResource,
  record?: RecordValue,
  copy = false,
): Draft {
  return {
    key: record?.key ?? "",
    version: record ? record.version + (copy ? 1 : 0) : 1,
    availability: record?.availability ?? "internal",
    data: toForm(
      resourceFields[resource],
      record?.data ?? structuredClone(initialData[resource]),
    ),
    ...(!copy && record ? { expectedUpdatedAt: record.updatedAt } : {}),
  };
}
export function DefinitionPage({
  resource,
  creating = false,
}: {
  resource: GlobalResource;
  creating?: boolean;
}) {
  const { id } = useParams();
  const [search] = useSearchParams();
  const from = search.get("from") ?? undefined;
  if (creating && historicalRegistry(resource))
    return <p className="notice">This registry is retained for history. New setup is no longer required.</p>;
  return (
    <DefinitionResource
      key={`${resource}:${creating ? "new:" + (from ?? "") : id}`}
      {...{ resource, creating, id, from }}
    />
  );
}
function DefinitionResource({
  resource,
  creating,
  id,
  from,
}: {
  resource: GlobalResource;
  creating: boolean;
  id?: string;
  from?: string;
}) {
  const api = useOperating();
  const [record, setRecord] = useState<RecordValue>();
  const [error, setError] = useState<unknown>();
  const [loading, setLoading] = useState(!creating || !!from);
  const mounted = useRef(true);
  const readController = useRef<AbortController | undefined>(undefined);
  const target = creating ? from : id;
  const refresh = useCallback(async () => {
    if (!target) return;
    readController.current?.abort();
    const controller = new AbortController();
    readController.current = controller;
    setLoading(true);
    try {
      if (!api) throw new DataError("pending");
      const next = await api.detail({ resource }, target, controller.signal);
      if (!controller.signal.aborted && mounted.current) {
        setRecord(next);
        setError(undefined);
      }
    } catch (e) {
      if (!controller.signal.aborted && mounted.current) {
        setError(e);
        if (e instanceof DataError && ["denied", "invalid"].includes(e.code))
          setRecord(undefined);
      }
    } finally {
      if (!controller.signal.aborted && mounted.current) setLoading(false);
    }
  }, [api, resource, target]);
  useEffect(() => {
    mounted.current = true;
    void refresh();
    const onFocus = () => {
      if (document.visibilityState === "visible") void refresh();
    };
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onFocus);
    return () => {
      mounted.current = false;
      readController.current?.abort();
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onFocus);
    };
  }, [refresh]);
  if (!api) return <OperatingFailure error={new DataError("pending")} />;
  if (error instanceof DataError && error.code === "denied")
    return <OperatingFailure error={error} />;
  if ((!creating || from) && !record)
    return error ? (
      <OperatingFailure error={error} retry={() => void refresh()} />
    ) : (
      <Loading label="Loading definition…" />
    );
  return (
    <ReferenceScope>
      <DefinitionEditor
        {...{ resource, creating, record }}
        copied={!!from}
        onDenied={() => {
          setRecord(undefined);
          setError(new DataError("denied"));
        }}
        readError={error}
        refreshing={loading}
        refresh={() => void refresh()}
        accept={setRecord}
      />
    </ReferenceScope>
  );
}
function DefinitionEditor({
  resource,
  creating,
  copied,
  record,
  readError,
  refreshing,
  refresh,
  accept,
  onDenied,
}: {
  resource: GlobalResource;
  creating: boolean;
  copied: boolean;
  record?: RecordValue;
  readError: unknown;
  refreshing: boolean;
  refresh: () => void;
  accept: (record: RecordValue) => void;
  onDenied: () => void;
}) {
  const api = useOperating(),
    area = areaFor(resource),
    navigate = useNavigate(),
    location = useLocation();
  const editor = useDraft(draftFor(resource, record, creating && copied));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<unknown>();
  const [busy, setBusy] = useState(false),
    busyRef = useRef(false);
  const [success, setSuccess] = useState(
    location.state?.saved ? "Draft created. It has not been published." : "",
  );
  const [destination, setDestination] = useState<string>();
  const [review, setReview] = useState<
    "publish" | "retire" | "delete" | "discard"
  >();
  const [removal, setRemoval] = useState<{
    allowed: boolean;
    blockers: string[];
  }>();
  useEffect(() => {
    setRemoval(undefined);
    if (
      resource !== "agent_definitions" ||
      !record ||
      !api ||
      (review !== "delete" && review !== "retire")
    )
      return;
    const abort = new AbortController();
    void api
      .removalReview(record.id, review, abort.signal)
      .then((result) => {
        if (!abort.signal.aborted) setRemoval(result);
      })
      .catch(() => {
        if (!abort.signal.aborted)
          setRemoval({
            allowed: false,
            blockers: ["Could not check dependencies. Cancel and try again."],
          });
      });
    return () => abort.abort();
  }, [resource, record, api, review]);
  const [picker, setPicker] = useState<ReferenceRequest>();
  const lastFocus = useRef<HTMLElement | null>(null);
  const controller = useRef(new AbortController());
  const reviewRef = useRef<HTMLHeadingElement>(null),
    summaryRef = useRef<HTMLDivElement>(null);
  const denied = error instanceof DataError && error.code === "denied";
  const legacyPsu =
    resource === "agent_definitions" &&
    record &&
    "executionImplementation" in record.data &&
    record.data.executionImplementation?.key ===
      "product_service_understanding";
  const historical = historicalRegistry(resource);
  const editable = !historical && (creating || (record?.status === "draft" && !legacyPsu));
  useEffect(() => {
    controller.current = new AbortController();
    return () => controller.current.abort();
  }, []);
  useEffect(() => {
    if (review) reviewRef.current?.focus();
  }, [review]);
  useEffect(() => {
    if (Object.keys(errors).length) summaryRef.current?.focus();
  }, [errors]);
  useEffect(() => {
    if (destination)
      void navigate(destination, {
        replace: true,
        state: creating ? { saved: true } : { deleted: true },
      });
  }, [destination, navigate, creating]);
  const change = (path: string, value: unknown) => {
    editor.edit(writePath(editor.draft, path, value));
    setSuccess("");
  };
  const choose = (request: ReferenceRequest) => {
    lastFocus.current = document.activeElement as HTMLElement;
    setPicker(request);
  };
  useEffect(() => {
    if (!picker) lastFocus.current?.focus();
  }, [picker]);
  const closePicker = () => {
    setPicker(undefined);
  };
  async function mutate(operation: "save" | "publish" | "retire" | "delete") {
    if (busyRef.current || !api) return;
    let payload: CreateDefinition<GlobalResource> | undefined;
    if (operation === "save") {
      const fieldErrors: Record<string, string> = {};
      const data = toPayload(
        resourceFields[resource],
        editor.draft.data,
        "data",
        fieldErrors,
      );
      const parsed = creating
        ? createSchema(resource).safeParse({
            key: editor.draft.key,
            version: Number(editor.draft.version),
            availability: editor.draft.availability,
            data,
          })
        : z.object({ data: globalDataSchemas[resource] }).safeParse({ data });
      if (!parsed.success)
        for (const issue of parsed.error.issues)
          fieldErrors[issue.path.join(".")] = issue.message;
      setErrors(fieldErrors);
      if (Object.keys(fieldErrors).length || !parsed.success) return;
      payload = {
        key: editor.draft.key,
        version: Number(editor.draft.version),
        availability: editor.draft.availability,
        data,
      } as CreateDefinition<GlobalResource>;
    }
    busyRef.current = true;
    setBusy(true);
    setError(undefined);
    setSuccess("");
    try {
      if (!creating && (!record || !editor.draft.expectedUpdatedAt))
        throw new DataError("invalid");
      const controls = {
        id: record?.id ?? "",
        expectedUpdatedAt: editor.draft.expectedUpdatedAt ?? "",
      };
      const saved =
        operation === "save"
          ? creating
            ? await api.create(resource, payload!, controller.current.signal)
            : await api.update(
                resource,
                { ...controls, data: payload!.data },
                controller.current.signal,
              )
          : await api.lifecycle(
              resource,
              operation,
              controls,
              controller.current.signal,
            );
      if (controller.current.signal.aborted) return;
      if (operation === "delete") {
        setDestination(`/empress/${area.path}`);
        return;
      }
      editor.saved(draftFor(resource, saved));
      accept(saved);
      setReview(undefined);
      setErrors({});
      setSuccess(
        operation === "save"
          ? "Changes saved."
          : operation === "publish"
            ? "Definition published."
            : resource === "agent_definitions"
              ? "Definition archived. Its history is retained."
              : "Definition retired. Historical identity is retained.",
      );
      if (creating) setDestination(`/empress/${area.path}/${saved.id}`);
      else refresh();
    } catch (e) {
      if (!controller.current.signal.aborted) {
        setError(e);
        setReview(undefined);
        if (e instanceof DataError && e.code === "denied") onDenied();
        if (e instanceof DataError && e.code === "conflict")
          editor.markConflict();
      }
    } finally {
      if (!controller.current.signal.aborted) {
        busyRef.current = false;
        setBusy(false);
      }
    }
  }
  // A mutation denial removes the whole protected editor rather than retaining its draft.
  if (denied) return <OperatingFailure error={error} />;
  const metadata: Field[] = [
    { key: "key", label: "Stable key", maxLength: 64 },
    { key: "version", label: "Version", kind: "number", min: 1 },
    {
      key: "availability",
      label: "Availability",
      kind: "select",
      options: ["internal", "queens", "experimental"],
    },
  ];
  return (
    <>
      <NavigationWarning dirty={!destination && (editor.dirty || busy)} />
      <Link className="text-link" to={`/empress/${area.path}`}>
        ← {area.label}
      </Link>
      <div className="page-heading">
        <p className="eyebrow">Empress · Platform</p>
        <h1>
          {creating
            ? `${copied ? "New version of" : "Create"} ${area.singular}`
            : record!.data.name}
        </h1>
        <p>{area.description}</p>
      </div>
      {record && !creating && (
        <div className="record-meta">
          <Status>{record.status}</Status>
          <Status>{record.availability}</Status>
          <span>
            {record.key} · v{record.version}
          </span>
          <small>
            {record.id} · Updated {record.updatedAt}
          </small>
          <Link
            to={`/empress/${area.path}?key=${encodeURIComponent(record.key)}`}
          >
            View versions for this key
          </Link>
        </div>
      )}
      {!editable && (
        <p className="notice">
          {historical ? "This record is retained for history. HVM application features do not require Agent setup or commercial approval." : "This version is immutable. Create a new version to change its definition. Historical references keep their original identity."}
        </p>
      )}
      {creating && copied && (
        <p className="notice">
          This creates a separate draft with a new record ID. Review the version
          number; existing versions and references are unchanged.
        </p>
      )}
      {resource === "agent_definitions" && (
        <p className="small">
          Methodology compatibility is governed in Methodologies. Capability IDs
          below refer to existing platform capabilities; the API does not expose
          a global capability selector.
        </p>
      )}
      {resource === "methodology_availability" &&
        record &&
        "methodology" in record.data &&
        record.data.methodology.id ===
          "offermethodology_00000000000000000000000001" &&
        record.data.methodology.version === 1 && (
          <p>
            Code-owned implementation: <strong>Value Equation · v1</strong>
          </p>
        )}
      {readError ? (
        <OperatingFailure error={readError} retry={refresh} />
      ) : null}
      {error ? <OperatingFailure error={error} /> : null}
      {editor.conflict && (
        <div className="notice" role="alert">
          <p>
            The draft is preserved. Reload the server value, then discard to
            adopt that baseline or copy your changes before resolving the
            conflict.
          </p>
          <button type="button" onClick={refresh} disabled={refreshing}>
            Reload server value
          </button>
          <button
            type="button"
            onClick={() => {
              editor.reset();
              setError(undefined);
              setErrors({});
            }}
            disabled={refreshing || busy}
          >
            Adopt loaded server value
          </button>
        </div>
      )}
      {Object.keys(errors).length > 0 && (
        <div role="alert" ref={summaryRef} tabIndex={-1} className="notice">
          <h2>Review these fields</h2>
          <ul>
            {Object.entries(errors).map(([path, message]) => (
              <li key={path}>
                <a href={`#${fieldId(path)}`}>
                  {path.replace(/^data\./, "")} — {message}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}
      <form
        className="operating-form"
        noValidate
        onSubmit={(e) => {
          e.preventDefault();
          void mutate("save");
        }}
      >
        <fieldset disabled={!creating || busy || !!destination || !!picker}>
          <legend>Definition identity</legend>
          <FormFields
            fields={metadata}
            values={editor.draft}
            errors={errors}
            prefix=""
            change={(path, value) => change(path.replace(/^\./, ""), value)}
            choose={choose}
          />
        </fieldset>
        <fieldset
          id={fieldId("data")}
          tabIndex={-1}
          disabled={!editable || busy || !!destination || !!picker}
        >
          <legend>Definition details</legend>
          <FormFields
            fields={resourceFields[resource]}
            values={editor.draft}
            errors={errors}
            change={change}
            choose={choose}
          />
        </fieldset>
        {editable && (
          <div className="form-actions">
            <button
              type="button"
              className="button secondary"
              disabled={busy || (!editor.dirty && !editor.conflict)}
              onClick={() => setReview("discard")}
            >
              Discard changes
            </button>
            <button
              className="button"
              disabled={busy || !!destination || (!creating && editor.conflict)}
            >
              {creating ? "Create draft" : "Save draft"}
            </button>
          </div>
        )}
        <p role="status">
          {busy
            ? "Saving…"
            : editor.dirty
              ? "Unsaved changes"
              : success || (refreshing ? "Refreshing server record…" : "")}
        </p>
      </form>
      {picker && (
        <ReferencePicker
          key={picker.path}
          request={picker}
          onClose={closePicker}
          onPick={(value) => {
            const current = readPath(editor.draft, picker.path) as unknown[];
            change(picker.path, [...current, value]);
            closePicker();
          }}
        />
      )}
      {!creating && (
        <section className="panel">
          <h2>Lifecycle and versions</h2>
          <p>
            {historical ? "Historical references are preserved. Eligible Agent records can be archived after dependency checks." : "Availability is fixed at creation. To change it, create a new version. Publication makes a draft active for its declared audience."}
          </p>
          <div className="form-actions">
            {record!.status === "draft" && !legacyPsu && !historical && (
              <button
                type="button"
                className="button"
                disabled={busy || editor.dirty || editor.conflict}
                onClick={() => setReview("publish")}
              >
                Review publication
              </button>
            )}
            {resource === "agent_definitions" &&
              record!.status === "draft" &&
              !record!.archived && (
                <button
                  type="button"
                  className="button secondary"
                  disabled={busy || editor.dirty || editor.conflict}
                  onClick={() => setReview("delete")}
                >
                  Delete unused draft
                </button>
              )}
            {!record!.archived && (!historical || resource === "agent_definitions") && (
              <button
                type="button"
                className="button secondary"
                disabled={busy || editor.dirty || editor.conflict}
                onClick={() => setReview("retire")}
              >
                {resource === "agent_definitions"
                  ? "Archive"
                  : "Review retirement"}
              </button>
            )}
            {!historical && <Link
              className="button secondary"
              to={`/empress/${area.path}/new?from=${record!.id}`}
            >
              Create new version
            </Link>}
            <button
              type="button"
              className="text-button"
              disabled={busy || refreshing}
              onClick={refresh}
            >
              Refresh record
            </button>
          </div>
        </section>
      )}
      {review && (
        <section className="notice" aria-label="Review action">
          <h2 tabIndex={-1} ref={reviewRef}>
            {review === "publish"
              ? "Publish this version?"
              : review === "retire"
                ? resource === "agent_definitions"
                  ? "Archive this definition?"
                  : "Retire this version?"
                : review === "delete"
                  ? "Delete this unused draft?"
                  : "Discard local changes?"}
          </h2>
          <p>
            {review === "publish"
              ? `This makes ${record?.key} v${record?.version} active with ${record?.availability} availability. Its data will be immutable.`
              : review === "retire"
                ? "This makes the definition unavailable for new configuration. Historical references remain. This does not delete client connections or claim to stop execution."
                : review === "delete"
                  ? "Permanently remove this unused draft. Its audit history will remain. This cannot be undone."
                  : "Replace your local draft with the latest loaded server baseline. This cannot be undone."}
          </p>
          {resource === "agent_definitions" &&
            (review === "delete" || review === "retire") && (
              <div role="status">
                {!removal ? (
                  "Checking dependencies…"
                ) : removal.allowed ? (
                  "No blocking dependencies found. These checks will run again when you confirm."
                ) : (
                  <ul>
                    {removal.blockers.map((message) => (
                      <li key={message}>{message}</li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          <div className="form-actions">
            <button
              type="button"
              className="button"
              disabled={
                busy ||
                (resource === "agent_definitions" &&
                  (review === "delete" || review === "retire") &&
                  !removal?.allowed)
              }
              onClick={() => {
                if (review === "discard") {
                  editor.reset();
                  setErrors({});
                  setError(undefined);
                  setReview(undefined);
                  setSuccess("Changes discarded.");
                } else void mutate(review);
              }}
            >
              Confirm{" "}
              {review === "retire" && resource === "agent_definitions"
                ? "archive"
                : review}
            </button>
            <button
              type="button"
              className="button secondary"
              disabled={busy}
              onClick={() => setReview(undefined)}
            >
              Cancel
            </button>
          </div>
        </section>
      )}
    </>
  );
}
