import { useEffect, useState } from "react";
import { useOperating } from "../../data/operating/context";
import type { OperatingGateway } from "../../data/operating/gateway";
type Method = Awaited<
  ReturnType<OperatingGateway["methodologyCatalogue"]>
>["items"][number];
export function MethodologyRegistration({
  onRegistered,
}: {
  onRegistered: () => void;
}) {
  const api = useOperating();
  const [items, setItems] = useState<Method[]>([]),
    [selected, setSelected] = useState("");
  const [busy, setBusy] = useState(false),
    [message, setMessage] = useState(""),
    [error, setError] = useState("");
  useEffect(() => {
    const c = new AbortController();
    if (api?.methodologyCatalogue)
      void api
        .methodologyCatalogue(c.signal)
        .then((r) => {
          setItems(r.items);
          const last = r.items.at(-1);
          setSelected(last ? last.id + ":" + last.version : "");
        })
        .catch(() => {
          if (!c.signal.aborted)
            setError(
              "The methodology definitions could not be loaded. Reload to retry.",
            );
        });
    return () => c.abort();
  }, [api]);
  const method = items.find((m) => m.id + ":" + m.version === selected);
  return (
    <section
      className="panel methodology-registration"
      aria-label="Available methodology definitions"
    >
      <h2>Register a methodology</h2>
      <p>
        Published definitions are immutable. Manage availability and catalogue
        versions below; existing offers keep their original version.
      </p>
      <label className="offer-field">
        Methodology
        <select
          value={selected}
          disabled={busy}
          onChange={(e) => {
            setSelected(e.target.value);
            setMessage("");
          }}
        >
          {items.map((m) => (
            <option key={m.id + ":" + m.version} value={m.id + ":" + m.version}>
              {m.name} v{m.version}.0
            </option>
          ))}
        </select>
      </label>
      {method && (
        <>
          <p>{method.description}</p>
          <details>
            <summary>Review the {method.stages.length} stages</summary>
            {method.stages.map((s) => (
              <section key={s.key}>
                <h3>{s.name}</h3>
                <p>{s.purpose}</p>
                {(
                  [
                    ["Required context", s.requiredContext],
                    ["Analysis", s.analysisRequirements],
                    [
                      "Structured outputs",
                      s.expectedOutputs?.map((o) => o.description),
                    ],
                    ["Validation decisions", s.validationDecisions],
                    ["Completion criteria", s.completionCriteria],
                  ] as [string, string[] | undefined][]
                ).map(([title, values]) =>
                  values?.length ? (
                    <div key={title}>
                      <h4>{title}</h4>
                      <ul>
                        {values.map((v) => (
                          <li key={v}>{v}</li>
                        ))}
                      </ul>
                    </div>
                  ) : null,
                )}
              </section>
            ))}
          </details>
          <div className="form-actions">
            <button
              disabled={busy || method.persisted}
              onClick={async () => {
                if (!api || busy) return;
                setBusy(true);
                setError("");
                setMessage("");
                try {
                  await api.registerMethodology(
                    method.id,
                    method.version,
                    new AbortController().signal,
                  );
                  const read = await api.methodologyCatalogue(
                    new AbortController().signal,
                  );
                  setItems(read.items);
                  onRegistered();
                  if (
                    !read.items.find(
                      (m) => m.id === method.id && m.version === method.version,
                    )?.persisted
                  )
                    throw new Error();
                  setMessage(
                    "Methodology registered and its complete versioned definition verified in Hive.",
                  );
                } catch {
                  setError(
                    "Registration could not be verified. Existing records are preserved; retry to check or complete registration.",
                  );
                } finally {
                  setBusy(false);
                }
              }}
            >
              {busy
                ? "Registering…"
                : method.persisted
                  ? "Definition registered"
                  : "Register and publish"}
            </button>
          </div>
        </>
      )}
      {message && <p role="status">{message}</p>}
      {error && <p role="alert">{error}</p>}
    </section>
  );
}
