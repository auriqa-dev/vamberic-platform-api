import { useEffect, useRef, useState } from "react";
import type {
  ConsumerFacts,
  ConsumerFactsGateway,
  ConsumerFactsRecord,
} from "../data/consumer-facts";
const empty = (): ConsumerFacts => ({
  country: "",
  region: "",
  needs: [],
  interests: [],
  purchaseStage: "",
  source: "",
  observedOn: "",
});
export function ConsumerCharacteristics({
  api,
  w,
  personId,
  canWrite,
}: {
  api?: ConsumerFactsGateway;
  w: string;
  personId: string;
  canWrite: boolean;
}) {
  const [row, setRow] = useState<ConsumerFactsRecord>(null),
    [facts, setFacts] = useState(empty),
    [editing, setEditing] = useState(false),
    [busy, setBusy] = useState(false),
    [loaded, setLoaded] = useState(false),
    [error, setError] = useState("");
  const lock = useRef(false);
  useEffect(() => {
    const c = new AbortController();
    api
      ?.read(w, personId, c.signal)
      .then((r) => {
        if (!c.signal.aborted) {
          setRow(r);
          setFacts(r?.facts ?? empty());
          setLoaded(true);
        }
      })
      .catch(() => {
        if (!c.signal.aborted)
          setError(
            "Consumer details could not be loaded. Reopen the contact to try again.",
          );
      });
    return () => c.abort();
  }, [api, w, personId]);
  if (!api) return null;
  const fields = {
    country: "Country",
    region: "Region",
    needs: "Recorded needs",
    interests: "Recorded interests",
  } as const;
  async function save(next: ConsumerFacts | null) {
    if (lock.current || !loaded) return;
    lock.current = true;
    setBusy(true);
    setError("");
    try {
      const saved = await api!.save(
        w,
        personId,
        row?.updatedAt ?? null,
        next,
        new AbortController().signal,
      );
      setRow(saved);
      setFacts(saved?.facts ?? empty());
      setEditing(false);
    } catch {
      setError(
        "These details could not be saved. Check the source and date; if another person changed the record, reopen it before retrying.",
      );
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  return (
    <section className="panel research-library">
      <h3>Consumer characteristics</h3>
      <p>
        Record what this person has told you or what a permitted source
        establishes. Do not infer sensitive traits or copy their employer’s
        characteristics. These details do not grant permission to contact them.
      </p>
      {error && <p role="alert">{error}</p>}
      {!loaded && !error && <p role="status">Loading consumer details…</p>}
      {editing ? (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void save(facts);
          }}
        >
          <fieldset disabled={busy}>
            <div className="research-grid">
              {Object.entries(fields).map(([key, label]) => (
                <label key={key} className="offer-field">
                  {label}
                  {key === "needs" || key === "interests" ? (
                    <textarea
                      rows={3}
                      value={facts[key].join("\n")}
                      onChange={(e) =>
                        setFacts({
                          ...facts,
                          [key]: e.target.value.split("\n"),
                        })
                      }
                      onBlur={() =>
                        setFacts((f) => ({
                          ...f,
                          [key]: [
                            ...new Set(
                              f[key].map((v) => v.trim()).filter(Boolean),
                            ),
                          ],
                        }))
                      }
                      placeholder="One item per line"
                    />
                  ) : (
                    <input
                      maxLength={key === "country" ? 100 : 150}
                      value={facts[key as "country" | "region"]}
                      onChange={(e) =>
                        setFacts({ ...facts, [key]: e.target.value })
                      }
                    />
                  )}
                </label>
              ))}
              <label className="offer-field">
                Purchase stage
                <select
                  value={facts.purchaseStage}
                  onChange={(e) =>
                    setFacts({
                      ...facts,
                      purchaseStage: e.target
                        .value as ConsumerFacts["purchaseStage"],
                    })
                  }
                >
                  <option value="">Not recorded</option>
                  <option value="exploring">Exploring</option>
                  <option value="comparing">Comparing options</option>
                  <option value="ready_to_buy">Ready to buy</option>
                  <option value="existing_customer">Existing customer</option>
                </select>
              </label>
              <label className="offer-field">
                Observation date
                <input
                  type="date"
                  required
                  max={new Date().toISOString().slice(0, 10)}
                  value={facts.observedOn}
                  onChange={(e) =>
                    setFacts({ ...facts, observedOn: e.target.value })
                  }
                />
              </label>
            </div>
            <label className="offer-field">
              Source
              <textarea
                required
                rows={2}
                maxLength={1000}
                value={facts.source}
                onChange={(e) => setFacts({ ...facts, source: e.target.value })}
                placeholder="For example: customer interview on 9 October; record the source, not assumptions"
              />
            </label>
            <div className="research-actions">
              <button
                type="button"
                onClick={() => {
                  setFacts(row?.facts ?? empty());
                  setEditing(false);
                }}
              >
                Cancel
              </button>
              <button className="button-primary" type="submit">
                {busy ? "Saving…" : "Save characteristics"}
              </button>
            </div>
          </fieldset>
        </form>
      ) : (
        <>
          {row?.facts ? (
            <dl className="research-grid">
              {Object.entries({
                ...fields,
                purchaseStage: "Purchase stage",
                observedOn: "Observation date",
                source: "Source",
              }).map(([key, label]) => {
                const value = row.facts![key as keyof ConsumerFacts];
                return (
                  <div key={key}>
                    <dt>{label}</dt>
                    <dd>
                      {Array.isArray(value)
                        ? value.join(", ") || "Not recorded"
                        : value.replaceAll("_", " ") || "Not recorded"}
                    </dd>
                  </div>
                );
              })}
            </dl>
          ) : (
            loaded && <p>No consumer characteristics recorded.</p>
          )}
          {canWrite && loaded && (
            <div className="research-actions">
              <button
                type="button"
                disabled={busy}
                onClick={() => setEditing(true)}
              >
                {row?.facts ? "Edit characteristics" : "Add characteristics"}
              </button>
              {row?.facts && (
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => {
                    if (
                      window.confirm(
                        "Delete current consumer characteristics? Historical changes remain in the audit trail.",
                      )
                    )
                      void save(null);
                  }}
                >
                  Delete characteristics
                </button>
              )}
            </div>
          )}
        </>
      )}
    </section>
  );
}
