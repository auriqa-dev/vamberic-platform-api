import { useEffect, useRef, useState } from "react";
import type { IcpGateway } from "../data/icp";
import type { DiscoveryResult } from "../data/icp-eligibility";
export function IcpDiscovery({
  api,
  w,
  policyId,
}: {
  api: IcpGateway;
  w: string;
  policyId: string;
}) {
  const [query, setQuery] = useState(""),
    [confirmed, setConfirmed] = useState(false),
    [job, setJob] = useState<DiscoveryResult>(),
    [error, setError] = useState(""),
    [starting, setStarting] = useState(false);
  const key = useRef(crypto.randomUUID()),
    lock = useRef(false);
  useEffect(() => {
    const c = new AbortController();
    api
      .discoveryLatest?.(w, policyId, c.signal)
      .then((result) => {
        if (!c.signal.aborted && result) setJob(result);
      })
      .catch(() => {
        if (!c.signal.aborted)
          setError(
            "Previous research could not be recovered. Reopen this policy before starting another search.",
          );
      });
    return () => c.abort();
  }, [api, w, policyId]);
  useEffect(() => {
    if (!job || job.status !== "searching" || !api.discovery) return;
    const controller = new AbortController();
    const timer = setTimeout(() => {
      api.discovery!(w, job.id, controller.signal)
        .then((r) => {
          if (!controller.signal.aborted) { setJob(r); setError(""); }
        })
        .catch(() => {
          if (!controller.signal.aborted)
            setError(
              "Research status could not be loaded. Check again shortly.",
            );
        });
    }, 2500);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [api, w, job]);
  if (!api.discover || !api.discovery) return null;
  const busy = starting || job?.status === "searching";
  return (
    <details className="research-library">
      <summary>Discover organisations beyond Hive</summary>
      <p>
        Search public sources for organisations to investigate. These are
        suggestions for review, not qualified customers or permission to contact
        anyone. Nothing is imported into Hive.
      </p>
      <label className="offer-field">
        Public research query
        <textarea
          rows={3}
          maxLength={1500}
          value={query}
          disabled={busy}
          placeholder="For example: UK manufacturers reporting energy-efficiency investment plans"
          onChange={(e) => {
            setQuery(e.target.value);
            setConfirmed(false);
            key.current = crypto.randomUUID();
            setError("");
          }}
        />
      </label>
      <label className="offer-check">
        <input
          type="checkbox"
          checked={confirmed}
          disabled={busy}
          onChange={(e) => setConfirmed(e.target.checked)}
        />
        This query contains only information suitable for public web search.
      </label>
      <div className="research-actions">
        <button
          type="button"
          disabled={busy || !confirmed || query.trim().length < 10}
          onClick={async () => {
            if (lock.current) return;
            lock.current = true;
            setStarting(true);
            setError("");
            setJob(undefined);
            try {
              setJob(
                await api.discover!(
                  w,
                  {
                    requestKey: key.current,
                    policyId,
                    query,
                    publicQueryConfirmed: true,
                  },
                  new AbortController().signal,
                ),
              );
            } catch {
              setError(
                "Research could not start. Check the current approved policy and try again.",
              );
            } finally {
              lock.current = false;
              setStarting(false);
            }
          }}
        >
          {busy ? "Researching public sources…" : "Find organisations"}
        </button>
        {job?.status === "searching" && error && (
          <button
            type="button"
            onClick={() => {
              setError("");
              setJob({ ...job });
            }}
          >
            Check progress
          </button>
        )}
      </div>
      {error && <p role="alert">{error}</p>}
      {job?.stale && (
        <p role="status">
          The policy or its approved sources changed. Review these suggestions
          against the current policy before using them.
        </p>
      )}
      {job && ["failed", "interrupted"].includes(job.status) && (
        <p role="alert">
          Research did not finish. Your Hive records are unchanged.{" "}
          <button
            type="button"
            onClick={() => {
              key.current = crypto.randomUUID();
              setJob(undefined);
              setError("");
            }}
          >
            Prepare another attempt
          </button>
        </p>
      )}
      {job?.status === "review" && (
        <div aria-live="polite">
          {!job.candidates?.length && (
            <p>
              No sufficiently sourced organisations were found. Try a more
              specific query.
            </p>
          )}
          {Boolean(job.omitted) && (
            <p>
              Some suggestions lacked usable source references and were left
              out.
            </p>
          )}
          {job.candidates?.map((c) => (
            <article className="research-row" key={c.website}>
              <h3>
                <a href={c.website} target="_blank" rel="noopener noreferrer">
                  {c.name}
                </a>
              </h3>
              <p>{c.observation}</p>
              <p className="muted">To check: {c.uncertainty}</p>
              <a href={c.sourceUrl} target="_blank" rel="noopener noreferrer">
                Read the source
              </a>
            </article>
          ))}
          <div className="research-actions">
            <button
              type="button"
              onClick={() => {
                key.current = crypto.randomUUID();
                setJob(undefined);
              }}
            >
              New search
            </button>
          </div>
        </div>
      )}
    </details>
  );
}
