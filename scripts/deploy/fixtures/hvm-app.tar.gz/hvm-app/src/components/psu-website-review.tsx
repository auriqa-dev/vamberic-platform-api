import { useHenryBinding } from "./workspace-henry";
import { type ReactNode, useContext, useEffect, useRef, useState } from "react";
import { type WebsiteReview, type ReviewField } from "../data/psu-website";
import { productGroups, fullWidthProductFields } from "./psu-understanding";
import { Failure } from "./ui";
import { CompanyReferenceContext } from "../data/company-reference";
const listFields = new Set([
  "secondaryOfferingTypes",
  "deliveryModes",
  "capabilities",
  "deliverables",
  "problemsSolved",
  "desiredOutcomes",
  "differentiators",
  "purchaseConsiderations",
  "buyerNextSteps",
  "industriesServed",
  "regionsServed",
  "competitors",
  "boundaries",
  "explicitExclusions",
  "approvedTerminology",
  "avoidTerminology",
  "approvedClaims",
  "proofPoints",
  "regulatoryContext",
  "unknowns",
]);

const offeringTypes = [
  "software",
  "installed_technology",
  "physical_product",
  "professional_service",
  "managed_service",
  "outsourced_operation",
  "infrastructure_engineering_service",
  "legal_advisory_service",
  "insurance_financial_product",
  "subscription_media",
  "hybrid",
  "other",
  "unknown",
];
const choices: Record<string, string[]> = {
  technologyRole: [
    "the_offering",
    "core_component",
    "delivery_enabler",
    "internal_only",
    "not_material",
    "unknown",
  ],
  primaryOfferingType: offeringTypes,
  secondaryOfferingTypes: offeringTypes,
  deliveryModes: [
    "digital_self_service",
    "digitally_assisted",
    "installed_deployed",
    "physical_delivery",
    "on_site_service",
    "remote_service",
    "people_led_advisory",
    "managed_outsourced",
    "project_based",
    "ongoing_subscription",
    "hybrid",
    "other",
    "unknown",
  ],
  implementationModel: [
    "customer_implementation",
    "supplier_led_implementation",
    "supplier_mobilisation",
    "light_configuration",
    "no_implementation",
    "other",
    "unknown",
  ],
};
export function ProductReview({
  draft,
  onSave,
  onChanged,
  researching = false,
  editing = false,
  company = false,
  competitorSuggestions = [],
  headerAction,
}: {
  draft: WebsiteReview;
  onSave: (rows: ReviewField[], signal: AbortSignal) => Promise<unknown>;
  onChanged: () => void;
  researching?: boolean;
  editing?: boolean;
  company?: boolean;
  competitorSuggestions?: string[];
  headerAction?: ReactNode;
}) {
  const { industries: industryOptions, regions: marketOptions } = useContext(
    CompanyReferenceContext,
  );
  const [rows, setRows] = useState<ReviewField[]>(() => [
    ...draft.fields.map((f) => ({ binding: f.binding, included: true })),
    ...(company
      ? [
          "name",
          "brandName",
          "websiteUrl",
          "description",
          "valueProposition",
          "businessModel",
          "industriesServed",
          "regionsServed",
          "competitors",
        ]
      : [
          "name",
          "description",
          "websiteUrl",
          "businessModel",
          "differentiators",
          "engagementModel",
          "valueProposition",
          "industriesServed",
          "regionsServed",
          "problemsSolved",
          "competitors",
        ]
    )
      .filter((field) => !draft.fields.some((f) => f.binding.field === field))
      .map((field) => ({
        binding: { field, value: listFields.has(field) ? [] : "" },
        included: (company
          ? ["name", "brandName", "description"]
          : ["name", "description"]
        ).includes(field),
      })),
  ]);
  const [confirmed, setConfirmed] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState<unknown>(),
    [add, setAdd] = useState("");
  const pending = useRef<AbortController | undefined>(undefined);
  useEffect(() => () => pending.current?.abort(), []);
  const touched = useRef(new Set<string>());
  const revision = useRef(draft.digest);
  useEffect(() => {
    if (revision.current === draft.digest) return;
    revision.current = draft.digest;
    setRows(current => {
      const incoming = new Map(draft.fields.map(f => [f.binding.field, {binding:f.binding,included:true}]));
      const merged = current.map(row => touched.current.has(row.binding.field) ? row : incoming.get(row.binding.field) ?? row);
      return [...merged, ...[...incoming.values()].filter(row => !current.some(r => r.binding.field === row.binding.field))];
    });
    setConfirmed(false);
  }, [draft]);
  const change = (next: ReviewField[]) => {
    for (const row of next) if (JSON.stringify(row) !== JSON.stringify(rows.find(r => r.binding.field === row.binding.field))) touched.current.add(row.binding.field);
    setRows(next);
    setConfirmed(false);
  };
  const sections = company ? companyGroups : productGroups;
  const labels = sections.flatMap(([, fs]) => fs);
  useHenryBinding({priority:100,key:company?"company-review":"product-review", summary:JSON.stringify({task:company?"Reviewing company details":"Reviewing product details",researching,approval:"not_approved"}),
    editor:!busy?{key:`psu-review:${company}:${draft.digest}`,title:company?"Company details":"Product details",fields:rows.map(r=>({key:r.binding.field,label:labels.find(([key])=>key===r.binding.field)?.[1]??r.binding.field,value:JSON.stringify(r.binding.value)}))}:undefined,
    apply:changes=>{change(rows.map(r=>{const c=changes.find(c=>c.key===r.binding.field);if(!c)return r;const value=JSON.parse(c.value);if(!(typeof value==="string"||Array.isArray(value)&&value.every(v=>typeof v==="string")))throw new Error("Use text or a list of text for these fields.");return {...r,included:true,binding:{...r.binding,value}};}));},
  });
  return (
    <form
      className={`panel psu-understanding psu-review${company ? " psu-company-review" : " psu-product-review"}`}
      onSubmit={async (e) => {
        e.preventDefault();
        if (researching || !confirmed || pending.current) return;
        const c = new AbortController();
        pending.current = c;
        setBusy(true);
        setError(undefined);
        try {
          await onSave(rows, c.signal);
          if (!c.signal.aborted) onChanged();
        } catch (e) {
          if (!c.signal.aborted) setError(e);
        } finally {
          pending.current = undefined;
          if (!c.signal.aborted) setBusy(false);
        }
      }}
    >
      <div className="profile-card-heading">
        <h2>{company ? "Review your company" : "Review your product or service"}</h2>
        {headerAction}
      </div>
      {!researching && !editing && !draft.fields.some(({ binding }) =>
        binding.field === "description" && typeof binding.value === "string" && binding.value.trim(),
      ) && (
        <p role="status">
          Generation has finished, but the summary is incomplete: no description was returned.
          The available details are shown below. You can add the description before saving,
          or use Generate Summary to try again. Your approved details have not changed.
        </p>
      )}
      {researching && <p role="status">Henry is still researching. You can edit these early suggestions; your edits will be kept as more details arrive. Save your review when research finishes.</p>}
      <p>
        {editing
          ? (company && !draft.fields.length ? "Enter your company details below and save your draft. Approval is a separate step." : "Edit the details below and save your draft. The approved version stays active until you approve this revision.")
          : "These are suggested details based on your website, not independently verified facts. You can add missing details below. Check these suggestions against your business. Edit anything that is wrong, add missing details and exclude anything you cannot confirm. Saving creates a draft; approval is a separate step."}
      </p>
      <fieldset disabled={busy}>
        <legend className="sr-only">Suggested details</legend>
        {sections.map(([title, fields]) => {
          const included = rows.filter((r) =>
            fields.some(([key]) => key === r.binding.field),
          );
          return included.length ? (
            <section key={title}>
              <h3>{title}</h3>
              {included.map((row) => {
                const isList = listFields.has(row.binding.field);
                return (
                  <div
                    className={`psu-review-field${!company && fullWidthProductFields.has(row.binding.field) ? " psu-product-wide" : ""}`}
                    key={row.binding.field}
                  >
                    <div className="psu-review-value">
                      <span>
                        {labels.find(
                          ([key]) => key === row.binding.field,
                        )?.[1] ?? row.binding.field}
                      </span>
                      {["industriesServed", "regionsServed"].includes(
                        row.binding.field,
                      ) ? (
                        <ReferenceList
                          label={
                            row.binding.field === "industriesServed"
                              ? "industry"
                              : "market or region"
                          }
                          options={
                            row.binding.field === "industriesServed"
                              ? industryOptions
                              : marketOptions
                          }
                          values={
                            Array.isArray(row.binding.value)
                              ? row.binding.value
                              : []
                          }
                          onChange={(value) =>
                            change(
                              rows.map((r) =>
                                r === row
                                  ? {
                                      ...r,
                                      included: value.length > 0,
                                      binding: { ...r.binding, value },
                                    }
                                  : r,
                              ),
                            )
                          }
                        />
                      ) : (
                          company && row.binding.field === "businessModel"
                            ? ["B2B", "B2C", "D2C", "Mixed", "Unknown"]
                            : choices[row.binding.field]
                        ) ? (
                        <select
                          aria-label={
                            labels.find(
                              ([key]) => key === row.binding.field,
                            )?.[1] ?? row.binding.field
                          }
                          multiple={isList}
                          value={row.binding.value}
                          onChange={(e) =>
                            change(
                              rows.map((r) =>
                                r === row
                                  ? {
                                      ...r,
                                      included: true,
                                      binding: {
                                        ...r.binding,
                                        value: isList
                                          ? Array.from(
                                              e.target.selectedOptions,
                                              (o) => o.value,
                                            )
                                          : e.target.value,
                                      },
                                    }
                                  : r,
                              ),
                            )
                          }
                        >
                          {!isList && <option value="">Choose a value</option>}
                          {(company && row.binding.field === "businessModel"
                            ? ["B2B", "B2C", "D2C", "Mixed", "Unknown"]
                            : choices[row.binding.field]!
                          ).map((v) => (
                            <option key={v} value={v}>
                              {v.replaceAll("_", " ")}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <textarea
                          aria-label={
                            labels.find(
                              ([key]) => key === row.binding.field,
                            )?.[1] ?? row.binding.field
                          }
                          rows={
                            !company
                              ? [
                                  "name",
                                  "websiteUrl",
                                  "businessModel",
                                ].includes(row.binding.field)
                                ? 1
                                : 3
                              : isList
                                ? 4
                                : ["name", "brandName", "websiteUrl"].includes(
                                      row.binding.field,
                                    )
                                  ? 1
                                  : 5
                          }
                          maxLength={row.binding.field === "name" ? 200 : 10000}
                          value={
                            Array.isArray(row.binding.value)
                              ? row.binding.value.join("\n")
                              : row.binding.value
                          }
                          onChange={(e) =>
                            change(
                              rows.map((r) =>
                                r === row
                                  ? {
                                      ...r,
                                      included: true,
                                      binding: {
                                        ...r.binding,
                                        value: isList
                                          ? e.target.value.split("\n")
                                          : e.target.value,
                                      },
                                    }
                                  : r,
                              ),
                            )
                          }
                          onBlur={() =>
                            change(
                              rows.map((r) =>
                                r === row
                                  ? {
                                      ...r,
                                      included:
                                        r.included &&
                                        (Array.isArray(r.binding.value)
                                          ? r.binding.value.some((v) =>
                                              v.trim(),
                                            )
                                          : !!r.binding.value.trim()),
                                      binding: {
                                        ...r.binding,
                                        value: Array.isArray(r.binding.value)
                                          ? r.binding.value
                                              .map((v) => v.trim())
                                              .filter(Boolean)
                                          : r.binding.value.trim(),
                                      },
                                    }
                                  : r,
                              ),
                            )
                          }
                        />
                      )}
                    </div>
                    {isList &&
                      !choices[row.binding.field] &&
                      !["industriesServed", "regionsServed"].includes(
                        row.binding.field,
                      ) && <small>One item per line.</small>}
                    {row.binding.field === "competitors" &&
                      competitorSuggestions.length > 0 && (
                        <div className="psu-competitor-suggestions">
                          <strong>Suggested competitors — please check</strong>
                          <p>
                            These are AI suggestions, not verified facts from
                            your website. Add only the alternatives you consider
                            competitors.
                          </p>
                          <div className="psu-reference-selected">
                            {competitorSuggestions.map((candidate) => (
                              <button
                                type="button"
                                className="button secondary"
                                key={candidate}
                                disabled={
                                  Array.isArray(row.binding.value) &&
                                  row.binding.value.includes(candidate)
                                }
                                onClick={() =>
                                  change(
                                    rows.map((r) =>
                                      r === row
                                        ? {
                                            ...r,
                                            included: true,
                                            binding: {
                                              ...r.binding,
                                              value: [
                                                ...(Array.isArray(
                                                  r.binding.value,
                                                )
                                                  ? r.binding.value
                                                  : []),
                                                candidate,
                                              ],
                                            },
                                          }
                                        : r,
                                    ),
                                  )
                                }
                              >
                                Add {candidate}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    <label className="psu-review-check">
                      <input
                        type="checkbox"
                        checked={row.included}
                        onChange={(e) =>
                          change(
                            rows.map((r) =>
                              r === row
                                ? { ...r, included: e.target.checked }
                                : r,
                            ),
                          )
                        }
                      />
                      Include in my reviewed details
                    </label>
                  </div>
                );
              })}
            </section>
          ) : null;
        })}
        {!researching && draft.unknowns.length > 0 && (
          <section>
            <h3>What we could not establish</h3>
            <ul>
              {draft.unknowns.map((u, i) => (
                <li key={i}>{u}</li>
              ))}
            </ul>
          </section>
        )}
        {!researching && draft.questions.length > 0 && (
          <details className="psu-optional-questions">
            <summary>Optional points to check</summary>
            <p>
              You can leave these unresolved. If you know an answer, update the
              matching detail above; you do not need to answer these to save
              your review.
            </p>
            <ul>
              {draft.questions.map((q, i) => (
                <li key={i}>
                  {q.question}
                  <p className="muted">{q.reason}</p>
                </li>
              ))}
            </ul>
            <p>
              Product-specific points can be addressed when you review the
              product’s detailed profile.
            </p>
          </details>
        )}
        {labels.some(([key]) => !rows.some((r) => r.binding.field === key)) && (
          <div className="psu-review-add">
            <label>
              Add a missing detail
              <select value={add} onChange={(e) => setAdd(e.target.value)}>
                <option value="">Choose a detail</option>
                {labels
                  .filter(([key]) => !rows.some((r) => r.binding.field === key))
                  .map(([key, label]) => (
                    <option key={key} value={key}>
                      {label}
                    </option>
                  ))}
              </select>
            </label>
            <button
              type="button"
              disabled={!add}
              onClick={() => {
                change([
                  ...rows,
                  {
                    binding: {
                      field: add,
                      value: listFields.has(add) ? [] : "",
                    },
                    included: true,
                  },
                ]);
                setAdd("");
              }}
            >
              Add detail
            </button>
          </div>
        )}
        <label className="psu-review-check psu-review-confirm">
          <input
            type="checkbox"
            checked={confirmed}
            onChange={(e) => setConfirmed(e.target.checked)}
          />
          I have reviewed the included details and want to save them.
        </label>
      </fieldset>
      <p>
        {company
          ? "Company name, brand name and description are required. Website is optional."
          : "Name and summary are required."}{" "}
        Approval is a separate step.
      </p>
      <button
        className="button"
        disabled={
          researching ||
          busy ||
          !confirmed ||
          !(
            company
              ? ["name", "brandName", "description"]
              : ["name", "description"]
          ).every((field) =>
            rows.some(
              (r) =>
                r.binding.field === field &&
                r.included &&
                typeof r.binding.value === "string" &&
                r.binding.value.trim(),
            ),
          ) ||
          rows.some(
            (r) =>
              r.included &&
              (Array.isArray(r.binding.value)
                ? r.binding.value.some((v) => !v.trim())
                : !r.binding.value.trim()),
          )
        }
      >
        {busy ? "Saving…" : "Save draft"}
      </button>
      {error ? <Failure error={error} /> : null}
    </form>
  );
}

export const companyGroups: [string, [string, string][]][] = [
  [
    "Company details",
    [
      ["name", "Company name"],
      ["brandName", "Brand name"],
      ["websiteUrl", "Company website"],
      ["description", "Company description"],
      ["valueProposition", "Value proposition"],
      ["businessModel", "Business model"],
    ],
  ],
  [
    "Markets and competitors",
    [
      ["industriesServed", "Industries"],
      ["regionsServed", "Markets and regions"],
      ["competitors", "Competitor companies"],
    ],
  ],
];

function ReferenceList({
  label,
  options,
  values,
  onChange,
}: {
  label: string;
  options: readonly string[];
  values: string[];
  onChange: (values: string[]) => void;
}) {
  const [custom, setCustom] = useState("");
  const [addingCustom, setAddingCustom] = useState(false);
  const add = (value: string) => {
    const trimmed = value.trim();
    if (
      trimmed &&
      !values.some((v) => v.toLowerCase() === trimmed.toLowerCase())
    )
      onChange([...values, trimmed]);
  };
  return (
    <span className="psu-reference-list">
      <span className="psu-reference-selected">
        {values.map((value) => (
          <span key={value}>
            {value}
            <button
              type="button"
              aria-label={`Remove ${value}`}
              onClick={() => onChange(values.filter((v) => v !== value))}
            >
              ×
            </button>
          </span>
        ))}
      </span>
      <select
        aria-label={`Add ${label}`}
        value=""
        onChange={(e) => {
          if (e.target.value === "__custom") setAddingCustom(true);
          else add(e.target.value);
        }}
      >
        <option value="">{`Select ${label}…`}</option>
        {options
          .filter((value) => !values.includes(value))
          .map((value) => (
            <option key={value} value={value}>
              {value}
            </option>
          ))}
        <option value="__custom">Add another…</option>
      </select>
      {addingCustom && (
        <span className="psu-reference-custom">
          <input
            aria-label={`Other ${label}`}
            value={custom}
            maxLength={1000}
            onChange={(e) => setCustom(e.target.value)}
          />
          <button
            type="button"
            disabled={!custom.trim()}
            onClick={() => {
              add(custom);
              setCustom("");
              setAddingCustom(false);
            }}
          >
            Add
          </button>
        </span>
      )}
    </span>
  );
}
