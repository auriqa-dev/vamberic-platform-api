import { useRef, useState } from "react";
import type { PsuGateway, ProfileDeletionPreview } from "../data/psu";
import { Failure } from "./ui";
export function ProfileDelete({
  api,
  w,
  kind,
  id,
  name,
  onDeleted,
}: {
  api: PsuGateway;
  w: string;
  kind: "company" | "product" | "generation" | "product-draft";
  id: string;
  name: string;
  onDeleted: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [preview, setPreview] = useState<ProfileDeletionPreview>();
  const [busy, setBusy] = useState(false),
    [error, setError] = useState<unknown>(),
    [confirmation, setConfirmation] = useState("");
  async function open() {
    setPreview(undefined);
    setConfirmation("");
    setError(undefined);
    setBusy(true);
    dialog.current?.showModal();
    try {
      setPreview(
        await api.deletionPreview(w, kind, id, new AbortController().signal),
      );
    } catch (e) {
      setError(e);
    } finally {
      setBusy(false);
    }
  }
  async function remove() {
    if (!preview || busy) return;
    setBusy(true);
    setError(undefined);
    try {
      await api.deleteProfile(
        w,
        preview,
        kind === "company" ? confirmation : "DELETE",
        new AbortController().signal,
      );
      dialog.current?.close();
      onDeleted();
    } catch (e) {
      setError(e);
      setPreview(undefined);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <button
        type="button"
        aria-label={`Delete ${name}`}
        title={`Permanently delete ${name}`}
        onClick={() => void open()}
      >
        <svg
          aria-hidden="true"
          width="18"
          height="18"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
        >
          <path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7" />
        </svg>{" "}
        Delete
      </button>
      <dialog
        className="profile-delete-dialog"
        ref={dialog}
        aria-label={`Delete ${name}`}
        onCancel={(e) => {
          if (busy) e.preventDefault();
        }}
        style={{
          maxWidth: "38rem",
          width: "calc(100% - 2rem)",
          maxHeight: "85vh",
          overflowY: "auto",
          padding: "1.5rem",
          margin: "auto",
        }}
      >
        <h2>Permanently delete {preview?.name ?? name}?</h2>
        <p>
          {kind === "company"
            ? "This permanently deletes all company versions, its products and services, and their dependent records listed below."
            : "This permanently deletes this product or service, its earlier drafts and versions, and its dependent records listed below. The company and other products remain."}
        </p>
        {busy && (
          <p role="status">
            {preview ? "Deleting…" : "Checking dependent records…"}
          </p>
        )}
        {preview && (
          <>
            <ul>
              {preview.counts.map((c) => (
                <li key={c.collection}>
                  {c.label}: {c.count}
                </li>
              ))}
            </ul>
            <p>
              Your client workspace, Brand Kit, users, billing and unrelated
              contacts and organisations will remain.
            </p>
            {preview.blockers.length > 0 ? (
              <div role="alert">
                <h3>Deletion is blocked</h3>
                {preview.blockers.map((b) => (
                  <p key={b}>{b}</p>
                ))}
              </div>
            ) : (
              kind === "company" && (
                <label
                  className="field"
                  style={{ display: "grid", gap: "0.5rem" }}
                >
                  Type {preview.name} to confirm
                  <input
                    autoComplete="off"
                    value={confirmation}
                    onChange={(e) => setConfirmation(e.target.value)}
                  />
                </label>
              )
            )}
          </>
        )}
        {error ? (
          <>
            <Failure error={error} />
            <p>
              No deletion was confirmed. Close this dialog and refresh before
              trying again.
            </p>
          </>
        ) : null}
        <div
          className="form-actions"
          style={{ marginTop: "1.25rem", gap: "1rem" }}
        >
          <button
            type="button"
            disabled={busy}
            onClick={() => dialog.current?.close()}
          >
            Cancel
          </button>
          <button
            type="button"
            className="button"
            disabled={
              busy ||
              !preview ||
              preview.blockers.length > 0 ||
              (kind === "company" && confirmation !== preview.name)
            }
            onClick={() => void remove()}
          >
            Delete permanently
          </button>
        </div>
      </dialog>
    </>
  );
}
