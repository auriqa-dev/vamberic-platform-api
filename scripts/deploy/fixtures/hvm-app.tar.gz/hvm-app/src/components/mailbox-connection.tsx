import { useCallback, useEffect, useRef, useState } from "react";
import { useResource } from "../data/use-resource";
import type { MailboxGateway, MailboxState } from "../data/mailbox";
import { DataError } from "../data/gateway";
import { Loading, Failure } from "./ui";
import "../styles/mailbox.css";
export function MailboxConnectionCard({
  api,
  workspaceId,
}: {
  api: MailboxGateway;
  workspaceId: string;
}) {
  const [version, setVersion] = useState(0);
  const load = useCallback(
    (signal: AbortSignal) => {
      void version;
      return api.read(workspaceId, signal);
    },
    [api, workspaceId, version],
  );
  const resource = useResource(load);
  return (
    <article className="panel integration-card mailbox-connection">
      <h3>Google Workspace / Gmail</h3>
      <p>
        Connect your client’s mailbox for individual emails and their replies.
      </p>
      {resource.state === "loading" ? (
        <Loading />
      ) : resource.state === "error" ? (
        <Failure error={resource.error} />
      ) : resource.state === "ready" ? (
        <MailboxControls
          key={workspaceId}
          api={api}
          workspaceId={workspaceId}
          initial={resource.data}
          refresh={() => setVersion((v) => v + 1)}
        />
      ) : null}
      <p className="small muted">
        Microsoft 365 support will follow. Connecting a mailbox does not
        activate campaigns.
      </p>
    </article>
  );
}
function MailboxControls({
  api,
  workspaceId,
  initial,
  refresh,
}: {
  api: MailboxGateway;
  workspaceId: string;
  initial: MailboxState;
  refresh: () => void;
}) {
  const [data, setData] = useState(initial),
    [busy, setBusy] = useState(""),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [recipient, setRecipient] = useState(initial.testRecipients[0] ?? ""),
    [confirmed, setConfirmed] = useState(false);
  const noticeKey = `hvm-mailbox-notice:${workspaceId}`;
  const noticeVersion = `${data.updatedAt}:${data.notice}`;
  const [dismissedNotice, setDismissedNotice] = useState(() => {
    try { return sessionStorage.getItem(noticeKey); } catch { return null; }
  });
  function dismissNotice() {
    setDismissedNotice(noticeVersion);
    try { sessionStorage.setItem(noticeKey, noticeVersion); } catch { /* Storage may be unavailable. */ }
  }
  const pending = useRef<{
    popup: Window;
    state: string;
    browserSecret: string;
  } | null>(null);
  const sendId = useRef<string | null>(null);
  const report = (e: unknown) =>
    setError(
      e instanceof DataError && e.userMessage
        ? e.userMessage
        : "The operation could not be completed. Refresh the connection to check its saved status before retrying.",
    );
  const accept = useCallback((next: MailboxState) => {
    setData(next);
    setRecipient((v) =>
      next.testRecipients.includes(v) ? v : (next.testRecipients[0] ?? ""),
    );
  }, []);
  useEffect(() => {
    accept(initial);
  }, [initial, accept]);
  useEffect(() => {
    async function receive(event: MessageEvent) {
      const p = pending.current;
      if (
        !p ||
        event.origin !== window.location.origin ||
        event.source !== p.popup ||
        event.data?.type !== "hvm-mailbox-callback" ||
        event.data.state !== p.state
      )
        return;
      pending.current = null;
      p.popup.close();
      if (event.data.error || typeof event.data.code !== "string") {
        setBusy("");
        setError("Google consent was not completed. Connect again when ready.");
        return;
      }
      try {
        accept(
          await api.change(
            workspaceId,
            "finish",
            {
              state: p.state,
              browserSecret: p.browserSecret,
              code: event.data.code,
            },
            new AbortController().signal,
          ),
        );
        setNotice("Gmail connected. Your saved mailbox is displayed below.");
      } catch (e) {
        report(e);
      } finally {
        setBusy("");
      }
    }
    const handler = (e: MessageEvent) => void receive(e);
    window.addEventListener("message", handler);
    const timer = setInterval(() => {
      if (pending.current?.popup.closed) {
        pending.current = null;
        setBusy("");
        setError("The Google window was closed. Connect again to finish.");
      }
    }, 1000);
    return () => {
      window.removeEventListener("message", handler);
      clearInterval(timer);
      pending.current?.popup.close();
      pending.current = null;
    };
  }, [api, workspaceId, accept]);
  async function connect() {
    dismissNotice();
    const popup = window.open(
      "about:blank",
      "hvm-gmail-connect",
      "width=600,height=760",
    );
    if (!popup) {
      setError("Allow the Google sign-in popup, then try again.");
      return;
    }
    setBusy("Connecting…");
    setError("");
    setNotice("");
    try {
      const result = await api.connect(
        workspaceId,
        new AbortController().signal,
      );
      const url = new URL(result.url);
      if (url.origin !== "https://accounts.google.com")
        throw new Error("Invalid provider");
      pending.current = {
        popup,
        state: result.state,
        browserSecret: result.browserSecret,
      };
      popup.location.assign(url.toString());
    } catch (e) {
      popup.close();
      setBusy("");
      report(e);
    }
  }
  async function action(kind: "test" | "send-test" | "replies" | "disconnect") {
    if (
      kind === "disconnect" &&
      !window.confirm(
        "Disconnect Gmail? HVM will stop sending and checking replies. Existing test history is retained.",
      )
    )
      return;
    setBusy(
      kind === "send-test"
        ? "Sending test…"
        : kind === "replies"
          ? "Checking replies…"
          : "Checking connection…",
    );
    setError("");
    setNotice("");
    if (kind === "send-test") sendId.current ??= crypto.randomUUID();
    try {
      const next = await api.change(
        workspaceId,
        kind,
        kind === "send-test"
          ? {
              operationId: sendId.current,
              recipient,
              controlledInboxConfirmed: confirmed,
            }
          : kind === "disconnect"
            ? { expectedUpdatedAt: data.updatedAt }
            : {},
        new AbortController().signal,
      );
      accept(next);
      if (kind === "send-test") {
        sendId.current = null;
        setConfirmed(false);
        setNotice(
          "Test status is shown below. Accepted means Google accepted it, not confirmed delivery. Reply to the email to test the return journey.",
        );
      } else if (kind === "test")
        setNotice(
          "Google account access checked. Send and reply tests are separate checks.",
        );
      else if (kind === "replies")
        setNotice(
          "Replies checked. If your reply has not arrived yet, check again shortly.",
        );
      else setNotice("Gmail disconnected. Existing history is retained.");
    } catch (e) {
      report(e);
      try {
        accept(await api.read(workspaceId, new AbortController().signal));
      } catch {
        /* Preserve last confirmed state. */
      }
    } finally {
      setBusy("");
    }
  }
  return (
    <div className="mailbox-form">
      {data.status !== "disconnected" && data.status !== "not_connected" && (
        <p role="status">
          <strong>{data.email}</strong> · {data.status.replaceAll("_", " ")}
        </p>
      )}
      {data.status !== "disconnected" && data.notice && dismissedNotice !== noticeVersion && busy !== "Connecting…" && (
        <div className="mailbox-notice">
          <p className="small muted">{data.notice}</p>
          <button type="button" className="secondary" onClick={dismissNotice}>
            Dismiss notice
          </button>
        </div>
      )}
      {!data.available ? (
        <p>
          Google connection setup is required before you can connect. Your
          administrator must configure HVM’s Google OAuth application.
        </p>
      ) : !data.canManage ? (
        <p>A workspace administrator can manage this connection.</p>
      ) : (
        <>
          <p className="small muted">
            Google will ask permission to send email and read messages. HVM only
            imports replies within conversations it starts; it does not import
            your historical inbox.
          </p>
          <div className="form-actions">
            <button
              className="button"
              disabled={!!busy}
              onClick={() => void connect()}
            >
              {data.status === "connected"
                ? "Reconnect Gmail"
                : "Connect Gmail"}
            </button>
            {data.email && data.status !== "disconnected" && (
              <>
                <button
                  className="secondary"
                  disabled={!!busy}
                  onClick={() => void action("test")}
                >
                  Test connection
                </button>
                <button
                  className="secondary"
                  disabled={!!busy}
                  onClick={() => void action("disconnect")}
                >
                  Disconnect
                </button>
              </>
            )}
            <button className="secondary" disabled={!!busy} onClick={() => { dismissNotice(); setError(""); setNotice(""); refresh(); }}>
              Refresh status
            </button>
          </div>
          {data.status === "connected" && (
            <section className="mailbox-test">
              <h4>Test an email and reply</h4>
              <label>
                Controlled test inbox
                <select
                  value={recipient}
                  onChange={(e) => {
                    setRecipient(e.target.value);
                    setConfirmed(false);
                  }}
                  disabled={!!busy}
                >
                  {data.testRecipients.map((r) => (
                    <option key={r}>{r}</option>
                  ))}
                </select>
              </label>
              <p className="small muted">
                The connected mailbox is available by default. Additional test
                addresses must be explicitly configured. No prospect is enrolled
                or contacted.
              </p>
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={confirmed}
                  onChange={(e) => setConfirmed(e.target.checked)}
                  disabled={!!busy}
                />
                I control this inbox and approve sending the connection test.
              </label>
              <div className="form-actions">
                <button
                  className="button"
                  disabled={!!busy || !confirmed || !recipient}
                  onClick={() => void action("send-test")}
                >
                  Send test email
                </button>
                <button
                  className="secondary"
                  disabled={!!busy}
                  onClick={() => void action("replies")}
                >
                  Check replies
                </button>
              </div>
            </section>
          )}
        </>
      )}
      {busy && <p role="status">{busy}</p>}
      {error && <p role="alert">{error}</p>}
      {notice && <p role="status">{notice}</p>}
      {data.email && data.status === "connected" && (
        <section>
          <h4>Mailbox readiness</h4>
          {data.readiness.ready ? (
            <p>
              Send and reply tests have passed. Campaign activation still
              requires its own checks and approval.
            </p>
          ) : (
            <ul>
              {data.readiness.missing.map((m) => (
                <li key={m}>{m}</li>
              ))}
            </ul>
          )}
          {data.lastCheckedAt && (
            <p className="small muted">
              Last checked{" "}
              {new Date(data.lastCheckedAt).toLocaleString("en-GB")}
            </p>
          )}
        </section>
      )}
      {data.status === "connected" && !!data.tests.length && (
        <section>
          <h4>Recent connection tests</h4>
          <ul>
            {data.tests.map((t) => (
              <li key={t.id}>
                {t.recipient} —{" "}
                {t.status === "sending"
                  ? "Submission pending; do not resend"
                  : t.status === "unknown"
                    ? "Outcome unknown; HVM will check Sent Items without resending"
                    : t.status}{" "}
                <span className="small muted">
                  {new Date(t.createdAt).toLocaleString("en-GB")}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}
      {data.status === "connected" && !!data.replies.length && (
        <section>
          <h4>Test replies</h4>
          {data.replies.map((r) => (
            <article className="mailbox-reply" key={r.id}>
              <strong>{r.subject}</strong>
              <p className="small muted">
                {r.from} · {new Date(r.receivedAt).toLocaleString("en-GB")}
                {!r.matched ? " · Association needs review" : ""}
              </p>
              <p className="mailbox-reply-text">
                {r.text || "No plain-text body was supplied."}
              </p>
            </article>
          ))}
        </section>
      )}
    </div>
  );
}
