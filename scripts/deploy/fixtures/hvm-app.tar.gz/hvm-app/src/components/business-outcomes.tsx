import { useEffect, useRef, useState } from "react";
import type {
  BusinessOutcomesGateway,
  OutcomeDefinition,
  OutcomeState,
} from "../data/business-outcomes";
import { DataError } from "../data/gateway";
import { useHenryBinding } from "./workspace-henry";
import "../styles/business-outcomes.css";
const empty: OutcomeDefinition = {
  name: "",
  description: "",
  brandId: "",
  campaignId: null,
  sourceName: "",
  expectedEvent: "",
  mapping: {
    eventId: "event_id",
    subjectId: "account_id",
    occurredAt: "occurred_at",
    eventType: "event_type",
    campaignId: "campaign_id",
  },
};
export function BusinessOutcomesCard({
  api,
  workspaceId: w,
}: {
  api: BusinessOutcomesGateway;
  workspaceId: string;
}) {
  const [state, setState] = useState<OutcomeState>(),
    [open, setOpen] = useState(false),
    [id, setId] = useState<string | null>(null);
  const [draft, setDraft] = useState<OutcomeDefinition>(empty),
    [version, setVersion] = useState(0);
  const [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false),
    [token, setToken] = useState("");
  const [sample, setSample] = useState(""),
    [selected, setSelected] = useState<string[]>([]),
    [retractId, setRetractId] = useState(""),
    [reason, setReason] = useState("");
  const controller = useRef<AbortController | null>(null),
    lock = useRef(false),
    pendingRequest = useRef<{ body: string; key: string } | null>(null);
  const chosen = state?.definitions.find((d) => d.id === id);
  const fail = (e: unknown) =>
    setError(
      e instanceof DataError
        ? e.userMessage || "Outcome setup could not be saved. Retry."
        : e instanceof Error
          ? e.message
          : "Outcome setup unavailable. Retry.",
    );
  useEffect(() => {
    const c = new AbortController();
    controller.current = c;
    setState(undefined);
    setToken("");
    setOpen(false);
    setSelected([]);
    setId(null);
    api
      .read(w, c.signal)
      .then((s) => {
        if (!c.signal.aborted) setState(s);
      })
      .catch((e) => {
        if (!c.signal.aborted) fail(e);
      });
    return () => c.abort();
  }, [api, w]);
  useHenryBinding({
    key: "outcome-setup",
    priority: open ? 20 : 1,
    summary: JSON.stringify({
      outcomes: state?.definitions.map((d) => ({
        name: d.definition.name,
        description: d.definition.description,
        enabled: d.enabled,
        archived: d.archived,
      })),
      instruction:
        "Help define a business outcome and its evidence source. Prepare the visible editor only. Receiving evidence does not activate a campaign or authorise messages. Do not request credentials in chat. Free signup is distinct from purchase; a campaign association needs evidence.",
    }),
    editor: open
      ? {
          key: `outcome-${id || "new"}`,
          title: "Business outcome",
          fields: ["name", "description", "sourceName", "expectedEvent"].map(
            (key) => ({
              key,
              label: (
                {
                  name: "Outcome name",
                  description: "What counts as success",
                  sourceName: "Evidence source",
                  expectedEvent: "Source event name",
                } as Record<string, string>
              )[key]!,
              value: draft[key as keyof OutcomeDefinition] as string,
            }),
          ),
        }
      : undefined,
    apply: (changes) =>
      setDraft((old) => {
        const next = { ...old };
        for (const c of changes)
          if (
            ["name", "description", "sourceName", "expectedEvent"].includes(
              c.key,
            )
          )
            (next as unknown as Record<string, unknown>)[c.key] = c.value;
        return next;
      }),
    actions: [
      {
        id: "prepare-outcome",
        label: "Prepare an outcome",
        run: (objective) => {
          setId(null);
          setVersion(0);
          setToken("");
          setDraft({
            ...empty,
            description: objective,
            brandId: state?.brands.length === 1 ? state.brands[0]!.id : "",
          });
          setOpen(true);
        },
      },
    ],
  });
  function edit(row?: NonNullable<OutcomeState>["definitions"][number]) {
    setId(row?.id ?? null);
    setVersion(row?.version ?? 0);
    setToken("");
    setSample("");
    setError("");
    setDraft(
      row?.definition ?? {
        ...empty,
        brandId: state?.brands.length === 1 ? state.brands[0]!.id : "",
      },
    );
    setOpen(true);
  }
  async function run(
    action: string,
    target = id,
    extra: Record<string, unknown> = {},
  ) {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError("");
    setNotice("");
    const c = controller.current;
    if (!c) return;
    try {
      const body = {
        action,
        id: target,
        version:
          target === id
            ? version
            : (state?.definitions.find((d) => d.id === target)?.version ?? 0),
        ...extra,
      };
      const serial = JSON.stringify(body);
      if (pendingRequest.current?.body !== serial)
        pendingRequest.current = { body: serial, key: crypto.randomUUID() };
      const r = await api.change(
        w,
        { ...body, requestId: pendingRequest.current.key },
        c.signal,
      );
      pendingRequest.current = null;
      if (c.signal.aborted) return;
      setState(r.state);
      const saved = target
        ? r.state.definitions.find((d) => d.id === target)
        : r.state.definitions.find(
            (d) => !state?.definitions.some((old) => old.id === d.id),
          );
      if (saved) {
        setId(saved.id);
        setVersion(saved.version);
        setDraft(saved.definition);
      }
      if (r.token) setToken(r.token);
      if (["archive", "restore"].includes(action)) setToken("");
      setNotice(
        action === "test"
          ? "Sample mapping validated. Send a test from your source to verify delivery before enabling live evidence."
          : "Saved. Campaign operation has not changed.",
      );
      if (action === "retract") {
        setRetractId("");
        setReason("");
      }
    } catch (e) {
      if (!c.signal.aborted) fail(e);
    } finally {
      lock.current = false;
      if (!c.signal.aborted) setBusy(false);
    }
  }
  async function archiveSelected() {
    if (
      !window.confirm(
        `Archive ${selected.length} selected outcomes? Receiving will stop and connection keys will be revoked. Existing evidence is retained.`,
      ) ||
      lock.current
    )
      return;
    lock.current = true;
    setBusy(true);
    setError("");
    const errors: string[] = [];
    const c = controller.current!;
    for (const target of selected) {
      const row = state?.definitions.find((d) => d.id === target);
      if (!row) continue;
      try {
        const r = await api.change(
          w,
          {
            action: "archive",
            id: target,
            version: row.version,
            requestId: crypto.randomUUID(),
          },
          c.signal,
        );
        if (!c.signal.aborted) setState(r.state);
      } catch {
        errors.push(row.definition.name);
      }
      if (c.signal.aborted) break;
    }
    if (!c.signal.aborted) {
      setSelected([]);
      setOpen(false);
      setToken("");
      setError(
        errors.length
          ? `Could not archive: ${errors.join(", ")}. Refresh and retry those outcomes.`
          : "",
      );
      setNotice(
        errors.length
          ? "Other selected outcomes were archived."
          : "Selected outcomes archived; evidence retained.",
      );
      setBusy(false);
    }
    lock.current = false;
  }
  return (
    <article className="panel integration-card outcome-setup">
      <header>
        <h2>Business outcomes</h2>
        <p>
          Define success, then connect evidence from your client’s system. No
          website access is required.
        </p>
      </header>
      {error && <p role="alert">{error}</p>}
      {notice && <p role="status">{notice}</p>}
      <div className="button-row">
        <button
          type="button"
          disabled={busy}
          onClick={() => {
            const c = controller.current!;
            api
              .read(w, c.signal)
              .then((s) => {
                if (!c.signal.aborted) setState(s);
              })
              .catch(fail);
          }}
        >
          Refresh outcomes
        </button>
        {state?.canManage && (
          <button
            type="button"
            disabled={busy}
            className={open ? undefined : "outcome-primary"}
            onClick={() => edit()}
          >
            Define an outcome
          </button>
        )}
      </div>
      {!state ? (
        <p>Loading outcome setup…</p>
      ) : (
        <>
          {state.canManage && !open && (
            <button
              type="button"
              disabled={busy}
              onClick={() => {
                edit();
                setDraft({
                  ...empty,
                  name: "Free account signup",
                  description:
                    "One newly created free account confirmed by the account system. Visits, clicks, paid accounts and upgrades do not count. The source must emit this event only after confirming a new free account.",
                  brandId: state.brands.length === 1 ? state.brands[0]!.id : "",
                  sourceName: "Client account system",
                  expectedEvent: "free_account_created",
                });
              }}
            >
              Use free account signup template
            </button>
          )}
          {!state.definitions.length && (
            <p>
              No outcomes defined. Ask Henry to help describe what success
              means, or define an outcome here.
            </p>
          )}
          {state.definitionsTruncated && (
            <p role="status">Showing the first 500 outcomes.</p>
          )}
          {selected.length > 0 && (
            <button
              type="button"
              disabled={busy}
              onClick={() => void archiveSelected()}
            >
              Archive {selected.length} selected outcomes
            </button>
          )}
          <ul className="outcome-list">
            {state.definitions.map((row) => (
              <li key={row.id}>
                {state.canManage && !row.archived && (
                  <input
                    type="checkbox"
                    aria-label={`Select ${row.definition.name}`}
                    checked={selected.includes(row.id)}
                    onChange={(e) =>
                      setSelected((old) =>
                        e.target.checked
                          ? [...old, row.id]
                          : old.filter((v) => v !== row.id),
                      )
                    }
                  />
                )}
                <div>
                  <strong>{row.definition.name}</strong>
                  <p>
                    {row.archived
                      ? "Archived"
                      : row.enabled
                        ? "Receiving live evidence"
                        : "Paused — no live evidence accepted"}{" "}
                    · {row.definition.sourceName}
                  </p>
                </div>
                <button type="button" onClick={() => edit(row)} disabled={busy}>
                  Review {row.definition.name}
                </button>
              </li>
            ))}
          </ul>
          {open && (
            <section className="outcome-editor" aria-label="Outcome editor">
              <h3>{id ? "Review outcome" : "Define success"}</h3>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  void run("save", id, { definition: draft });
                }}
              >
                <fieldset
                  disabled={busy || !state.canManage || chosen?.archived}
                >
                  <legend>Outcome and evidence</legend>
                  <label>
                    Outcome name
                    <input
                      required
                      maxLength={120}
                      value={draft.name}
                      onChange={(e) =>
                        setDraft({ ...draft, name: e.target.value })
                      }
                      placeholder="Free account signup"
                    />
                  </label>
                  <label>
                    What counts as success
                    <textarea
                      required
                      maxLength={2000}
                      value={draft.description}
                      onChange={(e) =>
                        setDraft({ ...draft, description: e.target.value })
                      }
                      placeholder="One newly created free account confirmed by our account system. A click does not count."
                    />
                  </label>
                  <div className="outcome-fields">
                    <label>
                      Brand
                      <select
                        required
                        value={draft.brandId}
                        disabled={!!id}
                        onChange={(e) =>
                          setDraft({
                            ...draft,
                            brandId: e.target.value,
                            campaignId: null,
                          })
                        }
                      >
                        <option value="">Choose a brand</option>
                        {state.brands.map((b) => (
                          <option key={b.id} value={b.id}>
                            {b.name}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Campaign to measure
                      <select
                        value={draft.campaignId ?? ""}
                        onChange={(e) =>
                          setDraft({
                            ...draft,
                            campaignId: e.target.value || null,
                          })
                        }
                      >
                        <option value="">Overall performance only</option>
                        {state.campaigns
                          .filter((c) => c.brandId === draft.brandId)
                          .map((c) => (
                            <option value={c.id} key={c.id}>
                              {c.name}
                            </option>
                          ))}
                      </select>
                    </label>
                  </div>
                  {state.campaignsTruncated && (
                    <p>
                      Campaign choices are partial; recent campaign history
                      exceeded the display limit.
                    </p>
                  )}
                  <p>
                    Selecting a campaign does not attribute every outcome to it.
                    The source must supply the matching campaign reference.
                    Other outcomes remain unattributed.
                  </p>
                  <label>
                    Evidence source
                    <input
                      required
                      maxLength={120}
                      value={draft.sourceName}
                      onChange={(e) =>
                        setDraft({ ...draft, sourceName: e.target.value })
                      }
                      placeholder="Account system via Zapier"
                    />
                  </label>
                  <label>
                    Source event name
                    <input
                      required
                      maxLength={120}
                      value={draft.expectedEvent}
                      onChange={(e) =>
                        setDraft({ ...draft, expectedEvent: e.target.value })
                      }
                    />
                  </label>
                  <details>
                    <summary>Map incoming fields</summary>
                    <p>
                      Use field names or dot paths from your source. Map a
                      stable account reference, not an email address. The same
                      account counts once per outcome, even if events are
                      retried.
                    </p>
                    <div className="outcome-fields">
                      {(
                        [
                          "eventId",
                          "subjectId",
                          "occurredAt",
                          "eventType",
                          "campaignId",
                        ] as const
                      ).map((key) => (
                        <label key={key}>
                          {
                            {
                              eventId: "Unique event reference",
                              subjectId: "Unique account or outcome reference",
                              occurredAt:
                                "Outcome time (ISO date with timezone)",
                              eventType: "Event name",
                              campaignId: "Campaign reference (optional)",
                            }[key]
                          }
                          <input
                            required={key !== "campaignId"}
                            value={draft.mapping[key] ?? ""}
                            onChange={(e) => {
                              const mapping = { ...draft.mapping };
                              if (key === "campaignId" && !e.target.value)
                                delete mapping.campaignId;
                              else mapping[key] = e.target.value;
                              setDraft({ ...draft, mapping });
                            }}
                          />
                        </label>
                      ))}
                    </div>
                  </details>
                  <p>
                    Saving changes pauses receiving and requires a fresh test.
                    Historical evidence is retained. Use a new definition when
                    the meaning of success changes.
                  </p>
                  <div className="button-row">
                    <button type="submit" className="outcome-primary">
                      Save outcome
                    </button>
                  </div>
                </fieldset>
              </form>
              {chosen && (
                <section aria-label="Evidence connection">
                  <h3>Connect and test</h3>
                  <p>
                    Use an HTTP POST action in Zapier or another trusted server.
                    Keep the connection key in that system’s secret settings;
                    never put it on a website or in Henry chat.
                  </p>
                  <label>
                    Webhook URL
                    <input readOnly value={api.endpoint(w, chosen.id)} />
                  </label>
                  {chosen.definition.campaignId && (
                    <label>
                      Campaign reference to preserve from the originating
                      campaign
                      <input readOnly value={chosen.definition.campaignId} />
                    </label>
                  )}
                  <p>
                    Send JSON with <code>Content-Type: application/json</code>{" "}
                    and <code>Authorization: Bearer YOUR_CONNECTION_KEY</code>.
                    Add <code>X-HVM-Test: true</code> for a test delivery. Tests
                    never count in dashboards.
                  </p>
                  {token && (
                    <label>
                      Connection key — shown once
                      <input
                        readOnly
                        type="password"
                        value={token}
                        autoComplete="off"
                        onFocus={(e) => e.target.select()}
                      />
                      <button
                        type="button"
                        onClick={() =>
                          void navigator.clipboard.writeText(token).then(
                            () =>
                              setNotice(
                                "Connection key copied. Store it in your source’s secret settings.",
                              ),
                            () =>
                              setError(
                                "Copy failed. Select and copy the connection key field.",
                              ),
                          )
                        }
                      >
                        Copy connection key
                      </button>
                    </label>
                  )}
                  <div className="button-row">
                    <button
                      type="button"
                      disabled={busy || !state.canManage || chosen.archived}
                      onClick={() => {
                        if (
                          window.confirm(
                            "Create a new key? This revokes the previous key and pauses receiving until tested again.",
                          )
                        )
                          void run("rotate");
                      }}
                    >
                      Create / replace connection key
                    </button>
                  </div>
                  <label>
                    Sample event JSON
                    <textarea
                      value={sample}
                      onChange={(e) => setSample(e.target.value)}
                      placeholder={
                        '{"event_id":"sample-1","account_id":"sample-account","event_type":"free_account_created","occurred_at":"2026-10-17T12:00:00Z"}'
                      }
                    />
                  </label>
                  <div className="button-row">
                    <button
                      type="button"
                      disabled={busy || !state.canManage || chosen.archived}
                      onClick={() => {
                        try {
                          void run("test", id, { sample: JSON.parse(sample) });
                        } catch {
                          setError("Enter valid JSON for the sample event.");
                        }
                      }}
                    >
                      Validate sample mapping
                    </button>
                    <button
                      type="button"
                      disabled={
                        busy ||
                        !state.canManage ||
                        chosen.archived ||
                        !chosen.testedAt ||
                        !chosen.connectionTestedAt ||
                        chosen.enabled
                      }
                      onClick={() => void run("enable")}
                    >
                      Enable outcome receiving
                    </button>
                    <button
                      type="button"
                      disabled={busy || !state.canManage || !chosen.enabled}
                      onClick={() => void run("pause")}
                    >
                      Pause receiving
                    </button>
                    <button
                      type="button"
                      disabled={busy || !state.canManage}
                      onClick={() => {
                        if (
                          chosen.archived ||
                          window.confirm(
                            "Archive this outcome and revoke its connection key? Existing evidence is retained.",
                          )
                        )
                          void run(chosen.archived ? "restore" : "archive");
                      }}
                    >
                      {chosen.archived ? "Restore outcome" : "Archive outcome"}
                    </button>
                  </div>
                  <p>
                    Mapping: {chosen.testedAt ? "validated" : "not tested"}.
                    Source delivery:{" "}
                    {chosen.connectionTestedAt
                      ? "test received"
                      : "send a test, then refresh"}
                    . Last received:{" "}
                    {chosen.lastReceivedAt
                      ? new Date(chosen.lastReceivedAt).toLocaleString()
                      : "none"}
                    . Enabling receiving does not launch a campaign or send
                    emails.
                  </p>
                </section>
              )}
              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  setToken("");
                }}
              >
                Close outcome editor
              </button>
            </section>
          )}
          <details>
            <summary>
              Review received evidence ({state.evidence.length}
              {state.evidenceTruncated ? "+" : ""})
            </summary>
            <p>
              Confirmed by the connected source; HVM does not independently
              verify its claims. Counts use unique account/outcome references.
              Retracted evidence is retained for audit but excluded from
              metrics. Incoming data never grants permission to contact anyone.
            </p>
            {!state.evidence.length && <p>No evidence received yet.</p>}
            <ul className="outcome-list">
              {state.evidence.map((e) => (
                <li key={e.id}>
                  <div>
                    <strong>{e.outcomeName}</strong>
                    <p>
                      {new Date(e.occurredAt).toLocaleString()} ·{" "}
                      {e.retracted
                        ? "Retracted"
                        : e.testOnly
                          ? "Test only"
                          : "Source-confirmed"}
                    </p>
                    <p>
                      {e.attribution}
                      {e.reviewNote && ` ${e.reviewNote}`}
                    </p>
                  </div>
                  {state.canManage && !e.retracted && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => {
                        setRetractId(e.id);
                        setReason("");
                      }}
                    >
                      Retract evidence
                    </button>
                  )}
                </li>
              ))}
            </ul>
            {retractId && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  void run("retract", retractId, { note: reason });
                }}
              >
                <label>
                  Reason for retracting this evidence
                  <textarea
                    required
                    maxLength={1000}
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                  />
                </label>
                <div className="button-row">
                  <button type="button" onClick={() => setRetractId("")}>
                    Cancel
                  </button>
                  <button type="submit" disabled={busy}>
                    Confirm retraction
                  </button>
                </div>
              </form>
            )}
          </details>
        </>
      )}
    </article>
  );
}
