import { useCallback, useEffect, useRef, useState } from "react";
import { useResource } from "../data/use-resource";
import { DataError } from "../data/gateway";
import type { Ga4Gateway, Ga4Properties, Ga4State } from "../data/ga4";
import { Loading, Failure } from "./ui";
import "../styles/mailbox.css";
export function Ga4ConnectionCard({ api, workspaceId }: { api: Ga4Gateway; workspaceId: string }) {
  const load = useCallback((signal: AbortSignal) => api.read(workspaceId, signal), [api, workspaceId]);
  const resource = useResource(load);
  return <article className="panel integration-card mailbox-connection"><h3>Google Analytics 4</h3><p>Connect your client workspace to a GA4 property for website reporting.</p>{resource.state === "loading" ? <Loading/> : resource.state === "error" ? <Failure error={resource.error}/> : resource.state === "ready" ? <Controls key={workspaceId} api={api} workspaceId={workspaceId} initial={resource.data}/> : null}</article>;
}
function Controls({ api, workspaceId, initial }: { api: Ga4Gateway; workspaceId: string; initial: Ga4State }) {
  const [data, setData] = useState(initial), [busy, setBusy] = useState(""), [error, setError] = useState(""), [notice, setNotice] = useState(""), [choices, setChoices] = useState<Ga4Properties | null>(null), [selected, setSelected] = useState("");
  const life = useRef<AbortController>(new AbortController());
  const popup = useRef<Window | null>(null);
  const attempt = useRef<{ state: string; browserSecret: string } | null>(null);
  const errorMessage = (e: unknown) => e instanceof DataError && e.userMessage ? e.userMessage : "The operation could not be completed. Refresh status before retrying.";
  useEffect(() => {
    const controller = new AbortController(); life.current = controller;
    async function receive(e: MessageEvent) {
      const a = attempt.current;
      if (!a || !popup.current || e.source !== popup.current || e.origin !== window.location.origin || e.data?.type !== "hvm-ga4-callback" || e.data.state !== a.state) return;
      popup.current.close(); popup.current = null;
      if (e.data.error || typeof e.data.code !== "string") { attempt.current = null; setBusy(""); setError("Google sign-in was not completed. Connect again when ready."); return; }
      setBusy("Loading your properties…");
      try { const next = await api.discover(workspaceId, "finish", { ...a, code: e.data.code }, controller.signal); if (!controller.signal.aborted) { setChoices(next); setSelected(""); } }
      catch (err) { if (!controller.signal.aborted) { attempt.current = null; setError(errorMessage(err)); } }
      finally { if (!controller.signal.aborted) setBusy(""); }
    }
    const handler = (e: MessageEvent) => void receive(e);
    window.addEventListener("message", handler);
    const timer = setInterval(() => { if (popup.current?.closed) { popup.current = null; attempt.current = null; setBusy(""); setError("The Google window was closed. Connect again to continue."); } }, 1000);
    return () => { controller.abort(); window.removeEventListener("message", handler); clearInterval(timer); popup.current?.close(); popup.current = null; attempt.current = null; };
  }, [api, workspaceId]);
  async function connect() {
    if (busy) return;
    const win = window.open("about:blank", "hvm-ga4-connect", "width=600,height=760");
    if (!win) { setError("Allow the Google sign-in popup, then try again."); return; }
    popup.current = win; setBusy("Waiting for Google sign-in…"); setError(""); setNotice(""); setChoices(null); attempt.current = null;
    const signal = life.current.signal;
    try {
      const result = await api.connect(workspaceId, data.updatedAt, signal);
      if (signal.aborted) { win.close(); return; }
      const url = new URL(result.url);
      if (url.origin !== "https://accounts.google.com") throw new Error("Unexpected sign-in destination");
      attempt.current = { state: result.state, browserSecret: result.browserSecret };
      win.location.assign(url.toString());
    } catch (e) { win.close(); popup.current = null; if (!signal.aborted) { setError(errorMessage(e)); setBusy(""); } }
  }
  async function perform(action: "select" | "test" | "disconnect" | "refresh" | "more") {
    if (busy) return;
    if (action === "disconnect" && !window.confirm("Disconnect this workspace from GA4? Reporting access will stop. Existing saved reports will be retained.")) return;
    const signal = life.current.signal;
    setBusy(action === "select" ? "Verifying and saving property…" : action === "more" ? "Loading more properties…" : "Checking connection…"); setError(""); setNotice("");
    try {
      if (action === "more") {
        if (!attempt.current || !choices?.nextPageToken) return;
        const next = await api.discover(workspaceId, "properties", { ...attempt.current, pageToken: choices.nextPageToken }, signal);
        if (!signal.aborted) setChoices({ properties: [...new Map([...choices.properties, ...next.properties].map(p => [p.property, p])).values()], nextPageToken: next.nextPageToken });
        return;
      }
      if (action === "select" && (!attempt.current || !selected)) return;
      const next = action === "refresh" ? await api.read(workspaceId, signal) : await api.change(workspaceId, action, action === "select" ? { ...attempt.current, property: selected } : { expectedUpdatedAt: data.updatedAt }, signal);
      if (signal.aborted) return;
      setData(next);
      if (action === "select" || action === "disconnect") { setChoices(null); attempt.current = null; setSelected(""); }
      setNotice(action === "select" ? "GA4 connected. Your saved property is shown below." : action === "disconnect" ? "GA4 disconnected from this workspace." : action === "test" ? "Google property and reporting access verified." : "Saved connection status refreshed.");
    } catch (e) {
      if (!signal.aborted) {
        setError(errorMessage(e));
        try { const next = await api.read(workspaceId, signal); if (!signal.aborted) setData(next); } catch { /* Keep last confirmed state. */ }
      }
    } finally { if (!signal.aborted) setBusy(""); }
  }
  return <div className="mailbox-form">
    <p role="status">{data.status.replaceAll("_", " ")}</p>
    {data.status === "needs_attention" && <p role="alert">Google access needs attention. Check property permissions, then test or reconnect GA4.</p>}
    {data.property && <section aria-label="Connected GA4 property"><h4>{data.property.displayName}</h4><p>{data.property.name} · {data.property.timeZone} · {data.property.currencyCode}</p>{data.lastCheckedAt && <p>Access verified {new Date(data.lastCheckedAt).toLocaleString("en-GB")}</p>}<p>{data.hasReportRows === false ? "Google returned no report rows for the last seven complete days. Check the property and website tracking; this does not establish a zero-traffic baseline." : "Reporting access is verified. The historical baseline and dashboards are the next step."}</p></section>}
    {!data.available ? <p>GA4 connection setup is pending with the HVM administrator.</p> : !data.canManage ? <p>A workspace administrator can manage this connection.</p> : <>
      <p>Google will ask for read-only Analytics access. Choose the property that belongs to this client workspace. HVM saves only the selected property for reporting.</p>
      <div className="form-actions"><button className="button" disabled={!!busy} onClick={() => void connect()}>{data.property ? "Change property / reconnect" : "Connect Google Analytics"}</button><button className="secondary" disabled={!!busy} onClick={() => void perform("refresh")}>Refresh status</button>{data.property && <><button className="secondary" disabled={!!busy} onClick={() => void perform("test")}>Test connection</button><button className="secondary" disabled={!!busy} onClick={() => void perform("disconnect")}>Disconnect</button></>}</div>
      {choices && <section aria-label="Choose GA4 property"><h4>Choose this client’s property</h4>{choices.properties.length ? <label>GA4 property<select value={selected} disabled={!!busy} onChange={e => setSelected(e.target.value)}><option value="">Choose a property</option>{choices.properties.map(p => <option key={p.property} value={p.property}>{p.accountName} — {p.displayName} ({p.property.replace("properties/", "")})</option>)}</select></label> : <p>No properties were returned on this page. Load more if available, or connect with a Google account that has access to the client’s GA4 property.</p>}<div className="form-actions">{choices.nextPageToken && <button className="secondary" disabled={!!busy} onClick={() => void perform("more")}>Load more properties</button>}<button className="button" disabled={!!busy || !selected} onClick={() => void perform("select")}>Verify and save property</button></div></section>}
    </>}
    {data.status === "disconnected" && <p>HVM has removed this workspace’s access. You can also remove HVM in your Google Account settings; that may affect other HVM connections using the same Google grant.</p>}
    {busy && <p role="status">{busy}</p>}{notice && <p role="status">{notice}</p>}{error && <p role="alert">{error}</p>}
  </div>;
}
