import type { OfferBundle } from "../data/offer";
export function OfferSummary({bundle,dirty,busy,canRegister,onRegister,workspaceId}:{bundle:OfferBundle;dirty:boolean;busy:boolean;canRegister:boolean;onRegister:()=>void;workspaceId:string}) {
 const output=bundle.output;
 return <section aria-label="Offer summary" className="offer-summary">
  <h3>Your offer</h3>
  <p>This is the saved offer and the decisions behind it. Publication and distribution require separate approval.</p>
  {dirty && <p role="status">Save your changes to update this summary.</p>}
  {!output ? <p>Save and reopen this offer to load its summary.</p> : <>
   {output.sections.map(s=><section key={s.title}><h4>{s.title}</h4><p className="offer-prose">{s.text}</p></section>)}
   <details><summary>Methodology decisions and unresolved questions</summary>{output.decisions.map(s=><section key={s.title}><h4>{s.title}</h4><p className="offer-prose">{s.text}</p></section>)}</details>
   <div className="offer-toolbar">
    {output.assetId ? <a href={`/queen/clients/${workspaceId}/library#${output.assetId}`}>View in Library</a> : <button disabled={!canRegister||busy||dirty} onClick={onRegister}>Add summary to Library</button>}
   </div>
   <p className="offer-hint">Edit the offer in its sections. Saved changes update the Library output while previous versions remain in its history.</p>
  </>}
 </section>;
}
