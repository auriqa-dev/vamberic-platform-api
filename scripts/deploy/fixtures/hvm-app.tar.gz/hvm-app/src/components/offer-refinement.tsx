import { useState } from "react";
import type { OfferBundle, OfferStage, Json } from "../data/offer";
import { fieldLabel } from "./offer-fields";

const unique = <T,>(items: T[]) => [
  ...new Map(items.map((x) => [JSON.stringify(x), x])).values(),
];
/** Add proposals without replacing recorded facts, decisions, research or evidence. */
export function includeStageSuggestions(
  current: OfferStage,
  proposal: OfferStage,
): OfferStage {
  const evidence = [...(current.evidence ?? [])];
  for (const item of proposal.evidence ?? []) {
    if (
      evidence.some(
        (e) =>
          e.reference === item.reference &&
          e.kind === item.kind &&
          e.observedAt === item.observedAt,
      )
    )
      continue;
    let key = item.key,
      n = 1;
    while (evidence.some((e) => e.key === key))
      key = `refinement_source_${n++}`;
    evidence.push({ ...item, key });
  }
  const groups = current.groups.map((g) => ({ ...g, items: [...g.items] }));
  for (const group of proposal.groups) {
    const found = groups.find((g) => g.key === group.key);
    if (found) found.items = unique([...found.items, ...group.items]);
    else groups.push({ ...group, items: [...group.items] });
  }
  const next = {
    ...current,
    status: "in_progress" as const,
    notes: unique([...current.notes, ...proposal.notes]),
    unknowns: unique([...current.unknowns, ...proposal.unknowns]),
    groups,
    evidence,
  };
  if (
    next.notes.length > 40 ||
    next.unknowns.length > 40 ||
    groups.length > 20 ||
    groups.some((g) => g.items.length > 40) ||
    evidence.length > 100
  )
    throw new Error(
      "This stage already contains a lot of research. Review and consolidate its notes before adding more suggestions.",
    );
  return next;
}
function Value({ value }: { value: Json | undefined }) {
  if (value == null) return <p>Not recorded</p>;
  if (Array.isArray(value))
    return (
      <ul>
        {value.map((v, i) => (
          <li key={i}>
            <Value value={v} />
          </li>
        ))}
      </ul>
    );
  if (typeof value === "object")
    return (
      <dl>
        {Object.entries(value).map(([k, v]) => (
          <div key={k}>
            <dt>{fieldLabel(k)}</dt>
            <dd>
              <Value value={v} />
            </dd>
          </div>
        ))}
      </dl>
    );
  return <p>{String(value)}</p>;
}
export function OfferRefinement({
  bundle,
  editable,
  onChange,
}: {
  bundle: OfferBundle;
  editable: boolean;
  onChange: (b: OfferBundle) => void;
}) {
  const [error, setError] = useState("");
  const refinement = bundle.refinement;
  if (!refinement) return null;
  const previous = refinement.previousDefinition,
    current = bundle.offer.definition;
  const changed = [
    ...new Set([...Object.keys(previous), ...Object.keys(current)]),
  ].filter((k) => JSON.stringify(previous[k]) !== JSON.stringify(current[k]));
  return (
    <section className="offer-refinement" aria-label="Review offer refinements">
      <h3>Review the refinements</h3>
      <p>
        The current draft contains the suggested wording. Compare it with the
        offer before refinement. Approved versions remain unchanged.
      </p>
      <p>
        {refinement.commercialChangesAuthorised
          ? "Commercial changes were allowed for this draft. Review pricing and terms carefully."
          : "Pricing, packaging and commercial terms were protected during generation."}
      </p>
      <details>
        <summary>
          Compare wording and terms ({changed.length} changed{" "}
          {changed.length === 1 ? "field" : "fields"})
        </summary>
        {!changed.length && <p>No differences from the earlier offer.</p>}
        {changed.map((key) => (
          <section key={key}>
            <h4>{fieldLabel(key)}</h4>
            <div className="offer-comparison">
              <div>
                <strong>Before refinement</strong>
                <Value value={previous[key]} />
              </div>
              <div>
                <strong>Current draft</strong>
                <Value value={current[key]} />
              </div>
            </div>
            {editable && (
              <div className="offer-toolbar">
                <button
                  type="button"
                  onClick={() => {
                    const definition = { ...current };
                    if (previous[key] === undefined) delete definition[key];
                    else definition[key] = previous[key];
                    onChange({
                      ...bundle,
                      offer: { ...bundle.offer, definition },
                    });
                  }}
                >
                  Restore previous {fieldLabel(key).toLowerCase()}
                </button>
              </div>
            )}
          </section>
        ))}
      </details>
      <details>
        <summary>Research and methodology suggestions</summary>
        <p>
          Existing research and decisions are retained. Add useful suggestions
          to individual stages, then save the offer. Adding a suggestion does
          not approve it or complete the stage.
        </p>
        {refinement.proposedWork.stages.map((proposal) => {
          const stage = bundle.design?.work.stages.find(
            (s) => s.stageKey === proposal.stageKey,
          );
          const hasNew =
            !!stage &&
            (proposal.notes.some((n) => !stage.notes.includes(n)) ||
              proposal.unknowns.some((n) => !stage.unknowns.includes(n)) ||
              (proposal.evidence ?? []).some(
                (item) =>
                  !(stage.evidence ?? []).some(
                    (e) =>
                      e.reference === item.reference &&
                      e.kind === item.kind &&
                      e.observedAt === item.observedAt,
                  ),
              ) ||
              proposal.groups.some((g) =>
                g.items.some(
                  (i) =>
                    !stage.groups
                      .find((s) => s.key === g.key)
                      ?.items.includes(i),
                ),
              ));
          return (
            <details key={proposal.stageKey}>
              <summary>{fieldLabel(proposal.stageKey)}</summary>
              {proposal.notes.map((n, i) => (
                <p key={i}>{n}</p>
              ))}
              {proposal.groups.map((g) => (
                <div key={g.key}>
                  <h4>{g.name}</h4>
                  <ul>
                    {g.items.map((n, i) => (
                      <li key={i}>{n}</li>
                    ))}
                  </ul>
                </div>
              ))}
              {!!proposal.unknowns.length && (
                <>
                  <h4>Still to establish</h4>
                  <ul>
                    {proposal.unknowns.map((n, i) => (
                      <li key={i}>{n}</li>
                    ))}
                  </ul>
                </>
              )}
              <div className="offer-toolbar">
                <button
                  type="button"
                  disabled={!editable || !hasNew}
                  onClick={() => {
                    setError("");
                    try {
                      if (!stage || !bundle.design) return;
                      const next = includeStageSuggestions(stage, proposal);
                      onChange({
                        ...bundle,
                        design: {
                          ...bundle.design,
                          work: {
                            ...bundle.design.work,
                            completedStageKeys:
                              bundle.design.work.completedStageKeys.filter(
                                (k) => k !== stage.stageKey,
                              ),
                            stages: bundle.design.work.stages.map((s) =>
                              s.stageKey === stage.stageKey ? next : s,
                            ),
                          },
                        },
                      });
                    } catch (e) {
                      setError(
                        e instanceof Error
                          ? e.message
                          : "Could not add these suggestions.",
                      );
                    }
                  }}
                >
                  {hasNew
                    ? "Add suggestions to draft"
                    : "Suggestions already included"}
                </button>
              </div>
            </details>
          );
        })}
      </details>
      {error && <p role="alert">{error}</p>}
    </section>
  );
}
