import { useEffect, useState } from "react";
import type {
  ContactManagementGateway,
  ManagedRecord,
} from "../data/contact-management";
import type { ContactContextGateway } from "../data/contact-context";
type Item = Awaited<
  ReturnType<ContactContextGateway["unlinked"]>
>["items"][number];
export function UnlinkedEmailHistory({
  api,
  w,
  canWrite,
}: {
  api: ContactManagementGateway;
  w: string;
  canWrite: boolean;
}) {
  const [open, setOpen] = useState(false),
    [items, setItems] = useState<Item[]>([]),
    [offset, setOffset] = useState(0),
    [more, setMore] = useState(false),
    [revision, setRevision] = useState(0),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [selected, setSelected] = useState<Item>(),
    [query, setQuery] = useState(""),
    [matches, setMatches] = useState<ManagedRecord[]>([]),
    [person, setPerson] = useState(""),
    [reason, setReason] = useState(""),
    [notice, setNotice] = useState("");
  useEffect(() => {
    if (!open || !api.context) return;
    const c = new AbortController();
    api.context
      .unlinked(w, offset, c.signal)
      .then((r) => {
        if (!c.signal.aborted) {
          setItems(r.items);
          setMore(r.hasMore);
        }
      })
      .catch(() => {
        if (!c.signal.aborted)
          setError(
            "Could not load unlinked email history. Close and reopen to retry.",
          );
      });
    return () => c.abort();
  }, [api, w, open, offset, revision]);
  async function search() {
    setBusy(true);
    setError("");
    try {
      const r = await api.list(
        w,
        "contacts",
        { search: query },
        new AbortController().signal,
      );
      setMatches(r.items);
      if (!r.items.length)
        setError("No contacts found. Import or create the person first.");
    } catch {
      setError("Could not search contacts. Try again.");
    } finally {
      setBusy(false);
    }
  }
  async function link() {
    if (!api.context || !selected || !person || !reason.trim() || busy) return;
    setBusy(true);
    setError("");
    try {
      await api.context.link(
        w,
        selected.id,
        { updatedAt: selected.updatedAt, personId: person, reason },
        new AbortController().signal,
      );
      setItems(items.filter((e) => e.id !== selected.id));
      setSelected(undefined);
      setNotice(
        "Email linked. Open the contact to see it in their interaction history.",
      );
      setRevision((v) => v + 1);
    } catch {
      setError(
        "Could not link this email. It may have changed; close and reopen the history before trying again.",
      );
    } finally {
      setBusy(false);
    }
  }
  if (!api.context) return null;
  return (
    <section className="cm-history">
      <button
        type="button"
        aria-expanded={open}
        onClick={() => {
          setOpen(!open);
          setError("");
        }}
      >
        {" "}
        {open ? "Close" : "Review"} unlinked email history
      </button>
      {open && (
        <>
          <p>
            These imported emails could not be associated safely. Review their
            participants and content before choosing a contact. Linking an email
            does not grant permission to contact them.
          </p>
          {error && <p role="alert">{error}</p>}
          {notice && <p role="status">{notice}</p>}
          {!items.length && <p>No unlinked emails on this page.</p>}
          {items.map((item) => (
            <details key={item.id}>
              <summary>
                {item.subject} ·{" "}
                {new Date(item.date).toLocaleDateString("en-GB")}
              </summary>
              <p>
                {Object.entries(item.participants)
                  .filter(([, v]) => v)
                  .map(([k, v]) => `${k}: ${v}`)
                  .join(" · ")}
              </p>
              <p className="cm-message-text">{item.body}</p>
              {canWrite && (
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => {
                    setSelected(item);
                    setPerson("");
                    setMatches([]);
                    setReason("");
                  }}
                >
                  Choose contact
                </button>
              )}
            </details>
          ))}
          <div className="icp-actions">
            <button
              disabled={busy || offset === 0}
              onClick={() => setOffset(Math.max(0, offset - 50))}
            >
              Previous
            </button>
            <button
              disabled={busy || !more}
              onClick={() => setOffset(offset + 50)}
            >
              Next
            </button>
          </div>
          {selected && (
            <section className="cm-history" aria-label="Link email to contact">
              <h3>Link: {selected.subject}</h3>
              <div className="icp-grid">
                <label className="field">
                  Find contact
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                  />
                </label>
                <div className="icp-actions">
                  <button
                    disabled={busy || !query.trim()}
                    onClick={() => void search()}
                  >
                    Search contacts
                  </button>
                </div>
                <label className="field">
                  Contact
                  <select
                    value={person}
                    onChange={(e) => setPerson(e.target.value)}
                  >
                    <option value="">Choose a contact</option>
                    {matches.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} — {p.email || "No email"} {p.organisationName}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="field">
                  Reason for linking
                  <textarea
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                  />
                </label>
              </div>
              <div className="icp-actions">
                <button
                  className="button"
                  disabled={busy || !person || !reason.trim()}
                  onClick={() => void link()}
                >
                  Confirm link
                </button>
                <button disabled={busy} onClick={() => setSelected(undefined)}>
                  Cancel
                </button>
              </div>
            </section>
          )}
        </>
      )}
    </section>
  );
}
