import { DataError } from "../data/gateway";
import { planningSchema } from "./library-planning";
import type { z } from "zod";
import { useEffect, useRef, useState } from "react";
import type { ContentGateway } from "../data/content-strategy";
import {
  assetData,
  scope as scopeSchema,
  type ContentRecord,
} from "../data/content-strategy-model";
import type { DiscoveryJob } from "../data/library";
import type { ResearchDocument } from "../data/research-documents";
import { extractContentFile } from "../data/content-import";
import { useHenryBinding } from "./workspace-henry";

type Scope = z.infer<typeof scopeSchema>;
const emptyAsset = (scope: Scope) =>
  assetData.parse({
    title: "Untitled",
    classification: "unclassified",
    assetType: "document",
    channel: "",
    url: "",
    text: "",
    description: "",
    sourceDocumentId: "",
    sourceAssetIds: [],
    scope,
    topics: [],
    buyerStages: [],
    claims: [],
    evidence: [],
    gaps: [],
    reuse: [],
    restrictions: [],
    analysisStatus: "needs_review",
  });
const accept =
  ".pdf,.docx,.doc,.pptx,.ppt,.xlsx,.xls,.csv,.txt,.md,.png,.jpg,.jpeg,.webp,.gif,.mp4,.mov,.webm,.mp3,.wav,.m4a,.ogg";
export function LibraryIngestion({
  api,
  workspaceId: w,
  scope,
  website,
  onChanged,
  records,
}: {
  api: ContentGateway;
  workspaceId: string;
  scope: Scope;
  website: string;
  onChanged: () => Promise<void>;
  records: ContentRecord[];
}) {
  const [jobs, setJobs] = useState<DiscoveryJob[]>([]),
    [active, setActive] = useState(""),
    [url, setUrl] = useState(website),
    [query, setQuery] = useState(""),
    [language, setLanguage] = useState(""),
    [region, setRegion] = useState(""),
    [selection, setSelection] = useState<string[]>([]),
    [selectionReasons, setSelectionReasons] = useState<Record<string, string>>(
      {},
    ),
    [busy, setBusy] = useState(""),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [docs, setDocs] = useState<ResearchDocument[]>([]),
    [replace, setReplace] = useState(""),
    [threshold, setThreshold] = useState(200),
    [discoveryMode, setDiscoveryMode] = useState<"website" | "page">("website");
  const stop = useRef(false),
    lock = useRef(false),
    upload = useRef<HTMLInputElement>(null);
  const signal = () => new AbortController().signal;
  const job =
    jobs.find((j) => j.id === active) ||
    jobs.find((j) => j.state.brandId === scope.brandId);
  useEffect(() => {
    const c = new AbortController();
    setJobs([]); setDocs([]); setReplace(""); setActive(""); setSelection([]); setError(""); setNotice("");
    void api.library
      ?.list(w, c.signal)
      .then(async (rows) => {
        const first = rows.find((j) => j.state.brandId === scope.brandId);
        if (first) {
          const full = await api.library.discovery(w, first.id, c.signal);
          if (!c.signal.aborted) setJobs(rows.map((j) => (j.id === first.id ? full : j)));
        } else if (!c.signal.aborted) setJobs(rows);
      })
      .catch(() => {
        if (!c.signal.aborted)
          setError(
            "The discovery index could not be loaded. Retry before starting another discovery.",
          );
      });
    return () => {
      c.abort();
      stop.current = true;
    };
  }, [api, w, scope.brandId]);
  useEffect(() => {
    setUrl(website);
    setSelection([]);
    setActive("");
  }, [website, scope.brandId]);
  async function refresh() {
    const rows = await api.library.list(w, signal());
    const current =
      rows.find((j) => j.id === job?.id) ||
      rows.find((j) => j.state.brandId === scope.brandId);
    if (current) {
      const full = await api.library.discovery(w, current.id, signal());
      setJobs(rows.map((j) => (j.id === full.id ? full : j)));
    } else setJobs(rows);
    await onChanged();
  }
  async function run(label: string, fn: () => Promise<void>) {
    if (lock.current) return;
    lock.current = true;
    stop.current = false;
    setBusy(label);
    setError("");
    setNotice("");
    try {
      await fn();
    } catch (e) {
      setError(
        e instanceof DataError
          ? e.userMessage || "Check the address and selected options, then try again."
          : e instanceof Error
          ? e.message
          : "The action could not finish. Saved items are preserved.",
      );
    } finally {
      lock.current = false;
      setBusy("");
    }
  }
  async function continueJob(id: string) {
    let next: DiscoveryJob;
    do {
      next = await api.library.step(w, id, signal());
      setJobs((rows) => [next, ...rows.filter((j) => j.id !== id)]);
      setBusy(`Discovering website · ${next.state.pages.length} pages found`);
      if (next.state.status === "running" && !stop.current)
        await new Promise((resolve) => setTimeout(resolve, 750));
    } while (next.state.status === "running" && !stop.current);
    setNotice("Discovery saved. Review the scope below before importing.");
  }
  const candidates = (job?.state.pages ?? []).filter(
    (p) =>
      (!language || p.language === language) &&
      (!region || p.region === region) &&
      (!query ||
        `${p.title} ${p.description} ${p.url}`
          .toLowerCase()
          .includes(query.toLowerCase())),
  );
  async function registerDocument(
    doc: ResearchDocument,
    text: string,
    note: string,
    previous?: ContentRecord,
  ) {
    const old = previous ? assetData.parse(previous.data) : undefined;
    const saved = await api.save(
      w,
      {
        id: previous?.id,
        kind: "asset",
        expectedVersion: previous?.version ?? 0,
        operation: "save",
        requestKey: crypto.randomUUID(),
        data: {
          ...emptyAsset(scope),
          ...old,
          title: old?.title ?? doc.details.name,
          text: text.slice(0, 180000),
          description: doc.details.purpose,
          sourceDocumentId: doc.id,
          sourceDocumentRevision: doc.revision,
          sourceType: "upload",
          assetType: /\.(png|jpe?g|webp|gif)$/i.test(doc.filename)
            ? "image"
            : /\.(mp4|mov|webm)$/i.test(doc.filename)
              ? "video"
              : /\.(mp3|wav|m4a|ogg)$/i.test(doc.filename)
                ? "audio"
                : /\.(pptx?|ppt)$/i.test(doc.filename)
                  ? "presentation"
                  : /\.(xlsx?|csv)$/i.test(doc.filename)
                    ? "spreadsheet"
                    : "document",
          originalFilename: doc.filename,
          uploadedAt: doc.updatedAt,
          visibility: "private",
          processingNote: note,
          usageRights: "unknown",
          allowedUses: [],
          analysisStatus: "needs_review",
          restrictions: [
            ...new Set([
              ...(old?.restrictions ?? []),
              "Private source. External publication or distribution requires explicit approval and rights review.",
            ]),
          ],
          associations: (old?.associations ?? []).map((a) => ({
            ...a,
            decision: "suggested",
          })),
          sourceMetadata: {
            ...emptyAsset(scope).sourceMetadata,
            ...old?.sourceMetadata,
            producer: doc.details.provenance,
            checkedAt: doc.updatedAt,
          },
        },
      },
      signal(),
    );
    return saved;
  }
  async function uploadFiles(files: File[]) {
    const failures: string[] = [];
    let count = 0;
    const processedIds = new Set<string>();
    for (const file of files) {
      if (stop.current) break;
      setBusy(`Uploading ${count + 1} of ${files.length} · ${file.name}`);
      try {
        let text = "",
          note =
            "Original file stored. Automatic text extraction is unavailable for this format; add a description or transcript to support relevance assessment.";
        try {
          text = await extractContentFile(file);
          note =
            text.length > 180000
              ? "Original file preserved. Extracted text exceeds the processing bound; review the original for full evidence."
              : "Text extracted. Review before using as evidence.";
        } catch (error) {
          note = `Original file stored. ${error instanceof Error ? error.message : "Text extraction could not finish; add a description or transcript."}`;
        }
        const doc = await api.documents.upload(
          w,
          file,
          {
            name: file.name,
            purpose: "Library source material",
            extract: text.slice(0, 6000) || note,
            provenance:
              "User upload; ownership and usage rights require review",
            grain: "other",
          },
          crypto.randomUUID(),
          signal(),
        );
        const asset = await registerDocument(
          doc,
          text,
          note,
          records.find((r) => r.id === replace),
        );
        processedIds.add(asset.id);
        count++;
        await onChanged();
      } catch {
        failures.push(file.name);
      }
    }
    await refresh();
    let relevance =
      "Relevance assessment is pending. Open Content Strategy to retry.";
    try {
      const plan = planningSchema.parse(
        await api.library.planning(w, signal()),
      );
      const matches = plan.requirements.filter((r) =>
        r.assets.some((a) => processedIds.has(a.id)),
      );
      relevance = `${matches.length} potential content requirement matches found. Review reuse suggestions in Content Strategy.`;
    } catch {
      /* Successful uploads remain visible when assessment is temporarily unavailable. */
    }
    setReplace("");
    setNotice(
      `${count} file${count === 1 ? "" : "s"} added to the Library as private drafts. ${relevance}${failures.length ? ` Could not finish: ${failures.join(", ")}. Successfully uploaded originals are available under “Existing workspace documents”.` : ""}`,
    );
  }
  useHenryBinding({
    key: "library-ingestion",
    brandId: scope.brandId,
    summary: JSON.stringify({
      library: {
        scope,
        discovery: job
          ? {
              pages: job.state.pages.length,
              status: job.state.status,
              recommendation: job.recommendation,
            }
          : null,
        selectedPages: selection.length,
        uploadStatus: busy,
      },
      instruction:
        "Discovery is not import or approval. Files are private by default. Recommend reviewing selected scope; never claim an import or publication has happened.",
    }),
    actions: busy
      ? []
      : [
          {
            id: "library:upload",
            label: "Upload Library files",
            run: () => upload.current?.click(),
          },
        ],
  });
  return (
    <section className="content-section library-ingestion">
      <h2>Add to Library</h2>
      <p>
        Upload private material, reuse a workspace document, or discover
        published content. New assets require review before external use.
      </p>
      <div className="content-actions library-upload-actions">
        <button
          className="button"
          disabled={!!busy}
          onClick={() => upload.current?.click()}
        >
          Upload files
        </button>
        <input
          ref={upload}
          type="file"
          hidden
          multiple={!replace}
          accept={accept}
          onChange={(e) => {
            const files = Array.from(e.target.files ?? []);
            e.target.value = "";
            if (files.length)
              void run("Preparing files…", () => uploadFiles(files));
          }}
        />
        <label>
          Replace an existing asset
          <select
            value={replace}
            disabled={!!busy}
            onChange={(e) => setReplace(e.target.value)}
          >
            <option value="">Add new assets</option>
            {records
              .filter(
                (r) =>
                  r.kind === "asset" && !r.data.archived && r.status !== "removed" &&
                  !["offer_output", "email_content"].includes(String(r.data.sourceType)) &&
                  (r.data.scope as Scope)?.brandId === scope.brandId,
              )
              .map((r) => (
                <option key={r.id} value={r.id}>
                  {String(r.data.title)}
                </option>
              ))}
          </select>
        </label>
        <button
          disabled={!!busy}
          onClick={() =>
            void run("Loading documents…", async () => {
              const r = await api.documents.list(w, signal());
              setDocs(r.documents);
              setNotice(
                r.more
                  ? "Showing the first 200 workspace documents."
                  : "Choose a ready document to reuse its original file.",
              );
            })
          }
        >
          Existing workspace documents
        </button>
      </div>
      <p className="small muted">
        Up to 50 MB per file. Multiple files are processed separately. Replacing
        a file preserves previous asset revisions and originals.
      </p>
      {docs.length > 0 && (
        <div className="content-discovered">
          {docs.map((doc) => (
            <div key={doc.id} className="content-record">
              <strong>{doc.filename}</strong>
              <p>
                {doc.details.purpose} · {doc.status}
              </p>
              <button
                disabled={
                  !!busy ||
                  doc.status !== "ready" ||
                  records.some((r) => r.data.sourceDocumentId === doc.id)
                }
                onClick={() =>
                  void run("Linking original document…", async () => {
                    await registerDocument(
                      doc,
                      doc.details.extract,
                      "Linked to the existing workspace original. Its original purpose and provenance are retained.",
                    );
                    await refresh();
                    setNotice(
                      "Document added to Library. No second upload was needed.",
                    );
                  })
                }
              >
                Add to Library
              </button>
            </div>
          ))}
        </div>
      )}
      <details>
        <summary>Discover website content or add an external URL</summary>
        <label>
          Import scope
          <select
            value={discoveryMode}
            onChange={(e) =>
              setDiscoveryMode(e.target.value as "website" | "page")
            }
            disabled={!!busy}
          >
            <option value="website">Discover this website</option>
            <option value="page">Only this external page</option>
          </select>
        </label>
        <div className="content-url">
          <label>
            Website or external page URL
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
            />
          </label>
          <button
            disabled={!!busy || !url || !scope.brandId}
            onClick={() =>
              void run("Starting discovery…", async () => {
                const r = await api.library.start(
                  w,
                  {
                    brandId: scope.brandId,
                    mode: discoveryMode,
                    url,
                    smallSiteThreshold: threshold,
                    requestKey: crypto.randomUUID(),
                  },
                  signal(),
                );
                setActive(r.id);
                if (discoveryMode === "page") {
                  const full = await api.library.discovery(w, r.id, signal());
                  setJobs((rows) => [
                    full,
                    ...rows.filter((j) => j.id !== r.id),
                  ]);
                  setSelection([full.state.root]);
                  setNotice(
                    "External page selected. Import it below to retrieve its content; usage rights still require review.",
                  );
                } else await continueJob(r.id);
              })
            }
          >
            {discoveryMode === "page" ? "Add external URL" : "Discover"}
          </button>
        </div>
        <label>
          Small-site recommendation threshold
          <input
            type="number"
            min={10}
            max={500}
            value={threshold}
            onChange={(e) => setThreshold(Number(e.target.value))}
          />
        </label>
        <p>
          Discovery saves URLs and metadata only. The external-page option reads
          only your selected page during import, without crawling its website.
        </p>
      </details>
      {busy && (
        <p role="status">
          {busy}{" "}
          <button
            onClick={() => {
              stop.current = true;
            }}
          >
            Pause after this item
          </button>
        </p>
      )}
      {error && <p role="alert">{error}</p>}
      {notice && <p role="status">{notice}</p>}
      {job && (
        <>
          <h3>Website discovery</h3>
          <label>
            Saved discovery
            <select
              value={job.id}
              disabled={!!busy}
              onChange={(e) => {
                const id = e.target.value;
                setActive(id);
                setSelection([]);
                void run("Loading discovery…", async () => {
                  const full = await api.library.discovery(w, id, signal());
                  setJobs((rows) =>
                    rows.map((j) =>
                      j.id === id
                        ? full
                        : { ...j, state: { ...j.state, pages: [] } },
                    ),
                  );
                });
              }}
            >
              {jobs
                .filter((j) => j.state.brandId === scope.brandId)
                .map((j) => (
                  <option key={j.id} value={j.id}>
                    {j.state.root} ·{" "}
                    {new Date(j.state.updatedAt).toLocaleString("en-GB")}
                  </option>
                ))}
            </select>
          </label>
          <p>
            {job.recommendation.eligiblePages} pages · {job.state.status}.{" "}
            {job.recommendation.reason}
          </p>
          <p className="small muted">{job.recommendation.volumeNote}</p>
          {job.state.warnings.map((v, i) => (
            <p key={i}>{v}</p>
          ))}
          {job.state.status === "running" && (
            <button
              disabled={!!busy}
              onClick={() =>
                void run("Resuming discovery…", () => continueJob(job.id))
              }
            >
              Resume discovery
            </button>
          )}
          <div className="content-fields">
            <label>
              Search discovered pages
              <input value={query} onChange={(e) => setQuery(e.target.value)} />
            </label>
            <label>
              Language
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
              >
                <option value="">
                  All languages — review before selecting
                </option>
                {job.recommendation.languages.map((l) => (
                  <option key={l}>{l}</option>
                ))}
              </select>
            </label>
            <label>
              Region
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value)}
              >
                <option value="">All regions</option>
                {[
                  ...new Set(
                    job.state.pages.map((p) => p.region).filter(Boolean),
                  ),
                ].map((r) => (
                  <option key={r}>{r}</option>
                ))}
              </select>
            </label>
          </div>
          <div className="content-actions">
            <button
              disabled={!!busy}
              onClick={() => setSelection(candidates.map((p) => p.url))}
            >
              Select filtered pages ({candidates.length})
            </button>
            <button
              disabled={!!busy}
              onClick={() =>
                void run("Finding pages for your offers…", async () => {
                  const plan = planningSchema.parse(
                    await api.library.planning(w, signal()),
                  );
                  const reasons: Record<string, string> = {};
                  for (const item of plan.requirements.filter(
                    (r) =>
                      r.requirement.brandId === scope.brandId &&
                      (!scope.offers.length ||
                        scope.offers.some(
                          (o) => o.id === r.requirement.offerId,
                        )),
                  ))
                    for (const page of item.discovered)
                      if (candidates.some((p) => p.url === page.url))
                        reasons[page.url] =
                          `Suggested for ${item.requirement.offerName}: ${item.requirement.title}`.slice(
                            0,
                            180,
                          );
                  setSelection(Object.keys(reasons));
                  setSelectionReasons(reasons);
                  setNotice(
                    `${Object.keys(reasons).length} possible matches selected within your language, region and search filters. Review before importing; metadata alone does not prove relevance.`,
                  );
                })
              }
            >
              Select pages suggested for offers
            </button>
            <button disabled={!!busy} onClick={() => setSelection([])}>
              Clear selection
            </button>
            <button
              disabled={
                !!busy || !selection.length || job.state.status === "running"
              }
              onClick={() => {
                if (
                  !window.confirm(
                    `Import or refresh ${selection.length} selected pages? Changed pages become drafts. Existing approvals remain in history.`,
                  )
                )
                  return;
                void run("Importing pages…", async () => {
                  const failures: string[] = [];
                  let count = 0;
                  for (const target of selection) {
                    if (stop.current) break;
                    setBusy(`Importing ${count + 1} of ${selection.length}`);
                    try {
                      await api.library.importPage(
                        w,
                        job.id,
                        target,
                        crypto.randomUUID(),
                        signal(),
                        selectionReasons[target] ??
                          "Selected by the user from the reviewed discovery scope",
                      );
                      count++;
                      await onChanged();
                    } catch {
                      failures.push(target);
                    }
                    if (!stop.current)
                      await new Promise((resolve) => setTimeout(resolve, 750));
                  }
                  await refresh();
                  setSelection([]);
                  setNotice(
                    `${count} pages imported or checked. ${failures.length} failed; review their status and retry individually.`,
                  );
                });
              }}
            >
              Import selected ({selection.length})
            </button>
          </div>
          <div className="content-discovered">
            {candidates.slice(0, 200).map((p) => (
              <label className="content-check" key={p.url}>
                <input
                  type="checkbox"
                  checked={selection.includes(p.url)}
                  disabled={!!busy}
                  onChange={(e) =>
                    setSelection((s) =>
                      e.target.checked
                        ? [...s, p.url]
                        : s.filter((u) => u !== p.url),
                    )
                  }
                />
                <span>
                  <strong>{p.title || p.url}</strong>
                  <small>{p.url}</small>
                  {selectionReasons[p.url] && (
                    <small>{selectionReasons[p.url]}</small>
                  )}
                  <small>
                    {p.language || "Language unknown"} ·{" "}
                    {p.ingestion.replaceAll("_", " ")} · {p.description}
                  </small>
                  {p.error && <small>{p.error}</small>}
                </span>
              </label>
            ))}
          </div>
          {candidates.length > 200 && (
            <p>
              Showing 200 of {candidates.length}. Narrow the search to inspect
              others; “select filtered pages” includes all matching pages.
            </p>
          )}
        </>
      )}
    </section>
  );
}
