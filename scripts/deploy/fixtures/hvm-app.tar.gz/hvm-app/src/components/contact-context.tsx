import { MeasurementPanel } from "./measurement";
import { useEffect, useId, useRef, useState } from "react";
import type {
  ContactContext,
  ContactContextGateway,
} from "../data/contact-context";
export function ContactHistory({
  api,
  w,
  kind,
  id,
  canWrite,
}: {
  api?: ContactContextGateway;
  w: string;
  kind: string;
  id: string;
  canWrite: boolean;
}) {
  const [record, setRecord] = useState<ContactContext>(),
    [controls, setControls] = useState<ContactContext["controls"]>(),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false),
    [responseReview, setResponseReview] = useState(""),
    [category, setCategory] = useState("ordinary_reply"),
    [departure, setDeparture] = useState(""),
    [point, setPoint] = useState(""),
    [relationship, setRelationship] = useState("");
  const lock = useRef(false);
  const reasonHelpId = useId();
  const saveHelpId = useId();
  useEffect(() => {
    const c = new AbortController();
    api
      ?.read(w, kind, id, c.signal)
      .then((r) => {
        if (!c.signal.aborted) {
          setRecord(r);
          setControls(r.controls);
        }
      })
      .catch(() => {
        if (!c.signal.aborted)
          setError(
            "Could not load contact history. Reopen this record to retry.",
          );
      });
    return () => c.abort();
  }, [api, w, kind, id]);
  async function save() {
    if (!api || !record || !controls || lock.current) return;
    lock.current = true;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const r = await api.save(
        w,
        kind,
        id,
        {
          revision: record.revision,
          controls,
          ...(responseReview
            ? { responseReview: { eventId: responseReview, category } }
            : {}),
          ...(departure
            ? {
                departure: {
                  eventId: departure,
                  contactPointId: point,
                  ...(relationship ? { relationshipId: relationship } : {}),
                },
              }
            : {}),
        },
        new AbortController().signal,
      );
      setRecord(r);
      setControls(r.controls);
      setDeparture("");
      setResponseReview("");
      setNotice("Saved. Contact context is updated; no messages were sent.");
    } catch {
      setError(
        "Could not save. Check the reason and selected address, or reopen if the record changed. Your entries are retained.",
      );
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  if (!api) return null;
  return (
    <section className="cm-history" aria-label="Contact context and history">
      <h2>Lifecycle and contact rules</h2>
      <MeasurementPanel data={record?.measurement} compact />
      {error && <p role="alert">{error}</p>}
      {notice && <p role="status">{notice}</p>}
      {!record || !controls ? (
        <p>Loading contact context…</p>
      ) : (
        <>
          <p>
            Imported stage: {record.sourceLifecycle || "Not recorded"}. HubSpot
            Current Customer:{" "}
            {record.sourceCurrentCustomer ? "Yes" : "Not asserted"}.
            Subscription: {record.subscriptionStatus || "Unknown"}. Customer
            status does not identify a purchased product.
          </p>
          {record.sourceRestrictions.length > 0 && (
            <p>
              Imported restrictions remain effective:{" "}
              {record.sourceRestrictions.join("; ")}. Clearing a local checkbox
              does not clear imported restrictions.
            </p>
          )}
          {record.inheritedRestrictions.length > 0 && (
            <p>Organisation rules: {record.inheritedRestrictions.join("; ")}</p>
          )}
          <div className="icp-grid">
            <label className="field">
              Lifecycle
              <select
                value={controls.lifecycle}
                disabled={!canWrite || busy}
                onChange={(e) =>
                  setControls({ ...controls, lifecycle: e.target.value })
                }
              >
                {[
                  "subscriber",
                  "lead",
                  "marketing_qualified",
                  "sales_qualified",
                  "opportunity",
                  "customer",
                  "advocate",
                  "other",
                  "unknown",
                ].map((s) => (
                  <option key={s} value={s}>
                    {s.replaceAll("_", " ")}
                  </option>
                ))}
              </select>
            </label>
            <div className="field">
              <label htmlFor={`${reasonHelpId}-field`}>
                Reason for changes (required)
              </label>
              <textarea
                id={`${reasonHelpId}-field`}
                required
                aria-describedby={reasonHelpId}
                value={controls.reason}
                disabled={!canWrite || busy}
                onChange={(e) =>
                  setControls({ ...controls, reason: e.target.value })
                }
              />
              <small id={reasonHelpId}>
                Explain why you are changing the lifecycle or contact rules.
              </small>
            </div>
          </div>
          <div className="icp-grid">
            {(
              [
                ["doNotContact", "Do not contact this person or organisation"],
                ["marketingSuppressed", "Suppress marketing"],
                ["oneToOneSuppressed", "Suppress one-to-one outreach"],
                [
                  "commercialExclusion",
                  "Exclude from acquisition for commercial reasons",
                ],
              ] as const
            ).map(([key, label]) => (
              <label key={key} className="icp-check">
                <input
                  type="checkbox"
                  disabled={!canWrite || busy}
                  checked={controls[key]}
                  onChange={(e) =>
                    setControls({ ...controls, [key]: e.target.checked })
                  }
                />
                {label}
              </label>
            ))}
          </div>
          <p>
            Commercial exclusion is separate from DNC. Inactivity rules need an
            approved strategy and actual account activity; no inactivity
            threshold is assumed.
          </p>
          {Object.keys(record.sourceFields).length > 0 && (
            <details>
              <summary>
                Original HubSpot fields (
                {Object.keys(record.sourceFields).length})
              </summary>
              <p>
                Original source evidence is retained separately from your
                reviewed HVM fields.
              </p>
              <div className="table-scroll">
                <table>
                  <tbody>
                    {Object.entries(record.sourceFields).map(
                      ([label, value]) => (
                        <tr key={label}>
                          <th scope="row">{label}</th>
                          <td className="cm-message-text">{value}</td>
                        </tr>
                      ),
                    )}
                  </tbody>
                </table>
              </div>
            </details>
          )}
          <h3>Contact addresses</h3>
          {record.points.length ? (
            record.points.map((p) => (
              <p key={p.id}>
                {p.value} ·{" "}
                {p.leftOrganisation
                  ? "Former work address"
                  : p.suppressed
                    ? "Suppressed"
                    : p.deliverability}
              </p>
            ))
          ) : (
            <p>No contact address recorded. The person is retained.</p>
          )}
          <h3>Interaction history</h3>
          <p>
            Latest 50 recorded interactions. Email content is shown as text;
            links and tracking content are not loaded.
          </p>
          {record.interactions.length ? (
            record.interactions.map((e) => (
              <details key={e.id}>
                <summary>
                  {e.subject} · {new Date(e.date).toLocaleDateString("en-GB")} ·{" "}
                  {e.direction}
                </summary>
                <p className="cm-message-text">{e.body}</p>
                {e.assessment && (
                  <p>
                    Response assessment:{" "}
                    {e.assessment.category.replaceAll("_", " ")} —{" "}
                    {e.assessment.status === "reviewed"
                      ? "reviewed"
                      : "review required"}
                    .
                  </p>
                )}
                {kind === "contacts" &&
                  canWrite &&
                  e.direction === "inbound" && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => {
                        setResponseReview(e.id);
                        setCategory(e.assessment?.category ?? "ordinary_reply");
                        setDeparture("");
                        setPoint("");
                        setRelationship("");
                      }}
                    >
                      Review this response
                    </button>
                  )}
              </details>
            ))
          ) : (
            <p>No interactions recorded.</p>
          )}
          {responseReview && (
            <section className="cm-history" aria-label="Review response">
              <h3>Review incoming response</h3>
              <label className="field">
                Response type
                <select
                  value={category}
                  onChange={(e) => {
                    setCategory(e.target.value);
                    setDeparture("");
                  }}
                >
                  {[
                    "ordinary_reply",
                    "temporary_absence",
                    "objection",
                    "departure",
                    "delivery_failure",
                    "needs_review",
                  ].map((c) => (
                    <option key={c} value={c}>
                      {c.replaceAll("_", " ")}
                    </option>
                  ))}
                </select>
              </label>
              <p>
                Review the original message. Set the contact rules above for an
                objection. Temporary absence does not mean departure. No
                permission to send is inferred from a reply.
              </p>
              <div className="icp-actions">
                {category === "departure" && (
                  <button
                    type="button"
                    onClick={() => setDeparture(responseReview)}
                  >
                    Review former address and employment
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setResponseReview("");
                    setDeparture("");
                  }}
                >
                  Cancel response review
                </button>
              </div>
            </section>
          )}
          {departure && (
            <section aria-label="Confirm departure">
              <h3>Confirm former employment</h3>
              <p>
                Confirm which address is no longer current. This preserves the
                person and suppresses the old address. Leave employment
                unchanged if uncertain.
              </p>
              <div className="icp-grid">
                <label className="field">
                  Former email address
                  <select
                    value={point}
                    onChange={(e) => setPoint(e.target.value)}
                  >
                    <option value="">Choose an address</option>
                    {record.points
                      .filter((p) => p.type === "email")
                      .map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.value}
                        </option>
                      ))}
                  </select>
                </label>
                <label className="field">
                  Employment relationship
                  <select
                    value={relationship}
                    onChange={(e) => setRelationship(e.target.value)}
                  >
                    <option value="">Leave employment unchanged</option>
                    {record.relationships
                      .filter((r) => r.current)
                      .map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.organisationName}
                        </option>
                      ))}
                  </select>
                </label>
              </div>
              <button type="button" onClick={() => setDeparture("")}>
                Cancel departure change
              </button>
            </section>
          )}
          {canWrite && (
            <div className="icp-actions">
              <button
                className="button"
                aria-describedby={saveHelpId}
                disabled={
                  busy || !controls.reason.trim() || (!!departure && !point)
                }
                onClick={() => void save()}
              >
                {busy
                  ? "Saving…"
                  : departure
                    ? "Confirm departure and save rules"
                    : "Save contact rules"}
              </button>
              <span id={saveHelpId} role="status">
                {!controls.reason.trim()
                  ? "Enter a reason for changes to enable Save."
                  : departure && !point
                    ? "Choose the former email address to enable Save."
                    : ""}
              </span>
            </div>
          )}
        </>
      )}
    </section>
  );
}
