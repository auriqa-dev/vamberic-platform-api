import { DataError } from "../data/gateway";
import { useEffect, useState } from "react";
import { z } from "zod";
import type { ContentGateway } from "../data/content-strategy";
import { assetData, type ContentRecord } from "../data/content-strategy-model";
import { useHenryBinding } from "./workspace-henry";
export const planningSchema = z.object({
  scopeVersion: z.number(),
  managedOfferIds: z.array(z.string()),
  offers: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      brandId: z.string(),
      active: z.boolean(),
    }),
  ),
  requirements: z.array(
    z.object({
      requirement: z.object({
        key: z.string(),
        offerId: z.string(),
        offerRevision: z.number(),
        brandId: z.string(),
        offerName: z.string(),
        audienceIds: z.array(z.string()),
        buyerIds: z.array(z.string()),
        title: z.string(),
        category: z.string(),
        priority: z.string(),
        contextHash: z.string(),
        suggestedStage: z.string().default(""),
        suggestedContentTypes: z.array(z.string()).default([]),
      }),
      status: z.string(),
      assets: z.array(
        z.object({
          id: z.string(),
          title: z.string(),
          version: z.number(),
          score: z.number(),
          approved: z.boolean(),
          reason: z.string(),
          contentHash: z.string(),
          contextHash: z.string(),
        }),
      ),
      discovered: z.array(
        z.object({
          url: z.string(),
          title: z.string(),
          score: z.number(),
          reason: z.string(),
        }),
      ),
    }),
  ),
  shared: z.array(
    z.object({
      title: z.string(),
      reason: z.string(),
      offerIds: z.array(z.string()),
    }),
  ),
  attention: z
    .array(
      z.object({
        kind: z.string(),
        title: z.string(),
        offerIds: z.array(z.string()),
        reason: z.string(),
      }),
    )
    .default([]),
  readiness: z.object({
    ready: z.boolean(),
    missing: z.number(),
    needsReview: z.number(),
    note: z.string(),
  }),
});
export type LibraryPlan = z.infer<typeof planningSchema>;
export function LibraryPlanning({
  api,
  workspaceId: w,
  brandId,
  records,
  onChanged,
  onGap,
}: {
  api: ContentGateway;
  workspaceId: string;
  brandId: string;
  records: ContentRecord[];
  onChanged: () => Promise<void>;
  onGap: (instruction: string) => void;
}) {
  const [plan, setPlan] = useState<LibraryPlan>(),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [offer, setOffer] = useState(""),
    [managed, setManaged] = useState<string[] | undefined>();
  async function load() {
    setPlan(
      planningSchema.parse(
        await api.library.planning(w, new AbortController().signal),
      ),
    );
  }
  useEffect(() => {
    const c = new AbortController();
    setError("");
    void api.library
      ?.planning(w, c.signal)
      .then((r) => { if (!c.signal.aborted) setPlan(planningSchema.parse(r)); })
      .catch(() => {
        if (!c.signal.aborted)
          setError("Content requirements could not be loaded.");
      });
    return () => c.abort();
  }, [api, w, records]);
  const requirements =
    plan?.requirements.filter(
      (r) =>
        r.requirement.brandId === brandId &&
        (!offer || r.requirement.offerId === offer),
    ) ?? [];
  useHenryBinding({
    key: "library-planning",
    brandId,
    summary: JSON.stringify({
      contentRequirements: requirements.slice(0, 12),
      shared: plan?.shared.slice(0, 6),
      instruction:
        "These are potential asset matches, not approved proof. Recommend reuse or importing relevant discoveries before a new brief. NBA handles individual contact decisions.",
    }).slice(0, 17000),
  });
  async function associate(
    item: (typeof requirements)[number],
    asset: (typeof item.assets)[number],
    decision: "suggested" | "accepted" | "excluded" = "suggested",
  ) {
    const row = records.find((r) => r.id === asset.id);
    if (!row) return;
    setBusy(true);
    setError("");
    try {
      const data = assetData.parse(row.data);
      const r = item.requirement;
      const associations = data.associations.filter(
        (a) => !(a.offerId === r.offerId && a.requirement === r.title),
      );
      associations.push({
        offerId: r.offerId,
        offerRevision: r.offerRevision,
        audienceIds: r.audienceIds,
        buyerIds: r.buyerIds,
        campaignIds: [],
        requirement: r.title,
        relevance: asset.score,
        reason: asset.reason,
        decision,
        contextHash: r.contextHash,
        contentHash: asset.contentHash,
      });
      await api.save(
        w,
        {
          id: row.id,
          kind: "asset",
          expectedVersion: row.version,
          operation: "associate",
          requestKey: crypto.randomUUID(),
          data: { associations },
        },
        new AbortController().signal,
      );
      await onChanged();
      await load();
    } catch (e) {
      setError(
        e instanceof DataError && e.userMessage ? e.userMessage : "The association could not be saved. Your choice is unchanged; reload the asset before retrying.",
      );
    } finally {
      setBusy(false);
    }
  }
  async function saveScope() {
    if (!plan || !managed) return;
    setBusy(true);
    setError("");
    try {
      await api.library.manageOffers(
        w,
        {
          offerIds: managed,
          expectedVersion: plan.scopeVersion,
          requestKey: crypto.randomUUID(),
        },
        new AbortController().signal,
      );
      await load();
      setManaged(undefined);
    } catch {
      setError(
        "Strategy scope changed or could not be saved. Refresh and try again.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="content-section">
      <h2>Content coverage across offers</h2>
      <p>
        One workspace view of approved offers, shared needs and reusable Library
        material. Recommendations do not change approved strategy decisions. Each item below is a content need, with possible Library assets underneath it. Confirm relevance when an asset supports that need, exclude unsuitable matches, or prepare a brief for new content. “Needs improvement” can mean the asset needs review, approval or stronger evidence; it is not a judgement that your offer is wrong.
      </p>
      {error && <p role="alert">{error}</p>}
      <details>
        <summary>Managed offers for this workspace</summary>
        <p>Changing scope preserves historical decisions and shared assets.</p>
        {plan?.offers
          .filter((o) => o.active)
          .map((o) => (
            <label className="content-check" key={o.id}>
              <input
                type="checkbox"
                checked={(managed ?? plan.managedOfferIds).includes(o.id)}
                disabled={busy}
                onChange={(e) =>
                  setManaged((ids) =>
                    e.target.checked
                      ? [...(ids ?? plan.managedOfferIds), o.id]
                      : (ids ?? plan.managedOfferIds).filter(
                          (id) => id !== o.id,
                        ),
                  )
                }
              />
              {o.name}
            </label>
          ))}
        <button disabled={busy || !managed} onClick={() => void saveScope()}>
          Save managed offers
        </button>
      </details>
      <label>
        Offer
        <select value={offer} onChange={(e) => setOffer(e.target.value)}>
          <option value="">All active offers in this brand</option>
          {plan?.offers
            .filter((o) => o.active && o.brandId === brandId)
            .map((o) => (
              <option key={o.id} value={o.id}>
                {o.name}
              </option>
            ))}
        </select>
      </label>
      {plan && (
        <p>
          {requirements.filter((r) => r.status === "available").length}{" "}
          available ·{" "}
          {
            requirements.filter((r) => r.status === "discovered_not_imported")
              .length
          }{" "}
          discovered, not imported ·{" "}
          {requirements.filter((r) => r.status === "needs_improvement").length}{" "}
          need improvement ·{" "}
          {requirements.filter((r) => r.status === "missing").length} missing
        </p>
      )}
      {!requirements.length && (
        <p>
          No approved offer requirements are available for this selection. Add
          evidence requirements and buyer questions through Offer Architecture.
        </p>
      )}
      <div className="content-records">
        {requirements.map((item) => (
          <article className="content-record" key={item.requirement.key}>
            <header>
              <h3>{item.requirement.title}</h3>
              <span>{item.status.replaceAll("_", " ")}</span>
            </header>
            <p>
              {item.requirement.offerName} · {item.requirement.category} ·{" "}
              {item.requirement.priority} priority
            </p>
            {item.requirement.suggestedStage && (
              <p className="small muted">
                Suggested: {item.requirement.suggestedStage} ·{" "}
                {item.requirement.suggestedContentTypes.join(" or ")}. Refine
                this in the strategy or brief.
              </p>
            )}
            {item.assets.map((asset) => (
              <div key={asset.id} className="content-match">
                <strong>Candidate asset: {asset.title}</strong>
                <p>{asset.reason}</p><p className="small muted">Confirming relevance links this asset to the requirement. It does not approve the content for external use.</p>
                <div className="content-actions">
                  <button
                    disabled={busy}
                    onClick={() => void associate(item, asset)}
                  >
                    Keep as a possible match
                  </button>
                  <button
                    disabled={busy}
                    onClick={() => void associate(item, asset, "accepted")}
                  >
                    Confirm relevance
                  </button>
                  <button
                    disabled={busy}
                    onClick={() => void associate(item, asset, "excluded")}
                  >
                    Exclude this match
                  </button>
                </div>
              </div>
            ))}
            {item.discovered.map((p) => (
              <p key={p.url}>
                <a href={p.url} target="_blank" rel="noreferrer">
                  {p.title || p.url}
                </a>{" "}
                — {p.reason}
              </p>
            ))}
            {item.status !== "available" && (
              <button
                onClick={() =>
                  onGap(
                    `Prepare an execution brief for ${item.requirement.offerName}: ${item.requirement.title}. First consider the suggested Library assets and discovered pages. Do not assume missing evidence is proven.`,
                  )
                }
              >
                Prepare brief for this need
              </button>
            )}
          </article>
        ))}
      </div>
      {plan?.shared.length ? (
        <details>
          <summary>Shared content opportunities</summary>
          {plan.shared.map((s, i) => (
            <p key={i}>
              {s.title} — {s.reason}
            </p>
          ))}
        </details>
      ) : null}
      {plan?.attention.length ? (
        <details>
          <summary>Priorities and messages to review</summary>
          {plan.attention
            .filter((a) =>
              a.offerIds.some((id) =>
                requirements.some((r) => r.requirement.offerId === id),
              ),
            )
            .map((a, i) => (
              <p key={i}>
                <strong>{a.title}</strong> — {a.reason}
              </p>
            ))}
          <p>
            Adjust production priorities in the strategy. These checks do not
            change approved decisions.
          </p>
        </details>
      ) : null}
      <p className="small muted">{plan?.readiness.note}</p>
    </section>
  );
}
