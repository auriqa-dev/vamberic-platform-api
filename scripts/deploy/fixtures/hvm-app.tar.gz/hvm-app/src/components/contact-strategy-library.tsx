import { useHenryBinding, henryFields, applyHenryFields } from "./workspace-henry";
import { useEffect, useState } from "react";
import type {
  StrategyGateway,
  StrategyPolicy,
  StrategyTemplate,
} from "../data/contact-strategy";
import "../styles/contact-strategy.css";
export function ContactStrategyLibrary({
  api,
  w,
}: {
  api: StrategyGateway;
  w: string;
}) {
  const [newKey, setNewKey] = useState<string>();
  const [newName, setNewName] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [reviews, setReviews] = useState<
    NonNullable<Awaited<ReturnType<StrategyGateway["list"]>>["reviews"]>
  >([]);
  const [recent, setRecent] = useState(false);
  const [instruction, setInstruction] = useState(""),
    [proposal, setProposal] = useState<{
      statement: string;
      explanation: string;
      conflicts: string[];
      questions: string[];
    }>(),
    [canInterpret, setCanInterpret] = useState(false);
  const [templates, setTemplates] = useState<StrategyTemplate[]>([]),
    [policies, setPolicies] = useState<StrategyPolicy[]>([]),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false),
    [loading, setLoading] = useState(true),
    [filter, setFilter] = useState("all"),
    [editing, setEditing] = useState<string>(),
    [statement, setStatement] = useState("");
  async function load(signal: AbortSignal) {
    const r = await api.list(w, signal);
    if (!signal.aborted) {
      setReviews(r.reviews ?? []);
      setCanInterpret(r.interpretationAvailable ?? false);
      setTemplates(r.templates);
      setPolicies(r.policies);
    }
  }
  useEffect(() => {
    const c = new AbortController();
    setLoading(true);
    setError("");
    setTemplates([]);
    setPolicies([]);
    setEditing(undefined);
    setNewKey(undefined);
    setNewName("");
    setSelected([]);
    setReviews([]);
    setProposal(undefined);
    void load(c.signal)
      .catch(() => {
        if (!c.signal.aborted)
          setError("Contact strategies could not be loaded. Please retry.");
      })
      .finally(() => {
        if (!c.signal.aborted) setLoading(false);
      });
    return () => c.abort();
  }, [api, w]); // eslint-disable-line react-hooks/exhaustive-deps
  function history(t: StrategyTemplate) {
    return policies
      .filter((p) => p.key === t.key)
      .sort((a, b) => b.version - a.version);
  }
  function review(t: StrategyTemplate) {
    return reviews
      .filter((r) => r.key === t.key)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
  }
  function conflict(t: StrategyTemplate) {
    const head = history(t)[0];
    return Boolean(
      (head &&
        head.source.reference !==
          `hvm_contact_strategy_template:${t.id}:v${t.version}`) ||
      review(t)?.proposal.conflicts.length,
    );
  }
  async function bulk(op: "deactivate" | "remove") {
    if (
      !window.confirm(
        `${op === "remove" ? "Remove" : "Deactivate"} ${selected.length} selected strategies? History is retained; active strategies must be deactivated before removal.`,
      )
    )
      return;
    setBusy(true);
    setError("");
    setNotice("");
    const failed: string[] = [];
    let count = 0;
    for (const key of selected) {
      const t = templates.find((t) => t.key === key)!;
      try {
        const saved = await api.change(
          w,
          key,
          history(t)[0]?.version ?? 0,
          op,
          undefined,
          new AbortController().signal,
        );
        setPolicies((old) => [...old.filter((p) => p.id !== saved.id), saved]);
        count++;
      } catch {
        failed.push(key);
      }
    }
    setSelected(failed);
    setBusy(false);
    setNotice(
      `${count} strategies ${op === "remove" ? "removed" : "deactivated"}.`,
    );
    if (failed.length)
      setError(
        `${failed.length} selected strategies could not be changed. They remain selected. Refresh to check their versions; deactivate active strategies before removal.`,
      );
  }
  function status(t: StrategyTemplate) {
    const rows = history(t),
      head = rows[0],
      active = rows.find((p) => p.status !== "draft")?.status === "recorded";
    return head?.status === "draft"
      ? active
        ? "Active · changes awaiting approval"
        : "Awaiting approval"
      : head?.status === "recorded"
        ? "Active"
        : head?.status === "withdrawn"
          ? "Inactive"
          : "Available template";
  }
  async function change(
    t: StrategyTemplate,
    op: "save" | "approve" | "deactivate" | "remove",
  ) {
    if (
      (op === "remove" || op === "deactivate" || op === "approve") &&
      !window.confirm(
        op === "approve"
          ? `Approve and activate “${t.name}”? This does not enable communications.`
          : `${op === "remove" ? "Remove" : "Deactivate"} “${t.name}”? Policy history will be retained.`,
      )
    )
      return;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const saved = await api.change(
        w,
        t.key,
        history(t)[0]?.version ?? 0,
        op,
        op === "save" ? statement : undefined,
        new AbortController().signal,
        t.key === newKey ? newName.trim() : undefined,
      );
      if (t.key === newKey) {
        setTemplates(old => old.map(item => item.key === t.key ? {...item, name:newName.trim()} : item));
        setNewKey(undefined);
      }
      setPolicies((old) => [...old.filter((p) => p.id !== saved.id), saved]);
      setEditing(undefined);
      setNotice(
        op === "approve"
          ? "Strategy approved for NBA policy checks. Prospecting and sending permissions are unchanged."
          : "Strategy saved.",
      );
    } catch {
      setError(
        "The strategy could not be changed. It may have changed elsewhere or require deactivation first. Your edits are retained; reload to check the latest version.",
      );
    } finally {
      setBusy(false);
    }
  }
  const categories = [...new Set(templates.map((t) => t.category))];
  async function interpretRule(t: StrategyTemplate) {
    setBusy(true);
    setError("");
    setProposal(undefined);
    try {
      setProposal(
        await api.interpret(
          w,
          t.key,
          `Current wording:\n${statement}\n\nRequested refinement:\n${instruction}`,
          crypto.randomUUID(),
          new AbortController().signal,
          t.key === newKey ? newName.trim() : undefined,
        ),
      );
      if (t.key !== newKey) await load(new AbortController().signal);
    } catch {
      setError(
        "Henry could not prepare the change. Your saved rule is unchanged. You can edit it directly or try again.",
      );
    } finally {
      setBusy(false);
    }
  }
  useHenryBinding({key:"contact-policy",summary:JSON.stringify({policies:templates.map(t=>({key:t.key,name:t.name,status:status(t),clauses:history(t)[0]?.clauses})),editing}),
    editor:editing&&!busy?{key:`policy:${editing}`,title:"Contact policy wording",fields:henryFields(newKey === editing ? {name:newName,statement} : {statement})}:undefined,
    apply:changes=>{const next=applyHenryFields({name:newName,statement},changes);setStatement(next.statement);if(newKey===editing)setNewName(next.name);setProposal(undefined);},
    actions:busy||newKey?[]:templates.map(t=>({id:`policy:${t.key}`,label:`Review ${t.name}`,run:()=>{setEditing(t.key);setStatement(history(t)[0]?.clauses[0]?.statement??t.description);}})),
  });
  return (
    <section className="cs-library" aria-label="Contact strategy library">
      <p>
        Review how your business treats prospects and customers. Templates start
        as drafts.
        NBA checks current approved strategies before progressing actions. Missing evidence or restrictive rules stop the action for review. Approval does not activate prospecting or authorise sending.
      </p>
      <div className="cs-toolbar">
        <button className="button" disabled={busy || loading || Boolean(editing)} onClick={() => {
          const key=`custom_${crypto.randomUUID().replaceAll("-", "")}`;
          setNewKey(key);setNewName("");setEditing(key);setStatement("");setInstruction("");setProposal(undefined);setError("");setNotice("");setFilter("all");
          setTemplates(old=>[{id:key,key,version:1,category:"Your strategies",name:"New strategy",description:"",type:"contact",configuration:["Applicability, exceptions and intended outcome"]},...old]);
        }}>Add strategy</button>
        <label>
          Show strategies
          <select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="all">All strategies</option>
            <option>Active</option>
            <option>Awaiting approval</option>
            <option>Available template</option>
            <option>Inactive</option>
            <option>Needs review</option>
          </select>
        </label>
        <label className="cs-check">
          <input
            type="checkbox"
            checked={recent}
            onChange={(e) => setRecent(e.target.checked)}
          />
          Recently changed first
        </label>
        {selected.length > 0 && (
          <>
            <span>{selected.length} selected</span>
            <button disabled={busy} onClick={() => void bulk("deactivate")}>
              Deactivate selected
            </button>
            <button disabled={busy} onClick={() => void bulk("remove")}>
              Remove selected
            </button>
          </>
        )}
        <button
          disabled={busy || loading || Boolean(newKey)}
          onClick={() => {
            setError("");
            void load(new AbortController().signal).catch(() =>
              setError("Unable to reload strategies."),
            );
          }}
        >
          Refresh
        </button>
      </div>
      {loading && <p role="status">Loading strategies…</p>}
      {error && <p role="alert">{error}</p>}
      {notice && <p role="status">{notice}</p>}
      {policies.some((p) => !templates.some((t) => t.key === p.key)) && (
        <details>
          <summary>Existing client policies — preserved for review</summary>
          <p>
            These policies have no reviewed template mapping. They remain
            unchanged; consider them when reviewing new strategies.
          </p>
          {policies
            .filter((p) => !templates.some((t) => t.key === p.key))
            .map((p) => (
              <article key={p.id}>
                <h3>
                  {p.key} · version {p.version} · {p.status}
                </h3>
                {p.clauses.map((c) => (
                  <p key={c.key}>{c.statement}</p>
                ))}
              </article>
            ))}
        </details>
      )}
      {categories.map((category) => {
        const matches = templates.filter(
          (t) =>
            t.category === category &&
            (filter === "all" ||
              (filter === "Needs review"
                ? conflict(t)
                : status(t).includes(filter))),
        );
        if (recent)
          matches.sort((a, b) =>
            (history(b)[0]?.createdAt ?? "").localeCompare(
              history(a)[0]?.createdAt ?? "",
            ),
          );
        return matches.length ? (
          <section key={category}>
            <h2>{category}</h2>
            <div className="cs-grid">
              {matches.map((t) => {
                const rows = history(t),
                  head = rows[0],
                  active =
                    rows.find((p) => p.status !== "draft")?.status ===
                    "recorded";
                return (
                  <article key={t.id} className="cs-item">
                    {head && (
                      <label className="cs-check">
                        <input
                          type="checkbox"
                          aria-label={`Select ${t.name}`}
                          disabled={busy || Boolean(newKey && newKey !== t.key)}
                          checked={selected.includes(t.key)}
                          onChange={(e) =>
                            setSelected((old) =>
                              e.target.checked
                                ? [...old, t.key]
                                : old.filter((k) => k !== t.key),
                            )
                          }
                        />
                        Select
                      </label>
                    )}
                    <div className="cs-meta">
                      {t.key.startsWith("custom_") ? `Your strategy · ${head ? status(t) : "Unsaved draft"}` : `${t.id} · Template ${t.version} · ${status(t)}`}
                    </div>
                    <h3>{t.name}</h3>
                    {conflict(t) && (
                      <p role="note">
                        Needs review: check the template mapping or Henry’s
                        concerns before approving this rule.
                      </p>
                    )}
                    {review(t) && (
                      <details>
                        <summary>Henry’s latest review</summary>
                        <p>{review(t)!.proposal.explanation}</p>
                        {[
                          ...review(t)!.proposal.conflicts,
                          ...review(t)!.proposal.questions,
                        ].map((v, i) => (
                          <p key={i}>{v}</p>
                        ))}
                      </details>
                    )}
                    {editing === t.key ? (
                      <>
                        {t.key === newKey && <label>Strategy name<input autoFocus maxLength={160} value={newName} onChange={e=>setNewName(e.target.value)}/></label>}
                        <label>
                          Business rule
                          <textarea
                            rows={5}
                            maxLength={2000}
                            value={statement}
                            onChange={(e) => setStatement(e.target.value)}
                          />
                        </label>
                        {canInterpret && (
                          <div className="cs-henry">
                            <label>
                              Ask Henry to refine this rule
                              <textarea
                                rows={3}
                                maxLength={3000}
                                value={instruction}
                                onChange={(e) => setInstruction(e.target.value)}
                              />
                            </label>
                            <button
                              disabled={busy || !instruction.trim() || (t.key === newKey && !newName.trim())}
                              onClick={() => void interpretRule(t)}
                            >
                              Prepare changes
                            </button>
                            {proposal && (
                              <div>
                                <h4>Proposed rule</h4>
                                <p>{proposal.statement}</p>
                                <p>{proposal.explanation}</p>
                                {[
                                  ...proposal.conflicts,
                                  ...proposal.questions,
                                ].map((q, i) => (
                                  <p key={i}>{q}</p>
                                ))}
                                <button
                                  disabled={busy || Boolean(newKey && newKey !== t.key)}
                                  onClick={() => {
                                    setStatement(proposal.statement);
                                    setProposal(undefined);
                                  }}
                                >
                                  Use proposed wording
                                </button>
                                <p>
                                  Review and save the draft before approval.
                                </p>
                              </div>
                            )}
                          </div>
                        )}
                      </>
                    ) : (
                      <p>{head?.clauses[0]?.statement ?? t.description}</p>
                    )}
                    <p className="cs-meta">
                      Review: {t.configuration.join("; ")}.
                    </p>
                    <div className="cs-actions">
                      {editing === t.key ? (
                        <>
                          <button
                            disabled={busy || Boolean(newKey && newKey !== t.key)}
                            onClick={() => {setEditing(undefined);if(t.key===newKey){setTemplates(old=>old.filter(item=>item.key!==newKey));setNewKey(undefined);}}}
                          >
                            Cancel
                          </button>
                          <button
                            className="button"
                            disabled={busy || !statement.trim() || (t.key === newKey && !newName.trim())}
                            onClick={() => void change(t, "save")}
                          >
                            Save draft
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            disabled={busy || Boolean(newKey)}
                            onClick={() => {
                              setProposal(review(t)?.proposal);
                              setInstruction("");
                              setEditing(t.key);
                              setStatement(
                                head?.clauses[0]?.statement ?? t.description,
                              );
                              setError("");
                            }}
                          >
                            Review / edit
                          </button>
                          {head?.status === "draft" && (
                            <button
                              disabled={busy || Boolean(newKey && newKey !== t.key)}
                              onClick={() => void change(t, "approve")}
                            >
                              Approve and activate
                            </button>
                          )}
                          {active && (
                            <button
                              disabled={busy || Boolean(newKey && newKey !== t.key)}
                              onClick={() => void change(t, "deactivate")}
                            >
                              Deactivate
                            </button>
                          )}
                          {head && !active && head.status !== "withdrawn" && (
                            <button
                              disabled={busy || Boolean(newKey && newKey !== t.key)}
                              onClick={() => void change(t, "remove")}
                            >
                              Remove
                            </button>
                          )}
                        </>
                      )}
                    </div>
                    {t.objective && (
                      <details>
                        <summary>About this template</summary>
                        <p>{t.objective}</p>
                        <p>{t.applicability}</p>
                        <p>{t.enforcement}</p>
                      </details>
                    )}
                    {rows.length > 0 && (
                      <details>
                        <summary>Version history ({rows.length})</summary>
                        <ul>
                          {rows.map((p) => (
                            <li key={p.id}>
                              Version {p.version} · {p.status} ·{" "}
                              {new Date(p.createdAt).toLocaleDateString(
                                "en-GB",
                              )}
                            </li>
                          ))}
                        </ul>
                      </details>
                    )}
                  </article>
                );
              })}
            </div>
          </section>
        ) : null;
      })}
    </section>
  );
}
