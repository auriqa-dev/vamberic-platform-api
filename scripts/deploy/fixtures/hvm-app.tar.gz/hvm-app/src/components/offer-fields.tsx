import { CurrencySelect } from "./currency-select";
import {
  useId,
  useEffect,
  useRef,
  useState,
  createContext,
  useContext,
} from "react";
import type { Fields, Json } from "../data/offer";
export const OfferValidation = createContext(false);
export type FieldSpec = {
  bsonType?: string | string[];
  enum?: string[];
  properties?: Record<string, FieldSpec>;
  items?: FieldSpec;
  required?: string[];
  maxLength?: number;
  maxItems?: number;
  minimum?: number;
  maximum?: number;
};
const labels: Record<string, string> = {
  conversionOutcome: "Desired conversion outcome",
  intermediateOutcomes: "Meaningful intermediate outcomes",
  qualificationCriteria: "Essential qualification criteria and supporting evidence",
  desirableQualification: "Desirable qualification information",
  acceptableUnknowns: "Information that may remain unknown",
  qualificationDisqualifiers: "Qualification disqualifiers",
  humanReviewTriggers: "When a person should review",
  salesReadiness: "Ready for a useful sales conversation when",
  handoverRecipient: "Handover person or team",
  handoverRequirements: "Information to include in a handover",
  afterHandover: "Next step after handover",
  bookingUrl: "Booking page URL",
  meetingPurpose: "Meeting purpose",

  headlineProposition: "Headline proposition",
  valueProposition: "Value proposition",
  promise: "Proposed promise",
  commercialTerms: "Pricing & terms",
  commercialEffect: "Component pricing",
  amountMinor: "Amount in minor currency units (for example 1995 = £19.95)",
  currency: "Currency code",
  whyChooseThisOffer: "Why choose this offer?",
  afterResponse: "After the first response",
  afterPurchase: "After purchase",
  primaryCallToAction: "Primary next step",
  secondaryCallToAction: "Alternative next step",
  weaknessesGaps: "Limitations and gaps",
  sourceReference: "Source",
  unknowns: "Details to clarify",
  reference: "Source URL or reference",
  observedAt: "Source date (ISO format)",
  researchedAt: "Research date (ISO format)",
};
export function fieldLabel(k: string) {
  return (
    labels[k] ||
    k
      .replace(/([A-Z])/g, " $1")
      .replaceAll("_", " ")
      .replace(/^./, (x) => x.toUpperCase())
  );
}
export const listLines = (v: string) =>
  v
    .split("\n")
    .map((x) => x.trim())
    .filter(Boolean);
const isNumber = (s: FieldSpec) =>
  [s.bsonType]
    .flat()
    .some((x) => ["int", "long", "double", "decimal"].includes(x ?? ""));
export function OfferLines({
  value,
  onChange,
  disabled,
  id,
  rows = 3,
  invalid,
  describedBy,
}: {
  value: string[];
  onChange: (v: string[]) => void;
  disabled?: boolean;
  id?: string;
  rows?: number;
  invalid?: boolean;
  describedBy?: string;
}) {
  const canonical = value.join("\n"),
    last = useRef(canonical),
    [text, setText] = useState(canonical);
  useEffect(() => {
    if (canonical !== last.current) {
      last.current = canonical;
      setText(canonical);
    }
  }, [canonical]);
  return (
    <textarea
      id={id}
      aria-invalid={invalid || undefined}
      aria-describedby={describedBy}
      rows={rows}
      disabled={disabled}
      value={text}
      onChange={(e) => {
        setText(e.target.value);
        const next = listLines(e.target.value);
        last.current = next.join("\n");
        onChange(next);
      }}
    />
  );
}
function initial(s: FieldSpec, name = ""): Json {
  if (name === "key") return "entry_" + crypto.randomUUID().replaceAll("-", "");
  if (name === "observedAt" || name === "researchedAt")
    return new Date().toISOString();
  if (s.enum) return "";
  if (s.bsonType === "object")
    return Object.fromEntries(
      (s.required ?? []).map((k) => [k, initial(s.properties![k]!, k)]),
    );
  if (s.bsonType === "array") return [];
  if (s.bsonType === "bool") return false;
  if (isNumber(s)) return 0;
  return "";
}
export function OfferField({
  name,
  spec,
  value,
  onChange,
  disabled = false,
  required = false,
}: {
  name: string;
  spec: FieldSpec;
  value: Json | undefined;
  onChange: (v: Json | undefined) => void;
  disabled?: boolean;
  required?: boolean;
}) {
  const showErrors = useContext(OfferValidation);
  const invalid =
    showErrors &&
    required &&
    (value === undefined ||
      value === null ||
      value === "" ||
      (typeof value === "string" && !value.trim()));
  const id = useId(),
    label = fieldLabel(name);
  const error = invalid ? (
    <small id={id + "error"} className="offer-field-error">
      Enter {label.toLowerCase()}.
    </small>
  ) : null;
  const validation = {
    "aria-invalid": invalid || undefined,
    "aria-describedby": invalid ? id + "error" : undefined,
  };
  if (name === "commercialEffect" && spec.bsonType === "object") {
    const separate = value !== undefined && value !== null;
    return (
      <fieldset className="offer-field-group">
        <legend>Component pricing</legend>
        <label className="offer-check">
          <input
            type="checkbox"
            checked={separate}
            disabled={disabled}
            onChange={(e) => {
              if (e.target.checked) onChange(initial(spec));
              else if (
                window.confirm(
                  "Include this component in the overall offer price? Its separate pricing and terms will be removed when you save. The overall offer pricing will stay unchanged.",
                )
              )
                onChange(undefined);
            }}
          />
          Priced separately
        </label>
        <p className="offer-hint">
          {separate
            ? "Only enter the additional price and terms for this component."
            : "Included in the overall offer price. Set the offer’s pricing in Pricing & terms."}
        </p>
        {separate && (
          <OfferFields
            specs={spec.properties ?? {}}
            required={spec.required}
            value={value as Fields}
            onChange={onChange}
            disabled={disabled}
          />
        )}
      </fieldset>
    );
  }
  if (
    spec.bsonType === "object" &&
    spec.properties?.amountMinor &&
    spec.properties.currency
  ) {
    const money = (value ?? {}) as Fields,
      currency = String(money.currency ?? "");
    let digits = 2;
    try {
      if (currency.length === 3)
        digits =
          new Intl.NumberFormat("en", {
            style: "currency",
            currency,
          }).resolvedOptions().maximumFractionDigits ?? 2;
    } catch {
      /* Incomplete currency while typing. */
    }
    const multiplier = 10 ** digits;
    return (
      <fieldset className="offer-field-group">
        <legend>{label}</legend>
        <div className="offer-fields">
          <label className="offer-field" htmlFor={id + "currency"}>
            Currency
            <CurrencySelect
              aria-invalid={
                (showErrors && value !== undefined && !currency.trim()) ||
                undefined
              }
              aria-describedby={
                showErrors && value !== undefined && !currency.trim()
                  ? id + "currency-error"
                  : undefined
              }
              id={id + "currency"}
              disabled={disabled}
              value={currency}
              onChange={(e) =>
                onChange({ ...money, currency: e.target.value.toUpperCase() })
              }
            />
            {showErrors && value !== undefined && !currency.trim() && (
              <small id={id + "currency-error"} className="offer-field-error">
                Enter a currency code or remove {label.toLowerCase()}.
              </small>
            )}
          </label>
          <label className="offer-field" htmlFor={id}>
            Amount
            <input
              aria-invalid={
                (showErrors &&
                  value !== undefined &&
                  money.amountMinor === undefined) ||
                undefined
              }
              aria-describedby={
                showErrors &&
                value !== undefined &&
                money.amountMinor === undefined
                  ? id + "amount-error"
                  : undefined
              }
              id={id}
              type="number"
              min={0}
              step={1 / multiplier}
              disabled={disabled}
              value={
                money.amountMinor === undefined
                  ? ""
                  : Number(money.amountMinor) / multiplier
              }
              onChange={(e) => {
                const next = { ...money };
                if (e.target.value === "") delete next.amountMinor;
                else
                  next.amountMinor = Math.round(
                    Number(e.target.value) * multiplier,
                  );
                onChange(next);
              }}
            />
            {showErrors &&
              value !== undefined &&
              money.amountMinor === undefined && (
                <small id={id + "amount-error"} className="offer-field-error">
                  Enter an amount or remove {label.toLowerCase()}.
                </small>
              )}
          </label>
        </div>
        {!disabled && value !== undefined && (
          <button type="button" onClick={() => onChange(undefined)}>
            Remove {label.toLowerCase()}
          </button>
        )}
      </fieldset>
    );
  }
  if (spec.bsonType === "object")
    return (
      <fieldset className="offer-field-group">
        <legend>{label}</legend>
        <OfferFields
          required={value !== undefined || required ? spec.required : []}
          specs={spec.properties ?? {}}
          value={(value || {}) as Fields}
          onChange={onChange}
          disabled={disabled}
        />
      </fieldset>
    );
  if (spec.bsonType === "array" && spec.items?.bsonType === "object") {
    const rows = (value ?? []) as Fields[];
    return (
      <fieldset className="offer-field-group">
        <legend>{label}</legend>
        {rows.map((row, i) => (
          <div className="offer-array-item" key={i}>
            <OfferFields
              required={spec.items!.required}
              specs={spec.items!.properties ?? {}}
              value={row}
              onChange={(v) => onChange(rows.map((x, n) => (n === i ? v : x)))}
              disabled={disabled}
            />
            {!disabled && (
              <button
                type="button"
                onClick={() => onChange(rows.filter((_, n) => n !== i))}
              >
                Remove {label.toLowerCase()} {i + 1}
              </button>
            )}
          </div>
        ))}
        {!disabled && (
          <button
            type="button"
            disabled={rows.length >= (spec.maxItems ?? 40)}
            onClick={() => onChange([...rows, initial(spec.items!)])}
          >
            Add {label.toLowerCase()}
          </button>
        )}
        {!rows.length && disabled && <p>None specified.</p>}
      </fieldset>
    );
  }
  if (spec.bsonType === "array")
    return (
      <label className="offer-field" htmlFor={id}>
        {label}
        <OfferLines
          invalid={invalid}
          describedBy={invalid ? id + "error" : undefined}
          id={id}
          disabled={disabled}
          value={(value ?? []) as string[]}
          onChange={onChange}
        />
        <small>One item per line.</small>
        {error}
      </label>
    );
  if (spec.enum)
    return (
      <label className="offer-field" htmlFor={id}>
        {label}
        <select
          {...validation}
          id={id}
          disabled={disabled}
          value={String(value ?? "")}
          onChange={(e) => onChange(e.target.value || undefined)}
        >
          <option value="">Not specified</option>
          {spec.enum.map((x) => (
            <option key={x} value={x}>
              {fieldLabel(x)}
            </option>
          ))}
        </select>
        {error}
      </label>
    );
  if (spec.bsonType === "bool")
    return (
      <label className="offer-check">
        <input
          type="checkbox"
          disabled={disabled}
          checked={!!value}
          onChange={(e) => onChange(e.target.checked)}
        />
        {label}
      </label>
    );
  if (isNumber(spec))
    return (
      <label className="offer-field" htmlFor={id}>
        {label}
        <input
          {...validation}
          id={id}
          type="number"
          min={spec.minimum}
          max={spec.maximum}
          disabled={disabled}
          value={value === undefined ? "" : Number(value)}
          onChange={(e) =>
            onChange(e.target.value === "" ? undefined : Number(e.target.value))
          }
        />
        {error}
      </label>
    );
  return (
    <label className="offer-field" htmlFor={id}>
      {label}
      {(spec.maxLength ?? 2000) > 500 ? (
        <textarea
          {...validation}
          id={id}
          rows={3}
          maxLength={spec.maxLength}
          disabled={disabled}
          value={String(value ?? "")}
          onChange={(e) => onChange(e.target.value || undefined)}
        />
      ) : (
        <input
          {...validation}
          id={id}
          maxLength={spec.maxLength}
          disabled={disabled}
          value={String(value ?? "")}
          onChange={(e) => onChange(e.target.value || undefined)}
        />
      )}
      {error}
    </label>
  );
}
export function OfferFields({
  specs,
  value,
  onChange,
  disabled,
  keys,
  required = [],
}: {
  specs: Record<string, FieldSpec>;
  value: Fields;
  onChange: (v: Fields) => void;
  disabled?: boolean;
  keys?: string[];
  required?: string[];
}) {
  return (
    <div className="offer-fields">
      {(keys ?? Object.keys(specs).filter((k) => k !== "key")).map((k) => (
        <OfferField
          key={k}
          name={k}
          required={required.includes(k)}
          spec={specs[k]!}
          value={value[k]}
          disabled={disabled}
          onChange={(v) => {
            const next = { ...value };
            if (v === undefined) delete next[k];
            else next[k] = v;
            onChange(next);
          }}
        />
      ))}
    </div>
  );
}

export function missingOfferFields(
  value: unknown,
  spec: FieldSpec,
  path = "",
): string[] {
  if (value === undefined || value === null) return [];
  if (spec.bsonType === "object") {
    const v = value as Record<string, unknown>;
    return Object.entries(spec.properties ?? {}).flatMap(([k, s]) => {
      const label = path ? path + " → " + fieldLabel(k) : fieldLabel(k);
      if (
        (spec.required ?? []).includes(k) &&
        (v[k] === undefined ||
          v[k] === null ||
          (typeof v[k] === "string" && !v[k].trim()))
      )
        return [label];
      return missingOfferFields(v[k], s, label);
    });
  }
  if (spec.bsonType === "array" && Array.isArray(value))
    return value.flatMap((x, i) =>
      missingOfferFields(x, spec.items ?? {}, path + " " + (i + 1)),
    );
  return [];
}
