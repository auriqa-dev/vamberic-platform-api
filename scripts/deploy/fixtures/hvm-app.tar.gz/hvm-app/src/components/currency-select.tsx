import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
  type SelectHTMLAttributes,
} from "react";
export type CurrencyReference = {
  code: string;
  name: string;
  minorUnits: number | null;
  selectable: boolean;
};
export type CurrencyLoader = (
  signal: AbortSignal,
) => Promise<CurrencyReference[]>;
const CurrencyContext = createContext<{
  rows: CurrencyReference[];
  loading: boolean;
  error: boolean;
  retry: () => void;
}>({ rows: [], loading: false, error: true, retry: () => {} });
export function CurrencyProvider({
  load,
  children,
}: {
  load?: CurrencyLoader;
  children: ReactNode;
}) {
  const [rows, setRows] = useState<CurrencyReference[]>([]),
    [loading, setLoading] = useState(true),
    [error, setError] = useState(false),
    [revision, setRevision] = useState(0);
  useEffect(() => {
    const c = new AbortController();
    setLoading(true);
    setError(false);
    if (!load) {
      setLoading(false);
      setError(true);
      return;
    }
    load(c.signal)
      .then((data) => {
        if (!c.signal.aborted) setRows(data);
      })
      .catch(() => {
        if (!c.signal.aborted) setError(true);
      })
      .finally(() => {
        if (!c.signal.aborted) setLoading(false);
      });
    return () => c.abort();
  }, [load, revision]);
  return (
    <CurrencyContext.Provider
      value={{ rows, loading, error, retry: () => setRevision((x) => x + 1) }}
    >
      {children}
    </CurrencyContext.Provider>
  );
}
export function CurrencySelect(props: SelectHTMLAttributes<HTMLSelectElement>) {
  const { rows, loading, error, retry } = useContext(CurrencyContext),
    value = String(props.value ?? "");
  return (
    <>
      <select {...props} disabled={props.disabled || loading || error}>
        <option value="">
          {loading ? "Loading currencies…" : "Choose a currency"}
        </option>
        {value && !rows.some((r) => r.code === value) && (
          <option value={value}>{value} — saved currency</option>
        )}
        {rows.map((r) => (
          <option
            key={r.code}
            value={r.code}
            disabled={!r.selectable && r.code !== value}
          >
            {r.code} — {r.name}
            {!r.selectable ? " (reference only)" : ""}
          </option>
        ))}
      </select>
      {error && (
        <small role="status">
          Currency list could not be loaded. Your saved value is retained.{" "}
          <button type="button" onClick={retry}>
            Retry currencies
          </button>
        </small>
      )}
    </>
  );
}
