import { OfferMethodologyChoice } from "./offer-methodology-choice";
import {
  useHenryBinding,
  useHenryObjective,
  henryFields,
  applyHenryFields,
} from "./workspace-henry";
import { useEffect, useRef, useState } from "react";
import type { OfferGateway } from "../data/offer";
import { briefFields, type BriefJob } from "../data/offer/brief";
export function OfferBrief({
  api,
  w,
  product,
  onGenerate,
  generationDisabled = false,
  researching = false,
  researchingIndex,
  selectedIndex,
  onChange,
  onDirty,
  onWorking,
}: {
  researching?: boolean;
  researchingIndex?: number;
  onWorking?: (working: boolean) => void;
  selectedIndex?: number;
  onChange?: (job: BriefJob | null) => void;
  onDirty?: (dirty: boolean) => void;
  api: OfferGateway;
  w: string;
  product: string;
  onGenerate: (
    value: { id: string; index: number; existingOfferId?: string },
    allowCommercialChanges: boolean,
  ) => void;
  generationDisabled?: boolean;
}) {
  const objective = useRef(useHenryObjective()).current;
  const [job, setJob] = useState<BriefJob | null>(null),
    [intent, setIntent] = useState(objective),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState<BriefJob["interpretation"]>();
  useEffect(() => {
    if (job) onChange?.(job);
  }, [job, onChange]);
  useEffect(() => {
    onDirty?.(
      job
        ? intent !== job.input.intent ||
            JSON.stringify(draft) !== JSON.stringify(job.interpretation)
        : intent !== objective,
    );
  }, [job, intent, draft, onDirty, objective]);
  useEffect(() => {
    onWorking?.(busy);
    return () => onWorking?.(false);
  }, [busy, onWorking]);
  const request = useRef({ intent: "", key: "" });
  const lock = useRef(false);
  useEffect(() => {
    const c = new AbortController();
    api
      .latestBrief(w, product, c.signal)
      .then((j) => {
        if (!c.signal.aborted) {
          setJob(j);
          setIntent(j?.input.intent ?? objective);
          setDraft(j?.interpretation);
        }
      })
      .catch(() => {
        if (!c.signal.aborted)
          setError(
            "Your previous brief could not be loaded. Reopen this page to try again.",
          );
      });
    return () => c.abort();
  }, [api, w, product, objective]); // The objective seeds a new brief; later conversation turns must not overwrite edits.

  useEffect(() => {
    if (job?.status !== "interpreting") return;
    const c = new AbortController();
    let timer: ReturnType<typeof setTimeout>;
    const poll = async () => {
      try {
        const next = await api.brief(w, job.id, c.signal);
        if (c.signal.aborted) return;
        setJob(next);
        setDraft(next.interpretation);
        if (["failed", "interrupted"].includes(next.status))
          request.current = { intent: "", key: "" };
        if (next.status === "interpreting") timer = setTimeout(poll, 1500);
      } catch {
        if (!c.signal.aborted) {
          setError(
            "Henry’s brief could not be refreshed. Reopen this page to recover it.",
          );
        }
      }
    };
    timer = setTimeout(poll, 1000);
    return () => {
      c.abort();
      clearTimeout(timer);
    };
  }, [api, w, job?.id, job?.status]);
  async function run(action: () => Promise<BriefJob>) {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError("");

    try {
      const j = await action();
      setJob(j);
      setDraft(j.interpretation);
    } catch {
      setError(
        "We couldn’t save this step. Your input is retained. Reopen the brief if it changed elsewhere.",
      );
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  const pending = busy || generationDisabled || job?.status === "interpreting";
  useHenryBinding({
    key: "offer-brief",
    priority: 60,
    summary: JSON.stringify({ product, intent, interpretation: draft }),
    editor: !pending
      ? {
          key: `offer-brief:${product}:${job?.id ?? "new"}`,
          title: "Offer objective",
          fields: henryFields({ intent }),
        }
      : undefined,
    apply: (changes) => setIntent(applyHenryFields({ intent }, changes).intent),
  });
  return (
    <section aria-label="Develop your offer with Henry">
      <details open={!draft}>
        <summary>Commercial objective</summary>
        <h3>What would you like to achieve with this offer?</h3>
        <p>
          Tell me who you want to reach, what you're trying to achieve, how you
          envisage selling it, and any commercial parameters you already have in
          mind. You can describe this in your own words — we'll develop and
          validate the offer together.
        </p>
        <label className="offer-field">
          Your commercial intent
          <textarea
            value={intent}
            rows={4}
            maxLength={6000}
            disabled={pending}
            onChange={(e) => {
              setIntent(e.target.value);
            }}
          />
        </label>
        {(!draft || intent !== job?.input.intent) && (
          <div className="offer-toolbar">
            <button
              disabled={pending || !intent.trim()}
              onClick={() =>
                void run(() => {
                  if (request.current.intent !== intent)
                    request.current = { intent, key: crypto.randomUUID() };
                  return api.interpretBrief(
                    w,
                    {
                      offeringId: product,
                      intent,
                      requestKey: request.current.key,
                    },
                    new AbortController().signal,
                  );
                })
              }
            >
              {draft ? "Revise offer brief" : "Prepare offer brief"}
            </button>
          </div>
        )}
      </details>
      {error && <p role="alert">{error}</p>}
      {job?.status === "interpreting" && (
        <p role="status">
          Henry is preparing your offer brief… You can return to it later.
        </p>
      )}
      {(job?.status === "failed" || job?.status === "interrupted") && (
        <p role="alert">
          The brief could not be completed. Your offers are unchanged. Change
          your intent or start again.
        </p>
      )}
      {draft && job && (
        <>
          <p>{draft.explanation}</p>
          {draft.offers.length > 1 && (
            <p>
              Henry has identified {draft.offers.length} separate offers.
              Confirm this separation below; each offer will be developed
              independently.
            </p>
          )}
          {draft.offers.map((offer, index) =>
            selectedIndex !== undefined && index !== selectedIndex ? null : (
              <section className="offer-brief-card" key={index}>
                <h4>{offer.brief.name}</h4>
                <p>
                  {offer.existingOfferId
                    ? "Refine an existing offer"
                    : "Proposed new offer"}
                </p>
                {job.status === "review" ? (
                  <>
                    <label className="offer-field">
                      Offer name
                      <input
                        value={offer.brief.name}
                        onChange={(e) =>
                          setDraft({
                            ...draft,
                            offers: draft.offers.map((o, i) =>
                              i === index
                                ? {
                                    ...o,
                                    brief: { ...o.brief, name: e.target.value },
                                  }
                                : o,
                            ),
                          })
                        }
                      />
                    </label>
                    <div className="offer-fields">
                      {Object.entries(briefFields).map(([key, label]) => {
                        const field = key as keyof typeof briefFields;
                        return (
                          <label className="offer-field" key={key}>
                            {label}
                            <textarea
                              rows={3}
                              value={offer.brief[field]
                                .map((s) => s.text)
                                .join("\n")}
                              onChange={(e) =>
                                setDraft({
                                  ...draft,
                                  offers: draft.offers.map((o, i) =>
                                    i === index
                                      ? {
                                          ...o,
                                          brief: {
                                            ...o.brief,
                                            [field]: e.target.value
                                              .split("\n")
                                              .filter(Boolean)
                                              .map(
                                                (text) =>
                                                  o.brief[field].find(
                                                    (s) => s.text === text,
                                                  ) ?? {
                                                    text,
                                                    origin:
                                                      field ===
                                                      "marketHypothesis"
                                                        ? "hypothesis"
                                                        : field ===
                                                            "questionsAndResearch"
                                                          ? "unknown"
                                                          : "queen_supplied",
                                                  },
                                              ),
                                          },
                                        }
                                      : o,
                                  ),
                                })
                              }
                            />
                            <small>
                              {offer.brief[field]
                                .map((s) => s.origin.replaceAll("_", " "))
                                .filter((x, i, a) => a.indexOf(x) === i)
                                .join(" · ") || "Not yet established"}
                            </small>
                          </label>
                        );
                      })}
                    </div>
                  </>
                ) : (
                  <details open={selectedIndex !== undefined}>
                    <summary>Confirmed commercial brief</summary>
                    {Object.entries(briefFields).map(([key, label]) => (
                      <div key={key}>
                        <strong>{label}</strong>
                        <ul>
                          {offer.brief[key as keyof typeof briefFields].map(
                            (s, i) => (
                              <li key={i}>
                                {s.text}{" "}
                                <small>({s.origin.replaceAll("_", " ")})</small>
                              </li>
                            ),
                          )}
                        </ul>
                      </div>
                    ))}
                  </details>
                )}
                {job.status === "confirmed" && (
                  <OfferMethodologyChoice
                    api={api}
                    w={w}
                    job={job}
                    index={index}
                    pending={pending}
                    researching={researching && index === researchingIndex}
                    run={run}
                    onGenerate={onGenerate}
                  />
                )}
              </section>
            ),
          )}
          {job.status === "review" && (
            <div className="offer-toolbar">
              {selectedIndex !== undefined && draft.offers.length > 1 && (
                <p>
                  Confirmation applies to all {draft.offers.length} proposed
                  briefs. Review them together via “Discuss offers with Henry”
                  on the overview before confirming.
                </p>
              )}
              <button
                className="button-primary"
                disabled={
                  pending ||
                  (selectedIndex !== undefined && draft.offers.length > 1)
                }
                onClick={() =>
                  void run(() =>
                    api.confirmBrief(
                      w,
                      {
                        id: job.id,
                        expectedUpdatedAt: job.updatedAt,
                        interpretation: draft,
                      },
                      new AbortController().signal,
                    ),
                  )
                }
              >
                Confirm{" "}
                {draft.offers.length > 1
                  ? "separate offer briefs"
                  : "offer brief"}
              </button>
            </div>
          )}
        </>
      )}
    </section>
  );
}
