import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import type { Measurement } from "../data/measurement";
import "../styles/measurement.css";
const label = (s: string) => s.replaceAll("_", " ");
export function MeasurementPanel({
  data,
  compact = false,
  headingLevel = 2,
}: {
  data?: Measurement;
  compact?: boolean;
  headingLevel?: 2 | 4;
}) {
  const Heading = headingLevel === 4 ? "h4" : "h2";
  const [days, setDays] = useState("all");
  const location = useLocation();
  if (!data) return null;
  const root = location.pathname.replace(
    /\/(communications|campaigns|nba|contacts|performance)(?:\/.*)?$/,
    "",
  );
  const workspace = new URLSearchParams(location.search).get("workspace");
  const workspaceQuery = workspace ? `&workspace=${encodeURIComponent(workspace)}` : "";
  const timeline = data.timeline.filter(
    (e) =>
      days === "all" ||
      Date.parse(e.occurredAt) >= Date.now() - Number(days) * 86400000,
  );
  return (
    <section
      className="panel measurement-panel"
      aria-label="Measurement and feedback"
    >
      <Heading>Measurement and feedback</Heading>
      <p className="muted">
        Updated {new Date(data.updatedAt).toLocaleString("en-GB")}. Refreshed
        with this view; not a live stream.
      </p>
      {data.truncated && (
        <p role="status">
          This view is limited to the latest evidence. Totals below cover that
          evidence, not the entire history.
        </p>
      )}
      {!compact && (
        <>
          <div className="measurement-grid">
            {data.metrics.map((m) => (
              <div key={m.kind}>
                <strong>{m.label}</strong>
                <p>{m.value ?? "Unavailable"}</p>
                <small>{m.unit}</small>
              </div>
            ))}
          </div>
          <p>
            {data.eventCount} outcome records · {data.contactCount} contacts ·{" "}
            {data.organisationCount} organisations.{" "}
            {Date.parse(data.windowStart) === 0
              ? "All loaded history."
              : `Evidence from ${new Date(data.windowStart).toLocaleDateString("en-GB", { timeZone: "UTC" })}${data.windowEnd ? ` to ${new Date(Date.parse(data.windowEnd) - 1).toLocaleDateString("en-GB", { timeZone: "UTC" })}` : ""}.`}
          </p>
        </>
      )}
      <p>
        Gmail acceptance does not prove delivery or reading. Website events are
        browser-reported; forwarded links and scanners can affect attribution.
        Test traffic is excluded.
      </p>
      <details open={compact}>
        <summary>Next-action feedback ({data.feedback.length})</summary>
        {!data.feedback.length && <p>No engagement feedback yet.</p>}
        {data.feedback.map((f) => (
          <article key={f.id} className="measurement-item">
            <strong>
              {f.contactName || "Contact"} · {label(f.state)}
            </strong>
            <p>{f.reason}</p>
            {f.dueAt && (
              <p>
                Reconsider after {new Date(f.dueAt).toLocaleString("en-GB")}
              </p>
            )}
            {!f.campaignId && (
              <p>
                Select an approved campaign before asking NBA to recommend an
                action.
              </p>
            )}
            <Link
              className="button"
              to={`${root}/nba?campaign=${encodeURIComponent(f.campaignId || "")}&contact=${encodeURIComponent(f.contactId)}${workspaceQuery}`}
            >
              Review with NBA
            </Link>
          </article>
        ))}
      </details>
      <details>
        <summary>Outcome timeline and reply review</summary>
        <label>
          Timeline period
          <select value={days} onChange={(e) => setDays(e.target.value)}>
            <option value="all">All loaded evidence</option>
            <option value="30">Last 30 days</option>
            <option value="7">Last 7 days</option>
          </select>
        </label>
        {!timeline.length && <p>No outcomes in this period.</p>}
        {timeline.map((e) => (
          <article key={e.id} className="measurement-item">
            <strong>
              {e.contactName || "Contact"} · {label(e.kind)}
              {e.category ? ` · ${label(e.category)}` : ""}
            </strong>
            <p>
              <time>{new Date(e.occurredAt).toLocaleString("en-GB")}</time> ·{" "}
              {e.fact === "derived"
                ? "Interpretation / derived condition"
                : "Observed event"}
            </p>
            <p>{e.guidance}</p>
            {e.website && (
              <p>
                {label(e.website.identity)} · {label(e.website.automation)} ·{" "}
                {e.website.path || "Email link"}
                {e.website.name ? ` · ${e.website.name}` : ""}
              </p>
            )}
            {e.communicationId && (
              <Link
                className="button"
                to={`${root}/communications?communication=${encodeURIComponent(e.communicationId)}${e.replyId ? `&reply=${encodeURIComponent(e.replyId)}` : ""}${workspaceQuery}`}
              >
                {e.replyId ? "Review reply and evidence" : "View communication"}
              </Link>
            )}
          </article>
        ))}
      </details>
      <p className="muted">
        Outcomes and delivery history are retained. Correct interpretations
        through reply review; corrections do not authorise sending or qualify a
        lead.
      </p>
    </section>
  );
}
