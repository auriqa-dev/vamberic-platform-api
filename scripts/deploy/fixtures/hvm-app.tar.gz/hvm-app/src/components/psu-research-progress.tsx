import type { PsuJob } from "../data/psu";
export function PsuResearchProgress({job}:{job:PsuJob}) {
  const progress=job.progress;
  const messages={reading:"I’m reading the website, including relevant pricing, comparison and product pages.",drafting:"I’m preparing the first suggestions. I’ll continue researching after these appear.",searching:"I’m looking for independent mentions and comparisons.",refining:"I’m bringing the research together and filling in the remaining details."};
  return <>
    {job.status === "generating" && <section className="panel" aria-label="Henry research progress" role="status" aria-live="polite">
      <h2>Henry is working on it</h2>
      <p>{messages[progress?.phase ?? "reading"]}</p>
      {progress && <p>{progress.pagesRead} pages read · up to {progress.maximumPages} pages</p>}
      <p className="muted">You can leave this page and return. The research continues in the background.</p>
    </section>}
    {job.researchIncomplete && <p role="status">The wider research was interrupted. Your early draft is retained below for review; you can save it or generate again.</p>}
    {job.status === "interrupted" && (job.draft || job.companyDraft) && <p role="status">Research stopped before completion. The early suggestions are retained below. Generate again to finish your review.</p>}
    {job.researchUnavailable && <p className="muted">Outside research was unavailable. The draft uses the website pages we could read.</p>}
    {job.status === "review" && job.input.includeWebResearch && !job.researchUnavailable && !job.researchSources?.length && <p className="muted">No matching outside sources were found. Your draft uses the company website.</p>}
    {!!job.researchSources?.length && <details className="panel psu-research-sources"><summary>Independent sources to review</summary><p>These are search suggestions, not verified company facts.</p><ul>{job.researchSources.map(url=><li key={url}><a href={url} target="_blank" rel="noreferrer">{url}</a></li>)}</ul></details>}
  </>;
}
