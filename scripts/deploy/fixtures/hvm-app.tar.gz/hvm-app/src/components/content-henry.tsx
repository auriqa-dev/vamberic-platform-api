import { useState } from "react";
import type { ContentBundle } from "../data/content-strategy";
import { henryResult } from "../data/content-strategy-model";
import type { z } from "zod";

type Reply = z.infer<typeof henryResult>;
export function ContentHenry({
  turns,
  busy,
  available,
  onAsk,
  onReview,
}: {
  turns: NonNullable<ContentBundle["conversations"]>;
  busy: boolean;
  available: boolean;
  onAsk: (message: string, conversationId: string) => Promise<void>;
  onReview: (
    reply: Reply,
    target?: NonNullable<ContentBundle["conversations"]>[number]["target"],
  ) => void;
}) {
  const [message, setMessage] = useState("");
  const [freshId, setFreshId] = useState<string>();
  const conversationId = freshId ?? turns[0]?.conversationId;
  const visible = turns
    .filter((t) => t.conversationId === conversationId)
    .slice()
    .reverse();
  return (
    <section className="content-section content-henry" aria-label="Ask Henry">
      <header className="content-henry-header">
        <div>
          <h2>Ask Henry</h2>
          <p>
            Tell me what you want to achieve. We can work through the strategy
            and brief together, then review the details below.
          </p>
        </div>
        <button
          disabled={busy}
          onClick={() => {
            setFreshId(crypto.randomUUID());
            setMessage("");
          }}
        >
          New conversation
        </button>
      </header>
      {visible.length > 0 && (
        <div
          className="content-conversation"
          role="log"
          aria-label="Conversation with Henry"
        >
          {visible.map((t) => (
            <div key={t.id} className="content-turn">
              <p>
                <strong>You</strong>
                <br />
                {t.instruction}
              </p>
              <p>
                <strong>Henry</strong>
                <br />
                {t.result.reply}
              </p>
              {(t.result.strategy ||
                t.result.brief ||
                t.result.reviewRecordId) && (
                <button
                  disabled={busy}
                  onClick={() => onReview(t.result, t.target)}
                >
                  Review this response
                </button>
              )}
            </div>
          ))}
        </div>
      )}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (busy || !message.trim()) return;
          const id = conversationId ?? crypto.randomUUID();
          setFreshId(id);
          void onAsk(message.trim(), id)
            .then(() => setMessage(""))
            .catch(() => {
              /* Parent displays error; retain message. */
            });
        }}
      >
        <label htmlFor="henry-message">Your message</label>
        <textarea
          id="henry-message"
          rows={3}
          maxLength={6000}
          value={message}
          disabled={busy}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Help us earn editorial coverage using our research, without customer case studies."
        />
        <p className="content-help">
          Henry uses this brand’s approved context and selected evidence.
          Responses are suggestions; saving, approval and delivery remain
          separate steps.
        </p>
        <div className="content-actions">
          <button
            className="button"
            disabled={busy || !available || !message.trim()}
          >
            {busy ? "Working…" : "Ask Henry"}
          </button>
        </div>
        {!available && (
          <p>
            Henry is unavailable at present. You can still use the structured
            views.
          </p>
        )}
      </form>
    </section>
  );
}
