import { useHenryBinding, henryFields, applyHenryFields } from "./workspace-henry";
import { useCallback, useId, useRef, useState } from "react";
import type {
  BrandKitGateway,
  EditableKit,
  KitSection,
} from "../data/brand-kit";
import type { BrandImagesGateway } from "../data/brand-images";
import { DataError } from "../data/gateway";
import { useResource } from "../data/use-resource";
import {
  BrandExpressionEditor,
  expressionTabs,
  type ExpressionTab,
} from "./brand-expression-editor";
import { BrandImages } from "./brand-images";
import { Failure, Loading } from "./ui";

type Field = {
  key: string;
  label: string;
  kind?: "lines" | "weights" | "select" | "input";
  options?: string[];
  max?: number;
  required?: boolean;
  pattern?: string;
};
type Definition = {
  key: KitSection;
  label: string;
  fields: Field[];
  rows?: boolean;
  maxRows?: number;
};
const text = (key: string, label: string, max = 1000): Field => ({
  key,
  label,
  max,
});
const lines = (key: string, label: string): Field => ({
  key,
  label,
  kind: "lines",
});
const role = (options: string[]): Field => ({
  key: "role",
  label: "Usage",
  kind: "select",
  options,
  required: true,
});
export const kitSections: Definition[] = [
  {
    key: "colours",
    label: "Colours",
    rows: true,
    maxRows: 100,
    fields: [
      role(["primary", "secondary", "accent", "surface", "text"]),
      { ...text("name", "Colour name", 100), kind: "input", required: true },
      {
        ...text("hex", "Hex colour", 9),
        required: true,
        pattern: "#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?",
      },
      text("usage", "When to use this colour"),
    ],
  },
  {
    key: "typography",
    label: "Typography",
    rows: true,
    maxRows: 20,
    fields: [
      role(["primary", "secondary", "heading", "body"]),
      { ...text("family", "Font family", 200), kind: "input", required: true },
      {
        key: "weights",
        label: "Font weights (comma-separated, e.g. 400, 700)",
        kind: "weights",
      },
      {
        key: "styles",
        label: "Font styles (one per line: normal, italic, oblique)",
        kind: "lines",
      },
      text("usage", "When to use this font"),
    ],
  },
  {
    key: "visualRules",
    label: "Visual rules",
    fields: [
      text("layout", "Layout"),
      text("spacing", "Spacing"),
      text("borders", "Borders"),
      text("imageTreatment", "Image treatment"),
      text("icons", "Icon rules"),
      text("illustrations", "Illustration rules"),
      lines("do", "Do (one rule per line)"),
      lines("dont", "Avoid (one rule per line)"),
    ],
  },
  {
    key: "voice",
    label: "Tone & voice",
    fields: [
      lines("descriptors", "Tone words (one per line)"),
      lines("principles", "Writing principles (one per line)"),
      text("writingStyle", "Writing style", 5000),
      lines("avoidLanguage", "Language to avoid (one per line)"),
      lines("preferredTerminology", "Preferred language (one per line)"),
    ],
  },
  {
    key: "terminology",
    label: "Terminology",
    fields: [
      lines("productNames", "Product names (one per line)"),
      lines("capabilityNames", "Capability names (one per line)"),
      lines("use", "Terms to use (one per line)"),
      lines("avoid", "Terms to avoid (one per line)"),
      lines("namingConventions", "Naming conventions (one per line)"),
    ],
  },
  {
    key: "descriptions",
    label: "Approved descriptions",
    fields: [
      text("tagline", "Tagline", 300),
      text("short", "Short description", 1000),
      text("long", "Long description", 10000),
      text("about", "About the business", 10000),
      text("legalCompany", "Legal company description", 5000),
      text("footer", "Footer description", 5000),
    ],
  },
  {
    key: "imageryGuidance",
    label: "Imagery guidance",
    fields: [
      text("photography", "Photography"),
      text("productImagery", "Product imagery"),
      text("icons", "Icons"),
      text("illustrations", "Illustrations"),
      text("motifs", "Motifs"),
      text("backgrounds", "Backgrounds"),
    ],
  },
  {
    key: "chatPersonality",
    label: "Chat personality",
    fields: [
      text("displayName", "Assistant display name", 100),

      text("role", "Role and purpose", 1000),
      text("greeting", "Introduction and greeting", 1000),
      text("manner", "Conversational manner", 2000),
      text("responseGuidance", "Response length and detail", 1000),
      text("questionsGuidance", "Questions and next steps", 1000),
      text("uncertaintyWording", "Expressing uncertainty", 1000),
      text("handoffWording", "Human handoff wording", 1000),
      lines("openingQuestions", "Opening questions (up to six, one per line)"),
    ],
  },
  {
    key: "emailDefaults",
    label: "Email defaults",
    fields: [
      text("fromDisplayName", "Sender display name", 200),
      text("replyToLabel", "Reply-to display name", 200),
      text("footer", "Email footer", 5000),
      text("signature", "Signature", 5000),
      text("legalFooter", "Legal footer", 5000),
      text("unsubscribeStyling", "Unsubscribe link styling"),
    ],
  },
];
function record(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}
function rows(value: unknown): Record<string, unknown>[] {
  return Array.isArray(value) ? value.map(record) : [];
}
function display(value: unknown, field: Field) {
  return Array.isArray(value)
    ? value.join(field.kind === "weights" ? ", " : "\n")
    : typeof value === "string"
      ? value
      : "";
}
function Fields({
  fields,
  value,
  onChange,
  disabled,
}: {
  fields: Field[];
  value: Record<string, unknown>;
  onChange: (v: Record<string, unknown>) => void;
  disabled: boolean;
}) {
  return (
    <>
      {fields.map((field) => (
        <label className={`field${field.max && field.max >= 5000 ? " kit-field-wide" : ""}`} key={field.key}>
          {field.label}
          {field.kind === "select" ? (
            <select
              disabled={disabled}
              required={field.required}
              value={display(value[field.key], field)}
              onChange={(e) =>
                onChange({ ...value, [field.key]: e.target.value })
              }
            >
              <option value="">Choose…</option>
              {field.options?.map((o) => (
                <option key={o} value={o}>
                  {o.charAt(0).toUpperCase() + o.slice(1)}
                </option>
              ))}
            </select>
          ) : field.kind === "input" ? (
            <input
              disabled={disabled}
              value={display(value[field.key], field)}
              required={field.required}
              maxLength={field.max}
              onChange={(e) => onChange({ ...value, [field.key]: e.target.value })}
            />
          ) : field.pattern ? (
            <span className="kit-colour-input">
              <input
                disabled={disabled}
                value={display(value[field.key], field)}
                required={field.required}
                pattern={field.pattern}
                maxLength={field.max}
                placeholder="#123456"
                onChange={(e) =>
                  onChange({ ...value, [field.key]: e.target.value })
                }
              />
              <ColourPreview hex={display(value[field.key], field)} />
            </span>
          ) : (
            <textarea
              disabled={disabled}
              rows={field.max && field.max <= 300 ? 2 : 3}
              value={display(value[field.key], field)}
              required={field.required}
              maxLength={field.max ?? 40040}
              onChange={(e) =>
                onChange({ ...value, [field.key]: e.target.value })
              }
            />
          )}
        </label>
      ))}
    </>
  );
}
function ColourPreview({ hex }: { hex: string }) {
  const valid = /^#[0-9a-fA-F]{6}(?:[0-9a-fA-F]{2})?$/.test(hex.trim());
  return (
    <span
      className="kit-colour-hexagon"
      aria-hidden="true"
      title={valid ? hex.trim() : "Enter a valid hex colour"}
    >
      <span style={{ backgroundColor: valid ? hex.trim() : "transparent" }} />
    </span>
  );
}
function normalized(value: Record<string, unknown>, fields: Field[]) {
  const result = { ...value };
  for (const field of fields) {
    const v = value[field.key];
    if (typeof v !== "string") continue;
    const trimmed = v.trim();
    if (!trimmed) {
      delete result[field.key];
      continue;
    }
    if (field.kind === "lines")
      result[field.key] = trimmed
        .split(/\r?\n/)
        .map((s) => s.trim())
        .filter(Boolean);
    else if (field.kind === "weights") {
      const weights = trimmed.split(",").map((s) => s.trim());
      if (
        weights.length > 20 ||
        weights.some((s) => !/^\d{1,4}$/.test(s) || +s < 1 || +s > 1000)
      )
        throw new Error("Use comma-separated font weights between 1 and 1000.");
      result[field.key] = weights.map(Number);
    } else result[field.key] = trimmed;
  }
  if (
    Array.isArray(result.styles) &&
    result.styles.some(
      (v) => !["normal", "italic", "oblique"].includes(String(v)),
    )
  )
    throw new Error(
      "Font styles must be normal, italic or oblique, one per line.",
    );
  return result;
}
export function BrandKitEditor({
  api,
  images,
  workspaceId,
  brandId,
  canEdit,
  onSaved,
}: {
  api: BrandKitGateway;
  images?: BrandImagesGateway;
  workspaceId: string;
  brandId: string;
  canEdit: boolean;
  onSaved?: () => void;
}) {
  const [selected, setSelected] = useState<
    KitSection | "images" | ExpressionTab
  >("images");
  const [visited, setVisited] = useState<
    Set<KitSection | "images" | ExpressionTab>
  >(() => new Set(["images"]));
  const tabId = useId();
  const buttons = useRef<(HTMLButtonElement | null)[]>([]);
  const categories = [
    { key: "images" as const, label: "Logos & images" },
    ...kitSections.slice(0, 3),
    ...(api.expression
      ? expressionTabs.filter((tab) => tab.key !== "voicePreview")
      : kitSections.filter((section) => section.key === "voice")),
    ...kitSections.slice(4),
    ...(api.expression
      ? expressionTabs.filter((tab) => tab.key === "voicePreview")
      : []),
  ];
  function select(key: KitSection | "images" | ExpressionTab) {
    setSelected(key);
    setVisited((previous) => new Set([...previous, key]));
  }
  useHenryBinding({key:"brand-tabs",brandId,summary:`Brand Kit section: ${selected}`,actions:categories.map(c=>({id:`brand:${c.key}`,label:`Open ${c.label}`,run:()=>select(c.key)}))});
  return (
    <div className="kit-tabs">
      <div
        className="kit-tab-list"
        role="tablist"
        aria-label="Brand Kit sections"
      >
        {categories.map((category, index) => (
          <button
            type="button"
            role="tab"
            key={category.key}
            ref={(element) => {
              buttons.current[index] = element;
            }}
            id={tabId + "-tab-" + category.key}
            aria-controls={tabId + "-panel-" + category.key}
            aria-selected={selected === category.key}
            tabIndex={selected === category.key ? 0 : -1}
            onClick={() => select(category.key)}
            onKeyDown={(event) => {
              const next =
                event.key === "ArrowRight"
                  ? (index + 1) % categories.length
                  : event.key === "ArrowLeft"
                    ? (index + categories.length - 1) % categories.length
                    : event.key === "Home"
                      ? 0
                      : event.key === "End"
                        ? categories.length - 1
                        : undefined;
              if (next === undefined) return;
              event.preventDefault();
              select(categories[next]!.key);
              buttons.current[next]?.focus();
            }}
          >
            {category.label}
          </button>
        ))}
      </div>
      {categories
        .filter(
          (category) => !expressionTabs.some((tab) => tab.key === category.key),
        )
        .map((category) => (
          <div
            key={category.key}
            id={tabId + "-panel-" + category.key}
            role="tabpanel"
            aria-labelledby={tabId + "-tab-" + category.key}
            hidden={selected !== category.key}
            className="kit-tab-panel"
            tabIndex={0}
          >
            {visited.has(category.key) &&
              (category.key === "images" ? (
                images ? (
                  <BrandImages
                    api={images}
                    workspaceId={workspaceId}
                    brandId={brandId}
                    canEdit={canEdit}
                    onSaved={onSaved}
                  />
                ) : (
                  <p>Image uploads are not available yet.</p>
                )
              ) : (
                <SectionLoader
                  active={selected === category.key}
                  api={api}
                  workspaceId={workspaceId}
                  brandId={brandId}
                  definition={kitSections.find(
                    (section) => section.key === category.key,
                  )!}
                  canEdit={canEdit}
                  onSaved={onSaved}
                />
              ))}
          </div>
        ))}
      {api.expression && (
        <BrandExpressionEditor
          api={api.expression}
          workspaceId={workspaceId}
          brandId={brandId}
          canEdit={canEdit}
          active={
            expressionTabs.some((tab) => tab.key === selected)
              ? (selected as ExpressionTab)
              : undefined
          }
          tabId={tabId}
        />
      )}
    </div>
  );
}

function SectionLoader({
  active,
  api,
  workspaceId,
  brandId,
  definition,
  canEdit,
  onSaved,
}: {
  active: boolean;
  api: BrandKitGateway;
  workspaceId: string;
  brandId: string;
  definition: Definition;
  canEdit: boolean;
  onSaved?: () => void;
}) {
  const [revision, setRevision] = useState(0),
    [saved, setSaved] = useState(false);
  const load = useCallback(
    (signal: AbortSignal) => {
      void revision;
      return api.load(workspaceId, brandId, signal);
    },
    [api, workspaceId, brandId, revision],
  );
  const result = useResource(load);
  if (result.state === "loading")
    return <Loading label={`Loading ${definition.label.toLowerCase()}…`} />;
  if (result.state === "error")
    return (
      <Failure error={result.error} retry={() => setRevision((v) => v + 1)} />
    );
  return (
    <>
      {saved && <p role="status">{definition.label} saved.</p>}
      <SectionForm
        active={active}
        key={revision}
        api={api}
        workspaceId={workspaceId}
        brandId={brandId}
        kit={result.data}
        definition={definition}
        canEdit={canEdit}
        refresh={() => {
          setSaved(false);
          setRevision((v) => v + 1);
        }}
        onSaved={() => {
          setSaved(true);
          setRevision((v) => v + 1);
          onSaved?.();
        }}
      />
    </>
  );
}
function SectionForm({
  active,
  api,
  workspaceId,
  brandId,
  kit,
  definition: d,
  canEdit,
  refresh,
  onSaved,
}: {
  active: boolean;
  api: BrandKitGateway;
  workspaceId: string;
  brandId: string;
  kit?: EditableKit;
  definition: Definition;
  canEdit: boolean;
  refresh: () => void;
  onSaved: () => void;
}) {
  const [value, setValue] = useState<unknown>(
    () => kit?.content[d.key] ?? (d.rows ? [] : {}),
  );
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const [confirmClear, setConfirmClear] = useState(false);
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  useHenryBinding({key:`brand-section:${d.key}`,brandId,enabled:active,summary:`Brand Kit ${d.label}`,
    editor:canEdit&&!busy?{key:`brand:${brandId}:${d.key}`,title:d.label,fields:henryFields({content:d.rows?value:{...Object.fromEntries(d.fields.map(f=>[f.key,f.kind==="lines"||f.kind==="weights"?[]:""])),...record(value)}})}:undefined,
    apply:changes=>{const base=d.rows?value:{...Object.fromEntries(d.fields.map(f=>[f.key,f.kind==="lines"||f.kind==="weights"?[]:""])),...record(value)};const next=applyHenryFields({content:base},changes).content;setValue(d.rows?rows(next).map(v=>normalized(v,d.fields)):normalized(record(next),d.fields));},
  });
  async function save(clear = false) {
    setError("");
    let content: unknown;
    try {
      content = clear ? (d.rows ? [] : {}) : d.rows
        ? rows(value).map((v) => normalized(v, d.fields))
        : normalized(record(value), d.fields);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Check the fields.");
      return;
    }
    setBusy(true);
    try {
      await api.save(
        workspaceId,
        brandId,
        kit,
        d.key,
        content,
        new AbortController().signal,
      );
      onSaved();
    } catch (e) {
      setError(
        e instanceof DataError && e.code === "conflict"
          ? "The Brand Kit changed. Copy any unsaved text before reloading, then apply your changes to the latest version."
          : e instanceof DataError && e.code === "denied"
            ? "You no longer have permission to edit this Brand Kit."
            : e instanceof DataError && e.code === "invalid"
              ? "Check the fields and shorten long entries. Lists allow up to 40 entries of 1,000 characters each."
              : "We could not confirm the save. Your entries are still here; reload to check the latest saved version before retrying.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <form
      className="operating-form kit-section"
      onSubmit={(e) => {
        e.preventDefault();
        void save();
      }}
    >
      <h3>{d.label}</h3>
      <p>
        {canEdit
          ? "Changes are saved directly to your Brand Kit."
          : "You can view these details. Contact your workspace administrator to make changes."}
      </p>
      {d.key === "chatPersonality" && <p>Inherits this brand’s approved personality, tone, writing style and terminology. These settings adapt that identity for conversation. Email sender names and signatures are separate. Saving does not publish website chat; visitors will always see an AI disclosure.</p>}
      {d.key === "emailDefaults" && (
        <p>
          These are writing and display defaults. They do not connect a mailbox
          or enable email sending. Manage email addresses and sending
          permissions in Integrations.
        </p>
      )}
      {d.key === "chatPersonality" && <label>Assistant image (optional)<select disabled={busy || !canEdit} value={String(record(value).avatarAssetId||"")} onChange={e=>setValue({...record(value),avatarAssetId:e.target.value})}><option value="">No image</option>{kit?.images?.map(a=><option key={a.id} value={a.id}>{a.name}</option>)}</select></label>}
      <fieldset disabled={busy || !canEdit}>
        <legend>{d.label} details</legend>
        {d.rows ? (
          <>
            <div className="kit-record-grid">
            {rows(value).map((v, i) => (
              <div className="kit-editor-row" key={i}>
                {canEdit && <label><input type="checkbox" checked={selectedRows.includes(i)} onChange={e => setSelectedRows(old => e.target.checked ? [...old, i] : old.filter(n => n !== i))} /> Select {d.key === "colours" ? "colour" : "font"} {i + 1}</label>}
                <h4>
                  {d.key === "colours" ? "Colour" : "Font"} {i + 1}
                </h4>
                <Fields
                  fields={d.fields}
                  value={v}
                  disabled={!canEdit}
                  onChange={(next) =>
                    setValue(
                      rows(value).map((old, j) => (j === i ? next : old)),
                    )
                  }
                />
                {canEdit && (
                  <button
                    type="button"
                    onClick={() =>
                      { setValue(rows(value).filter((_, j) => j !== i)); setSelectedRows([]); }
                    }
                  >
                    Remove {d.key === "colours" ? "colour" : "font"} {i + 1}
                  </button>
                )}
              </div>
            ))}
            </div>
            {canEdit && selectedRows.length > 0 && <button type="button" onClick={() => {setValue(rows(value).filter((_, i) => !selectedRows.includes(i))); setSelectedRows([]);}}>Remove selected ({selectedRows.length})</button>}
            {canEdit && (
              <button
                type="button"
                disabled={rows(value).length >= (d.maxRows ?? 20)}
                onClick={() => setValue([...rows(value), {}])}
              >
                Add {d.key === "colours" ? "colour" : "font"}
              </button>
            )}
          </>
        ) : (
          <div className="kit-field-grid">
            <Fields
              fields={d.fields}
              value={record(value)}
              disabled={!canEdit}
              onChange={setValue}
            />
          </div>
        )}
        {canEdit && (
          <button className="button" type="submit">
            {busy ? "Saving…" : `Save ${d.label.toLowerCase()}`}
          </button>
        )}
      </fieldset>
      {canEdit && <div className="kit-clear-actions">
        {confirmClear ? <div role="alert"><p>Delete all saved {d.label.toLowerCase()}? Other Brand Kit tabs will stay unchanged.</p><button type="button" disabled={busy} onClick={() => void save(true)}>Confirm delete</button><button type="button" disabled={busy} onClick={() => setConfirmClear(false)}>Cancel</button></div> : <button type="button" disabled={busy || !kit?.content[d.key]} onClick={() => setConfirmClear(true)}>Delete {d.label.toLowerCase()}</button>}
      </div>}
      {error && (
        <div role="alert">
          <p>{error}</p>
          <button type="button" disabled={busy} onClick={refresh}>
            Reload saved details
          </button>
        </div>
      )}
    </form>
  );
}
