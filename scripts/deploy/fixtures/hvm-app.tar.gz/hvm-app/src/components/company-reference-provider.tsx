import { useEffect, useState, type ReactNode } from "react";
import type { PsuGateway } from "../data/psu";
import { CompanyReferenceContext } from "../data/company-reference";
export function CompanyReferenceProvider({
  api,
  w,
  children,
}: {
  api: PsuGateway;
  w: string;
  children: ReactNode;
}) {
  const [value, setValue] = useState({
    industries: [] as string[],
    regions: [] as string[],
  });
  const [error, setError] = useState(false);
  const [revision, setRevision] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    setError(false);
    Promise.resolve()
      .then(() => api.referenceData(w, controller.signal))
      .then((data) => {
        if (controller.signal.aborted) return;
        const names = (rows: { name: string }[]) => [
          ...new Set(rows.map((row) => row.name)),
        ];
        setValue({
          industries: names(data.industries),
          regions: names(data.regions),
        });
      })
      .catch(() => {
        if (!controller.signal.aborted) setError(true);
      });
    return () => controller.abort();
  }, [api, w, revision]);
  return (
    <CompanyReferenceContext.Provider value={value}>
      {error && (
        <p role="alert">
          Industry and region lists could not be loaded. Your existing
          selections are retained.{" "}
          <button type="button" onClick={() => setRevision((v) => v + 1)}>
            Retry lists
          </button>
        </p>
      )}
      {children}
    </CompanyReferenceContext.Provider>
  );
}
