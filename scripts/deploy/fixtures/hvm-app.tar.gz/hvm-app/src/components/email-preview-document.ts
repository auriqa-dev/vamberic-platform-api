// Build a script-free preview DOM instead of injecting HTML. CSSOM assignments
// preserve email styles under the application's strict inline-style CSP.
const tags=new Set(['html','head','body','table','tbody','tr','td','div','p','a','img','br','strong','em','span']);
const styles=new Set(['margin','margin-bottom','background','color','font-family','font-size','line-height','padding','max-width','max-height','width','height','border-top','padding-top','white-space','overflow-wrap','text-decoration','display']);
export function paintEmailPreview(target: Document, html: string) {
  // The effect can run before srcdoc finishes loading; onLoad paints it later.
  if (!target.body) return;
  const source=new DOMParser().parseFromString(html,'text/html');
  target.body.replaceChildren();
  function copy(node:Node):Node|null {
    if(node.nodeType===3)return target.createTextNode(node.textContent||'');
    if(!(node instanceof HTMLElement)||!tags.has(node.localName))return null;
    const out=target.createElement(node.localName);
    for(const key of ['role','width','cellspacing','cellpadding','alt']) {
      const value=node.getAttribute(key);if(value!==null)out.setAttribute(key,value);
    }
    if(node.localName==='img'){
      const src=node.getAttribute('src')||'';
      if(!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(src))return null;
      out.setAttribute('src',src);
    }
    // Preview links are visually accurate but deliberately do not navigate.
    for(const declaration of (node.getAttribute("style")||"").split(";")){
      const separator=declaration.indexOf(":");if(separator<0)continue;
      const key=declaration.slice(0,separator).trim().toLowerCase();
      const value=declaration.slice(separator+1).trim();
      if(styles.has(key)&&!/(url\s*\(|expression\s*\(|@import)/i.test(value))out.style.setProperty(key,value);
    }
    for(const child of node.childNodes){const next=copy(child);if(next)out.append(next);}
    return out;
  }
  const body=copy(source.body);if(body){
    const wrapper=target.createElement('div');
    if(body.nodeType===1)wrapper.style.cssText=(body as HTMLElement).style.cssText;
    wrapper.append(...Array.from(body.childNodes));target.body.append(wrapper);
  }
  target.body.style.margin='0';
}
