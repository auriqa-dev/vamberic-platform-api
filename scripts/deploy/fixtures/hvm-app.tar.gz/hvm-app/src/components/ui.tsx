import type { ReactNode } from "react";
import { DataError } from "../data/gateway";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <img
      className={compact ? "logo logo-compact" : "logo"}
      src="/brand/hvm-logo-colour.png"
      alt="HVM"
      width="148"
      height="148"
    />
  );
}
export function Status({ children }: { children: ReactNode }) {
  const label = typeof children === "string" ? children.toLowerCase() : "";
  const tone = ["approved", "ready", "completed"].includes(label) ? "success"
    : ["pending", "needs_attention", "needs attention"].includes(label) ? "warning"
    : ["failed", "blocked", "error"].includes(label) ? "danger" : undefined;
  return <span className="status" data-tone={tone}>{children}</span>;
}
export function Empty({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <div className="empty">
      <span aria-hidden="true" className="empty-mark">
        ↗
      </span>
      <h3>{title}</h3>
      <p>{children}</p>
    </div>
  );
}
export function Loading({
  label = "Loading your workspace…",
}: {
  label?: string;
}) {
  return (
    <div className="loading" role="status">
      <span aria-hidden="true" className="loading-dot" />
      {label}
    </div>
  );
}
export function Failure({
  error,
  retry,
}: {
  error: unknown;
  retry?: () => void;
}) {
  const code = error instanceof DataError ? error.code : "unavailable";
  const content = {
    pending: [
      "Your workspace is taking shape.",
      "Workspace access is not available yet. HVM needs to complete your account setup before you can continue.",
    ],
    denied: [
      "Access not available",
      "You do not have access to this workspace or view. Contact HVM if you need access.",
    ],
    unavailable: [
      "Unable to load your workspace",
      "The service is temporarily unavailable. Please try again.",
    ],
    conflict: [
      "Record changed",
      "Reload this workspace before trying again; your changes were not saved.",
    ],
    invalid: [
      "Workspace data could not be verified",
      "We could not safely load this information. Please try again or contact HVM.",
    ],
  }[code];
  return (
    <div role={code === "pending" ? "status" : "alert"} className="notice">
      <p className="eyebrow">
        {code === "pending" ? "Account setup" : "Workspace access"}
      </p>
      <h2>{content[0]}</h2>
      <p>{content[1]}</p>
      {retry && (
        <button className="button secondary" onClick={retry}>
          Check again <span aria-hidden="true">↗</span>
        </button>
      )}
    </div>
  );
}
