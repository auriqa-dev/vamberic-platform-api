import { useEffect, useRef, useState } from "react";
import { useHenryAssist } from "./workspace-henry";
import type { OfferBundle, OfferStage, OfferWork } from "../data/offer";
import {
  proposals,
  PROPOSAL_PREFIX,
  reviewSections,
  acceptStage,
} from "../data/offer/review";
import { fieldLabel } from "./offer-fields";

const guidance =
  "Prepare useful proposed answers from the information already available for this offer. Distinguish facts, assumptions and recommendations. Explain any genuine business decisions or evidence gaps. Preserve unrelated answers.";

export function OfferReview({
  bundle,
  brandId,
  editable,
  onSave,
  onWorking,
  onUnsaved,
}: {
  bundle: OfferBundle;
  brandId: string;
  editable: boolean;
  onSave: (work: OfferWork) => Promise<void>;
  onWorking?: (busy: boolean) => void;
  onUnsaved?: () => void;
}) {
  const assist = useHenryAssist();
  const work = bundle.design!.work;
  const latestBundle = useRef(bundle);
  latestBundle.current = bundle;
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [reply, setReply] = useState("");
  const [editing, setEditing] = useState<Record<string, string>>({});
  const [discussion, setDiscussion] = useState<{
    stage: string;
    question: string;
    message: string;
  }>();
  const [pending, setPending] = useState<OfferWork>();
  useEffect(() => {
    const protect = (e: BeforeUnloadEvent) => {
      if (Object.keys(editing).length || pending) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", protect);
    return () => window.removeEventListener("beforeunload", protect);
  }, [editing, pending]);
  const alive = useRef(true),
    guard = useRef(false);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);
  useEffect(() => {
    onWorking?.(busy);
    return () => onWorking?.(false);
  }, [busy, onWorking]);
  useEffect(() => {
    if (Object.keys(editing).length || pending) onUnsaved?.();
  }, [editing, pending, onUnsaved]);
  const unanswered = work.stages.flatMap((s) =>
    s.status === "completed"
      ? []
      : s.unknowns
          .filter(
            (q) =>
              !s.userInputs.some((a) => a.question === q) &&
              !proposals(s).some((p) => p.question === q),
          )
          .map((question) => ({ stage: s, question })),
  );
  const pendingEditKeys = useRef<string[]>([]);
  const save = async (next: OfferWork, editKeys: string[] = []) => {
    pendingEditKeys.current = editKeys;
    const selectedEdits = Object.fromEntries(Object.entries(editing).filter(([key]) => editKeys.includes(key)));
    setPending(next);
    const merged = {
      ...next,
      stages: next.stages.map((stage) => ({
        ...stage,
        ...(selectedEdits[`notes:${stage.stageKey}`] !== undefined
          ? {
              notes: selectedEdits[`notes:${stage.stageKey}`]!.split("\n")
                .map((s) => s.trim())
                .filter(Boolean),
            }
          : {}),
        ...(selectedEdits[`rationale:${stage.stageKey}`] !== undefined
          ? {
              decisionRationale:
                selectedEdits[`rationale:${stage.stageKey}`]!.trim() || undefined,
            }
          : {}),
        userInputs: [
          ...stage.userInputs.filter(
            (a) =>
              !stage.unknowns.some(
                (q, i) =>
                  q === a.question &&
                  selectedEdits[`${stage.stageKey}:${i}`] !== undefined,
              ),
          ),
          ...stage.unknowns.flatMap((question, i) =>
            selectedEdits[`${stage.stageKey}:${i}`]?.trim()
              ? [
                  {
                    question,
                    answer: selectedEdits[`${stage.stageKey}:${i}`]!.trim(),
                  },
                ]
              : [],
          ),
        ],
      })),
    };
    setPending(merged);
    await onSave(merged);
    if (alive.current) {
      setPending(undefined);
      setEditing((old) => Object.fromEntries(Object.entries(old).filter(([key]) => !editKeys.includes(key))));
      setDiscussion(undefined);
    }
  };
  const perform = async (action: () => Promise<void>) => {
    if (guard.current) return;
    guard.current = true;
    setBusy(true);
    setError("");
    try {
      await action();
    } catch (e) {
      if (alive.current)
        setError(
          e instanceof Error
            ? ["unavailable", "invalid", "conflict"].includes(e.message)
              ? "Henry couldn’t complete this request. Your saved answers are unchanged. Please try again."
              : e.message
            : "Could not save. Your proposals remain here.",
        );
    } finally {
      guard.current = false;
      if (alive.current) setBusy(false);
    }
  };
  const prepare = async (focus?: {
    stage: string;
    question: string;
    message: string;
  }) => {
    if (!assist) return;
    await perform(async () => {
      const targets = focus
        ? [
            {
              stage: work.stages.find((s) => s.stageKey === focus.stage)!,
              question: focus.question,
            },
          ]
        : unanswered.slice(0, 12);
      if (!targets.length) return;
      const fields = targets.map(({ question }, i) => ({
        key: `proposal${i}`,
        label: question.slice(0, 200),
        value: "[]",
      }));
      // Six-string contracts stay within the existing Henry editor transport.
      fields.forEach((f, i) => {
        const p = proposals(targets[i]!.stage).find(
          (p) => p.question === targets[i]!.question,
        );
        f.value = JSON.stringify(
          p
            ? [p.question, editing[`${targets[i]!.stage.stageKey}:${targets[i]!.stage.unknowns.indexOf(targets[i]!.question)}`] ?? targets[i]!.stage.userInputs.find(a => a.question === p.question)?.answer ?? p.answer, p.basis, p.kind, p.decision, p.gap]
            : [targets[i]!.question, editing[`${targets[i]!.stage.stageKey}:${targets[i]!.stage.unknowns.indexOf(targets[i]!.question)}`] ?? targets[i]!.stage.userInputs.find(a => a.question === targets[i]!.question)?.answer ?? "", "", "assumption", "review", ""],
        );
      });
      const result = await assist(
        {
          section: "offers",
          brandId,
          summary: JSON.stringify({
            offer: bundle.offer.definition,
            offerId: bundle.offer.id,
            context:
              "Use the selected offer review context retrieved by the server.",
          }).slice(0, 18000),
          editor: {
            key: `offer-review:${bundle.offer.id}`,
            title: "Offer decision proposals",
            fields,
          },
          actions: [],
        },
        guidance +
          (focus
            ? `\nFocus only on this question: ${focus.question}. If the user requests a correction, return a replacement in changes for proposal0, using the exact six-string array. Update the answer, not just the chat explanation. If this is only a question, explain without changing it. Use the selected product context when requested; do not substitute competitors from another offer.\nUser: ${focus.message}`
            : "\nPrepare proposed answers for all supplied unanswered questions together."),
      );
      if (!alive.current) return;
      if (latestBundle.current !== bundle) throw new Error("The offer changed while Henry was working. Your answer is unchanged; ask again using the latest version.");
      setReply(result.reply);
      const next = structuredClone(work);
      let count = 0;
      for (const change of result.changes) {
        const i = fields.findIndex((f) => f.key === change.key);
        if (i < 0) continue;
        let values: unknown;
        try {
          values = JSON.parse(change.value);
        } catch {
          continue;
        }
        if (
          !Array.isArray(values) ||
          values.length !== 6 ||
          values.some((v) => typeof v !== "string" || v.length > 2000) ||
          values[0] !== targets[i]!.question ||
          !["supported_information", "assumption", "recommendation"].includes(
            values[3],
          ) ||
          !["review", "human_input"].includes(values[4])
        )
          continue;
        const items = (values as string[]).map(
          (v, j) =>
            v.trim() ||
            (j === 1
              ? "No proposal — your decision is needed."
              : j === 5
                ? "No additional evidence gap identified."
                : "Needs review."),
        );
        const stage = next.stages.find(
          (s) => s.stageKey === targets[i]!.stage.stageKey,
        )!;
        if (
          stage.status === "completed" ||
          (!focus && stage.userInputs.some((a) => a.question === items[0]))
        )
          continue;
        const existing = stage.groups.find(
          (g) => g.key.startsWith(PROPOSAL_PREFIX) && g.items[0] === items[0],
        );
        if (focus) stage.userInputs = stage.userInputs.filter(a => a.question !== items[0]);
        if (existing) existing.items = items;
        else if (stage.groups.length < 20)
          stage.groups.push({
            key: `${PROPOSAL_PREFIX}${
              Math.max(
                -1,
                ...stage.groups
                  .filter((g) => g.key.startsWith(PROPOSAL_PREFIX))
                  .map((g) => Number(g.key.slice(PROPOSAL_PREFIX.length)))
                  .filter(Number.isFinite),
              ) + 1
            }`,
            name: "Henry’s proposed answer",
            items,
          });
        else continue;
        count++;
      }
      if (!count && focus) {
        setDiscussion(focus);
        if (result.changes.length) setError("Henry has not changed this answer. Your instruction is retained; clarify the correction or edit the answer directly.");
        return;
      }
      if (!count)
        throw new Error(
          "Henry could not prepare a usable proposal. Existing work is unchanged; you can retry or answer directly.",
        );
      await save(next, []);
      if (focus) {
        const stage = targets[0]!.stage;
        const key = `${stage.stageKey}:${stage.unknowns.indexOf(focus.question)}`;
        setEditing(old => Object.fromEntries(Object.entries(old).filter(([k]) => k !== key)));
      }
      setDiscussion(focus ? { ...focus, message: "" } : undefined);
    });
  };
  const shown = pending ?? work;
  const attention = shown.stages.flatMap((stage) =>
    proposals(stage)
      .filter(
        (p) =>
          p.decision === "human_input" &&
          !stage.userInputs.some((a) => a.question === p.question),
      )
      .map((proposal) => ({ stage, proposal })),
  );
  const gaps = shown.stages.flatMap((stage) =>
    proposals(stage)
      .filter((p) => p.gap !== "No additional evidence gap identified.")
      .map((proposal) => ({ stage, proposal })),
  );
  const focusAnswer = (stage: OfferStage, question: string) => {
    const input = document.getElementById(
      `offer-answer-${stage.stageKey}-${stage.unknowns.indexOf(question)}`,
    );
    const group = input?.closest("details");
    if (group) group.open = true;
    input?.focus();
  };
  return (
    <section className="offer-review" aria-label="Review with Henry">
      <header>
        <h3>Review with Henry</h3>
        <p>
          Henry prepares the thinking. Review the recommendations, adjust
          anything that is wrong and decide what matters. Accepting a section
          records your review; final offer approval is separate.
        </p>
      </header>
      <p role="status">
        {busy
          ? "Henry is preparing or saving your review…"
          : `${shown.stages.filter((s) => s.status === "completed").length} of ${shown.stages.length} decisions reviewed. ${shown.stages.flatMap((s) => proposals(s).filter((p) => p.decision === "human_input" && !s.userInputs.some((a) => a.question === p.question))).length} proposals need a business decision.`}
      </p>
      {!!attention.length && (
        <section aria-label="Your business decisions">
          <h4>Your decisions</h4>
          <ul>
            {attention.map(({ stage, proposal }) => (
              <li key={stage.stageKey + proposal.question}>
                <button
                  className="button-link"
                  onClick={() => focusAnswer(stage, proposal.question)}
                >
                  {proposal.question}
                </button>
                <p>{proposal.basis}</p>
              </li>
            ))}
          </ul>
        </section>
      )}
      {!!gaps.length && (
        <details>
          <summary>Evidence to strengthen ({gaps.length})</summary>
          <p>These gaps remain with the offer after review and approval.</p>
          {gaps.map(({ stage, proposal }) => (
            <p key={stage.stageKey + proposal.question}>
              <strong>{fieldLabel(stage.stageKey)}</strong> — {proposal.gap}
            </p>
          ))}
        </details>
      )}
      {error && !discussion && <p role="alert">{error}</p>}
      {pending && (
        <button
          disabled={busy}
          onClick={() => void perform(() => save(pending, pendingEditKeys.current))}
        >
          Retry saving prepared work
        </button>
      )}
      {!busy && unanswered.length > 0 && assist && (
        <button
          disabled={!editable || !!pending || !!Object.keys(editing).length}
          onClick={() => void prepare()}
        >
          Ask Henry to prepare unanswered decisions
        </button>
      )}
      {reply && (
        <details>
          <summary>Henry’s explanation</summary>
          <p className="offer-prose">{reply}</p>
        </details>
      )}
      {[
        ...reviewSections,
        ...shown.stages
          .filter(s => !reviewSections.some(g => g.keys.includes(s.stageKey)))
          .map(s => ({name: fieldLabel(s.stageKey), keys:[s.stageKey]})),
      ].filter(section => shown.stages.some(s => section.keys.includes(s.stageKey))).map((section, sectionIndex) => {
        const stages = shown.stages.filter((s) =>
          section.keys.includes(s.stageKey),
        );
        if (!stages.length) return null;
        return (
          <details
            className="offer-review-section"
            key={section.name}
            open={sectionIndex === 0}
          >
            <summary>
              <h3>{section.name}</h3>
            </summary>
            {stages.map((s) => (
              <div className="offer-review-stage" key={s.stageKey}>
                <h4>
                  {fieldLabel(s.stageKey)}{" "}
                  {s.status === "completed" ? "· Reviewed" : ""}
                </h4>
                <p className="offer-prose">{s.notes.join("\n")}</p>
                {s.unknowns.map((q, i) => {
                  const proposal = proposals(s).find((p) => p.question === q),
                    accepted = s.userInputs.find((a) => a.question === q),
                    key = `${s.stageKey}:${i}`,
                    value =
                      editing[key] ??
                      accepted?.answer ??
                      proposal?.answer ??
                      "",
                    changed = editing[key] !== undefined && value !== (accepted?.answer ?? proposal?.answer ?? "");
                  return (
                    <div className="offer-review-answer" key={q}>
                      <label className="offer-field">
                        {q}
                        <textarea
                          id={`offer-answer-${s.stageKey}-${i}`}
                          rows={4}
                          maxLength={4000}
                          disabled={
                            !editable || busy || s.status === "completed"
                          }
                          value={value}
                          onChange={(e) =>
                            setEditing((old) => ({
                              ...old,
                              [key]: e.target.value,
                            }))
                          }
                        />
                      </label>
                      <p className="offer-hint">
                        {pending && pendingEditKeys.current.includes(key)
                          ? "Waiting to save"
                          : changed
                          ? "Unsaved changes"
                          : accepted
                          ? "Your saved answer"
                          : proposal
                            ? `${proposal.kind.replaceAll("_", " ")} · ${proposal.decision === "human_input" ? "Your decision is needed" : "Proposed by Henry"}`
                            : "Henry needs more information here. You can answer directly or ask him for help."}
                      </p>
                      {proposal && (
                        <details>
                          <summary>Basis and evidence gaps</summary>
                          <p>{proposal.basis}</p>
                          <p>{proposal.gap}</p>
                        </details>
                      )}
                      {editable && s.status !== "completed" && (!accepted || changed) && (
                        <div className="offer-toolbar">
                          <button
                            disabled={
                              busy ||
                              !value.trim() ||
                              value.startsWith("No proposal —")
                            }
                            onClick={() =>
                              void perform(async () => {
                                const next = structuredClone(shown),
                                  stage = next.stages.find(
                                    (x) => x.stageKey === s.stageKey,
                                  )!;
                                stage.userInputs = [
                                  ...stage.userInputs.filter(
                                    (a) => a.question !== q,
                                  ),
                                  { question: q, answer: value.trim() },
                                ];
                                await save(next, [key]);
                              })
                            }
                          >
                            {changed ? "Save answer" : "Accept answer"}
                          </button>
                          {assist && (
                            <button
                              disabled={busy || !!pending}
                              onClick={() => {
                                setReply("");
                                setDiscussion({
                                  stage: s.stageKey,
                                  question: q,
                                  message: "",
                                });
                              }}
                            >
                              Discuss with Henry
                            </button>
                          )}
                        </div>
                      )}{" "}
                      {discussion?.stage === s.stageKey &&
                        discussion.question === q && (
                          <section className="offer-review-discussion">
                            <h4>Discuss with Henry</h4>
                            {error && <p role="alert">{error}</p>}
                            {reply && (
                              <p className="offer-prose" role="status">
                                {reply}
                              </p>
                            )}
                            <p>{discussion.question}</p>
                            <label className="offer-field">
                              Your question or correction
                              <textarea
                                rows={3}
                                value={discussion.message}
                                onChange={(e) =>
                                  setDiscussion({
                                    ...discussion,
                                    message: e.target.value,
                                  })
                                }
                              />
                            </label>
                            <div className="offer-toolbar">
                              <button
                                disabled={busy || !discussion.message.trim()}
                                onClick={() => void prepare(discussion)}
                              >
                                Ask Henry
                              </button>
                              <button
                                disabled={busy}
                                onClick={() => setDiscussion(undefined)}
                              >
                                Cancel
                              </button>
                            </div>
                          </section>
                        )}
                    </div>
                  );
                })}
                <details>
                  <summary>Decision context</summary>
                  <label className="offer-field">
                    Working notes: {fieldLabel(s.stageKey)}
                    <textarea
                      rows={3}
                      disabled={!editable || busy || s.status === "completed"}
                      value={
                        editing[`notes:${s.stageKey}`] ?? s.notes.join("\n")
                      }
                      onChange={(e) =>
                        setEditing((old) => ({
                          ...old,
                          [`notes:${s.stageKey}`]: e.target.value,
                        }))
                      }
                    />
                  </label>
                  <label className="offer-field">
                    Decision rationale: {fieldLabel(s.stageKey)}
                    <textarea
                      rows={3}
                      maxLength={4000}
                      disabled={!editable || busy || s.status === "completed"}
                      value={
                        editing[`rationale:${s.stageKey}`] ??
                        s.decisionRationale ??
                        ""
                      }
                      onChange={(e) =>
                        setEditing((old) => ({
                          ...old,
                          [`rationale:${s.stageKey}`]: e.target.value,
                        }))
                      }
                    />
                  </label>
                  {editable && s.status !== "completed" &&
                    (editing[`notes:${s.stageKey}`] !== undefined || editing[`rationale:${s.stageKey}`] !== undefined) && (
                      <div className="offer-toolbar">
                        <button disabled={busy} onClick={() => void perform(() => save(shown, [`notes:${s.stageKey}`, `rationale:${s.stageKey}`]))}>
                          Save decision context
                        </button>
                      </div>
                    )}
                  <p>{s.decisionRationale}</p>
                  {s.evidence?.map((e) => (
                    <p key={e.key}>{e.reference}</p>
                  ))}
                </details>
                {editable && s.status === "completed" && (
                  <button
                    className="offer-review-reopen"
                    disabled={busy}
                    onClick={() =>
                      void perform(() =>
                        save({
                          ...shown,
                          completedStageKeys: shown.completedStageKeys.filter(
                            (k) => k !== s.stageKey,
                          ),
                          stages: shown.stages.map((x) =>
                            x.stageKey === s.stageKey
                              ? { ...x, status: "in_progress" }
                              : x,
                          ),
                        }),
                      )
                    }
                  >
                    Reopen this decision
                  </button>
                )}
              </div>
            ))}
            {editable && stages.some((s) => s.status !== "completed") && (
              <button
                disabled={busy}
                onClick={() =>
                  void perform(async () => {
                    const answers = (s: OfferStage) =>
                      Object.fromEntries(
                        s.unknowns.map((q, i) => [
                          q,
                          editing[`${s.stageKey}:${i}`] ??
                            s.userInputs.find((a) => a.question === q)
                              ?.answer ??
                            proposals(s).find((p) => p.question === q)
                              ?.answer ??
                            "",
                        ]),
                      );
                    const unresolved = stages.flatMap((s) =>
                      s.unknowns.filter(
                        (q) =>
                          !answers(s)[q]?.trim() ||
                          answers(s)[q]!.startsWith("No proposal —"),
                      ),
                    );
                    const decisions = stages.flatMap((s) =>
                      proposals(s).filter(
                        (p) =>
                          p.decision === "human_input" &&
                          !s.userInputs.some(
                            (a) => a.question === p.question,
                          ) &&
                          !editing[
                            `${s.stageKey}:${s.unknowns.indexOf(p.question)}`
                          ]?.trim(),
                      ),
                    );
                    if (decisions.length)
                      throw new Error(
                        "Accept or edit the answers marked Your decision is needed before accepting this section.",
                      );
                    if (
                      !window.confirm(
                        `Accept the decisions in ${section.name}, including the stated assumptions and evidence gaps${unresolved.length ? ` and ${unresolved.length} unresolved items` : ""}? This does not approve the offer.`,
                      )
                    )
                      return;
                    await save({
                      ...shown,
                      completedStageKeys: [
                        ...new Set([
                          ...shown.completedStageKeys,
                          ...stages.map((s) => s.stageKey),
                        ]),
                      ],
                      stages: shown.stages.map((s) =>
                        section.keys.includes(s.stageKey) &&
                        s.status !== "completed"
                          ? acceptStage(s, answers(s))
                          : s,
                      ),
                    }, stages.flatMap((stage) => [
                      `notes:${stage.stageKey}`,
                      `rationale:${stage.stageKey}`,
                      ...stage.unknowns.map((_, index) => `${stage.stageKey}:${index}`),
                    ]));
                  })
                }
              >
                Accept this section
              </button>
            )}
          </details>
        );
      })}
    </section>
  );
}
