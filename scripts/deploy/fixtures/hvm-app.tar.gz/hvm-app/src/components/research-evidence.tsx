import { useEffect, useState } from "react";
import type { ResearchGateway } from "../data/research";
export function ResearchEvidencePanel({
  api,
  w,
  type,
  id,
}: {
  api?: ResearchGateway;
  w: string;
  type: string;
  id: string;
}) {
  const [items, setItems] = useState<
      Awaited<ReturnType<ResearchGateway["evidence"]>>
    >([]),
    [error, setError] = useState("");
  useEffect(() => {
    setItems([]);
    setError("");
    if (!api || !id) return;
    const c = new AbortController();
    void api
      .evidence(w, type, id, c.signal)
      .then((v) => {
        if (!c.signal.aborted) setItems(v);
      })
      .catch(() => {
        if (!c.signal.aborted)
          setError("Research evidence could not be loaded.");
      });
    return () => c.abort();
  }, [api, w, type, id]);
  if (!api || (!items.length && !error)) return null;
  return (
    <section className="research-panel">
      <h2>Research &amp; evidence</h2>
      {error && <p role="alert">{error}</p>}
      {items.map((f) => (
        <article className="research-finding" key={f.id}>
          <p>{f.statement}</p>
          <small>
            {f.decision === "accepted"
              ? "Reviewed finding"
              : f.decision === "rejected"
                ? "Excluded"
                : "Proposed finding"}{" "}
            · {f.evidenceIds.length} supporting sources
          </small>
          <p>{f.rationale}</p>
        </article>
      ))}
      <p>
        Review sources and decisions in Research. Findings do not change
        approved records automatically.
      </p>
    </section>
  );
}
