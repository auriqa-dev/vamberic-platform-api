import { PsuResearchProgress } from "./psu-research-progress";
import { latestPsuJobs } from "../data/psu-jobs";
import { useHenryBinding, henryFields, applyHenryFields } from "./workspace-henry";
import { ProfileDelete } from "./profile-delete";
import { useCallback, useRef, useState } from "react";
import type { CompanyState, PsuGateway, PsuJob } from "../data/psu";
import type { WebsiteReview } from "../data/psu-website";
import { useRefreshingResource } from "../data/use-refreshing-resource";
import { ProductReview, companyGroups } from "./psu-website-review";
import { Failure, Loading } from "./ui";
export function Company({
  api,
  w,
  brandId,
  jobs,
  available,
  generating,
  queen,
  refresh,
  onProduct,
}: {
  api: PsuGateway;
  w: string;
  brandId: string;
  jobs: PsuJob[];
  available: boolean;
  generating: boolean;
  queen: boolean;
  refresh: () => void;
  onProduct: (url?: string) => void;
}) {
  const [revision, setRevision] = useState(0);
  const load = useCallback(
    (s: AbortSignal) => {
      void revision;
      return api.company(w, brandId, s);
    },
    [api, w, brandId, revision],
  );
  const state = useRefreshingResource(load);
  const changed = () => {
    setRevision((v) => v + 1);
    refresh();
  };
  if (state.state === "loading") return <Loading />;
  if (state.state === "error") return <Failure error={state.error} />;
  return (
    <CompanyForm
      key={state.data.current?.versionId ?? "new"}
      {...{ api, w, brandId, jobs, available, generating, queen, onProduct }}
      data={state.data}
      changed={changed}
    />
  );
}
function CompanyForm({
  api,
  w,
  brandId,
  jobs,
  available,
  generating,
  queen,
  onProduct,
  data,
  changed,
}: {
  api: PsuGateway;
  w: string;
  brandId: string;
  jobs: PsuJob[];
  available: boolean;
  generating: boolean;
  queen: boolean;
  onProduct: (url?: string) => void;
  data: CompanyState;
  changed: () => void;
}) {
  const latestAttempt = latestPsuJobs(jobs).find(
    (job) => job.input.kind === "company" && job.input.brandId === brandId,
  );
  const [url, setUrl] = useState(() => String(
    (!latestAttempt?.companySaved && latestAttempt?.status !== "saved"
      ? latestAttempt?.input.websiteUrls?.[0]
      : undefined) ?? data.current?.definition.websiteUrl ?? data.websiteUrl ?? "",
  ));
  const [includeWebResearch, setWebResearch] = useState(false);
  const [editing, setEditing] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState<unknown>();
  const request = useRef<{ body: string; key: string } | undefined>(undefined);
  const saveRequest = useRef<{ body: string; key: string } | undefined>(
    undefined,
  );
  const [dismissedFailures, setDismissedFailures] = useState<Set<string>>(
    () => new Set(jobs.filter(j => ["failed", "interrupted"].includes(j.status)).map(j => j.id)),
  );
  useHenryBinding({key:"company",brandId,summary:JSON.stringify({company:data.current?.definition,website:url}),
    editor:!busy&&!generating?{key:`company-url:${brandId}`,title:"Company website",fields:henryFields({website:url})}:undefined,
    apply:changes=>{setUrl(applyHenryFields({website:url},changes).website);},
    actions:busy?[]:[...(data.current?[{id:"company:edit",label:"Edit company details",run:()=>setEditing(true)}]:[]),{id:"company:product",label:"Prepare a product",run:()=>onProduct(url)}],
  });
  const version = data.current;
  const save = async (
    definition: Record<string, unknown>,
    s: AbortSignal,
    job?: PsuJob,
  ) => {
    const body = JSON.stringify({
      definition,
      version: version?.versionId,
      job: job?.id,
    });
    if (saveRequest.current?.body !== body)
      saveRequest.current = { body, key: crypto.randomUUID() };
    return api.saveCompany(
      w,
      brandId,
      {
        definition,
        requestKey: saveRequest.current.key,
        expectedVersionId: version?.versionId ?? null,
        ...(job
          ? { jobId: job.id, draftDigest: job.companyDraft!.digest }
          : {}),
      },
      s,
    );
  };
  return (
    <>
      <form
        className="panel psu-intake"
        onSubmit={async (e) => {
          e.preventDefault();
          if (busy) return;
          setBusy(true);
          setError(undefined);
          setDismissedFailures(
            new Set(
              jobs
                .filter(
                  (j) =>
                    j.input.kind === "company" &&
                    ["failed", "interrupted"].includes(j.status),
                )
                .map((j) => j.id),
            ),
          );
          const input = {
            mode: "create" as const,
            kind: "company" as const,
            depth: "summary" as const,
            brandId,
            workingLabel: data.brandName,
            orientation: "",
            websiteUrls: [url.trim()],
            includeWebResearch,
          };
          const body = JSON.stringify(input);
          if (request.current?.body !== body)
            request.current = { body, key: crypto.randomUUID() };
          try {
            await api.generate(
              w,
              input,
              request.current.key,
              new AbortController().signal,
            );
            request.current = undefined;
            changed();
          } catch (e) {
            setError(e);
          } finally {
            setBusy(false);
          }
        }}
      >
        <h2>
          {version
            ? "Read your company website again"
            : "Start with your company website"}
        </h2>
        <p>
          We’ll save a short company summary and, where identifiable, a main
          product summary for you to review. You can add more products
          afterwards.
        </p>
        <div className="psu-url-action">
          <label>
            Company URL
            <input
              type="url"
              required
              pattern="https://.*"
              maxLength={2048}
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              disabled={busy || generating}
            />
          </label>
          <button
            className="button"
            disabled={busy || generating || !available || !url.trim()}
          >
            {busy || generating ? "Generating…" : "Generate Summary"}
          </button>
        </div>
        <label className="psu-research-option"><input type="checkbox" checked={generating ? !!jobs.find(j => j.input.kind === "company" && j.status === "generating")?.input.includeWebResearch : includeWebResearch} disabled={busy || generating} onChange={e=>setWebResearch(e.target.checked)} /> Also find independent mentions and comparisons</label>
        {!version && (
          <p className="muted">
            Copied from client setup. Change it here if needed.
          </p>
        )}
        {!available && (
          <p>
            Website reading is temporarily unavailable. Saved company details
            remain available.
          </p>
        )}
        {error ? <Failure error={error} /> : null}
      </form>
      {!version && !generating && (
        <section className="panel">
          {!editing ? <><h2>No public website?</h2><p>Enter your company details directly. You can review and approve them before use.</p><button type="button" onClick={() => setEditing(true)}>Enter company details</button></> : <ProductReview
            company editing draft={asReview({})}
            onSave={(rows, signal) => save(Object.fromEntries(rows.filter(r => r.included).map(r => [r.binding.field, r.binding.value])), signal)}
            onChanged={changed}
          />}
        </section>
      )}
      {version && (
        <section className="panel">
          <div className="profile-card-heading"><h2>{String(version.definition.name)}</h2>{queen && <ProfileDelete api={api} w={w} kind="company" id={brandId} name={String(version.definition.name)} onDeleted={changed}/>}</div>
          <p>
            {version.approved
              ? "Approved company details"
              : "Company draft — review and approve when ready"}
          </p>
          {editing ? (
            <ProductReview
              company
              editing
              draft={asReview(version.definition)}
              onSave={(rows, s) =>
                save(
                  Object.fromEntries(
                    rows
                      .filter((r) => r.included)
                      .map((r) => [r.binding.field, r.binding.value]),
                  ),
                  s,
                )
              }
              onChanged={changed}
            />
          ) : (
            <>
              <CompanyDetails definition={version.definition} />
              <button onClick={() => setEditing(true)}>
                {version.approved
                  ? "Create a new draft to edit"
                  : "Edit company details"}
              </button>
              {queen && !version.approved && (
                <button
                  disabled={busy}
                  onClick={async () => {
                    setBusy(true);
                    setError(undefined);
                    try {
                      await api.approveCompany(
                        w,
                        brandId,
                        version.versionId,
                        new AbortController().signal,
                      );
                      changed();
                    } catch (e) {
                      setError(e);
                    } finally {
                      setBusy(false);
                    }
                  }}
                >
                  Approve company
                </button>
              )}
            </>
          )}
          {data.approved && !version.approved && (
            <details>
              <summary>Current approved company details</summary>
              <p>These stay active until you approve the new draft.</p>
              <CompanyDetails definition={data.approved.definition} />
            </details>
          )}
        </section>
      )}
      {latestPsuJobs(jobs)
        .filter((j) => j.input.kind === "company")
        .filter((j) => (!busy && !generating) || j.status === "generating")
        .filter(
          (j, index) =>
            !["failed", "interrupted"].includes(j.status) ||
            (index === 0 &&
              !busy &&
              !generating &&
              !dismissedFailures.has(j.id)),
        )
        .map((job) => (
          <section key={job.id}>
            <PsuResearchProgress job={job} />
            {job.companyDraft ? (
              <>
                {job.status === "review" && !job.companySaved && (
                  <p role="status">
                    Generation has finished. Review the suggestions below, then save your company draft.
                  </p>
                )}
                {!job.companySaved && (
                  <ProductReview
                    headerAction={queen && job.status === "review" ? <ProfileDelete api={api} w={w} kind="company" id={brandId} name={job.input.workingLabel || data.brandName} onDeleted={changed} /> : undefined}
                    researching={job.status !== "review"}
                    company
                    competitorSuggestions={job.competitorSuggestions}
                    draft={{
                      ...job.companyDraft,
                      kind: "psu_website_review_draft",
                      fields: [
                        ...job.companyDraft.fields,
                        ...Object.entries({
                          brandName: data.brandName,
                          websiteUrl: job.input.websiteUrls[0] ?? "",
                        })
                          .filter(
                            ([field]) =>
                              !job.companyDraft!.fields.some(
                                (f) => f.binding.field === field,
                              ),
                          )
                          .map(([field, value]) => ({
                            binding: { field, value },
                            basis: "interpretation" as const,
                            support: [],
                          })),
                      ],
                    }}
                    onSave={(rows, s) =>
                      save(
                        Object.fromEntries(
                          rows
                            .filter((r) => r.included)
                            .map((r) => [r.binding.field, r.binding.value]),
                        ),
                        s,
                        job,
                      )
                    }
                    onChanged={changed}
                  />
                )}
                {job.status === "review" && !job.productDeleted && <div className="panel">
                  <h3>Your products and services</h3>
                  {job.offeringCountReason && <p>{job.offeringCountReason}</p>}
                  {job.draft ? (
                    <>
                      <p>
                        {job.offeringId
                          ? "Your product draft has been saved."
                          : "A product draft is ready for you to review."}
                      </p>
                      <button onClick={() => onProduct()}>
                        View products and services
                      </button>
                    </>
                  ) : (
                    <>
                      <p>
                        {job.productUnavailable
                          ? "Your company details are ready, but the product draft could not be completed. You can retry it without repeating the company step."
                          : job.offeringCount === "multiple"
                            ? "Add each product or service using its own page URL."
                            : "Does this brand have just one product or service?"}
                      </p>
                      {job.offeringCount !== "multiple" && (
                        <button
                          onClick={() => onProduct(job.input.websiteUrls[0])}
                        >
                          Yes — add this product or service
                        </button>
                      )}
                      <button onClick={() => onProduct("")}>
                        Add a product using its own URL
                      </button>
                    </>
                  )}
                </div>}
              </>
            ) : job.status === "generating" ? null : (
              <div className="panel">
                <p>
                  {companyFailureMessage(job.failureCode)} No new company draft
                  was saved.
                </p>
              </div>
            )}
          </section>
        ))}
    </>
  );
}
function asReview(
  definition: Record<string, string | string[]>,
): WebsiteReview {
  return {
    kind: "psu_website_review_draft",
    version: 1,
    approval: "not_approved",
    digest: "0".repeat(64),
    fields: Object.entries(definition).map(([field, value]) => ({
      binding: { field, value },
      basis: "interpretation",
      support: [],
    })),
    unknowns: [],
    questions: [],
  };
}
function CompanyDetails({
  definition,
}: {
  definition: Record<string, string | string[]>;
}) {
  return (
    <div className="psu-understanding psu-company-details">
      {companyGroups.map(([title, fields]) => (
        <section key={title}>
          <h3>{title}</h3>
          <dl>
            {fields.map(([key, label]) => (
              <div key={key}>
                <dt>{label}</dt>
                <dd>
                  {Array.isArray(definition[key])
                    ? (definition[key] as string[]).join(", ")
                    : definition[key] || "Not recorded"}
                </dd>
              </div>
            ))}
          </dl>
        </section>
      ))}
    </div>
  );
}
export function PrimaryProduct({
  api,
  w,
  brandId,
  products,
}: {
  api: PsuGateway;
  w: string;
  brandId: string;
  products: { id: string; definition: Record<string, unknown> }[];
}) {
  const [revision, setRevision] = useState(0),
    [choice, setChoice] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState<unknown>();
  const load = useCallback(
    (s: AbortSignal) => {
      void revision;
      return api.company(w, brandId, s);
    },
    [api, w, brandId, revision],
  );
  const state = useRefreshingResource(load);
  if (state.state === "loading") return <Loading />;
  if (state.state === "error") return <Failure error={state.error} />;
  return (
    <div className="panel psu-primary-product">
      <label>
        Primary product or service
        <select
          value={choice || state.data.primaryOfferingId || ""}
          onChange={(e) => setChoice(e.target.value)}
        >
          <option value="">Choose a primary product</option>
          {products.map((p) => (
            <option key={p.id} value={p.id}>
              {String(p.definition.name)}
            </option>
          ))}
        </select>
      </label>
      <button
        disabled={busy || !choice || choice === state.data.primaryOfferingId}
        onClick={async () => {
          setBusy(true);
          setError(undefined);
          try {
            await api.primaryProduct(
              w,
              brandId,
              choice,
              state.data.primaryOfferingId,
              new AbortController().signal,
            );
            setChoice("");
            setRevision((v) => v + 1);
          } catch (e) {
            setError(e);
          } finally {
            setBusy(false);
          }
        }}
      >
        Save primary product
      </button>
      <p>
        Used as the default when a product needs to be selected. This does not
        approve it.
      </p>
      {error ? <Failure error={error} /> : null}
    </div>
  );
}

export function companyFailureMessage(code?: PsuJob["failureCode"]) {
  switch (code) {
    case "sources_unavailable":
      return "We couldn’t read this page. Check that it is publicly accessible, or try another company page.";
    case "service_configuration":
      return "We couldn’t start the company draft because of a service configuration problem. Please contact support; changing your URL won’t resolve this.";
    case "service_unavailable":
      return "The drafting service is temporarily unavailable. Please try again shortly.";
    case "output_model_mismatch":
    case "output_format_invalid":
      return "The drafting service returned an unexpected response. Please contact support; you don’t need to change your company details.";
    case "output_evidence_invalid":
    case "output_invalid":
      return "We couldn’t verify the generated company details against the website. Please try again.";
    case "timed_out":
      return "Preparing the company details took too long. Please try again.";
    default:
      return "We couldn’t complete the company draft. Please try again. If this continues, contact support.";
  }
}
