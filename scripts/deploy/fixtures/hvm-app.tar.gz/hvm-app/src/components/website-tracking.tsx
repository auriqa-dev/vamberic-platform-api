import { useEffect, useState } from "react";
import { DataError } from "../data/gateway";
const trackingError = (e: unknown) => e instanceof DataError ? e.userMessage || "Website tracking is unavailable. Refresh and try again." : e instanceof Error ? e.message : "Could not update website tracking.";
import type {
  WebsiteTrackingGateway,
  TrackingState,
  TrackingSettings,
  TrackingSite,
} from "../data/website-tracking";
import "../styles/website-tracking.css";
export function WebsiteTrackingCard({
  api,
  workspaceId,
}: {
  api: WebsiteTrackingGateway;
  workspaceId: string;
}) {
  const [data, setData] = useState<TrackingState>(),
    [error, setError] = useState(""),
    [errorSite, setErrorSite] = useState<string>(),
    [busy, setBusy] = useState(false),
    [editing, setEditing] = useState<TrackingSite | null | undefined>(),
    [selected, setSelected] = useState<string[]>([]);
  const [form, setForm] = useState<TrackingSettings>({
    origin: "",
    brandId: "",
    enabled: false,
    testOnly: true,
    retentionDays: 30,
    policyConfirmed: false,
    paths: [],
    events: [],
  });
  useEffect(() => {
    const c = new AbortController();
    api
      .read(workspaceId, c.signal)
      .then(setData)
      .catch((e) => {
        if (!c.signal.aborted) setError(trackingError(e));
      });
    return () => c.abort();
  }, [api, workspaceId]);
  const edit = (s: TrackingSite | null) => {
    setEditing(s);
    setErrorSite(undefined);
    setError("");
    setForm(
      s
        ? {
            origin: s.origin,
            brandId: s.brandId,
            enabled: s.enabled,
            testOnly: s.testOnly,
            retentionDays: s.retentionDays,
            policyConfirmed: s.policyConfirmed,
            paths: s.paths,
            events: s.events,
          }
        : {
            origin: "",
            brandId: data?.brands[0]?.id || "",
            enabled: false,
            testOnly: true,
            retentionDays: 30,
            policyConfirmed: false,
            paths: [],
            events: [],
          },
    );
  };
  async function change(
    site: TrackingSite | null,
    operation: string,
    settings?: TrackingSettings,
  ) {
    setError("");
    setErrorSite(operation === "verify" ? site?.id : undefined);
    setBusy(true);
    try {
      const result = await api.change(
        workspaceId,
        {
          id: site?.id || "",
          expectedVersion: site?.version || 0,
          operation,
          ...(settings ? { settings } : {}),
        },
        new AbortController().signal,
      );
      setData(result);
      setEditing(undefined);
    } catch (e) {
      setError(
        trackingError(e),
      );
    } finally {
      setBusy(false);
    }
  }
  async function bulk(operation: "revoke" | "delete" | "disable") {
    if (
      !confirm(
        `${operation === "delete" ? "Delete" : operation === "disable" ? "Disable tracking for" : "Revoke tracking for"} ${selected.length} selected websites? Existing email destinations remain available.`,
      )
    )
      return;
    setBusy(true);
    setErrorSite(undefined);
    setError("");
    const failures: string[] = [];
    let latest = data;
    for (const id of selected) {
      const s = latest?.sites.find((x) => x.id === id);
      if (!s) continue;
      try {
        latest = await api.change(
          workspaceId,
          {
            id,
            expectedVersion: s.version,
            operation: operation === "disable" ? "save" : operation,
            ...(operation === "disable"
              ? {
                  settings: {
                    origin: s.origin,
                    brandId: s.brandId,
                    enabled: false,
                    testOnly: s.testOnly,
                    retentionDays: s.retentionDays,
                    policyConfirmed: s.policyConfirmed,
                    paths: s.paths,
                    events: s.events,
                  },
                }
              : {}),
          },
          new AbortController().signal,
        );
        setData(latest);
      } catch (e) {
        failures.push(
          `${s.origin}: ${trackingError(e)}`,
        );
      }
    }
    setSelected([]);
    setError(failures.join("\n"));
    setBusy(false);
  }
  return (
    <article className="panel integration-card website-tracking">
      <h3>Website tracking</h3>
      <p>
        Connect email CTA activity and consented website visits to Measurement
        and NBA. A link identifies its intended recipient; it does not prove who
        visited.
      </p>
      {!data && !error && <p role="status">Loading website settings…</p>}
      {data && (
        <>
          {!data.available && (
            <p role="status">
              Tracking endpoints are not configured for this environment. You
              can prepare website settings; collection remains off.
            </p>
          )}
          {data.canManage && (
            <div className="tracking-actions">
              <button
                className={editing === undefined ? "button" : undefined}
                disabled={busy}
                onClick={() => edit(null)}
              >
                Add website
              </button>
              {selected.length > 0 && (
                <>
                  <button disabled={busy} onClick={() => void bulk("disable")}>
                    Disable selected
                  </button>
                  <button disabled={busy} onClick={() => void bulk("revoke")}>
                    Revoke selected ({selected.length})
                  </button>
                  <button disabled={busy} onClick={() => void bulk("delete")}>
                    Delete selected
                  </button>
                </>
              )}
            </div>
          )}
          {!data.sites.length && (
            <p>
              No websites configured. Add a website, verify ownership and
              connect your consent manager before enabling tracking.
            </p>
          )}
          {data.sites.map((s) => (
            <section className="tracking-site" key={s.id}>
              <div className="tracking-actions">
                {data.canManage && (
                  <input
                    type="checkbox"
                    aria-label={`Select ${s.origin}`}
                    checked={selected.includes(s.id)}
                    onChange={(e) =>
                      setSelected(
                        e.target.checked
                          ? [...selected, s.id]
                          : selected.filter((x) => x !== s.id),
                      )
                    }
                  />
                )}
                <strong>{s.origin}</strong>
                <span>
                  {s.revoked
                    ? "Revoked"
                    : s.enabled
                      ? "Enabled"
                      : s.verifiedAt
                        ? "Verified · disabled"
                        : "Awaiting verification"}
                  {s.testOnly ? " · Test mode" : ""}
                </span>
              </div>
              <p>
                {data.brands.find((b) => b.id === s.brandId)?.name} · Retention:{" "}
                {s.retentionDays} days.{" "}
                {s.lastReceivedAt
                  ? `Last received ${new Date(s.lastReceivedAt).toLocaleString("en-GB")}.`
                  : "No consented browser events received yet."}
              </p>
              {!s.revoked && !s.verifiedAt && (
                <div className="tracking-dns" aria-label={`DNS setup for ${s.origin}`}>
                  <h4>1. Add your DNS record</h4>
                  <p>At your domain’s DNS provider, add this record. Keep it in place, then select Verify ownership below.</p>
                  <dl>
                    <dt>Type</dt><dd>TXT</dd>
                    <dt>Host / full record name</dt><dd><code>_hvm-tracking.{new URL(s.origin).hostname}</code></dd>
                    <dt>Value</dt><dd><pre>{s.verification}</pre></dd>
                    <dt>TTL</dt><dd>Automatic or your provider’s default</dd>
                  </dl>
                  <p>If your DNS provider adds the domain automatically, enter only the host prefix. For example, when managing <code>example.com</code>, the host for <code>_hvm-tracking.www.example.com</code> is <code>_hvm-tracking.www</code>. Use the exact name shown for your website; do not replace existing unrelated TXT records.</p>
                  <p>DNS changes can take time to appear. If verification fails, check the name and value and try again after the record has propagated.</p>
                  <h4>2. Verify ownership</h4>
                  {error && errorSite === s.id && <p className="tracking-error" role="alert">{error}</p>}
                </div>
              )}
              {data.canManage && !s.revoked && (
                <div className="tracking-actions">
                  <button disabled={busy} onClick={() => edit(s)}>
                    Edit
                  </button>
                  {!s.verifiedAt && (
                    <button
                      disabled={busy}
                      onClick={() => void change(s, "verify")}
                    >
                      Verify ownership
                    </button>
                  )}
                  <button
                    disabled={busy}
                    onClick={() => {
                      if (
                        confirm(
                          "Revoke this installation? Existing email destinations will still open.",
                        )
                      )
                        void change(s, "revoke");
                    }}
                  >
                    Revoke
                  </button>
                  <button
                    disabled={busy}
                    onClick={() => {
                      if (
                        confirm(
                          "Delete this unused website setup? Sites with email links must be revoked instead.",
                        )
                      )
                        void change(s, "delete");
                    }}
                  >
                    Delete
                  </button>
                </div>
              )}
              {!s.revoked && (
                <details>
                  <summary>Installation and consent instructions</summary>
                  <p>
                    Install this snippet on this exact website. Subdomains need
                    their own setup.
                  </p>
                  <pre>{`<script defer src="${data.base}/tracker.js" data-site="${s.id}"></script>`}</pre>
                  <p>
                    After the script loads, connect your existing consent
                    manager. No browser events or browser storage are used until
                    consent is granted. Consent enables a short-lived tab
                    session to connect page visits. On withdrawal, call it with
                    false.
                  </p>
                  <pre>
                    {
                      "window.HVMTracking.consent(true);\n// When consent is withdrawn:\nwindow.HVMTracking.consent(false);"
                    }
                  </pre>
                  <p>
                    Optional configured event (no form contents or personal
                    values):
                  </p>
                  <pre>{'window.HVMTracking.event("resource_download");'}</pre>
                  <p>
                    Browse after granting consent, then refresh status below.
                    Test mode must remain on until your own checks are complete.
                    Custom events are browser reports, not verified bookings or
                    conversions.
                  </p>
                </details>
              )}
            </section>
          ))}
          {editing !== undefined && (
            <form
              className="tracking-form"
              onSubmit={(e) => {
                e.preventDefault();
                void change(editing, "save", {
                  ...form,
                  events: form.events.map((x) => x.trim()).filter(Boolean),
                  paths: form.paths.map((x) => x.trim()).filter(Boolean),
                });
              }}
            >
              <h4>{editing ? "Edit website" : "Add website"}</h4>
              <label>
                Website origin
                <input
                  required
                  type="url"
                  disabled={!!editing}
                  value={form.origin}
                  placeholder="https://example.com"
                  onChange={(e) => setForm({ ...form, origin: e.target.value })}
                />
              </label>
              <label>
                Brand
                <select
                  disabled={!!editing}
                  value={form.brandId}
                  onChange={(e) =>
                    setForm({ ...form, brandId: e.target.value })
                  }
                >
                  {data.brands.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </label>
              <label className="tracking-retention">
                Retain website evidence (days)
                <input
                  required
                  type="number"
                  min="1"
                  max="365"
                  value={form.retentionDays}
                  onChange={(e) =>
                    setForm({ ...form, retentionDays: Number(e.target.value) })
                  }
                />
              </label>
              <label>
                Public page paths to report, one per line
                <textarea
                  value={form.paths.join("\n")}
                  onChange={(e) =>
                    setForm({ ...form, paths: e.target.value.split("\n") })
                  }
                  placeholder={"/pricing\n/compare"}
                />
                <small>
                  Use static public paths only. Other paths appear as “other
                  page”; query strings are never stored.
                </small>
              </label>
              <label>
                Custom event names, one per line
                <textarea
                  value={form.events.join("\n")}
                  onChange={(e) =>
                    setForm({ ...form, events: e.target.value.split("\n") })
                  }
                  placeholder="resource_download"
                />
              </label>
              <label className="tracking-check">
                <input
                  type="checkbox"
                  checked={form.testOnly}
                  onChange={(e) =>
                    setForm({ ...form, testOnly: e.target.checked })
                  }
                />
                Test mode — exclude new activity from campaign metrics and NBA
              </label>
              <label className="tracking-check">
                <input
                  type="checkbox"
                  checked={form.policyConfirmed}
                  onChange={(e) =>
                    setForm({ ...form, policyConfirmed: e.target.checked })
                  }
                />
                I have reviewed this website’s tracking notice, consent
                integration and retention period.
              </label>
              <label className="tracking-check">
                <input
                  type="checkbox"
                  disabled={!editing?.verifiedAt}
                  checked={form.enabled}
                  onChange={(e) =>
                    setForm({ ...form, enabled: e.target.checked })
                  }
                />
                Enable tracking after ownership verification
              </label>
              {error && (
                <p className="tracking-error" role="alert">
                  {error}
                </p>
              )}
              <div className="tracking-actions">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => setEditing(undefined)}
                >
                  Cancel
                </button>
                <button className="button" disabled={busy}>
                  Save website
                </button>
              </div>
            </form>
          )}
          <button
            disabled={busy}
            onClick={() => {
              setError("");
              setErrorSite(undefined);
              setBusy(true);
              api
                .read(workspaceId, new AbortController().signal)
                .then(setData)
                .catch((e) => setError(trackingError(e)))
                .finally(() => setBusy(false));
            }}
          >
            Refresh status
          </button>
        </>
      )}
      {busy && <p role="status">Working…</p>}
      {error && !errorSite && editing === undefined && (
        <p className="tracking-error" role="alert">
          {error}
        </p>
      )}
    </article>
  );
}
