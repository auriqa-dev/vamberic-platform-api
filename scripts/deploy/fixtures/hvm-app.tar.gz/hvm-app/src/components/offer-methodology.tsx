import { useEffect, useState } from "react";
import type { OfferGateway, OfferBundle } from "../data/offer";

export function OfferMethodology({
  api,
  workspaceId,
  design,
}: {
  api: OfferGateway;
  workspaceId: string;
  design: NonNullable<OfferBundle["design"]>;
}) {
  const [method, setMethod] =
    useState<Awaited<ReturnType<OfferGateway["methodology"]>>>();
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    const c = new AbortController();
    setMethod(undefined);
    setFailed(false);
    api
      .methodology(
        workspaceId,
        design.methodologyId,
        design.methodologyVersion,
        c.signal,
      )
      .then((value) => {
        if (!c.signal.aborted) setMethod(value);
      })
      .catch(() => {
        if (!c.signal.aborted) setFailed(true);
      });
    return () => c.abort();
  }, [api, workspaceId, design.methodologyId, design.methodologyVersion]);
  if (failed)
    return (
      <p role="status">
        The methodology could not be loaded. Reopen this offer to try again.
        Your saved decisions are unchanged.
      </p>
    );
  if (!method) return <p role="status">Loading the offer methodology…</p>;
  return (
    <section aria-label="Offer methodology">
      <h3>{method.name}</h3>
      <p className="muted">
        Methodology v{design.methodologyVersion} ·{" "}
        {design.work.completedStageKeys.length} of {method.stages.length}{" "}
        decisions reviewed. Reviewing stages does not approve the offer.
      </p>
      {method.conceptualModel && (
        <>
          <p className="notice">{method.conceptualModel.expression}</p>
          <dl className="offer-fields">
            {method.conceptualModel.dimensions.map((dimension) => {
              const stage = design.work.stages.find(
                (s) => s.stageKey === dimension.key,
              );
              return (
                <div key={dimension.key}>
                  <dt>
                    <strong>{dimension.name}</strong>
                  </dt>
                  <dd>{dimension.explanation}</dd>
                  <dd>
                    {stage?.notes.join(" ") ||
                      "This part of the offer still needs development."}
                  </dd>
                </div>
              );
            })}
          </dl>
        </>
      )}
      <details>
        <summary>How this methodology develops your offer</summary>
        <ol>
          {method.stages.map((stage) => (
            <li key={stage.key}>
              <strong>{stage.name}</strong>
              <p>{stage.purpose}</p>
              {stage.guidance?.length ? (
                <ul>
                  {stage.guidance.map((text) => (
                    <li key={text}>{text}</li>
                  ))}
                </ul>
              ) : null}
            </li>
          ))}
        </ol>
      </details>
    </section>
  );
}
