import { useCallback, useState } from "react";
import { DataError } from "../data/gateway";
import { useResource } from "../data/use-resource";
import type { LushaGateway,LushaConnection } from "../data/lusha";
import "../styles/lusha.css";
import { Loading,Failure } from "./ui";
export function LushaConnectionCard({api,workspaceId}:{api:LushaGateway;workspaceId:string}) {
 const [version,setVersion]=useState(0),load=useCallback((signal:AbortSignal)=>{void version;return api.read(workspaceId,signal);},[api,workspaceId,version]);
 const state=useResource(load);
 return <article className="panel integration-card lusha-connection"><h3>Lusha</h3><p>Use your client’s account for contact research and verified business email addresses.</p>{state.state==="loading"?<Loading/>:state.state==="error"?<Failure error={state.error}/>:state.state==="ready"?<Connection key={state.data.updatedAt??"new"} data={state.data} api={api} workspaceId={workspaceId} changed={()=>setVersion(v=>v+1)}/>:null}</article>;
}
function Connection({data,api,workspaceId,changed}:{data:LushaConnection;api:LushaGateway;workspaceId:string;changed:()=>void}) {
 const [key,setKey]=useState(""),[permissions,setPermissions]=useState(data.permissions),[busy,setBusy]=useState(false),[error,setError]=useState("");
 async function submit(action:"connect"|"test"|"update",disconnect=false) {
  setBusy(true);setError("");
  try {await api.change(workspaceId,action,action==="test"?{}:action==="connect"?{apiKey:key,expectedUpdatedAt:data.updatedAt,permissions}:{expectedUpdatedAt:data.updatedAt,permissions,disconnect},new AbortController().signal);setKey("");changed();}
  catch (e) {setError(e instanceof DataError && e.userMessage ? e.userMessage : "HVM could not update the Lusha connection. Refresh the status and try again.");}
  finally {setBusy(false);}
 }
 return <div className="lusha-form"><p role="status">{data.status.replaceAll("_"," ")}</p>
 {!data.canManage?<p>You can view this connection. A workspace administrator can change it.</p>:!data.available?<p>Secure Lusha connections are awaiting deployment.</p>:<>
 <label>API key<input type="password" autoComplete="new-password" value={key} onChange={e=>setKey(e.target.value)} placeholder={data.id?"Enter a replacement key":"Enter your Lusha API key"}/></label>
 <p className="small muted">Only enter your key here. Do not send it to Henry.</p>
 <fieldset disabled={busy}><legend>Research permissions</legend>{(["research","discovery","enrichment"] as const).map(p=><label className="checkbox-label" key={p}><input type="checkbox" checked={permissions[p]} onChange={e=>setPermissions(v=>({...v,[p]:e.target.checked}))}/>{p==="research"?"Allow Research to use Lusha":p==="discovery"?"Allow supplementary people discovery":"Allow email enrichment"}</label>)}</fieldset>
 <div className="form-actions"><button className="secondary" disabled={busy} onClick={changed}>Refresh status</button><button className="button" disabled={busy||!key.trim()} onClick={()=>void submit("connect")}>{busy?"Working…":data.id?"Test and replace key":"Test and connect"}</button>{data.status==="connected"&&<><button className="secondary" disabled={busy} onClick={()=>void submit("test")}>Test connection</button><button className="secondary" disabled={busy} onClick={()=>void submit("update")}>Save permissions</button><button className="secondary" disabled={busy} onClick={()=>{if(window.confirm("Disconnect Lusha and stop future Research lookups?"))void submit("update",true);}}>Disconnect</button></>}</div>
 </>}
 {error&&<p role="alert">{error}</p>}
 <p>HVM recorded usage: {data.usage.recordedCredits} credits{data.usage.limited?" (latest 1,000 lookups)":""}. {data.usage.uncertainLookups>0?`${data.usage.uncertainLookups} lookup outcomes need review; this is not a complete cost total.`:""}</p>
 <p>Account credits remaining: {data.credits?.remaining??"Unknown"}</p>
 {data.lastTestedAt&&<p className="small muted">Last checked {new Date(data.lastTestedAt).toLocaleString("en-GB")}. Account balance may include usage outside HVM.</p>}
 <p className="small muted">Account access does not confirm every paid capability. Research will request only permitted operations.</p>
 </div>;
}
