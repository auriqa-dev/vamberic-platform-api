import { useHenryBinding, henryFields, applyHenryFields } from "./workspace-henry";
import { useEffect, useRef, useState } from "react";
import { readUpload, type UploadSheet } from "../data/hive-upload";
import {
  researchDetails,
  type ResearchDetails,
  type ResearchDocument,
  type ResearchGateway,
  type ResearchSelection,
} from "../data/research-documents";
const empty = (): ResearchDetails => ({
  name: "",
  purpose: "",
  extract: "",
  provenance: "",
  grain: "other",
});
export function ResearchDocuments({
  api,
  w,
  selected,
  onSelect,
  disabled = false,
}: {
  api?: ResearchGateway;
  w: string;
  selected: ResearchSelection;
  onSelect: (value: ResearchSelection) => void;
  disabled?: boolean;
}) {
  const [rows, setRows] = useState<ResearchDocument[]>([]),
    [available, setAvailable] = useState(false);
  const [details, setDetails] = useState(empty),
    [file, setFile] = useState<File>(),
    [editing, setEditing] = useState<ResearchDocument>();
  const [sheets, setSheets] = useState<UploadSheet[]>([]),
    [sheet, setSheet] = useState(0),
    [from, setFrom] = useState(1),
    [to, setTo] = useState(5);
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState("");
  const [bulkPurpose, setBulkPurpose] = useState("");
  const [marked, setMarked] = useState<string[]>([]);
  const lock = useRef(false),
    key = useRef(crypto.randomUUID());
  const signal = useRef(new AbortController());
  useEffect(() => {
    const controller = new AbortController();
    signal.current = controller;
    setRows([]);
    setMarked([]);
    setDetails(empty());
    setFile(undefined);
    setEditing(undefined);
    api
      ?.list(w, controller.signal)
      .then((result) => {
        if (!controller.signal.aborted) {
          setRows(result.documents);
          setAvailable(result.available);
          if (result.more) setNotice("Showing the latest 200 documents.");
        }
      })
      .catch(() => {
        if (!controller.signal.aborted)
          setError(
            "Research documents could not be loaded. Reopen this page to try again.",
          );
      });
    return () => controller.abort();
  }, [api, w]);
  useHenryBinding({key:"research-documents",priority:80,enabled:!!editing||!!file,summary:JSON.stringify({document:details.name,purpose:details.purpose,grain:details.grain,provenance:details.provenance,extract:details.extract.slice(0,10000)}),
    editor:!busy&&!disabled?{key:`research:${editing?.id??file?.name??"new"}`,title:"Research document details",fields:henryFields({name:details.name,purpose:details.purpose})}:undefined,
    apply:changes=>change(applyHenryFields({name:details.name,purpose:details.purpose},changes)),
  });
  if (!api) return null;
  function change(next: Partial<ResearchDetails>) {
    setDetails((d) => ({ ...d, ...next }));
    key.current = crypto.randomUUID();
  }
  async function act(work: () => Promise<void>) {
    if (lock.current || disabled) return;
    lock.current = true;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await work();
      const result = await api!.list(w, signal.current.signal);
      setRows(result.documents);
    } catch (e) {
      if (!signal.current.signal.aborted)
        setError(
          e instanceof Error && !("code" in e)
            ? e.message
            : "The document action could not finish. Your entries are retained; retry or reload if the document changed.",
        );
    } finally {
      lock.current = false;
      if (!signal.current.signal.aborted) setBusy(false);
    }
  }
  async function remove(targets: ResearchDocument[]) {
    if (
      !targets.length ||
      !window.confirm(
        `Remove ${targets.length} research document(s) from future use? Historical evidence and private originals are retained.`,
      )
    )
      return;
    await act(async () => {
      await api!.remove(w, targets, signal.current.signal);
      onSelect(selected.filter((s) => !targets.some((t) => t.id === s.id)));
      setMarked([]);
      setNotice("Documents removed from future generation.");
    });
  }
  return (
    <details className="research-library">
      <summary>Research documents (optional)</summary>
      <p>
        Keep supporting files here without importing companies or contacts.
        Generation uses the extract you review below, not the whole file.
        Original files remain available to download.
      </p>
      {error && <p role="alert">{error}</p>}
      {notice && <p role="status">{notice}</p>}
      <fieldset disabled={busy || disabled}>
        <legend>Choose evidence for this generation</legend>
        {!rows.length && <p>No research documents yet.</p>}
        {rows.map((row) => (
          <div className="research-row" key={row.id}>
            <label className="offer-check">
              <input
                type="checkbox"
                aria-label={`Select ${row.details.name} for removal`}
                checked={marked.includes(row.id)}
                onChange={(e) =>
                  setMarked(
                    e.target.checked
                      ? [...marked, row.id]
                      : marked.filter((id) => id !== row.id),
                  )
                }
              />
              <strong>{row.details.name}</strong>
            </label>
            <p className="muted">
              {row.filename} · {Math.ceil(row.size / 1024)} KB ·{" "}
              {row.status === "ready"
                ? `Version ${row.revision}`
                : "Upload incomplete — retry using the same file"}
            </p>
            <label className="offer-check">
              <input
                type="checkbox"
                disabled={
                  row.status !== "ready" ||
                  (!selected.some((s) => s.id === row.id) &&
                    selected.length >= 6)
                }
                checked={selected.some(
                  (s) => s.id === row.id && s.revision === row.revision,
                )}
                onChange={(e) =>
                  onSelect(
                    e.target.checked
                      ? [
                          ...selected.filter((s) => s.id !== row.id),
                          { id: row.id, revision: row.revision },
                        ]
                      : selected.filter((s) => s.id !== row.id),
                  )
                }
              />
              Use reviewed extract
            </label>
            {row.status === "uploading" && (
              <label className="offer-field">
                Resume upload with the original file
                <input
                  type="file"
                  accept=".csv,.xlsx,.txt,.md"
                  onChange={(e) => {
                    const original = e.target.files?.[0];
                    if (original)
                      void act(async () => {
                        await api.resume(
                          w,
                          row,
                          original,
                          signal.current.signal,
                        );
                        setNotice("Upload completed.");
                      });
                  }}
                />
              </label>
            )}
            <details>
              <summary>View extract</summary>
              <p>{row.details.purpose}</p>
              <p>
                {row.details.provenance} ·{" "}
                {row.details.grain.replaceAll("_", " ")}
              </p>
              <pre>{row.details.extract}</pre>
            </details>
            <div className="research-actions">
              <button
                type="button"
                onClick={() => {
                  setEditing(row);
                  setDetails(row.details);
                  setFile(undefined);
                  setSheets([]);
                }}
              >
                Edit extract
              </button>
              <button
                type="button"
                disabled={row.status !== "ready"}
                onClick={() =>
                  void act(async () => {
                    const blob = await api.download(
                      w,
                      row,
                      signal.current.signal,
                    );
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement("a");
                    link.href = url;
                    link.download = row.filename;
                    link.click();
                    setTimeout(() => URL.revokeObjectURL(url), 1000);
                  })
                }
              >
                Download original
              </button>
              <button type="button" onClick={() => void remove([row])}>
                Remove
              </button>
            </div>
          </div>
        ))}
        {marked.length > 0 && (
          <button
            type="button"
            onClick={() =>
              void remove(rows.filter((r) => marked.includes(r.id)))
            }
          >
            Remove selected ({marked.length})
          </button>
        )}
        {marked.length > 0 && (
          <div className="research-editor">
            <label className="offer-field">
              Research purpose for selected documents
              <textarea
                rows={2}
                maxLength={1000}
                value={bulkPurpose}
                onChange={(e) => setBulkPurpose(e.target.value)}
              />
            </label>
            <button
              type="button"
              disabled={!bulkPurpose.trim()}
              onClick={() =>
                void act(async () => {
                  await api.updatePurpose(
                    w,
                    rows.filter((r) => marked.includes(r.id)),
                    bulkPurpose,
                    signal.current.signal,
                  );
                  onSelect(selected.filter((s) => !marked.includes(s.id)));
                  setMarked([]);
                  setBulkPurpose("");
                  setNotice(
                    "Selected document purposes updated. Select their new versions before generation.",
                  );
                })
              }
            >
              Update selected purposes
            </button>
          </div>
        )}
      </fieldset>
      {!available ? (
        <p>Research file storage is not enabled in this environment.</p>
      ) : (
        <fieldset disabled={busy || disabled} className="research-editor">
          <legend>
            {editing ? "Edit research extract" : "Add research document"}
          </legend>
          {!editing && (
            <label className="offer-field">
              File (CSV, Excel, text or Markdown; up to 50 MB)
              <input
                type="file"
                accept=".csv,.xlsx,.txt,.md"
                onChange={(e) => {
                  const next = e.target.files?.[0];
                  if (!next) return;
                  setFile(next);
                  setSheets([]);
                  setDetails({ ...empty(), name: next.name });
                  key.current = crypto.randomUUID();
                  void act(async () => {
                    if (next.size > 50 * 1024 * 1024)
                      throw new Error("Choose a file up to 50 MB.");
                    if (/\.(csv|xlsx)$/i.test(next.name)) {
                      const parsed = await readUpload(next);
                      setSheets(parsed);
                      setDetails((d) => ({ ...d, grain: "mixed" }));
                      setSheet(0);
                      setFrom(1);
                      setTo(Math.min(5, parsed[0]?.rows.length ?? 1));
                    } else {
                      const text = await next.text();
                      if (text.length <= 6000)
                        setDetails((d) => ({
                          ...d,
                          extract: text,
                          provenance: "Complete text document",
                        }));
                      else
                        setNotice(
                          "This document is longer than the generation extract. Paste the relevant passage below; the complete file will still be stored.",
                        );
                    }
                  });
                }}
              />
            </label>
          )}
          {sheets.length > 0 && (
            <div className="research-grid">
              <label className="offer-field">
                Sheet
                <select
                  value={sheet}
                  onChange={(e) => {
                    setSheet(Number(e.target.value));
                    setFrom(1);
                    setTo(
                      Math.min(5, sheets[Number(e.target.value)]!.rows.length),
                    );
                  }}
                >
                  {sheets.map((s, i) => (
                    <option key={i} value={i}>
                      {s.name} ({s.rows.length} data rows)
                    </option>
                  ))}
                </select>
              </label>
              <label className="offer-field">
                From data row
                <input
                  type="number"
                  min={1}
                  value={from}
                  onChange={(e) => setFrom(Number(e.target.value))}
                />
              </label>
              <label className="offer-field">
                To data row
                <input
                  type="number"
                  min={from}
                  value={to}
                  onChange={(e) => setTo(Number(e.target.value))}
                />
              </label>
              <button
                type="button"
                onClick={() => {
                  const s = sheets[sheet]!;
                  if (
                    !Number.isInteger(from) ||
                    !Number.isInteger(to) ||
                    from < 1 ||
                    to < from ||
                    to > s.rows.length
                  ) {
                    setError("Choose a valid data-row range.");
                    return;
                  }
                  const extract = s.rows
                    .slice(from - 1, to)
                    .map(
                      (r, i) =>
                        `Row ${s.sourceRows?.[from - 1 + i] ?? from + i + 1}: ${s.headers.map((h, j) => `${h}: ${r[j] ?? ""}`).join("; ")}`,
                    )
                    .join("\n");
                  if (extract.length > 6000) {
                    setError(
                      "That selection exceeds the 6,000-character extract. Choose fewer rows or summarise the relevant evidence below. The complete original is retained.",
                    );
                    return;
                  }
                  setError("");
                  change({
                    extract,
                    provenance: `Sheet: ${s.name}; selected data rows ${from}–${to} of ${s.rows.length}. Original row numbers are shown in the extract.`,
                  });
                }}
              >
                Use selected rows
              </button>
            </div>
          )}
          <div className="research-grid">
            <label className="offer-field">
              Document name
              <input
                maxLength={200}
                value={details.name}
                onChange={(e) => change({ name: e.target.value })}
              />
            </label>
            <label className="offer-field">
              What does each observation describe?
              <select
                value={details.grain}
                onChange={(e) =>
                  change({ grain: e.target.value as ResearchDetails["grain"] })
                }
              >
                <option value="other">Other / narrative</option>
                <option value="company">Individual company</option>
                <option value="reporting_group">Reporting group</option>
                <option value="person">Individual person</option>
                <option value="mixed">Mixed or uncertain</option>
              </select>
            </label>
          </div>
          <label className="offer-field">
            How should this inform the research?
            <textarea
              maxLength={1000}
              rows={2}
              value={details.purpose}
              onChange={(e) => change({ purpose: e.target.value })}
            />
          </label>
          <label className="offer-field">
            Source location and scope
            <textarea
              maxLength={1000}
              rows={2}
              value={details.provenance}
              onChange={(e) => change({ provenance: e.target.value })}
              placeholder="Sheet, rows or pages; dates; whether this is a sample or complete evidence"
            />
          </label>
          <label className="offer-field">
            Reviewed extract
            <textarea
              maxLength={6000}
              rows={6}
              value={details.extract}
              onChange={(e) => change({ extract: e.target.value })}
            />
            <span className="muted">
              {details.extract.length.toLocaleString()} / 6,000 characters.
              Group totals must not be treated as individual company figures.
            </span>
          </label>
          <div className="research-actions">
            {editing && (
              <button
                type="button"
                onClick={() => {
                  setEditing(undefined);
                  setDetails(empty());
                }}
              >
                Cancel
              </button>
            )}
            <button
              type="button"
              className="button-primary"
              disabled={
                !researchDetails.safeParse(details).success ||
                (!editing && !file)
              }
              onClick={() =>
                void act(async () => {
                  if (editing) {
                    await api.update(
                      w,
                      editing,
                      details,
                      signal.current.signal,
                    );
                    onSelect(selected.filter((s) => s.id !== editing.id));
                  } else
                    await api.upload(
                      w,
                      file!,
                      details,
                      key.current,
                      signal.current.signal,
                    );
                  setDetails(empty());
                  setFile(undefined);
                  setSheets([]);
                  setEditing(undefined);
                  key.current = crypto.randomUUID();
                  setNotice(
                    "Research document saved. Choose its reviewed extract above to use it in generation.",
                  );
                })
              }
            >
              {busy
                ? "Saving…"
                : editing
                  ? "Save changes"
                  : "Upload research document"}
            </button>
          </div>
        </fieldset>
      )}
    </details>
  );
}
