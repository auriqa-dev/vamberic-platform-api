import { useState, useRef } from "react";
import type { ContentBundle, ContentGateway } from "../data/content-strategy";
import { briefData, type ContentRecord } from "../data/content-strategy-model";
import { DataError } from "../data/gateway";

/** Uses the same saved brief and approval path as Content Strategy. */
export function EmailBrief({api, workspaceId, brandId, bundle, onSaved}: {
  api: ContentGateway; workspaceId: string; brandId: string; bundle: ContentBundle;
  onSaved: (record: ContentRecord) => Promise<void>;
}) {
  const [title,setTitle]=useState(""), [objective,setObjective]=useState(""),
    [audience,setAudience]=useState(""), [message,setMessage]=useState(""),
    [cta,setCta]=useState(""), [restrictions,setRestrictions]=useState(""),
    [offerId,setOfferId]=useState(""), [saved,setSaved]=useState<ContentRecord>(),
    [busy,setBusy]=useState(false), [error,setError]=useState("");
  const attempt=useRef<{signature:string;key:string}|undefined>(undefined);
  const offer=bundle.choices.offers?.find(o=>o.id===offerId && o.brandId===brandId);
  function data(){return briefData.parse({
    title,actionId:"",scope:{brandId,products:[],offers:offer?[{id:offer.id,revision:offer.revision}]:[],audiences:[]},
    classification:"channel",format:"Personalised email",channel:"email",objective,audience,
    buyerQuestion:"",buyerStage:"",messages:message?[message]:[],evidence:[],sourceAssetIds:[],structure:[],preserve:[],mayChange:[],cta,
    restrictions:restrictions?[restrictions]:[],approvalRequirements:["Review and approve the email before delivery."],
    personalisation:{objective,depth:"CONTEXTUAL",allowedContext:[],requiredContext:[],evidenceSources:[],maximumAgeDays:null,opening:"",coreMessage:message,variations:[],prohibitedAssumptions:["Do not invent recipient facts or familiarity."],fallback:"Flag missing evidence for review.",length:"Concise",sendingRequirements:[]}
  });}
  const dirty=!!saved && (()=>{try{return JSON.stringify(data())!==JSON.stringify(saved.data);}catch{return true;}})();
  async function mutate(operation:"save"|"approve"){
    if(busy)return;setBusy(true);setError("");
    try{
      const input={kind:"brief" as const,operation,id:saved?.id,expectedVersion:saved?.version??0,data:operation==="save"?data():undefined};
      const signature=JSON.stringify(input);
      if(attempt.current?.signature!==signature)attempt.current={signature,key:crypto.randomUUID()};
      const row=await api.save(workspaceId,{...input,requestKey:attempt.current.key},new AbortController().signal);
      attempt.current=undefined;
      setSaved(row);await onSaved(row);
    }catch(e){setError(e instanceof DataError?e.userMessage||"Could not save the brief.":"Check the brief fields and try again.");}
    finally{setBusy(false);}
  }
  return <details className="panel"><summary>Create an email brief here</summary>
    <p>This is saved in Content Strategy too. Approve the saved brief before generating an email.</p>
    <div className="email-fields">
      <label>Brief title<input maxLength={200} value={title} onChange={e=>setTitle(e.target.value)}/></label>
      <label>Offer<select value={offerId} onChange={e=>setOfferId(e.target.value)}><option value="">No specific offer</option>{bundle.choices.offers?.filter(o=>o.brandId===brandId).map(o=><option key={o.id} value={o.id}>{o.name}</option>)}</select></label>
      <label>What should the email achieve?<textarea maxLength={2000} value={objective} onChange={e=>setObjective(e.target.value)}/></label>
      <label>Who is it for?<textarea maxLength={2000} value={audience} onChange={e=>setAudience(e.target.value)}/></label>
      <label>Key message<textarea maxLength={2000} value={message} onChange={e=>setMessage(e.target.value)}/></label>
      <label>Desired next step<textarea maxLength={2000} value={cta} onChange={e=>setCta(e.target.value)}/></label>
      <label>Restrictions and evidence requirements<textarea maxLength={2000} value={restrictions} onChange={e=>setRestrictions(e.target.value)}/></label>
    </div>
    {saved && <p role="status">{String(saved.data.title)} · {saved.status}{dirty?" · Unsaved changes":""}</p>}
    <div className="email-actions"><button disabled={busy||!title.trim()||!objective.trim()||!audience.trim()||!!saved&&!dirty} onClick={()=>void mutate("save")}>Save brief</button>
      {saved?.status==="draft"&&!dirty&&<button disabled={busy} onClick={()=>void mutate("approve")}>Approve brief</button>}
    </div>{error&&<p role="alert">{error}</p>}
  </details>;
}
