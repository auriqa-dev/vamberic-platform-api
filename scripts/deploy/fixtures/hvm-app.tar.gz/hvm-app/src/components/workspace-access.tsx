import { useCallback, useState } from "react";
import { useResource } from "../data/use-resource";
import { DataError } from "../data/gateway";
import type {
  WorkspaceAccessGateway,
  WorkspaceAccess,
} from "../data/workspace-access";
import { Loading, Failure } from "./ui";
export function WorkspaceAccessEditor({
  api,
  workspaceId,
}: {
  api: WorkspaceAccessGateway;
  workspaceId: string;
}) {
  const [revision, setRevision] = useState(0);
  const load = useCallback(
    (signal: AbortSignal) => {
      void revision;
      return api.load(workspaceId, signal);
    },
    [api, workspaceId, revision],
  );
  const result = useResource(load);
  if (result.state === "loading") return <Loading />;
  if (result.state === "error")
    return (
      <Failure error={result.error} retry={() => setRevision((v) => v + 1)} />
    );
  return (
    <AccessForm
      key={revision}
      api={api}
      data={result.data}
      refresh={() => setRevision((v) => v + 1)}
    />
  );
}
function AccessForm({
  api,
  data,
  refresh,
}: {
  api: WorkspaceAccessGateway;
  data: WorkspaceAccess;
  refresh: () => void;
}) {
  const [account, setAccount] = useState(""),
    [role, setRole] = useState("member"),
    [management, setManagement] = useState(data.management),
    [partner, setPartner] = useState(
      data.partnerAssignments.find((a) => a.role === "primary")?.partnerId ??
        "",
    );
  const [confirm, setConfirm] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const admins = data.memberships.filter(
    (m) => m.status === "active" && m.role === "admin",
  ).length;
  async function change(
    operation: Parameters<WorkspaceAccessGateway["change"]>[1],
    input: unknown,
  ) {
    setBusy(true);
    setError("");
    try {
      await api.change(
        data.workspaceId,
        operation,
        input,
        new AbortController().signal,
      );
      refresh();
    } catch (e) {
      setError(
        e instanceof DataError && e.code === "conflict"
          ? "Access has changed or this would remove the last administrator. Reload the team and review before trying again."
          : "We couldn’t confirm the change. Reload the team to check its current access.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="panel workspace-access">
      <h2>Team & workspace access</h2>
      <p>
        This workspace belongs to your client organisation. Client
        administrators can operate it directly, with or without an assigned
        Queen.
      </p>
      <p>
        <strong>
          {data.management === "client"
            ? "Client-managed workspace"
            : "Queen-managed workspace"}
        </strong>
      </p>
      <details>
        <summary>Your sign-in account ID</summary>
        <p>{data.currentHuman.id}</p>
        <p className="muted">
          Share this ID with your workspace administrator when requesting
          access. It is not your password.
        </p>
      </details>
      {error && <p role="alert">{error}</p>}
      <button className="text-button" onClick={refresh} disabled={busy}>
        Reload team
      </button>
      <div className="table-scroll">
        <table>
          <thead>
            <tr>
              <th>Account</th>
              <th>Role</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {data.memberships.map((m) => (
              <tr key={m.id}>
                <td className="wrap-anywhere">
                  {m.human.id === data.currentHuman.id ? "You" : m.human.id}
                </td>
                <td>
                  {m.role === "admin"
                    ? "Workspace administrator"
                    : "Member (view access)"}
                </td>
                <td>{m.status}</td>
                <td>
                  {data.canManage &&
                    m.status === "active" &&
                    m.human.id !== data.currentHuman.id &&
                    !(m.role === "admin" && admins === 1) && (
                      <button
                        disabled={busy}
                        onClick={() =>
                          void change("member-revoke", {
                            id: m.id,
                            expectedUpdatedAt: m.updatedAt,
                          })
                        }
                      >
                        Remove access
                      </button>
                    )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {data.canManage && (
        <form
          className="workspace-access-form"
          onSubmit={(e) => {
            e.preventDefault();
            void change("member-provision", {
              human: { ...data.currentHuman, id: account.trim() },
              role,
            });
          }}
        >
          <h3>Add a signed-in client user</h3>
          <p>
            Ask the user for their existing HVM account ID. This adds workspace
            access; it does not send an invitation or grant platform privileges.
          </p>
          <div className="form-grid">
            <label className="field">
              Account ID
              <input
                required
                maxLength={200}
                value={account}
                onChange={(e) => setAccount(e.target.value)}
                disabled={busy}
              />
            </label>
            <label className="field">
              Workspace role
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                disabled={busy}
              >
                <option value="member">Member — view access</option>
                <option value="admin">Workspace administrator</option>
              </select>
            </label>
          </div>
          <button className="button" disabled={busy || !account.trim()}>
            Add user
          </button>
        </form>
      )}
      {data.canChangeManagement && (
        <form
          className="workspace-access-form"
          onSubmit={(e) => {
            e.preventDefault();
            void change("management-change", {
              management,
              ...(management === "queen" ? { partnerId: partner.trim() } : {}),
              expectedUpdatedAt: data.updatedAt,
              confirm: true,
            });
          }}
        >
          <h3>Who manages this workspace?</h3>
          <label className="field">
            Management
            <select
              disabled={busy}
              value={management}
              onChange={(e) => {
                setManagement(e.target.value as typeof management);
                setConfirm(false);
              }}
            >
              <option value="client">Our client team</option>
              <option value="queen">An assigned Queen</option>
            </select>
          </label>
          {management === "queen" && (
            <label className="field">
              Queen / Partner ID
              <input
                required
                value={partner}
                onChange={(e) => {
                  setPartner(e.target.value);
                  setConfirm(false);
                }}
                disabled={busy}
              />
            </label>
          )}
          <p>
            {management === "client"
              ? "This ends all current Queen assignments. Your client team and saved records remain."
              : "This grants the selected Queen access and ends other Queen assignments. Your client administrators retain access."}{" "}
            Billing and integration permissions remain unchanged.
          </p>
          <label>
            <input
              type="checkbox"
              checked={confirm}
              onChange={(e) => setConfirm(e.target.checked)}
              disabled={busy}
            />
            I have reviewed this change in access.
          </label>
          <button
            className="button"
            disabled={
              busy || !confirm || (management === "queen" && !partner.trim())
            }
          >
            Save management arrangement
          </button>
        </form>
      )}
    </section>
  );
}
