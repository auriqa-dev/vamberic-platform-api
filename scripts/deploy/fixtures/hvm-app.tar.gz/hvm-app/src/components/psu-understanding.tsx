import type { ReactNode } from "react";

export const groups: [string, [string, string][]][] = [
  [
    "What is being sold?",
    [
      ["name", "Name"],
      ["description", "Summary"],
      ["primaryOfferingType", "Type of offering"],
      ["offeringTypeExplanation", "Why this type"],
      ["offeringTypeOtherDetail", "Other offering type details"],
      ["secondaryOfferingTypes", "Other offering types"],
      ["whatItIs", "What it is"],
      ["websiteUrl", "Website"],
    ],
  ],
  [
    "What does the customer buy?",
    [
      ["whatCustomerBuys", "What the customer buys"],
      ["deliverables", "Deliverables"],
      ["desiredOutcomes", "Intended outcomes"],
      ["valueProposition", "Value proposition"],
    ],
  ],
  [
    "How is it delivered?",
    [
      ["deliveryModes", "Delivery approach"],
      ["engagementModel", "How it works"],
      ["implementationModel", "Implementation"],
      ["implementationExplanation", "Implementation details"],
      ["technologyRole", "Role of technology"],
      ["technologyRoleExplanation", "How technology is used"],
      ["businessModel", "Business model"],
      ["commercialModel", "Commercial model"],
    ],
  ],
  [
    "Who does what?",
    [
      ["supplierRole", "Supplier responsibilities"],
      ["customerRole", "Customer responsibilities"],
    ],
  ],
  [
    "Capabilities and problems solved",
    [
      ["capabilities", "Capabilities"],
      ["problemsSolved", "Problems solved"],
      ["purchaseConsiderations", "Buyer considerations"],
      ["buyerNextSteps", "Next steps for a buyer"],
      ["differentiators", "Differentiators"],
      ["industriesServed", "Industries"],
      ["regionsServed", "Regions"],
      ["competitors", "Competitors"],
    ],
  ],
  [
    "Scope and exclusions",
    [
      ["boundaries", "Scope limits"],
      ["explicitExclusions", "Explicit exclusions"],
    ],
  ],
  [
    "Language and claims",
    [
      ["approvedTerminology", "Terms to use"],
      ["avoidTerminology", "Terms to avoid"],
      ["approvedClaims", "Claims recorded in this version"],
      ["proofPoints", "Supporting proof"],
      ["regulatoryContext", "Regulatory context"],
    ],
  ],
  ["What is still unknown?", [["unknowns", "Unresolved facts"]]],
];
// Put the editable product profile first; retain detailed fields below it.
const profileFields: [string, string][] = [
  ["name", "Product name"],
  ["businessModel", "Business model"],
  ["description", "Summary"],
  ["competitors", "Competitor products"],
  ["websiteUrl", "Product URL"],
  ["differentiators", "Key differentiators"],
  ["engagementModel", "How it works"],
  ["valueProposition", "Value proposition"],
  ["industriesServed", "Industries served"],
  ["regionsServed", "Regions served"],
  ["problemsSolved", "Buyer pains solved"],
];
const profileKeys = new Set(profileFields.map(([key]) => key));
export const productGroups: typeof groups = [
  ["Product details", profileFields],
  ...groups
    .map(([title, fields]): [string, [string, string][]] => [
      title,
      fields.filter(([key]) => !profileKeys.has(key)),
    ])
    .filter(([, fields]) => fields.length > 0),
];
export const fullWidthProductFields = new Set([
  "description",
  "competitors",
  "websiteUrl",
  "valueProposition",
  "problemsSolved",
]);
const enums = new Set([
  "primaryOfferingType",
  "secondaryOfferingTypes",
  "deliveryModes",
  "implementationModel",
  "technologyRole",
]);
function value(v: unknown, humanize = false): ReactNode {
  if (v == null || v === "" || (Array.isArray(v) && !v.length))
    return <span className="muted">Not recorded</span>;
  if (Array.isArray(v))
    return (
      <ul>
        {v.map((item, i) => (
          <li key={i}>{value(item, humanize)}</li>
        ))}
      </ul>
    );
  if (typeof v === "object")
    return (
      <dl>
        {Object.entries(v).map(([k, item]) => (
          <div key={k}>
            <dt>{k}</dt>
            <dd>{value(item)}</dd>
          </div>
        ))}
      </dl>
    );
  return String(humanize ? String(v).replaceAll("_", " ") : v);
}
/** Presentation only: no evidence status or approval is inferred from field names. */
export function PsuUnderstanding({
  definition,
}: {
  definition: Record<string, unknown>;
}) {
  const mapped = new Set(
    productGroups.flatMap(([, fields]) => fields.map(([key]) => key)),
  );
  const remaining = Object.fromEntries(
    Object.entries(definition).filter(([key]) => !mapped.has(key)),
  );
  return (
    <div className="psu-understanding psu-product-details">
      {productGroups
        .filter(([, fields]) => fields.some(([key]) => key in definition))
        .map(([title, fields]) => (
          <section key={title}>
            <h3>{title}</h3>
            <dl>
              {fields
                .filter(([key]) => key in definition)
                .map(([key, label]) => (
                  <div
                    key={key}
                    className={
                      fullWidthProductFields.has(key)
                        ? "psu-product-wide"
                        : undefined
                    }
                  >
                    <dt>{label}</dt>
                    <dd>{value(definition[key], enums.has(key))}</dd>
                  </div>
                ))}
            </dl>
          </section>
        ))}
      {Object.keys(remaining).length > 0 && (
        <details>
          <summary>Additional recorded information</summary>
          {value(remaining)}
        </details>
      )}
    </div>
  );
}
