import { z } from "zod";
import type { createTransport } from "./transport";
export const settings = z.object({
  name: z.string(),
  layout: z.enum(["personal", "branded"]),
  accentRole: z.enum(["primary", "secondary", "accent"]),
  includeLogo: z.boolean().default(false),
  logoAlignment: z.enum(["left", "centre", "right"]).default("left"),
  logoWidth: z.number().int().min(48).max(320).default(160),
  logoSpacing: z.number().int().min(8).max(64).default(24),
  includeSignature: z.boolean(),
  includeFooter: z.boolean(),
});
export type TemplateSettings = z.infer<typeof settings>;
const template = z.object({
  id: z.string(),
  version: z.number(),
  brandId: z.string(),
  status: z.string(),
  isDefault: z.boolean(),
  settings,
});
export type EmailTemplate = z.infer<typeof template>;
const preview = z.object({
  template: z.object({ id: z.string(), version: z.number() }).passthrough(),
  rendered: z.object({
    subject: z.string(),
    text: z.string(),
    html: z.string(),
    notice: z.string().optional(),
    inlineImages: z
      .array(z.object({ cid: z.literal("brand-logo"), base64: z.string() }))
      .optional(),
  }),
});
export type RenderedEmail = z.infer<typeof preview>["rendered"];
export function templateGateway(http: ReturnType<typeof createTransport>) {
  const root = (w: string) =>
    `/api/v1/hvm/workspaces/${encodeURIComponent(w)}/communications`;
  return {
    list: async (w: string, brandId: string, s: AbortSignal) =>
      z
        .array(template)
        .parse(await http(root(w) + "/templates", s, { query: { brandId } })),
    change: async (w: string, input: unknown, s: AbortSignal) =>
      http(root(w) + "/templates", s, { method: "POST", body: input }),
    sample: async (w: string, input: unknown, s: AbortSignal) =>
      preview.parse(await http(root(w) + "/templates/sample", s, {method:"POST",body:input})),
    preview: async (w: string, input: unknown, s: AbortSignal) =>
      preview.parse(
        await http(root(w) + "/preview", s, { method: "POST", body: input }),
      ),
  };
}
export type TemplateGateway = ReturnType<typeof templateGateway>;
