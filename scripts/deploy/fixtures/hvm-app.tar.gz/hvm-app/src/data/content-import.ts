import JSZip from "jszip";
export async function extractContentFile(file: File): Promise<string> {
  if (file.size > 50 * 1024 * 1024)
    throw new Error("Choose a file up to 50 MB.");
  let text = "";
  if (/\.(md|txt|csv)$/i.test(file.name)) text = await file.text();
  else if (/\.docx$/i.test(file.name)) {
    const zip = await JSZip.loadAsync(await file.arrayBuffer());
    const entry = zip.file("word/document.xml");
    if (!entry) throw new Error("This is not a readable Word document.");
    const size = (entry as unknown as { _data?: { uncompressedSize?: number } })
      ._data?.uncompressedSize;
    if (!size || size > 8 * 1024 * 1024)
      throw new Error("This Word document is too large to extract safely.");
    const xml = await entry.async("string");
    if (xml.includes("<!DOCTYPE"))
      throw new Error("Unsupported Word document.");
    const doc = new DOMParser().parseFromString(xml, "application/xml");
    if (doc.querySelector("parsererror"))
      throw new Error("Word text could not be read.");
    text = Array.from(doc.getElementsByTagName("w:p"))
      .map((p) =>
        Array.from(p.getElementsByTagName("w:t"))
          .map((t) => t.textContent ?? "")
          .join(""),
      )
      .join("\n");
  } else if (/\.(pptx|xlsx)$/i.test(file.name)) {
    const zip = await JSZip.loadAsync(await file.arrayBuffer());
    const entries = Object.values(zip.files)
      .filter(
        (entry) =>
          !entry.dir &&
          /^(ppt\/slides\/slide\d+\.xml|xl\/sharedStrings\.xml|xl\/worksheets\/sheet\d+\.xml)$/.test(
            entry.name,
          ),
      )
      .sort((a, b) =>
        a.name.localeCompare(b.name, undefined, { numeric: true }),
      );
    if (entries.length > 300)
      throw new Error(
        "This document has too many sections for automatic extraction. The original can still be stored.",
      );
    let total = 0;
    const documents = new Map<string, Document>();
    for (const entry of entries) {
      const size = (
        entry as unknown as { _data?: { uncompressedSize?: number } }
      )._data?.uncompressedSize;
      if (!size || (total += size) > 8 * 1024 * 1024)
        throw new Error("Extracted document exceeds the safe processing size.");
      const xml = await entry.async("string");
      if (/<!DOCTYPE|<!ENTITY/i.test(xml))
        throw new Error("Unsupported document structure.");
      const doc = new DOMParser().parseFromString(xml, "application/xml");
      if (doc.querySelector("parsererror"))
        throw new Error("Document text could not be read.");
      documents.set(entry.name, doc);
    }
    const nodes = (parent: Document | Element, name: string) =>
      Array.from(parent.getElementsByTagName("*")).filter(
        (n) => n.localName === name,
      );
    const strings = documents.get("xl/sharedStrings.xml");
    const shared = strings
      ? nodes(strings, "si").map((si) =>
          nodes(si, "t")
            .map((n) => n.textContent ?? "")
            .join(""),
        )
      : [];
    const sections: string[] = [];
    for (const [name, doc] of documents) {
      if (name === "xl/sharedStrings.xml") continue;
      if (name.startsWith("xl/")) {
        sections.push(
          `[${name}]\n` +
            nodes(doc, "row")
              .map((row) =>
                nodes(row, "c")
                  .map((cell) => {
                    const value = nodes(cell, "v")[0]?.textContent ?? "";
                    const type = cell.getAttribute("t");
                    // Retain cell addresses and numeric values; formula results are cached values, never executed.
                    const displayed =
                      type === "s"
                        ? (shared[Number(value)] ?? "")
                        : type === "inlineStr"
                          ? nodes(cell, "t")
                              .map((n) => n.textContent ?? "")
                              .join("")
                          : value;
                    return `${cell.getAttribute("r") ?? "cell"}: ${displayed}`;
                  })
                  .join(" | "),
              )
              .join("\n"),
        );
      } else
        sections.push(
          `[${name}]\n` +
            nodes(doc, "p")
              .map((p) =>
                nodes(p, "t")
                  .map((n) => n.textContent ?? "")
                  .join(" "),
              )
              .join("\n"),
        );
    }
    text = sections.join("\n\n");
  } else if (/\.pdf$/i.test(file.name)) {
    const pdf = await import("pdfjs-dist"),
      worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
    pdf.GlobalWorkerOptions.workerSrc = worker.default;
    const loading = pdf.getDocument({
      data: new Uint8Array(await file.arrayBuffer()),
      isEvalSupported: false,
      useSystemFonts: false,
    });
    try {
      const doc = await loading.promise;
      if (doc.numPages > 300)
        throw new Error(
          "Split PDFs longer than 300 pages into smaller documents.",
        );
      const pages = [];
      let readableCharacters = 0;
      for (let i = 1; i <= doc.numPages; i++) {
        const p = await doc.getPage(i),
          content = await p.getTextContent();
        const pageText = content.items
          .map((x) => ("str" in x ? x.str : ""))
          .join(" ");
        readableCharacters += pageText.trim().length;
        pages.push(`[Page ${i}]\n${pageText}`);
        if (pages.join("\n").length > 180000)
          throw new Error(
            "The extracted text is too long. Split the document before importing.",
          );
      }
      text = readableCharacters ? pages.join("\n\n") : "";
    } finally {
      await loading.destroy();
    }
  } else
    throw new Error(
      "Automatic text extraction is not available for this format. Store the original and add a description or transcript.",
    );
  if (!text.trim())
    throw new Error(
      "No readable text found. Supply a transcript or paste a description; scanned pages are not automatically analysed.",
    );
  if (text.length > 180000)
    throw new Error("The text is too long. Split it into smaller assets.");
  return text;
}
