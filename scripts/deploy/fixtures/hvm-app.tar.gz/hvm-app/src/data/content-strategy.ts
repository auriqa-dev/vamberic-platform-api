import { createEmailContentGateway } from "./email-content";
import { createLibraryGateway } from "./library";
import { z } from "zod";
import type { AuthSession } from "../auth/session";
import { createTransport } from "./transport";
import { createResearchGateway } from "./research-documents";
import {
  record,
  mutation,
  generateRequest,
  scope,
  henryResult,
} from "./content-strategy-model";
const choice = z.object({
  id: z.string(),
  name: z.string(),
  revision: z.number(),
  brandId: z.string().optional(),
});
export const bundle = z.object({
  records: z.array(record),
  brands: z.array(
    z.object({ id: z.string(), name: z.string(), website: z.string() }),
  ),
  choices: z.record(z.array(choice)),
  proposals: z.array(
    z.object({
      id: z.string(),
      task: z.string(),
      result: z.record(z.unknown()),
      contextHash: z.string(),
      scope: scope.optional(),
      sourceRefs: z.array(z.object({id:z.string(),version:z.number()})).optional(),
      createdAt: z.string(),
    }),
  ),
  conversations: z
    .array(
      z.object({
        id: z.string(),
        conversationId: z.string(),
        scope,
        instruction: z.string(),
        target: z
          .object({
            id: z.string(),
            version: z.number(),
            kind: z.enum(["strategy", "brief"]),
          })
          .optional(),
        result: henryResult,
        createdAt: z.string(),
      }),
    )
    .optional(),
  capabilities: z
    .array(z.object({ id: z.string(), name: z.string() }))
    .optional(),
  integrations: z
    .array(z.object({ id: z.string(), name: z.string() }))
    .optional(),
  actionTypes: z.array(z.object({ id: z.string(), name: z.string() })),
  generationAvailable: z.boolean(),
  catalogueManageable: z.boolean().optional(),
});
export type ContentBundle = z.infer<typeof bundle>;
export function createContentGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request),
    root = (w: string) =>
      `/api/v1/hvm/workspaces/${encodeURIComponent(w)}/content-strategy`;
  return {
    async initialiseCatalogue(w: string, signal: AbortSignal) {
      return await http(root(w) + "/catalogue", signal, {
        method: "POST",
        body: {},
      });
    },
    email: createEmailContentGateway(base, session, request),
    library: createLibraryGateway(base, session, request),
    documents: createResearchGateway(base, session, request),
    async list(w: string, signal: AbortSignal) {
      return bundle.parse(await http(root(w), signal));
    },
    async history(w: string, id: string, signal: AbortSignal) {
      return z
        .array(record)
        .parse(
          await http(root(w) + `/${encodeURIComponent(id)}/history`, signal),
        );
    },
    async save(
      w: string,
      input: z.infer<typeof mutation>,
      signal: AbortSignal,
    ) {
      return record.parse(
        await http(root(w), signal, {
          method: "POST",
          body: mutation.parse(input),
        }),
      );
    },
    async generate(
      w: string,
      input: z.infer<typeof generateRequest>,
      signal: AbortSignal,
    ) {
      return z.record(z.unknown()).parse(
        await http(root(w) + "/generate", signal, {
          method: "POST",
          body: generateRequest.parse(input),
          timeoutMs: 60000,
          rateLimitRetries: 0,
        }),
      );
    },
    async discover(w: string, url: string, signal: AbortSignal) {
      return z
        .object({
          pages: z.array(z.object({ url: z.string(), title: z.string() })),
          note: z.string(),
          more: z.boolean(),
        })
        .parse(
          await http(root(w) + "/website", signal, {
            method: "POST",
            body: { url, mode: "discover" },
            timeoutMs: 60000,
            rateLimitRetries: 0,
          }),
        );
    },
    async read(w: string, url: string, signal: AbortSignal) {
      return z
        .object({
          url: z.string(),
          canonical: z.string(),
          title: z.string(),
          description: z.string(),
          headings: z.array(z.string()),
          text: z.string(),
          fingerprint: z.string(),
          checkedAt: z.string(),
        })
        .parse(
          await http(root(w) + "/website", signal, {
            method: "POST",
            body: { url, mode: "read" },
            timeoutMs: 60000,
            rateLimitRetries: 0,
          }),
        );
    },
    async handoff(
      w: string,
      id: string,
      expectedVersion: number,
      actionTypeId: string,
      signal: AbortSignal,
    ) {
      return z.object({ id: z.string() }).parse(
        await http(root(w) + "/handoff", signal, {
          method: "POST",
          body: { id, expectedVersion, actionTypeId },
        }),
      );
    },
    async exportBrief(w: string, id: string, signal: AbortSignal) {
      return await http(root(w) + `/${encodeURIComponent(id)}/export`, signal);
    },
  };
}
export type ContentGateway = ReturnType<typeof createContentGateway>;
