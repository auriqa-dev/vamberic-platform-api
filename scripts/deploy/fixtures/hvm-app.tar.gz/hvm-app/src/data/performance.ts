import { businessOutcomeReport } from "./business-outcomes";
import { z } from "zod";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
import { ga4State } from "./ga4";
import { measurementSchema } from "./measurement";
const windowSchema = z.object({ startDate: z.string(), endDate: z.string() });
const values = z.object({
  sessions: z.number(),
  totalUsers: z.number(),
  newUsers: z.number(),
  screenPageViews: z.number(),
  engagedSessions: z.number(),
  keyEvents: z.number(),
});
const table = z.object({
  rows: z.array(z.object({ dimensions: z.array(z.string()), metrics: values })),
  rowCount: z.number(),
  truncated: z.boolean(),
  warnings: z.array(z.string()),
});
const analytics = z.object({
  property: z.object({
    name: z.string(),
    displayName: z.string(),
    timeZone: z.string().nullable(),
    currencyCode: z.string().nullable(),
  }),
  connectionVersion: z.string(),
  traffic: z.object({
    window: windowSchema,
    totals: values.nullable(),
    daily: table,
    sources: table,
    campaigns: table,
    warnings: z.array(z.string()),
    fetchedAt: z.string(),
    timeZone: z.string(),
  }),
});
const notes = z.object({
  label: z.string(),
  customerCount: z.number().nullable(),
  customerNote: z.string(),
});
const baseline = z.object({
  id: z.string(),
  notes,
  capturedAt: z.string(),
  changedAt: z.string(),
  snapshot: z.object({
    window: windowSchema,
    analytics,
    measurement: z.object({
      metrics: measurementSchema.shape.metrics,
      eventCount: z.number(),
      truncated: z.boolean(),
      updatedAt: z.string(),
    }),
  }),
});
export const performanceState = z.object({
  canManage: z.boolean(),
  connection: ga4State,
  defaultWindow: windowSchema,
  campaigns: z.array(
    z.object({ id: z.string(), name: z.string(), status: z.string() }),
  ),
  campaignsTruncated: z.boolean(),
  baselineVersion: z.string().nullable(),
  baseline: baseline.nullable(),
});
export const performanceReport = z.object({
  campaignTags: z
    .array(
      z.object({
        field: z.enum(["sessionCampaignId", "sessionCampaignName"]),
        value: z.string(),
        label: z.string(),
      }),
    )
    .default([]),
  window: windowSchema,
  campaign: z.object({ id: z.string(), name: z.string() }).nullable(),
  mapping: z
    .object({
      automatic: z.boolean().optional(),
      id: z.string().nullable(),
      property: z.string().nullable(),
      removed: z.boolean(),
      filter: z
        .object({
          field: z.enum(["sessionCampaignId", "sessionCampaignName"]),
          value: z.string(),
        })
        .nullable(),
    })
    .nullable(),
  analytics: analytics.nullable(),
  analyticsError: z.string().nullable(),
  measurement: measurementSchema,
  businessOutcomes: businessOutcomeReport.optional(),
  fetchedAt: z.string(),
});
export type PerformanceState = z.infer<typeof performanceState>;
export type PerformanceReport = z.infer<typeof performanceReport>;
export type BaselineNotes = z.infer<typeof notes>;
export function createPerformanceGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const call = createTransport(base, session, request),
    path = (w: string) => `/api/v1/hvm/workspaces/${w}/performance`;
  const post = (
    w: string,
    action: string,
    body: unknown,
    signal: AbortSignal,
  ) =>
    call(`${path(w)}/${action}`, signal, {
      method: "POST",
      body,
      timeoutMs: 60000,
      rateLimitRetries: 0,
    });
  return {
    read: async (w: string, signal: AbortSignal) =>
      performanceState.parse(await call(path(w), signal)),
    report: async (w: string, body: unknown, signal: AbortSignal) =>
      performanceReport.parse(await post(w, "report", body, signal)),
    baseline: async (w: string, body: unknown, signal: AbortSignal) =>
      performanceState.parse(await post(w, "baseline", body, signal)),
    attribution: async (w: string, body: unknown, signal: AbortSignal) =>
      post(w, "attribution", body, signal),
  };
}
export type PerformanceGateway = ReturnType<typeof createPerformanceGateway>;
