import {
  createBrandExpressionGateway,
  type BrandExpressionGateway,
} from "./brand-expression";
import { z } from "zod";
import type { createTransport } from "./transport";
import { DataError } from "./gateway";
export const sectionKeys = [
  "colours",
  "typography",
  "visualRules",
  "voice",
  "terminology",
  "descriptions",
  "imageryGuidance",
  "emailDefaults",
  "chatPersonality",
] as const;
export type KitSection = (typeof sectionKeys)[number];
export type KitContent = Partial<Record<KitSection, unknown>>;
export type EditableKit = {
  id: string;
  updatedAt: string;
  content: KitContent;
  images?: {id:string;name:string}[];
};
export interface BrandKitGateway {
  expression?: BrandExpressionGateway;
  load(
    w: string,
    b: string,
    signal: AbortSignal,
  ): Promise<EditableKit | undefined>;
  save(
    w: string,
    b: string,
    kit: EditableKit | undefined,
    section: KitSection,
    value: unknown,
    signal: AbortSignal,
  ): Promise<void>;
}
const id = (p: string) =>
  z.string().regex(new RegExp(`^${p}_[0-7][0-9abcdefghjkmnpqrstvwxyz]{25}$`));
export function createBrandKitGateway(
  read: ReturnType<typeof createTransport>,
): BrandKitGateway {
  return {
    expression: createBrandExpressionGateway(read),
    async load(w, b, signal) {
      id("workspace").parse(w);
      id("brand").parse(b);
      const response = z
        .object({
          kits: z.array(
            z
              .object({
                id: id("brandkit"),
                workspaceId: id("workspace"),
                brandId: id("brand"),
                status: z.enum(["draft", "approved", "retired"]),
                updatedAt: z.string().datetime(),
              })
              .passthrough(),
          ),
        })
        .parse(
          await read(`/api/v1/hvm/workspaces/${w}/brands/${b}/kits`, signal),
        );
      if (response.kits.some((k) => k.workspaceId !== w || k.brandId !== b))
        throw new DataError("invalid");
      const active = response.kits.filter((k) => k.status === "approved");
      if (active.length > 1) throw new DataError("conflict");
      const kit = active[0];
      return kit
        ? {
            images: z.array(z.object({name:z.string(),status:z.string(),object:z.object({key:z.string()})})).parse(kit.assets ?? []).filter(a=>a.status==='approved').flatMap(a=>{const id=/\/([a-f0-9]{64})\.png$/.exec(a.object.key)?.[1];return id?[{id,name:a.name}]:[];}),
            id: kit.id,
            updatedAt: kit.updatedAt,
            content: Object.fromEntries(
              sectionKeys
                .filter((k) => kit[k] !== undefined)
                .map((k) => [k, kit[k]]),
            ),
          }
        : undefined;
    },
    async save(w, b, kit, section, value, signal) {
      id("workspace").parse(w);
      id("brand").parse(b);
      z.enum(sectionKeys).parse(section);
      await read(`/api/v1/hvm/workspaces/${w}/kit-save`, signal, {
        method: "POST",
        body: {
          brandId: b,
          expectedKitId: kit?.id ?? null,
          expectedUpdatedAt: kit?.updatedAt,
          content: { [section]: value },
        },
      });
    },
  };
}
