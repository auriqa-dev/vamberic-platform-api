import { createContactContextGateway } from "./contact-context";
import { createConsumerFactsGateway } from "./consumer-facts";
import { z } from "zod";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
export type RecordKind = "contacts" | "organisations";
const base = {
  id: z.string(),
  updatedAt: z.string().datetime(),
  archived: z.boolean(),
  lastEngagedAt: z.string().datetime().nullable(),
  name: z.string(),
};
export const managedRecordSchema = z.object({
  ...base,
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  title: z.string().optional(),
  email: z.string().optional(),
  phone: z.string().optional(),
  organisationId: z.string().optional(),
  organisationName: z.string().optional(),
  organisationNames: z.array(z.string()).optional(),
  leadSource: z.string().optional(),
  lifecycleStage: z.string().optional(),
  marketingContactStatus: z.string().optional(),
  subscriptionPlanId: z.string().optional(),
  subscriptionPlanAmount: z.string().optional(),
  subscriptionStatus: z.string().optional(),
  website: z.string().optional(),
  industry: z.string().optional(),
  country: z.string().optional(),
  region: z.string().optional(),
  description: z.string().optional(),
  type: z.string().optional(),
  registration: z.string().optional(),
  createdAt: z.string().datetime().optional(),
  lastActivityAt: z.string().datetime().nullable().optional(),
  city: z.string().optional(),
  companyOwner: z.string().optional(),
});
export type ManagedRecord = z.infer<typeof managedRecordSchema>;
const page = z.object({
  items: z.array(managedRecordSchema),
  total: z.number(),
  offset: z.number(),
  limit: z.number(),
  canWrite: z.boolean(),
});
export type RecordPage = z.infer<typeof page>;
export function createContactManagementGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const call = createTransport(base, session, request);
  const root = (w: string, k: RecordKind) =>
    `/api/v1/hvm/workspaces/${w}/records/${k}`;
  return {
    context: createContactContextGateway(base,session,request),
    consumer: createConsumerFactsGateway(base, session, request),
    async list(
      w: string,
      k: RecordKind,
      query: { search?: string; offset?: number; archived?: boolean },
      signal: AbortSignal,
    ) {
      return page.parse(await call(root(w, k), signal, { query }));
    },
    async read(w: string, k: RecordKind, id: string, signal: AbortSignal) {
      return managedRecordSchema.parse(
        await call(root(w, k) + "/" + id, signal),
      );
    },
    async save(
      w: string,
      k: RecordKind,
      id: string | undefined,
      fields: Record<string, string>,
      updatedAt: string | undefined,
      signal: AbortSignal,
    ) {
      return z.object({ id: z.string() }).parse(
        await call(root(w, k) + (id ? `/${id}/save` : "/create"), signal, {
          method: "POST",
          body: { fields, updatedAt },
        }),
      );
    },
    async archive(
      w: string,
      k: RecordKind,
      row: ManagedRecord,
      restore: boolean,
      signal: AbortSignal,
    ) {
      return call(
        root(w, k) + `/${row.id}/${restore ? "restore" : "archive"}`,
        signal,
        { method: "POST", body: { updatedAt: row.updatedAt } },
      );
    },
  };
}
export type ContactManagementGateway = Omit<
  ReturnType<typeof createContactManagementGateway>,
  "consumer" | "context"
> &
  Partial<Pick<ReturnType<typeof createContactManagementGateway>, "consumer" | "context">>;
