import { sheet } from "./hive-upload-parser";
import Papa from "papaparse";
export type UploadSheet = { name: string; headers: string[]; rows: string[][]; sourceRows?: number[] };
export const mappingFields = {
  company: "Company name",
  registration: "Registration number",
  registrationJurisdiction: "Registration jurisdiction (country)",
  registrationType: "Registration type (company_number, tax_id or other)",
  website: "Company website",
  industry: "Industry",
  country: "Country (two-letter code)",
  region: "Region",
  employees: "Employee count",
  addressLine1: "Address line 1",
  addressLine2: "Address line 2",
  city: "Town or city",
  postalCode: "Postcode",
  addressRegion: "Address county or region",
  firstName: "First name",
  lastName: "Last name",
  email: "Email",
  phone: "Phone",
  jobTitle: "Job title",
  lifecycle: "Lifecycle stage",
} as const;
export async function readUpload(file: File): Promise<UploadSheet[]> {
  if (file.size > 50 * 1024 * 1024)
    throw new Error("Choose a file up to 50 MB.");
  if (/\.csv$/i.test(file.name)) {
    const result = Papa.parse<string[]>(await file.text(), {
      skipEmptyLines: false,
    });
    if (result.errors.length)
      throw new Error(
        "This CSV could not be read. Check its column structure and quotation marks.",
      );
    return [sheet(file.name, result.data)];
  }
  if (/\.zip$/i.test(file.name)) {
    const bytes = new Uint8Array(await file.arrayBuffer());
    const view = new DataView(bytes.buffer); let expanded = 0, entries = 0;
    for (let i=0;i+46<=bytes.length;i++) {
      if(view.getUint32(i,true)!==0x02014b50)continue;
      expanded+=view.getUint32(i+24,true);entries++;
      if(expanded>100*1024*1024||entries>100)throw new Error("This archive expands beyond 100 MB or 100 entries. Upload individual CSV files.");
      i+=45+view.getUint16(i+28,true)+view.getUint16(i+30,true)+view.getUint16(i+32,true);
    }
    if(!entries)throw new Error("This ZIP cannot be read.");
    const {default:JSZip}=await import("jszip"); const archive=await JSZip.loadAsync(bytes);
    const files=Object.values(archive.files).filter(f=>!f.dir&&!f.name.startsWith("__MACOSX/")&&/\.csv$/i.test(f.name));
    if(!files.length)throw new Error("No CSV files found in this archive.");
    const sheets:UploadSheet[]=[]; let actualExpanded=0;
    for(const f of files){const text=await f.async("string");actualExpanded+=new TextEncoder().encode(text).byteLength;if(actualExpanded>100*1024*1024)throw new Error("CSV exceeds supported size");const result=Papa.parse<string[]>(text,{skipEmptyLines:false});if(result.errors.length)throw new Error("Check the CSV column structure.");sheets.push(sheet(f.name,result.data));}
    return sheets;
  }
  if (!/\.xlsx$/i.test(file.name))
    throw new Error("Choose a CSV, XLSX or HubSpot ZIP file.");
  const buffer = await file.arrayBuffer();
  return new Promise((resolve, reject) => {
    const worker = new Worker(
      new URL("./hive-upload-worker.ts", import.meta.url),
      { type: "module" },
    );
    const timeout = setTimeout(() => {
      worker.terminate();
      reject(
        new Error("This workbook took too long to read. Try a smaller file."),
      );
    }, 120000);
    const finish = () => {
      clearTimeout(timeout);
      worker.terminate();
    };
    worker.onmessage = (event) => {
      finish();
      if (event.data.error) reject(new Error(event.data.error));
      else resolve(event.data.sheets);
    };
    worker.onerror = () => {
      finish();
      reject(
        new Error("This workbook could not be read. Try saving it as CSV."),
      );
    };
    worker.postMessage(buffer, [buffer]);
  });
}
export function suggestMapping(headers: string[]): Record<string, string> {
  const aliases: Record<string, string[]> = {
    lifecycle: ["lifecycle", "lifecyclestage"],
    company: [
      "company",
      "companyname",
      "organisation",
      "organization",
      "organisationname",
      "organizationname",
    ],
    registration: [
      "companyregistrationnumber",
      "companynumber",
      "registrationnumber",
    ],
    registrationJurisdiction: ["registrationjurisdiction", "registrationcountry"],
    registrationType: ["registrationtype", "identifiertype"],
    addressLine1: ["addressline1", "organisationaddressaddressline1"],
    addressLine2: ["addressline2", "organisationaddressaddressline2optional"],
    city: ["city", "town", "townorcity", "organisationaddresstownorcity"],
    postalCode: ["postcode", "postalcode", "organisationaddresspostcode"],
    addressRegion: ["county", "organisationaddresscountyoptional"],
    website: ["website", "companywebsite", "domain"],
    industry: ["industry"],
    country: ["country", "countrycode"],
    region: ["region", "state"],
    employees: ["employees", "employeecount"],
    firstName: ["firstname", "givenname"],
    lastName: ["lastname", "surname"],
    email: ["email", "emailaddress", "workemail"],
    phone: ["phone", "telephone"],
    jobTitle: ["jobtitle", "title", "role"],
  };
  const assigned = new Set<string>();
  return Object.fromEntries(
    headers.map((header) => {
      const key =
        Object.entries(aliases).find(
          ([key, values]) =>
            !assigned.has(key) &&
            values.includes(header.toLowerCase().replace(/[^a-z]/g, "")),
        )?.[0] ?? "";
      if (key) assigned.add(key);
      return [header, key];
    }),
  );
}

export function hubspotKind(headers:string[]): "contacts"|"companies"|"emails"|undefined {
 if(!headers.includes("Record ID"))return;
 if(headers.includes("Email Direction")&&headers.includes("Email body"))return "emails";
 if(headers.includes("First Name")&&headers.includes("Last Name"))return "contacts";
 if(headers.includes("Company name")&&headers.includes("Company Domain Name"))return "companies";
}
