import type { UploadSheet } from "./hive-upload";

// These are source row classifications, not deduplicated company counts or ICP qualification.
// A company may have different roles in different notifications.
export function esosReview(sheets: UploadSheet[]) {
  const count = (sheet: string, field?: string, value?: string) => {
    const source = sheets.find((s) => s.name === sheet);
    if (!source) return 0;
    if (!field) return source.rows.length;
    const column = source.headers.indexOf(field);
    if (column < 0) return 0;
    return source.rows.filter((r) => r[column]?.trim().toLowerCase() === value?.toLowerCase()).length;
  };
  return {
    reportingRows: count("Reporting Obligation"),
    qualifyingRows: count("Reporting Obligation", "Does your organisation qualify for ESOS?", "Yes"),
    nonQualifyingRows: count("Reporting Obligation", "Does your organisation qualify for ESOS?", "No"),
    responsibleRows: count("Responsible Undertaking"),
    coveredRows: count("Organisation Structure", "Is the organisation covered by the NOC?", "Yes"),
    excludedRows: count("Organisation Structure", "Is the organisation covered by the NOC?", "No"),
  };
}
