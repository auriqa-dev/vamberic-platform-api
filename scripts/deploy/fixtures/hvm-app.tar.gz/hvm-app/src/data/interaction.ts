import { z } from "zod";
import type { AuthSession } from "../auth/session";
import { createTransport } from "./transport";
const settings=z.object({siteId:z.string(),brandId:z.string(),enabled:z.boolean(),testOnly:z.boolean(),publicAssetIds:z.array(z.string()),privacyUrl:z.string(),bookingUrl:z.string(),handoffEmail:z.string(),retentionDays:z.number()});
const installation=settings.extend({id:z.string(),version:z.number(),archived:z.boolean().default(false)});
const conversation=z.object({id:z.string(),kind:z.string(),version:z.number(),status:z.string(),updatedAt:z.string(),testOnly:z.boolean(),installationId:z.string(),contactId:z.string().optional(),archived:z.boolean().default(false),reviewNote:z.string().optional(),visitor:z.object({name:z.string(),email:z.string(),organisation:z.string(),message:z.string()}).optional()});
const state=z.object({nextCursor:z.string().nullable().default(null),canManage:z.boolean().default(false),installations:z.array(installation),conversations:z.array(conversation),sites:z.array(z.object({id:z.string(),brandId:z.string(),origin:z.string(),verified:z.boolean()})),assets:z.array(z.object({id:z.string(),title:z.string(),brandId:z.string(),publicReady:z.boolean()}))});
export type InteractionState=z.infer<typeof state>;
export type InteractionSettings=z.infer<typeof settings>;
export function createInteractionGateway(base:string,session:Pick<AuthSession,"getAccessToken"|"invalidate">,request:typeof fetch=fetch){const call=createTransport(base,session,request),path=(w:string)=>`/api/v1/hvm/workspaces/${w}/interactions`;return{
 read:async(w:string,signal:AbortSignal,cursor?:string)=>state.parse(await call(path(w)+(cursor?`?cursor=${encodeURIComponent(cursor)}`:""),signal)),
 change:async(w:string,body:unknown,signal:AbortSignal)=>state.parse(await call(path(w),signal,{method:"POST",body,rateLimitRetries:0})),
 transcript:async(w:string,id:string,signal:AbortSignal)=>z.array(z.object({id:z.string(),message:z.string(),status:z.string(),reply:z.object({answer:z.string(),uncertainties:z.array(z.string()),qualificationEvidence:z.array(z.string())}).optional()})).parse(await call(`${path(w)}/${id}`,signal)),
 };}
export type InteractionGateway=ReturnType<typeof createInteractionGateway>;
