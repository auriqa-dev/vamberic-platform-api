import { z } from "zod";
import type { createTransport } from "../transport";
export const briefFields = {
  commercialObjective: "Commercial objective",
  marketHypothesis: "Intended market",
  problemAndOutcome: "Problem and desired outcome",
  differentiation: "Differentiation",
  pricingAndPackaging: "Pricing and packaging constraints",
  purchasingProcess: "Sales and purchasing process",
  conversionGoal: "Conversion goal",
  existingCommitments: "Commitments to preserve",
  questionsAndResearch: "Questions and research",
} as const;
const statement = z.object({
  text: z.string(),
  origin: z.enum(["product_fact", "queen_supplied", "hypothesis", "unknown"]),
});
const briefSchema = z.object({
  name: z.string(),
  ...(Object.fromEntries(
    Object.keys(briefFields).map((k) => [k, z.array(statement)]),
  ) as Record<keyof typeof briefFields, z.ZodArray<typeof statement>>),
});
const interpretation = z.object({
  explanation: z.string(),
  offers: z.array(
    z.object({
      existingOfferId: z.string().nullable(),
      brief: briefSchema,
      methodologyRecommendation: z
        .object({ id: z.string(), version: z.number(), rationale: z.string() })
        .optional(),
    }),
  ),
});
export const briefJobSchema = z.object({
  id: z.string(),
  updatedAt: z.string(),
  status: z.enum([
    "interpreting",
    "review",
    "confirmed",
    "failed",
    "interrupted",
  ]),
  input: z.object({ intent: z.string(), offeringId: z.string() }),
  interpretation: interpretation.optional(),
  methodologyApprovals: z
    .record(
      z.string(),
      z.object({ id: z.string(), version: z.number(), approvedAt: z.string() }),
    )
    .optional(),
  linkedOffers: z.record(z.string(), z.string()).optional(),
  existingOffers: z.array(
    z.object({ id: z.string(), name: z.string(), status: z.string() }),
  ),
});
export type BriefJob = z.infer<typeof briefJobSchema>;
export function createOfferBriefGateway(
  http: ReturnType<typeof createTransport>,
  root: (w: string) => string,
) {
  return {
    latestBrief: async (w: string, offeringId: string, s: AbortSignal) =>
      briefJobSchema.nullable().parse(
        await http(root(w) + "/offer-architecture/briefs", s, {
          query: { offeringId },
        }),
      ),
    brief: async (w: string, id: string, s: AbortSignal) =>
      briefJobSchema.parse(
        await http(root(w) + "/offer-architecture/briefs/" + id, s),
      ),
    interpretBrief: async (w: string, body: unknown, s: AbortSignal) =>
      briefJobSchema.parse(
        await http(root(w) + "/offer-architecture/briefs", s, {
          method: "POST",
          body,
        }),
      ),
    chooseBriefMethodology: async (w: string, body: unknown, s: AbortSignal) =>
      briefJobSchema.parse(
        await http(root(w) + "/offer-architecture/briefs/methodology", s, {
          method: "POST",
          body,
        }),
      ),
    confirmBrief: async (w: string, body: unknown, s: AbortSignal) =>
      briefJobSchema.parse(
        await http(root(w) + "/offer-architecture/briefs/confirm", s, {
          method: "POST",
          body,
        }),
      ),
  };
}
