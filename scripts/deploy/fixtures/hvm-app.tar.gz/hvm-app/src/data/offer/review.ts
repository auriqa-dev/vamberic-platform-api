import type { OfferStage } from "./index";

// Proposals use the existing stage working-data groups. They remain separate from
// userInputs and completedStageKeys; saving a proposal never records acceptance.
export const PROPOSAL_PREFIX = "henry_proposal_";
export type Proposal = {
  question: string;
  answer: string;
  basis: string;
  kind: string;
  decision: string;
  gap: string;
};
export function proposals(stage: OfferStage): Proposal[] {
  return stage.groups
    .filter((g) => g.key.startsWith(PROPOSAL_PREFIX) && g.items.length === 6)
    .map((g) => {
      const [question, answer, basis, kind, decision, gap] = g.items as [
        string,
        string,
        string,
        string,
        string,
        string,
      ];
      return { question, answer, basis, kind, decision, gap };
    });
}
export const reviewSections = [
  {
    name: "Customer and opportunity",
    keys: [
      "market_context",
      "desired_outcome",
      "customer_context",
      "problems_priorities",
      "desired_outcomes",
    ],
  },
  {
    name: "Value and differentiation",
    keys: [
      "value_stack",
      "positioning",
      "proposition_cta",
      "alternatives_competition",
      "differentiated_value",
    ],
  },
  {
    name: "Delivery and customer effort",
    keys: [
      "solution_design",
      "delivery_packaging",
      "customer_effort",
      "obstacles",
    ],
  },
  {
    name: "Pricing and commitments",
    keys: ["pricing_terms", "commercial_proposition"],
  },
  {
    name: "Confidence and evidence",
    keys: ["confidence", "risk_reduction", "evidence_credibility"],
  },
  {
    name: "Outcomes and final review",
    keys: ["time_to_value", "review", "validation_approval"],
  },
];
export function acceptStage(
  stage: OfferStage,
  answers: Record<string, string>,
): OfferStage {
  const pending = stage.unknowns.filter(
    (q) => !stage.userInputs.some((a) => a.question === q),
  );
  const additions = pending
    .filter((q) => answers[q]?.trim())
    .map((question) => ({ question, answer: answers[question]!.trim() }));
  return {
    ...stage,
    userInputs: [...stage.userInputs, ...additions],
    status: "completed",
    decisionRationale:
      stage.decisionRationale ||
      "Reviewed Henry’s proposal, its assumptions and remaining evidence gaps; accepted as the working offer decision.",
  };
}
