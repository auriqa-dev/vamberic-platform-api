import { createOfferBriefGateway } from "./brief";
import { z } from "zod";
import { createTransport } from "../transport";
import { DataError } from "../gateway";
import { canonicalId } from "../operating/models";
import type { AuthSession } from "../../auth/session";
export type Json =
  string | number | boolean | null | Json[] | { [key: string]: Json };
export type Fields = { [key: string]: Json };
const fields = z.record(z.unknown()).transform((x) => x as Fields);
export const offerSchema = z.object({
  id: canonicalId("offer"),
  workspaceId: canonicalId("workspace"),
  offeringId: canonicalId("offering"),
  offerDesignId: z.string().optional(),
  status: z.enum(["draft", "approved", "retired"]),
  revision: z.number(),
  approvedRevision: z.number().optional(),
  updatedAt: z.string(),
  definition: fields,
  archived: z.boolean(),
});
const stageSchema = z
  .object({
    stageKey: z.string(),
    status: z.enum(["not_started", "in_progress", "completed"]),
    evidence: z
      .array(
        z
          .object({
            key: z.string(),
            reference: z.string(),
            kind: z.string(),
            observedAt: z.string(),
          })
          .passthrough(),
      )
      .optional(),
    notes: z.array(z.string()),
    unknowns: z.array(z.string()),
    decisionRationale: z.string().optional(),
    userInputs: z.array(z.object({ question: z.string(), answer: z.string() })),
    groups: z.array(
      z.object({
        key: z.string(),
        name: z.string(),
        items: z.array(z.string()),
      }),
    ),
  })
  .passthrough();
const workSchema = z
  .object({
    name: z.string(),
    targetIcpIds: z.array(z.string()),
    targetBuyerProfileIds: z.array(z.string()),
    completedStageKeys: z.array(z.string()),
    stages: z.array(stageSchema),
    competitiveAnalysis: fields.optional(),
  })
  .passthrough();
const designSchema = z.object({
  id: z.string(),
  workspaceId: z.string(),
  updatedAt: z.string(),
  work: workSchema,
  status: z.string(),
  methodologyId: z.string(),
  methodologyVersion: z.number(),
});
export const bundleSchema = z.object({
  output: z.object({sections:z.array(z.object({title:z.string(),text:z.string()})),decisions:z.array(z.object({title:z.string(),text:z.string()})),text:z.string(),fingerprint:z.string(),assetId:z.string().nullable()}).optional(),
  offer: offerSchema,
  design: designSchema.nullable(),
  refinement: z
    .object({
      generationId: z.string(),
      previousDefinition: fields,
      proposedWork: workSchema,
      commercialChangesAuthorised: z.boolean(),
    })
    .optional(),
  reviewHistory: z
    .array(
      z.object({
        id: z.string(),
        stageKey: z.string(),
        at: z.string(),
        before: z
          .object({
            userInputs: z.array(
              z.object({ question: z.string(), answer: z.string() }),
            ),
            status: z.string(),
            decisionRationale: z.string().nullable(),
          })
          .passthrough()
          .nullable(),
        after: z
          .object({
            userInputs: z.array(
              z.object({ question: z.string(), answer: z.string() }),
            ),
            status: z.string(),
            decisionRationale: z.string().nullable(),
          })
          .passthrough(),
      }),
    )
    .optional(),
  sourceChanged: z.boolean(),
  sourceReferences: z.array(
    z.object({ kind: z.string(), id: z.string(), revision: z.number() }),
  ),
});
export const jobSchema = z
  .object({
    id: z.string(),
    status: z.enum(["generating", "complete", "failed", "interrupted"]),
    offerId: z.string().optional(),
    limitations: z.array(z.string()).optional(),
    diagnostics: z.array(z.object({
      stage: z.enum(["starting", "research", "pages", "provider", "response", "validation", "design", "persistence"]),
      outcome: z.enum(["started", "complete", "warning", "failed"]),
      elapsedMs: z.number(),
      code: z.string().regex(/^[a-z0-9_]+$/).optional(),
      httpStatus: z.number().optional(),
      issues: z.array(z.object({field: z.string().regex(/^[a-zA-Z0-9_.]+$/), code: z.string().regex(/^[a-z0-9_]+$/)})).optional(),
    })).optional(),
  })
  .nullable();
export type OfferRecord = z.infer<typeof offerSchema>;
export type OfferBundle = z.infer<typeof bundleSchema>;
export type OfferJob = z.infer<typeof jobSchema>;
export type OfferStage = z.infer<typeof stageSchema>;
export type OfferWork = z.infer<typeof workSchema>;
export function createOfferGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request),
    root = (w: string) =>
      `/api/v1/hvm/workspaces/${canonicalId("workspace").parse(w)}`;
  const scope = (w: string, b: OfferBundle) => {
    if (b.offer.workspaceId !== w || (b.design && b.design.workspaceId !== w))
      throw new DataError("denied");
    return b;
  };
  return {
    ...createOfferBriefGateway(http, root),
    async registerOutput(w: string, b: OfferBundle, s: AbortSignal) {
      return scope(w,bundleSchema.parse(await http(root(w)+"/offer-architecture/output",s,{method:"POST",body:{id:b.offer.id,expectedUpdatedAt:b.offer.updatedAt,expectedDesignUpdatedAt:b.design!.updatedAt}})));
    },
    async permissions(w: string, s: AbortSignal) {
      return z
        .object({
          canCreate: z.boolean(),
          canUpdate: z.boolean(),
          canApprove: z.boolean(),
          generationAvailable: z.boolean(),
        })
        .parse(await http(root(w) + "/offer-architecture/permissions", s));
    },
    async list(
      w: string,
      offeringId: string,
      archived: boolean,
      s: AbortSignal,
    ) {
      const rows: OfferRecord[] = [];
      for (let offset = 0; offset <= 10000; offset += 100) {
        const r = z
          .object({ items: z.array(offerSchema), hasMore: z.boolean() })
          .parse(
            await http(root(w) + "/offers", s, {
              query: {
                offeringId,
                archived: String(archived),
                offset,
                limit: 100,
              },
            }),
          );
        if (r.items.some((x) => x.workspaceId !== w))
          throw new DataError("denied");
        rows.push(...r.items);
        if (!r.hasMore) return rows;
      }
      throw new DataError("invalid");
    },
    async buyers(w: string, offeringId: string, s: AbortSignal) {
      const rows: {
        id: string;
        name: string;
        icpId: string;
        approved: boolean;
      }[] = [];
      for (let offset = 0; offset <= 10000; offset += 100) {
        const r = z
          .object({
            items: z.array(
              z.object({
                id: z.string(),
                workspaceId: z.string(),
                idealCustomerProfileId: z.string(),
                approvedRevision: z.number().optional(),
                definition: z.object({ name: z.string() }),
              }),
            ),
            hasMore: z.boolean(),
          })
          .parse(
            await http(root(w) + "/buyer-profiles", s, {
              query: { offeringId, offset, limit: 100 },
            }),
          );
        if (r.items.some((x) => x.workspaceId !== w))
          throw new DataError("denied");
        rows.push(
          ...r.items.map((x) => ({
            id: x.id,
            name: x.definition.name,
            icpId: x.idealCustomerProfileId,
            approved: !!x.approvedRevision,
          })),
        );
        if (!r.hasMore) return rows;
      }
      throw new DataError("invalid");
    },
    async methodologies(w: string, s: AbortSignal) {
      return z
        .object({
          items: z.array(
            z.object({ id: z.string(), name: z.string(), version: z.number() }),
          ),
        })
        .parse(await http(root(w) + "/offer-design-methodologies", s)).items;
    },
    async methodology(w: string, id: string, version: number, s: AbortSignal) {
      return z
        .object({
          name: z.string(),
          conceptualModel: z
            .object({
              expression: z.string(),
              dimensions: z.array(
                z.object({
                  key: z.string(),
                  name: z.string(),
                  explanation: z.string(),
                }),
              ),
            })
            .optional(),
          stages: z.array(
            z.object({
              key: z.string(),
              name: z.string(),
              purpose: z.string(),
              guidance: z.array(z.string()).optional(),
            }),
          ),
        })
        .parse(
          await http(
            root(w) + `/offer-design-methodologies/${id}/versions/${version}`,
            s,
          ),
        );
    },
    async bundle(w: string, id: string, s: AbortSignal) {
      return scope(
        w,
        bundleSchema.parse(
          await http(
            root(w) +
              "/offer-architecture/offers/" +
              canonicalId("offer").parse(id),
            s,
          ),
        ),
      );
    },
    async latest(w: string, offeringId: string, s: AbortSignal) {
      return jobSchema.parse(
        await http(root(w) + "/offer-architecture/generations", s, {
          query: { offeringId },
        }),
      );
    },
    async job(w: string, id: string, s: AbortSignal) {
      return jobSchema.parse(
        await http(
          root(w) +
            "/offer-architecture/generations/" +
            canonicalId("event").parse(id),
          s,
        ),
      );
    },
    async generate(w: string, body: unknown, s: AbortSignal) {
      return jobSchema.parse(
        await http(root(w) + "/offer-architecture/generations", s, {
          method: "POST",
          body,
        }),
      );
    },
    async save(w: string, body: unknown, s: AbortSignal) {
      return scope(
        w,
        bundleSchema.parse(
          await http(root(w) + "/offer-architecture/save", s, {
            method: "POST",
            body,
          }),
        ),
      );
    },
    async transition(w: string, body: unknown, s: AbortSignal) {
      return scope(
        w,
        bundleSchema.parse(
          await http(root(w) + "/offer-architecture/transition", s, {
            method: "POST",
            body,
          }),
        ),
      );
    },
    async archive(w: string, row: OfferRecord, s: AbortSignal) {
      return offerSchema.parse(
        await http(root(w) + "/offers/archive", s, {
          method: "POST",
          body: { id: row.id, expectedUpdatedAt: row.updatedAt },
        }),
      );
    },
    async revision(w: string, id: string, revision: number, s: AbortSignal) {
      return z
        .object({
          snapshot: offerSchema,
          designSnapshot: designSchema.optional(),
        })
        .parse(
          await http(
            root(w) +
              `/offers/${canonicalId("offer").parse(id)}/revisions/${revision}`,
            s,
          ),
        );
    },
  };
}
export type OfferGateway = ReturnType<typeof createOfferGateway>;
