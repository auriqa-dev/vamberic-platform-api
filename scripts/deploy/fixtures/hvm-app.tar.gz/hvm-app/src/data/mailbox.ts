import { z } from "zod";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
export const mailboxState = z.object({
  available: z.boolean(),
  canManage: z.boolean(),
  email: z.string().nullable(),
  status: z.string(),
  updatedAt: z.string().nullable(),
  lastCheckedAt: z.string().nullable(),
  notice: z.string().nullable(),
  readiness: z.object({
    ready: z.boolean(),
    missing: z.array(z.string()),
    campaignExecutionAuthorised: z.literal(false),
  }),
  testRecipients: z.array(z.string()),
  tests: z.array(
    z.object({
      id: z.string(),
      recipient: z.string(),
      status: z.string(),
      createdAt: z.string(),
    }),
  ),
  replies: z.array(
    z.object({
      id: z.string(),
      from: z.string(),
      subject: z.string(),
      text: z.string(),
      receivedAt: z.string(),
      matched: z.boolean(),
    }),
  ),
});
export type MailboxState = z.infer<typeof mailboxState>;
export function createMailboxGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const call = createTransport(base, session, request),
    path = (w: string) => `/api/v1/hvm/workspaces/${w}/mailbox`;
  return {
    read: async (w: string, signal: AbortSignal) =>
      mailboxState.parse(await call(path(w), signal)),
    connect: async (w: string, signal: AbortSignal) =>
      z
        .object({
          url: z.string().url(),
          state: z.string(),
          browserSecret: z.string(),
        })
        .parse(
          await call(path(w) + "/connect", signal, {
            method: "POST",
            body: {},
            timeoutMs: 60000,
            rateLimitRetries: 0,
          }),
        ),
    change: async (
      w: string,
      action: "finish" | "test" | "send-test" | "replies" | "disconnect",
      body: unknown,
      signal: AbortSignal,
    ) =>
      mailboxState.parse(
        await call(path(w) + "/" + action, signal, {
          method: "POST",
          body,
          timeoutMs: 60000,
          rateLimitRetries: 0,
        }),
      ),
  };
}
export type MailboxGateway = ReturnType<typeof createMailboxGateway>;
