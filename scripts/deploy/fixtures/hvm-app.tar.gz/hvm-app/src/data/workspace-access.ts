import { z } from "zod";
import type { createTransport } from "./transport";
const human = z.object({
  id: z.string(),
  issuer: z.string(),
  type: z.literal("human"),
});
export const teamSchema = z.object({
  workspaceId: z.string(),
  updatedAt: z.string(),
  management: z.enum(["client", "queen"]),
  canManage: z.boolean(),
  canChangeManagement: z.boolean(),
  currentHuman: human,
  memberships: z.array(
    z.object({
      id: z.string(),
      human,
      role: z.enum(["admin", "member"]),
      status: z.enum(["active", "ended"]),
      updatedAt: z.string(),
    }),
  ),
  partnerAssignments: z.array(
    z.object({
      id: z.string(),
      partnerId: z.string(),
      role: z.string(),
      status: z.string(),
    }),
  ),
});
export type WorkspaceAccess = z.infer<typeof teamSchema>;
export interface WorkspaceAccessGateway {
  load(w: string, signal: AbortSignal): Promise<WorkspaceAccess>;
  change(
    w: string,
    operation: "member-provision" | "member-revoke" | "management-change",
    input: unknown,
    signal: AbortSignal,
  ): Promise<void>;
}
export function createWorkspaceAccessGateway(
  http: ReturnType<typeof createTransport>,
): WorkspaceAccessGateway {
  return {
    async load(w, signal) {
      const result = teamSchema.parse(
        await http(`/api/v1/hvm/workspaces/${w}/team`, signal),
      );
      if (result.workspaceId !== w) throw new Error("Workspace mismatch");
      return result;
    },
    async change(w, operation, input, signal) {
      await http(`/api/v1/hvm/workspaces/${w}/${operation}`, signal, {
        method: "POST",
        body: input,
      });
    },
  };
}
