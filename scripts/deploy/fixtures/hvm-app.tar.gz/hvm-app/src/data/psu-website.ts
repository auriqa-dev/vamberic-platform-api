import { z } from "zod";
const hash = z.string().regex(/^[a-f0-9]{64}$/);
export const websiteReviewSchema = z
  .object({
    kind: z.literal("psu_website_review_draft"),
    version: z.literal(1),
    approval: z.literal("not_approved"),
    digest: hash,
    fields: z
      .array(
        z
          .object({
            binding: z
              .object({
                field: z.string(),
                value: z.union([z.string(), z.array(z.string())]),
              })
              .strict(),
            basis: z.enum(["source_claim", "interpretation"]),
            support: z
              .array(
                z
                  .object({
                    pageDigest: hash,
                    quote: z.string(),
                    url: z.string().url(),
                    retrievedAt: z.string().datetime(),
                  })
                  .strict(),
              )
              .max(3),
          })
          .strict(),
      )
      .max(40),
    unknowns: z.array(z.string()).max(20),
    questions: z
      .array(z.object({ question: z.string(), reason: z.string() }).strict())
      .max(3),
  })
  .strict();
export type WebsiteReview = z.infer<typeof websiteReviewSchema>;
export type ReviewField = {
  binding: WebsiteReview["fields"][number]["binding"];
  included: boolean;
};
