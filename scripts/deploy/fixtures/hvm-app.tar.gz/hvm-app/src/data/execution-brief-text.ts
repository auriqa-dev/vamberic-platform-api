import { z } from "zod";
/** Human-readable export of the same approved contract, without another generation call. */
export function executionBriefText(raw: unknown): string {
  const envelope = z
    .object({
      brief: z.object({
        id: z.string(),
        version: z.number(),
        data: z.record(z.unknown()),
      }),
      approvedBrandBrief: z.unknown(),
      sourceAssets: z.unknown(),
    })
    .passthrough()
    .parse(raw);
  const brief = envelope.brief as {
    id: string;
    version: number;
    data: Record<string, unknown>;
  };
  const heading = (key: string) =>
    key
      .replace(/([a-z])([A-Z])/g, "$1 $2")
      .replace(/^./, (c) => c.toUpperCase());
  const render = (value: unknown): string => {
    if (value === null || value === undefined || value === "") return "";
    if (Array.isArray(value))
      return value
        .map(render)
        .filter(Boolean)
        .map((v) => `- ${v}`)
        .join("\n");
    if (typeof value === "object")
      return Object.entries(value)
        .map(([k, v]) => {
          const text = render(v);
          return text ? `${heading(k)}: ${text}` : "";
        })
        .filter(Boolean)
        .join("\n");
    return String(value);
  };
  return [
    `# ${brief.data.title}`,
    `Brief ${brief.id} · approved revision ${brief.version}`,
    ...Object.entries(brief.data)
      .filter(
        ([k]) => !["title", "scope", "actionId", "sourceAssetIds"].includes(k),
      )
      .map(([k, v]) => {
        const text = render(v);
        return text ? `## ${heading(k)}\n${text}` : "";
      })
      .filter(Boolean),
    `## Approved brand guidance\n${render(envelope.approvedBrandBrief) || "Use clear, neutral British English."}`,
    `## Source material\n${render(envelope.sourceAssets) || "No attached source assets."}`,
    "## Handoff\nThis brief does not authorise spending, publication or sending. Return deliverables with this brief identity and revision for separate review. Completion is not evidence of effectiveness.",
  ].join("\n\n");
}
