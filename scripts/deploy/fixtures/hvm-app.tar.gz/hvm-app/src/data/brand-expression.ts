import { z } from "zod";
import type { createTransport } from "./transport";
import { DataError } from "./gateway";
const text = z.string().trim().max(2000),
  list = z
    .array(z.string().trim().max(500))
    .transform((v) => v.filter(Boolean))
    .pipe(z.array(z.string().min(1).max(500)).max(20));
export const dimensions = ["personality", "tone", "writingStyle"] as const;
export type Dimension = (typeof dimensions)[number];
export const formats = [
  "website",
  "linkedin",
  "email",
  "article",
  "newsletter",
  "interaction",
] as const;
export const contentSchema = z.object({
  personality: z.object({
    attributes: list,
    character: text,
    values: text,
    perception: text,
    boundaries: text,
  }),
  tone: z.object({
    defaultTone: text,
    attributes: list,
    boundaries: text,
    variations: z
      .array(z.object({ context: z.enum(formats), guidance: text }))
      .max(6),
  }),
  writingStyle: z.object({
    characteristics: text,
    structure: text,
    narrative: text,
    evidence: text,
    conventions: text,
    exclusions: text,
    inspirations: z
      .array(
        z.object({
          reference: z.string().max(300),
          interpretation: z.string().max(1000),
        }),
      )
      .max(10),
  }),
});
export type ExpressionContent = z.infer<typeof contentSchema>;
export const defaults: ExpressionContent = {
  personality: {
    attributes: [],
    character: "",
    values: "",
    perception: "",
    boundaries: "",
  },
  tone: { defaultTone: "", attributes: [], boundaries: "", variations: [] },
  writingStyle: {
    characteristics: "",
    structure: "",
    narrative: "",
    evidence: "",
    conventions: "",
    exclusions: "",
    inspirations: [],
  },
};
export type ExpressionEntry<K extends Dimension> = {
  content: ExpressionContent[K];
  originalDescription: string;
  sourceGenerationId?: string;
};
export type ExpressionKit = {
  id: string;
  updatedAt: string;
  expression: {
    [K in Dimension]?: {
      draft?: ExpressionEntry<K>;
      approved?: ExpressionEntry<K>;
    };
  };
  legacyVoice?: { writingStyle?: string; descriptors?: string[] };
};
export interface BrandExpressionGateway {
  load(
    w: string,
    b: string,
    signal: AbortSignal,
  ): Promise<ExpressionKit | undefined>;
  save(
    w: string,
    b: string,
    kit: ExpressionKit | undefined,
    dimension: Dimension,
    entry: ExpressionEntry<Dimension>,
    approve: boolean,
    signal: AbortSignal,
  ): Promise<void>;
  remove(w: string, b: string, kit: ExpressionKit, dimension: Dimension, target: "draft" | "approved", signal: AbortSignal): Promise<void>;
  generate(
    w: string,
    b: string,
    input: {
      requestKey: string;
      mode: "interpret" | "preview";
      description: string;
      format: (typeof formats)[number];
      useDrafts: boolean;
    },
    signal: AbortSignal,
  ): Promise<{ id: string }>;
  result(
    w: string,
    b: string,
    id: string,
    signal: AbortSignal,
  ): Promise<{
    status: string;
    result?: { settings?: ExpressionContent; sample?: string };
    input: { description: string };
  }>;
}
export function createBrandExpressionGateway(
  read: ReturnType<typeof createTransport>,
): BrandExpressionGateway {
  const root = (w: string, b: string) =>
    "/api/v1/hvm/workspaces/" +
    encodeURIComponent(w) +
    "/brands/" +
    encodeURIComponent(b) +
    "/expression";
  const gateway: BrandExpressionGateway = {
    async load(w, b, signal) {
      const data = z
        .object({
          kits: z.array(
            z.object({
              id: z.string(),
              workspaceId: z.string(),
              brandId: z.string(),
              status: z.string(),
              updatedAt: z.string().datetime(),
              expression: z.unknown().optional(),
              voice: z
                .object({
                  writingStyle: z.string().optional(),
                  descriptors: z.array(z.string()).optional(),
                })
                .optional(),
            }),
          ),
        })
        .parse(
          await read(
            "/api/v1/hvm/workspaces/" + w + "/brands/" + b + "/kits",
            signal,
          ),
        );
      if (data.kits.some((k) => k.workspaceId !== w || k.brandId !== b))
        throw new DataError("invalid");
      const active = data.kits.filter((k) => k.status === "approved");
      if (active.length > 1) throw new DataError("conflict");
      const kit = active[0];
      if (!kit) return undefined;
      const state = (content: z.ZodTypeAny) =>
        z
          .object({
            draft: z
              .object({
                content,
                originalDescription: z.string(),
                sourceGenerationId: z.string().optional(),
              })
              .optional(),
            approved: z
              .object({
                content,
                originalDescription: z.string(),
                sourceGenerationId: z.string().optional(),
              })
              .optional(),
          })
          .optional();
      const expression = z
        .object({
          personality: state(contentSchema.shape.personality),
          tone: state(contentSchema.shape.tone),
          writingStyle: state(contentSchema.shape.writingStyle),
        })
        .parse(kit.expression ?? {}) as ExpressionKit["expression"];
      return {
        id: kit.id,
        updatedAt: kit.updatedAt,
        expression,
        legacyVoice: kit.voice,
      };
    },
    async remove(w,b,kit,dimension,target,signal) {
      await read(`/api/v1/hvm/workspaces/${w}/kit-expression-remove`, signal, {method:"POST",body:{brandId:b,expectedKitId:kit.id,expectedUpdatedAt:kit.updatedAt,dimension,target}});
    },
    async save(w, b, kit, dimension, entry, approve, signal) {
      // Other tabs version the same kit. Rebase only when the reviewed dimension
      // is unchanged; the server still fences the final write against races.
      const latest = await gateway.load(w, b, signal);
      const baseline = kit?.expression[dimension];
      const current = latest?.expression[dimension];
      if (
        (kit && !latest) ||
        JSON.stringify(baseline ?? null) !== JSON.stringify(current ?? null) ||
        (dimension !== "personality" && !baseline &&
          JSON.stringify(kit?.legacyVoice ?? null) !== JSON.stringify(latest?.legacyVoice ?? null))
      ) throw new DataError("conflict");
      await read(
        "/api/v1/hvm/workspaces/" +
          w +
          "/kit-expression-" +
          (approve ? "approve" : "save"),
        signal,
        {
          method: "POST",
          body: {
            brandId: b,
            expectedKitId: latest?.id ?? null,
            expectedUpdatedAt: latest?.updatedAt,
            dimension,
            ...(approve
              ? {}
              : {
                  content: contentSchema.shape[dimension].parse(entry.content),
                  originalDescription: entry.originalDescription,
                  sourceGenerationId: entry.sourceGenerationId,
                }),
          },
        },
      );
    },
    async generate(w, b, input, signal) {
      return z.object({ id: z.string() }).parse(
        await read(root(w, b) + "/generations", signal, {
          method: "POST",
          body: input,
        }),
      );
    },
    async result(w, b, id, signal) {
      return z
        .object({
          status: z.enum(["generating", "completed", "failed", "interrupted"]),
          input: z.object({ description: z.string() }),
          result: z
            .object({
              settings: contentSchema.optional(),
              sample: z.string().max(5000).optional(),
            })
            .optional(),
        })
        .parse(
          await read(
            root(w, b) + "/generations/" + encodeURIComponent(id),
            signal,
          ),
        );
    },
  };
  return gateway;
}
