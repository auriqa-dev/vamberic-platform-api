import { suggestMapping, type UploadSheet } from "./hive-upload";

export type PreparedRow = {
  row: number;
  original: Record<string, string>;
  skip?: boolean;
  company?: string;
  registration?: string;
  website?: string;
  sourceOnly?: boolean;
  origin?: {
    sheet: string;
    row: number;
    scope: "organisation" | "notification";
    notification?: string;
    relatedRegistration?: string;
    relatedName?: string;
  };
  [key: string]: unknown;
};
export type ImportPlan = {
  rows: PreparedRow[];
  sourceRows: number;
  companies: number;
  notes: string[];
  fields: { name: string; type: string; mappedTo: string[] }[];
};
const clean = (v: string | undefined) =>
  !v || /^(?:-|n\/a|not applicable)$/i.test(v.trim())
    ? ""
    : v.trim().replace(/\s+/g, " ");
export const registration = (v: string | undefined) => {
  const text = clean(v).replace(/\s/g, "").toUpperCase();
  return /^\d{1,8}$/.test(text) ? text.padStart(8, "0") : text;
};
export function inferredType(value: string, label: string): string {
  if (/registration|\bcode\b|\bid\b|postcode|phone/i.test(label)) return "text";
  if (/^(yes|no)$/i.test(value.trim())) return "boolean";
  if (
    /^[-+]?(?:\d+|\d{1,3}(?:,\d{3})+)(\.\d+)?\s*(kWh|MWh|%|GBP)?$/.test(value.trim()) ||
    /^£\s*(?:\d+|\d{1,3}(?:,\d{3})+)(\.\d+)?$/.test(value.trim())
  )
    return "number";
  if (
    /^\d{4}-\d{2}-\d{2}$/.test(value.trim()) ||
    /^\d{1,2} [A-Za-z]{3} \d{4}$/.test(value.trim())
  )
    return "date";
  return "text";
}
export function isEsos(sheets: UploadSheet[]) {
  return [
    "Reporting Obligation",
    "Responsible Undertaking",
    "Organisation Structure",
  ].every((n) =>
    sheets.some((s) => s.name === n && s.headers.includes("NOC ID")),
  );
}
export function prepareLegacyImport(
  sheets: UploadSheet[],
  selected: number,
  mapping: Record<string, string>,
  workbook: boolean,
): ImportPlan {
  const rows: PreparedRow[] = [],
    fields = new Map<string, Set<string>>();
  const mappedFields = new Map<string, Set<string>>();
  let sourceRows = 0;
  const companies = new Map<string, PreparedRow>();
  const notes: string[] = [];
  const source = workbook
    ? sheets.filter((s) => s.headers.includes("NOC ID"))
    : [sheets[selected]!];
  const addCompany = (
    name: string,
    reg: string,
    original: Record<string, string>,
    origin: PreparedRow["origin"],
  ) => {
    if (!name) return;
    // A registration number is an identity. Names alone remain separate from registered identities.
    const key = reg ? `GB:${reg}` : `name:${name.toLowerCase()}`;
    const existing = companies.get(key);
    if (!existing)
      companies.set(key, {
        row: 0,
        company: name,
        ...(reg ? { registration: reg, registrationJurisdiction: "GB", registrationType: "company_number" } : {}),
        original,
        origin,
      });
  };
  for (const s of source) {
    const map = workbook ? suggestMapping(s.headers) : mapping;
    for (let i = 0; i < s.rows.length; i++) {
      const cells = s.rows[i]!,
        original = Object.fromEntries(
          s.headers.map((h, j) => [h, cells[j] ?? ""]),
        );
      const at = (h: string) => clean(original[h]);
      sourceRows++;
      for (const h of s.headers)
        if (clean(original[h])) {
          const types = fields.get(h) ?? new Set<string>();
          types.add(inferredType(original[h]!, h));
          fields.set(h, types);
          if (map[h]) {
            const targets = mappedFields.get(h) ?? new Set<string>();
            targets.add(map[h]!);
            mappedFields.set(h, targets);
          }
        }
      if (!workbook) {
        const values = Object.fromEntries(
          s.headers
            .filter((h) => map[h])
            .map((h) => [
              map[h]!,
              clean(original[h]),
            ]),
        );
        rows.push({
          row: s.sourceRows?.[i] ?? i + 2,
          original,
          ...values,
          origin: { sheet: s.name, row: s.sourceRows?.[i] ?? i + 2, scope: "organisation" },
        });
        continue;
      }
      const notification = at("NOC ID");
      const name = at("Organisation name"),
        reg = registration(at("Company registration number"));
      const origin = {
        sheet: s.name,
        row: s.sourceRows?.[i] ?? i + 2,
        scope: "organisation" as const,
        notification,
      };
      addCompany(name, reg, {}, origin);
      if (s.name === "Responsible Undertaking") {
        const entity = companies.get(
          reg ? `GB:${reg}` : `name:${name.toLowerCase()}`,
        );
        if (entity) {
          for (const [field, header] of Object.entries({
            addressLine1: "Organisation address - Address line 1",
            addressLine2: "Organisation address - Address line 2 (optional)",
            city: "Organisation address - Town or City",
            addressRegion: "Organisation address - County (optional)",
            postalCode: "Organisation address - Postcode",
          })) {
            if (at(header) && !entity[field]) entity[field] = at(header);
          }
          const location = at(
            "Organisation address - Location of Registered Office",
          );
          if (
            /^(England|Scotland|Wales|Northern Ireland|United Kingdom|UK)$/i.test(
              location,
            )
          )
            entity.country = "GB";
        }
      }

      if (s.name === "Organisation Structure") {
        const memberName = at(
          "Names of relevant undertakings included in the NOC",
        );
        const memberReg = registration(
          at(
            "Company registration numbers of relevant undertakings included in the NOC",
          ),
        );
        // Never split a compound cell heuristically: retain it for review instead of inventing identities.
        if (
          memberName &&
          !/[;\n]/.test(
            original["Names of relevant undertakings included in the NOC"] ??
              "",
          ) &&
          (!memberReg || /^[A-Z0-9]{8}$/.test(memberReg))
        ) {
          addCompany(memberName, memberReg, {}, origin);
          rows.push({
            row: 0,
            sourceOnly: true,
            company: memberName,
            ...(memberReg ? { registration: memberReg, registrationJurisdiction: "GB", registrationType: "company_number" } : {}),
            original,
            origin: { ...origin, relatedRegistration: reg, relatedName: name },
          });
        } else {
          rows.push({
            row: 0,
            sourceOnly: true,
            original,
            origin: { ...origin, scope: "notification" },
          });
          if (memberName)
            notes.push(
              `Organisation Structure row ${i + 2}: compound or unrecognised member identity retained for review.`,
            );
        }
      } else {
        const individual = s.name === "Responsible Undertaking";
        rows.push({
          row: 0,
          sourceOnly: true,
          ...(individual
            ? { company: name, ...(reg ? { registration: reg, registrationJurisdiction: "GB", registrationType: "company_number" } : {}) }
            : {}),
          original,
          origin: {
            ...origin,
            scope: individual ? "organisation" : "notification",
          },
        });
      }
    }
  }
  if (workbook) rows.unshift(...companies.values());
  rows.forEach((r, i) => {
    r.row = i + 1;
  });
  return {
    rows,
    sourceRows,
    companies: companies.size,
    notes,
    fields: [...fields].map(([name, types]) => ({
      name,
      mappedTo: [...(mappedFields.get(name) ?? [])],
      type: types.size === 1 ? [...types][0]! : "text",
    })),
  };
}
// Version 3 keeps only responsible undertakings as canonical account candidates.
// Preserve the legacy planner for receipt reconciliation; never replay v3 rows under a v2 job.
export function prepareImport(
  sheets: UploadSheet[], selected: number, mapping: Record<string, string>, workbook: boolean,
): ImportPlan {
  const legacy = prepareLegacyImport(sheets, selected, mapping, workbook);
  if (!workbook) return legacy;
  const responsible = sheets.find(s => s.name === "Responsible Undertaking");
  if (!responsible) throw new Error("Responsible Undertaking worksheet is required.");
  const key = (name: string | undefined, reg: string | undefined) => registration(reg)
    ? `GB:${registration(reg)}` : `name:${clean(name).toLowerCase()}`;
  const identities = new Set(responsible.rows.map(r => key(
    r[responsible.headers.indexOf("Organisation name")],
    r[responsible.headers.indexOf("Company registration number")],
  )));
  const responsibleOrigins = new Map(legacy.rows.filter(r => r.sourceOnly && r.origin?.sheet === "Responsible Undertaking").map(r => [key(r.company, r.registration), r.origin]));
  const rows = legacy.rows.filter(r => r.sourceOnly || identities.has(key(r.company, r.registration))).map(r => {
    if (!r.sourceOnly) return {...r, origin: responsibleOrigins.get(key(r.company, r.registration))};
    if (r.origin?.sheet !== "Organisation Structure") return r;
    // The original row describes membership within a notification, not member facts.
    const supporting = {...r};
    delete supporting.company;
    delete supporting.registration;
    return {...supporting, origin: {...r.origin, scope: "notification" as const}};
  });
  rows.forEach((r, i) => {r.row = i + 1;});
  return {...legacy, rows, companies: rows.filter(r => !r.sourceOnly).length,
    notes: [...legacy.notes, "Only responsible undertakings become account candidates. Members, excluded entries and non-qualifying reporting entries are retained as notification evidence. ESOS qualification does not imply ICP qualification."]};
}
export async function contentKey(value: string | ArrayBuffer): Promise<string> {
  const bytes =
    typeof value === "string" ? new TextEncoder().encode(value) : value;
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))]
    .map((x) => x.toString(16).padStart(2, "0"))
    .join("");
}
export function batches(plan: ImportPlan): PreparedRow[][] {
  const output: PreparedRow[][] = [];
  let batch: PreparedRow[] = [],
    bytes = 0;
  for (const row of plan.rows) {
    const size = new TextEncoder().encode(JSON.stringify(row)).length;
    if (size > 700000)
      throw new Error(
        `Source row ${row.origin?.row ?? row.row} is too large. No data has been discarded.`,
      );
    if (batch.length && (batch.length >= 100 || bytes + size > 700000)) {
      output.push(batch);
      batch = [];
      bytes = 0;
    }
    batch.push(row);
    bytes += size;
  }
  if (batch.length) output.push(batch);
  return output;
}
export async function batchKey(job: string, index: number): Promise<string> {
  const h = await contentKey(`${job}:${index}`);
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-8${h.slice(17, 20)}-${h.slice(20, 32)}`;
}
