import type { Measurement } from "./measurement";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
export type NbaDecision = {
  action: string;
  outcome: string;
  offerId: string | null;
  reason: string;
  alternatives: string[];
  evidenceIds: string[];
  missingInformation: string[];
  dueAt: string | null;
  awaitEvent: string | null;
  policyContextHash?: string;
  policyAssessments?: { policyId: string; version: number; action: string; offerId: string | null;
    applies: boolean; effect: string; reason: string; evidenceIds: string[] }[];
  instruction: string;
};
export type NbaRecord = {
  id: string;
  campaignId: string;
  campaignVersion: number;
  version: number;
  state: string;
  subject: { type: "campaign" | "organisation" | "person"; id?: string };
  instruction: string;
  decision: NbaDecision | null;
  blockers: string[];
  updatedAt: string;
  researchSummary?: string;
  contextVersions: { type: string; id: string; version: string }[];
};
export type NbaOverview = {
  measurement?: Measurement;
  decisions: NbaRecord[];
  executionAvailable: boolean;
  executionMessage: string;
};
export function createNbaGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request),
    root = (w: string) => `/api/v1/hvm/workspaces/${encodeURIComponent(w)}/nba`;
  return {
    async list(w: string, signal: AbortSignal) {
      return (await http(root(w), signal)) as NbaOverview;
    },
    async preview(w: string, body: unknown, signal: AbortSignal) {
      return (await http(root(w), signal, {
        method: "POST",
        body,
        timeoutMs: 60000,
        rateLimitRetries: 0,
      })) as NbaRecord;
    },
    async change(w: string, id: string, body: unknown, signal: AbortSignal) {
      return (await http(root(w) + `/${encodeURIComponent(id)}`, signal, {
        method: "POST",
        body,
      })) as NbaRecord;
    },
    async history(w: string, id: string, signal: AbortSignal) {
      return (await http(
        root(w) + `/${encodeURIComponent(id)}/history`,
        signal,
      )) as { history: NbaRecord[] };
    },
  };
}
export type NbaGateway = ReturnType<typeof createNbaGateway>;
