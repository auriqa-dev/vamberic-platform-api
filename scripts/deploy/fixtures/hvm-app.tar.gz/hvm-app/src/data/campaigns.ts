import type { Measurement } from "./measurement";
import { z } from "zod";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
import type { ResearchOverview, ResearchJob } from "./research";
export type CampaignSetup = {
  operatingMode?: "opportunity_development" | "engagement_management" | "both";
  organisationPriorities?: string;
  researchRefresh?: string;
  bookingUrl?: string;
  meetingPurpose?: string;
  handoverRecipient?: string;
  enrichmentPolicy?: string;
  dailyEmailFetchLimit?: number;
  monthlyCreditAllocation?: number;
  name: string;
  objective: string;
  purpose?:
    | "acquisition"
    | "retention"
    | "reactivation"
    | "education"
    | "cross_sell"
    | "other";
  brandId: string;
  products: { id: string; revision: number }[];
  offers: { id: string; revision: number }[];
  audiences: { id: string; revision: number }[];
  source: "existing" | "discovery" | "both";
  researchPriority: string;
  urls: string[];
  channels: ("email" | "website" | "linkedin" | "chat")[];
  goal: string;
  target: number | null;
  owner: string;
  timezone: string;
  startDate: string;
  endDate: string;
  schedule: string;
  assetIds: string[];
  contentRecordIds: string[];
  overlapPolicy: string;
};
export type Campaign = {
  id: string;
  version: number;
  status: string;
  setup: CampaignSetup;
  updatedAt: string;
};
export type CampaignAudience = {
  items: {
    id: string;
    name: string;
    domain: string;
    contacts: number;
    management: string;
    lastEvidenceAt: string | null;
  }[];
  offset: number;
  more: boolean;
};
export type CampaignOverview = {
  campaigns: Campaign[];
  choices: ResearchOverview;
  overlapStatement: string;
  contentChoices: {
    id: string;
    name: string;
    status: string;
    brandId: string | null;
  }[];
  integrations: { name: string; status: string }[];
  policies: {
    key: string;
    version: number;
    status: string;
    clauses: { statement: string }[];
  }[];
};
export type CampaignMeeting = {
  id: string;
  version: number;
  personId: string;
  personName: string;
  offerId: string;
  status:
    | "confirmed"
    | "rescheduled"
    | "cancelled"
    | "attended"
    | "no_show"
    | "voided";
  startsAt: string;
  notes: string;
  providerReference?: string;
  provenance: string;
  updatedAt: string;
};
export type CampaignDetail = Campaign & {
  readiness: string[];
  execution: string;
  meetings?: CampaignMeeting[];
  preparation?: {
    offerId: string;
    name: string;
    conversionOutcome: string;
    bookingUrl: string;
    meetingPurpose: string;
    handoverRecipient: string;
    gaps: string[];
  }[];
  measurement?: Measurement;
  metrics: {
    kind: string;
    label: string;
    unit: string;
    value: number | null;
  }[];
  assessments: {
    id: string;
    organisationId: string;
    personId?: string;
    offerId: string;
    icpId: string;
    fit: string;
    rationale: string;
    unknowns: string[];
    stale: boolean;
  }[];
  jobs: ResearchJob[];
  organisations: number;
  contacts: number;
  evidenceCount: number;
  findings: {
    id: string;
    statement: string;
    kind: string;
    rationale: string;
    decision: string;
  }[];
};
export function createCampaignGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request),
    root = (w: string) =>
      `/api/v1/hvm/workspaces/${encodeURIComponent(w)}/campaigns`;
  return {
    async journey(w:string,id:string,signal:AbortSignal):Promise<CampaignJourney> {
      return await http(root(w)+`/${encodeURIComponent(id)}/journey`,signal) as CampaignJourney;
    },
    async saveJourney(w:string,id:string,body:unknown):Promise<CampaignJourney> {
      return await http(root(w)+`/${encodeURIComponent(id)}/journey`,new AbortController().signal,{method:'POST',body}) as CampaignJourney;
    },
    async recipients(w:string,id:string,search:string,offset:number,signal:AbortSignal):Promise<{items:RecipientReview[];offset:number;more:boolean}> {
      return await http(root(w)+`/${encodeURIComponent(id)}/recipients`,signal,{query:{search,offset}}) as {items:RecipientReview[];offset:number;more:boolean};
    },
    async list(w: string, signal: AbortSignal): Promise<CampaignOverview> {
      return (await http(root(w), signal)) as CampaignOverview;
    },
    async read(
      w: string,
      id: string,
      signal: AbortSignal,
    ): Promise<CampaignDetail> {
      return (await http(
        root(w) + `/${encodeURIComponent(id)}`,
        signal,
      )) as CampaignDetail;
    },
    async change(
      w: string,
      id: string | undefined,
      body: unknown,
    ): Promise<Campaign> {
      return (await http(
        root(w) + (id ? `/${encodeURIComponent(id)}` : ""),
        new AbortController().signal,
        { method: "POST", body },
      )) as Campaign;
    },
    async meeting(
      w: string,
      id: string,
      body: unknown,
    ): Promise<CampaignMeeting> {
      return (await http(
        root(w) + `/${encodeURIComponent(id)}/meetings`,
        new AbortController().signal,
        { method: "POST", body },
      )) as CampaignMeeting;
    },
    async policy(
      w: string,
      id: string,
      campaignVersion: number,
      expectedVersion: number,
    ) {
      await http(
        root(w) + `/${encodeURIComponent(id)}/overlap-policy`,
        new AbortController().signal,
        { method: "POST", body: { campaignVersion, expectedVersion } },
      );
    },
    async audience(
      w: string,
      id: string,
      offset: number,
      signal: AbortSignal,
      entity: "organisations" | "people" = "organisations",
    ): Promise<CampaignAudience> {
      return (await http(
        root(w) + `/${encodeURIComponent(id)}/audience`,
        signal,
        { query: { offset, entity } },
      )) as CampaignAudience;
    },
    async research(
      w: string,
      id: string,
      expectedVersion: number,
      organisationIds: string[] = [],
      personIds: string[] = [],
    ) {
      return z
        .object({ id: z.string() })
        .parse(
          await http(
            root(w) + `/${encodeURIComponent(id)}/research`,
            new AbortController().signal,
            {
              method: "POST",
              body: { expectedVersion, organisationIds, personIds },
            },
          ),
        );
    },
  };
}
export type CampaignGateway = ReturnType<typeof createCampaignGateway>;

export type RecipientReview = {
  personId: string; contactPointId: string; decision: 'review'|'include'|'exclude'; reason: string;
  contextRevision: string; name: string; organisations: string[]; points:{id:string;value:string}[];
  blockers:string[]; stale?:boolean; lifecycle:string;
};
export type CampaignJourney = {
  version:number;campaignVersion:number;status:string;excludedOrganisations:string[];
  recipients:RecipientReview[];blockers:string[];reviewFingerprint:string;sender:string|null;
  tracking:{automatic:boolean;property:string|null;connectedProperty:string|null;ready:boolean};
  emails:{id:string;contactId:string;subject:string;status:string;version:number}[];notice:string;
};
