import { z } from "zod";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
import { canonicalId } from "./operating/models";
const discoverySchema = z.object({
  id: z.string(),
  status: z.enum(["searching", "review", "failed", "interrupted"]),
  stale: z.boolean(),
  candidates: z
    .array(
      z.object({
        name: z.string(),
        website: z.string().url(),
        observation: z.string(),
        sourceUrl: z.string().url(),
        uncertainty: z.string(),
      }),
    )
    .optional(),
  omitted: z.number().optional(),
});
export type DiscoveryResult = z.infer<typeof discoverySchema>;
const rule = z.object({
  field: z.enum([
    "industry",
    "country",
    "region",
    "size",
    "jobTitle",
    "department",
    "seniority",
    "preferredLanguage",
    "timezone",
    "consumerCountry",
    "consumerRegion",
    "consumerNeeds",
    "consumerInterests",
    "purchaseStage",
  ]),
  values: z.array(z.string()),
  effect: z.enum(["include", "exclude"]),
});
export const policyDefinition = z.object({
  name: z.string(),
  exclusivity: z.enum([
    "multiple_offers",
    "one_offer_per_organisation",
    "one_offer_per_customer",
  ]),
  segments: z.array(
    z.object({ icpId: z.string(), revision: z.number(), rules: z.array(rule) }),
  ),
  offerPriority: z.array(z.string()),
});
export type PolicyDefinition = z.infer<typeof policyDefinition>;
const policy = z.object({
  id: z.string(),
  updatedAt: z.string(),
  definition: policyDefinition,
  status: z.enum(["draft", "approved"]),
  stale: z.boolean().optional(),
  active: z.boolean().optional(),
});
export type IcpPolicy = z.infer<typeof policy>;
const result = z.object({
  recordType: z.enum(["organisations", "people"]).optional(),
  items: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      preferredLanguage: z.string().nullable().optional(),
      timezone: z.string().nullable().optional(),
      consumerObservedOn: z.string().nullable().optional(),
      fits: z.array(
        z.object({
          icpId: z.string(),
          fit: z.string(),
          reasons: z.array(z.string()),
        }),
      ),
      eligibleOfferIds: z.array(z.string()),
      permittedOfferIds: z.array(z.string()),
      contacts: z.array(
        z.object({
          id: z.string(),
          name: z.string(),
          roleFit: z.string(),
          permittedOfferIds: z.array(z.string()).default([]),
          fits: z
            .array(
              z.object({
                icpId: z.string(),
                offerId: z.string(),
                fit: z.string(),
                reasons: z.array(z.string()),
              }),
            )
            .default([]),
          jobTitle: z.string().nullable(),
        }),
      ),
      moreContacts: z.boolean(),
    }),
  ),
  hasMore: z.boolean(),
  notice: z.string(),
  offset: z.number(),
});
export type MarketResult = z.infer<typeof result>;
export function createEligibilityGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch,
) {
  const http = createTransport(base, session, request);
  const root = (w: string) =>
    `/api/v1/hvm/workspaces/${canonicalId("workspace").parse(w)}/icp/eligibility`;
  return {
    policies: async (w: string, signal: AbortSignal) =>
      z.array(policy).parse(await http(root(w), signal)),
    savePolicy: async (
      w: string,
      definition: PolicyDefinition,
      requestKey: string,
      signal: AbortSignal,
    ) =>
      policy.parse(
        await http(root(w), signal, {
          method: "POST",
          body: { definition, requestKey },
        }),
      ),
    updatePolicy: async (
      w: string,
      p: IcpPolicy,
      definition: PolicyDefinition,
      requestKey: string,
      signal: AbortSignal,
    ) =>
      policy.parse(
        await http(root(w) + "/update", signal, {
          method: "POST",
          body: {
            id: p.id,
            expectedUpdatedAt: p.updatedAt,
            definition,
            requestKey,
          },
        }),
      ),
    deletePolicyDrafts: async (
      w: string,
      rows: IcpPolicy[],
      signal: AbortSignal,
    ) =>
      z
        .object({
          results: z.array(
            z.object({
              id: z.string(),
              status: z.enum(["deleted", "changed", "protected", "not_found"]),
            }),
          ),
        })
        .parse(
          await http(root(w) + "/delete-drafts", signal, {
            method: "POST",
            body: {
              items: rows.map((p) => ({
                id: p.id,
                expectedUpdatedAt: p.updatedAt,
              })),
              confirmation: "DELETE",
            },
          }),
        ),
    approvePolicy: async (w: string, p: IcpPolicy, signal: AbortSignal) =>
      z.array(policy).parse(
        await http(root(w) + "/approve", signal, {
          method: "POST",
          body: { id: p.id, expectedUpdatedAt: p.updatedAt },
        }),
      ),
    discoveryLatest: async (w: string, policyId: string, signal: AbortSignal) =>
      discoverySchema
        .nullable()
        .parse(
          await http(root(w) + "/discovery", signal, { query: { policyId } }),
        ),
    discover: async (w: string, body: unknown, signal: AbortSignal) =>
      discoverySchema.parse(
        await http(root(w) + "/discovery", signal, { method: "POST", body }),
      ),
    discovery: async (w: string, id: string, signal: AbortSignal) =>
      discoverySchema.parse(
        await http(
          root(w) + `/discovery/${canonicalId("event").parse(id)}`,
          signal,
        ),
      ),
    identify: async (
      w: string,
      policyId: string,
      offset: number,
      signal: AbortSignal,
      recordType: "organisations" | "people" = "organisations",
    ) =>
      result.parse(
        await http(root(w) + "/identify", signal, {
          query: { policyId, offset, recordType },
        }),
      ),
  };
}
