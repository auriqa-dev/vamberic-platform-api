import { templateGateway } from "./email-templates";
import { z } from "zod";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
import {
  emailRecord,
  emailRequest,
  emailMutation,
} from "./email-content-model";
export const ctaCandidate = z.object({
  id: z.string(),
  title: z.string(),
  url: z.string(),
  version: z.number(),
  description: z.string(),
});
export function createEmailContentGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request),
    root = (w: string) =>
      `/api/v1/hvm/workspaces/${encodeURIComponent(w)}/content-strategy/email`;
  return {
    templates: templateGateway(http),
    async list(w: string, signal: AbortSignal) {
      return z
        .object({
          records: z.array(emailRecord),
          generationAvailable: z.boolean(),
        })
        .parse(await http(root(w), signal));
    },
    async candidates(w: string, briefId: string, signal: AbortSignal) {
      return z
        .array(ctaCandidate)
        .parse(
          await http(root(w) + "/candidates", signal, { query: { briefId } }),
        );
    },
    async generate(
      w: string,
      input: z.infer<typeof emailRequest>,
      signal: AbortSignal,
    ) {
      return emailRecord.parse(
        await http(root(w) + "/generate", signal, {
          method: "POST",
          body: emailRequest.parse(input),
          timeoutMs: 60000,
          rateLimitRetries: 0,
        }),
      );
    },
    async save(
      w: string,
      id: string,
      input: z.infer<typeof emailMutation>,
      signal: AbortSignal,
    ) {
      return emailRecord.parse(
        await http(root(w) + `/${encodeURIComponent(id)}`, signal, {
          method: "POST",
          body: input,
        }),
      );
    },
    async history(w: string, id: string, signal: AbortSignal) {
      return z
        .array(emailRecord)
        .parse(
          await http(root(w) + `/${encodeURIComponent(id)}/history`, signal),
        );
    },
  };
}
export type EmailContentGateway = ReturnType<typeof createEmailContentGateway>;
