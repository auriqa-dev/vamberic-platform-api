import { measurementSchema } from "./measurement";
import { z } from "zod";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
const controls = z.object({
  lifecycle: z.string(),
  doNotContact: z.boolean(),
  marketingSuppressed: z.boolean(),
  oneToOneSuppressed: z.boolean(),
  commercialExclusion: z.boolean(),
  reason: z.string(),
});
const schema = z.object({
  measurement: measurementSchema.optional(),
  revision: z.string(),
  sourceId: z.string().nullable(),
  sourceLifecycle: z.string(),
  sourceCurrentCustomer: z.boolean(),
  lifecycle: z.string(),
  leadStatus: z.string(),
  subscriptionStatus: z.string(),
  marketingContactStatus: z.string(),
  sourceFields: z.record(z.string()).default({}),
  sourceRestrictions: z.array(z.string()),
  inheritedRestrictions: z.array(z.string()),
  controls,
  points: z.array(
    z.object({
      id: z.string(),
      value: z.string(),
      type: z.string(),
      suppressed: z.boolean(),
      leftOrganisation: z.boolean(),
      deliverability: z.string(),
    }),
  ),
  relationships: z.array(
    z.object({
      id: z.string(),
      organisationId: z.string(),
      organisationName: z.string(),
      current: z.boolean(),
      endDate: z.string().nullable(),
    }),
  ),
  interactions: z.array(
    z.object({
      id: z.string(),
      date: z.string(),
      subject: z.string(),
      body: z.string(),
      direction: z.string(),
      assessment: z
        .object({
          category: z.string(),
          status: z.string(),
          reason: z.string(),
        })
        .nullable(),
    }),
  ),
});
export type ContactContext = z.infer<typeof schema>;
export function createContactContextGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const call = createTransport(base, session, request);
  const path = (w: string, k: string, id: string) =>
    `/api/v1/hvm/workspaces/${w}/records/${k}/${id}/context`;
  return {
    unlinked: async (w: string, offset: number, signal: AbortSignal) =>
      z
        .object({
          hasMore: z.boolean(),
          items: z.array(
            z.object({
              id: z.string(),
              updatedAt: z.string(),
              subject: z.string(),
              body: z.string(),
              date: z.string(),
              participants: z.record(z.string()),
            }),
          ),
        })
        .parse(
          await call(
            `/api/v1/hvm/workspaces/${w}/email-history/unlinked`,
            signal,
            { query: { offset } },
          ),
        ),
    link: async (
      w: string,
      id: string,
      body: { updatedAt: string; personId: string; reason: string },
      signal: AbortSignal,
    ) =>
      call(`/api/v1/hvm/workspaces/${w}/email-history/${id}/link`, signal, {
        method: "POST",
        body,
      }),
    read: async (w: string, k: string, id: string, signal: AbortSignal) =>
      schema.parse(await call(path(w, k, id), signal)),
    save: async (
      w: string,
      k: string,
      id: string,
      body: {
        revision: string;
        controls: ContactContext["controls"];
        responseReview?: { eventId: string; category: string };
        departure?: {
          eventId: string;
          contactPointId: string;
          relationshipId?: string;
        };
      },
      signal: AbortSignal,
    ) =>
      schema.parse(
        await call(path(w, k, id), signal, { method: "POST", body }),
      ),
  };
}
export type ContactContextGateway = ReturnType<
  typeof createContactContextGateway
>;
