import { createContext } from "react";
export const CompanyReferenceContext = createContext<{
  industries: string[];
  regions: string[];
}>({ industries: [], regions: [] });
