import { z } from "zod";
export const measurementSchema = z.object({
  updatedAt: z.string(),
  truncated: z.boolean(),
  eventCount: z.number(),
  contactCount: z.number(),
  organisationCount: z.number(),
  windowStart: z.string(),
  windowEnd: z.string().nullable().optional(),
  limitations: z.array(z.string()),
  metrics: z.array(
    z.object({
      kind: z.string(),
      label: z.string(),
      value: z.number().nullable(),
      unit: z.string(),
    }),
  ),
  timeline: z.array(
    z.object({
      id: z.string(),
      kind: z.string(),
      occurredAt: z.string(),
      contactId: z.string(),
      contactName: z.string().optional(),
      communicationId: z.string(),
      replyId: z.string().optional(),
      category: z.string().optional(),
      reviewed: z.boolean().optional(),
      associated: z.boolean().optional(),
      website: z.object({identity:z.string(),automation:z.string(),path:z.string(),name:z.string().optional()}).optional(),
      guidance: z.string(),
      fact: z.string(),
    }),
  ),
  feedback: z.array(
    z.object({
      id: z.string(),
      state: z.string(),
      reason: z.string(),
      contactId: z.string(),
      contactName: z.string().optional(),
      campaignId: z.string().nullish(),
      dueAt: z.string().nullable(),
      evidenceId: z.string(),
      updatedAt: z.string(),
    }),
  ),
});
export type Measurement = z.infer<typeof measurementSchema>;
