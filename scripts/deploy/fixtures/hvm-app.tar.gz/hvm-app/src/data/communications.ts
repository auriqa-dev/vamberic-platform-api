import { measurementSchema } from "./measurement";
import { templateGateway } from "./email-templates";
import { DataError } from "./gateway";
import { z } from "zod";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
import { emailRecord } from "./email-content-model";
export const categories = [
  "interested",
  "question",
  "objection",
  "meeting_request",
  "not_interested",
  "unsubscribe",
  "out_of_office",
  "left_organisation",
  "wrong_person",
  "referral",
  "automated",
  "delivery_failure",
  "unclear",
] as const;
const record = z
  .object({
    id: z.string(),
    version: z.number(),
    status: z.string(),
    archived: z.boolean(),
    sender: z.string(),
    recipient: z.string(),
    testOnly: z.boolean(),
    draft: emailRecord,
    rendered: z.object({
      subject: z.string(),
      text: z.string(),
      html: z.string(),
      notice: z.string().optional(),
      inlineImages: z
        .array(z.object({ cid: z.literal("brand-logo"), base64: z.string() }))
        .optional(),
    }),
    notice: z.string().default(""),
    dueAt: z.string(),
    updatedAt: z.string(),
  })
  .passthrough();
const reply = z
  .object({
    id: z.string(),
    version: z.number(),
    communicationId: z.string(),
    contactId: z.string(),
    proposedContactId: z.string(),
    testOnly: z.boolean(),
    associated: z.boolean(),
    reviewed: z.boolean(),
    message: z.object({
      from: z.string(),
      subject: z.string(),
      text: z.string(),
      occurredAt: z.string(),
    }),
    interpretation: z.object({
      category: z.enum(categories),
      reason: z.string(),
      confidence: z.string(),
      evidence: z.string(),
    }),
  })
  .passthrough();
export const communicationsBundle = z.object({
  measurement: measurementSchema.optional(),
  records: z.array(record),
  replies: z.array(reply),
  drafts: z.array(
    emailRecord.extend({
      points: z.array(
        z.object({
          id: z.string(),
          value: z.string(),
          suppressed: z.boolean().optional(),
          leftOrganisation: z.boolean().optional(),
        }),
      ),
    }),
  ),
  policies: z.array(
    z.object({
      id: z.string(),
      key: z.string(),
      version: z.number(),
      title: z.string(),
      details: z.record(z.unknown()),
    }),
  ),
  mailbox: z.object({
    email: z.string().nullable(),
    status: z.string(),
    testRecipients: z.array(z.string()),
  }),
});
export type Communication = z.infer<typeof record>;
export type CommunicationReply = z.infer<typeof reply>;
export type CommunicationsBundle = z.infer<typeof communicationsBundle>;
export function createCommunicationsGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request),
    root = (w: string) =>
      `/api/v1/hvm/workspaces/${encodeURIComponent(w)}/communications`;
  return {
    templates: templateGateway(http),
    list: async (w: string, s: AbortSignal) =>
      parseCommunications(await http(root(w), s)),
    create: async (w: string, input: unknown, s: AbortSignal) =>
      record.parse(await http(root(w), s, { method: "POST", body: input })),
    mutate: async (w: string, id: string, input: unknown, s: AbortSignal) =>
      record.parse(
        await http(root(w) + "/" + encodeURIComponent(id), s, {
          method: "POST",
          body: input,
          timeoutMs: 60000,
          rateLimitRetries: 0,
        }),
      ),
    review: async (w: string, id: string, input: unknown, s: AbortSignal) =>
      reply.parse(
        await http(root(w) + "/replies/" + encodeURIComponent(id), s, {
          method: "POST",
          body: input,
        }),
      ),
    sync: async (w: string, s: AbortSignal) =>
      parseCommunications(
        await http(root(w) + "/sync", s, {
          method: "POST",
          body: {},
          timeoutMs: 60000,
          rateLimitRetries: 0,
        }),
      ),
  };
}
export type CommunicationsGateway = ReturnType<
  typeof createCommunicationsGateway
>;

export function parseCommunications(value: unknown): CommunicationsBundle {
  const parsed = communicationsBundle.safeParse(value);
  if (parsed.success) return parsed.data;
  // Paths and error codes only: never log message text, addresses or tokens.
  const fields = parsed.error.issues.map(issue => `${issue.path.join(".")}: ${issue.code}`).join("; ");
  console.error("Communications response contract", fields);
  throw new DataError("invalid", "Communications returned records that could not be displayed. Your saved emails are retained. Refresh to retry.");
}
