import { z } from "zod";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
const job = z
  .object({
    id: z.string(),
    updatedAt: z.string(),
    status: z.string(),
    phase: z.string(),
    summary: z.string(),
    error: z.string(),
    gaps: z.array(z.string()),
    request: z
      .object({
        objective: z.string(),
        type: z.string(),
        scope: z.object({ brandId: z.string() }).passthrough(),
      })
      .passthrough(),
    usage: z.array(
      z.object({
        model: z.string().default("provider"),
        inputTokens: z.number().default(0),
        outputTokens: z.number().default(0),
      }),
    ),
    discovery: z
      .array(
        z.object({
          candidateId:z.string().optional(),kind:z.string().optional(),details:z.record(z.unknown()).optional(),evidenceIds:z.array(z.string()).optional(),
          id: z.string().nullable().optional(),
          name: z.string().optional(),
          type: z.string().optional(),
          status: z.string(),
          reason: z.string().optional(),
        }),
      )
      .default([]),
  })
  .passthrough();
const finding = z
  .object({
    id: z.string(),
    updatedAt: z.string(),
    decision: z.string(),
    statement: z.string(),
    kind: z.string(),
    verification: z.string(),
    rationale: z.string(),
    reviewNote: z.string(),
    evidenceIds: z.array(z.string()),
  })
  .passthrough();
const evidence = z
  .object({
    access: z.string().default("workspace"),
    restrictions: z.array(z.string()).default([]),
    excerptOnly: z.boolean().default(false),
    revision: z.number().optional(),
    id: z.string(),
    title: z.string(),
    url: z.string(),
    extract: z.string(),
    retrievedAt: z.string(),
  })
  .passthrough();
const policy = z.object({
  error: z.string().default(""),
  id: z.string(),
  updatedAt: z.string(),
  name: z.string(),
  enabled: z.boolean(),
  mode: z.string(),
  request: z.unknown(),
  intervalDays: z.number(),
  trigger: z.string(),
});
const overview = z.object({
  documents: z
    .array(z.object({ id: z.string(), revision: z.number(), name: z.string() }))
    .default([]),
  assets: z.array(
    z.object({ id: z.string(), name: z.string(), brandId: z.string() }),
  ),
  workerEnabled: z.boolean(),
  choices: z.record(
    z.array(
      z.object({
        id: z.string(),
        revision: z.number(),
        name: z.string(),
        brandId: z.string().nullable(),
      }),
    ),
  ),
  jobs: z.array(job),
  policies: z.array(policy),
  brands: z.array(z.object({ id: z.string(), name: z.string() })),
  generationAvailable: z.boolean(),
});
export type ResearchOverview = z.infer<typeof overview>;
export type ResearchJob = z.infer<typeof job>;
const detail = z.object({
  job,
  findings: z.array(finding),
  evidence: z.array(evidence),
});
export type ResearchDetail = z.infer<typeof detail>;
export const organisationDossier=z.object({organisation:z.object({id:z.string(),name:z.string()}).nullable(),matchCount:z.number().optional(),contacts:z.array(z.object({id:z.string(),firstName:z.string().optional(),lastName:z.string().optional(),title:z.string().optional()})).default([]),context:z.object({lifecycle:z.string(),controls:z.object({doNotContact:z.boolean(),commercialExclusion:z.boolean(),marketingSuppressed:z.boolean(),oneToOneSuppressed:z.boolean()})}).optional(),hasMore:z.boolean().optional(),evidence:z.array(z.unknown()).default([]),executionAuthorised:z.literal(false)});
export type OrganisationDossier=z.infer<typeof organisationDossier>;
export function createResearchServiceGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request),
    root = (w: string) => `/api/v1/hvm/workspaces/${w}/research`;
  return {
    async candidate(w:string,id:string,action:"review"|"enrich"|"promote"|"people"|"supplement",body:unknown={}) {
      return http(root(w)+`/candidates/${id}/${action}`,new AbortController().signal,{method:"POST",body,timeoutMs:60000});
    },
    async dossier(w:string,id:string) { return organisationDossier.parse(await http(root(w)+`/candidates/${id}/dossier`,new AbortController().signal)); },
    async list(w: string, signal: AbortSignal) {
      return overview.parse(await http(root(w), signal));
    },
    async read(w: string, id: string, signal: AbortSignal) {
      return detail.parse(await http(root(w) + `/${id}`, signal));
    },
    async start(w: string, body: unknown) {
      return job.parse(
        await http(root(w), new AbortController().signal, {
          method: "POST",
          body,
        }),
      );
    },
    async change(w: string, id: string, body: unknown) {
      return z.object({ id: z.string() }).parse(
        await http(root(w) + `/${id}/update`, new AbortController().signal, {
          method: "POST",
          body,
        }),
      );
    },
    async continue(w: string, id: string) {
      await http(root(w) + `/${id}/continue`, new AbortController().signal, {
        method: "POST",
        body: {},
      });
    },
    async review(w: string, id: string, body: unknown) {
      await http(root(w) + `/findings/${id}`, new AbortController().signal, {
        method: "POST",
        body,
      });
    },
    async removePolicy(w: string, id: string, updatedAt: string) {
      await http(
        root(w) + `/policies/${id}/remove`,
        new AbortController().signal,
        { method: "POST", body: { expectedUpdatedAt: updatedAt } },
      );
    },
    async policy(w: string, body: unknown) {
      await http(root(w) + "/policies", new AbortController().signal, {
        method: "POST",
        body,
      });
    },
    async evidence(w: string, type: string, id: string, signal: AbortSignal) {
      return z
        .array(finding)
        .parse(await http(root(w) + `/evidence/${type}/${id}`, signal));
    },
  };
}
export type ResearchGateway = ReturnType<typeof createResearchServiceGateway>;
