import { z } from "zod";
import { canonicalId } from "./operating/models";
import { createTransport } from "./transport";
import { DataError } from "./gateway";
import type { AuthSession } from "../auth/session";
export const researchDetails = z.object({
  name: z.string().trim().min(1).max(200),
  purpose: z.string().trim().min(1).max(1000),
  extract: z.string().trim().min(1).max(6000),
  provenance: z.string().trim().min(1).max(1000),
  grain: z.enum(["company", "reporting_group", "person", "mixed", "other"]),
});
export type ResearchDetails = z.infer<typeof researchDetails>;
export type ResearchSelection = { id: string; revision: number }[];
const document = z.object({
  id: canonicalId("event"),
  updatedAt: z.string().datetime(),
  filename: z.string(),
  size: z.number(),
  revision: z.number(),
  status: z.enum(["uploading", "ready"]),
  details: researchDetails,
});
export type ResearchDocument = z.infer<typeof document>;
export function createResearchGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request);
  const root = (w: string) =>
    `/api/v1/hvm/workspaces/${canonicalId("workspace").parse(w)}/research-documents`;
  async function fileRequest(
    w: string,
    id: string,
    signal: AbortSignal,
    file?: File,
  ) {
    const token = await session.getAccessToken();
    if (!token) throw new DataError("denied");
    const response = await request(
      new URL(root(w) + `/${canonicalId("event").parse(id)}/file`, base),
      {
        method: file ? "POST" : "GET",
        body: file,
        headers: {
          Authorization: `Bearer ${token}`,
          ...(file ? { "Content-Type": "application/octet-stream" } : {}),
        },
        signal: AbortSignal.any([signal, AbortSignal.timeout(120000)]),
        credentials: "omit",
        redirect: "error",
        cache: "no-store",
        referrerPolicy: "no-referrer",
      },
    );
    if (response.status === 401)
      await session.invalidate("Your session expired. Please sign in again.");
    if (!response.ok)
      throw new DataError(response.status === 409 ? "conflict" : "unavailable");
    return response;
  }
  return {
    async list(w: string, signal: AbortSignal) {
      return z
        .object({
          available: z.boolean(),
          documents: z.array(document),
          more: z.boolean(),
        })
        .parse(await http(root(w), signal));
    },
    async upload(
      w: string,
      file: File,
      details: ResearchDetails,
      requestKey: string,
      signal: AbortSignal,
    ) {
      if (file.size > 50 * 1024 * 1024)
        throw new Error("Choose a file up to 50 MB.");
      const hash = await crypto.subtle.digest(
        "SHA-256",
        await file.arrayBuffer(),
      );
      const sha256 = Array.from(new Uint8Array(hash), (b) =>
        b.toString(16).padStart(2, "0"),
      ).join("");
      const row = document.parse(
        await http(root(w), signal, {
          method: "POST",
          body: {
            requestKey,
            filename: file.name,
            size: file.size,
            sha256,
            details: researchDetails.parse(details),
          },
        }),
      );
      if (row.status === "ready") return row;
      return document.parse(
        await (await fileRequest(w, row.id, signal, file)).json(),
      );
    },
    async resume(
      w: string,
      row: ResearchDocument,
      file: File,
      signal: AbortSignal,
    ) {
      return document.parse(
        await (await fileRequest(w, row.id, signal, file)).json(),
      );
    },
    async download(
      w: string,
      row: Pick<ResearchDocument, "id">,
      signal: AbortSignal,
    ) {
      return (await fileRequest(w, row.id, signal)).blob();
    },
    async update(
      w: string,
      row: ResearchDocument,
      details: ResearchDetails,
      signal: AbortSignal,
    ) {
      await http(root(w) + "/update", signal, {
        method: "POST",
        body: {
          operation: "update",
          id: row.id,
          expectedUpdatedAt: row.updatedAt,
          details: researchDetails.parse(details),
        },
      });
    },
    async updatePurpose(
      w: string,
      rows: ResearchDocument[],
      purpose: string,
      signal: AbortSignal,
    ) {
      await http(root(w) + "/update", signal, {
        method: "POST",
        body: {
          operation: "update-purpose",
          purpose,
          targets: rows.map((row) => ({
            id: row.id,
            expectedUpdatedAt: row.updatedAt,
          })),
        },
      });
    },
    async remove(w: string, rows: ResearchDocument[], signal: AbortSignal) {
      await http(root(w) + "/update", signal, {
        method: "POST",
        body: {
          operation: "remove",
          targets: rows.map((row) => ({
            id: row.id,
            expectedUpdatedAt: row.updatedAt,
          })),
        },
      });
    },
  };
}
export type ResearchGateway = ReturnType<typeof createResearchGateway>;
