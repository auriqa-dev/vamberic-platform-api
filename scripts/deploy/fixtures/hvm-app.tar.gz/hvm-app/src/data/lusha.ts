import { z } from "zod";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
const permissions=z.object({research:z.boolean(),discovery:z.boolean(),enrichment:z.boolean()});
const connection=z.object({available:z.boolean(),canManage:z.boolean(),usage:z.object({recordedCredits:z.number(),uncertainLookups:z.number(),limited:z.boolean()}),id:z.string().nullable(),updatedAt:z.string().nullable(),status:z.string(),permissions,credits:z.object({total:z.number(),used:z.number(),remaining:z.number()}).nullable(),lastTestedAt:z.string().nullable(),capabilitiesVerified:z.boolean()});
export type LushaConnection=z.infer<typeof connection>;
export function createLushaGateway(base:string,session:Pick<AuthSession,"getAccessToken"|"invalidate">,request:typeof fetch=fetch) {
 const call=createTransport(base,session,request),path=(w:string)=>`/api/v1/hvm/workspaces/${w}/lusha`;
 return {read:async(w:string,signal:AbortSignal)=>connection.parse(await call(path(w),signal)),
  change:async(w:string,action:"connect"|"update"|"test",body:unknown,signal:AbortSignal)=>connection.parse(await call(path(w)+"/"+action,signal,{method:"POST",body,timeoutMs:60000}))};
}
export type LushaGateway=ReturnType<typeof createLushaGateway>;
