import { websiteReviewSchema } from "./psu-website";
import { z } from "zod";
import { canonicalId as id } from "./operating/models";
import { createTransport } from "./transport";
import { DataError } from "./gateway";
import type { AuthSession } from "../auth/session";
const version = z.number().int().positive();
const offeringSchema = z.object({
  id: id("offering"),
  workspaceId: id("workspace"),
  brandId: id("brand").optional(),
  updatedAt: z.string().datetime(),
  revision: version,
  status: z.enum(["draft", "approved", "retired"]),
  approvedRevision: version.optional(),
  definition: z.record(z.unknown()),
  evidence: z
    .array(
      z.object({
        field: z.string(),
        value: z.unknown(),
        sourceReference: z.string().optional(),
        verification: z.string(),
        observedAt: z.string(),
      }),
    )
    .optional(),
});
export type PsuOffering = z.infer<typeof offeringSchema>;
const jobSchema = z.object({
  id: id("event"),
  workspaceId: id("workspace"),
  createdAt: z.string().datetime(),
  input: z.object({
    brandId: id("brand"),
    kind: z.enum(["company", "product"]).optional(),
    depth: z.enum(["summary", "detailed"]).optional(),
    offeringId: id("offering").optional(),
    expectedUpdatedAt: z.string().datetime().optional(),
    workingLabel: z.string(),
    orientation: z.string(),
    websiteUrls: z.array(z.string()),
    includeWebResearch: z.boolean().optional(),
  }),
  status: z.enum(["generating", "review", "saved", "failed", "interrupted"]),
  progress: z.object({phase:z.enum(["reading","drafting","searching","refining"]),pagesRead:z.number(),pagesAttempted:z.number(),maximumPages:z.number()}).optional(),
  researchIncomplete:z.boolean().optional(),
  researchSources:z.array(z.string().url()).optional(),
  researchUnavailable:z.boolean().optional(),
  failureCode: z
    .enum([
      "sources_unavailable",
      "service_configuration",
      "service_unavailable",
      "output_invalid",
      "output_model_mismatch",
      "output_format_invalid",
      "output_evidence_invalid",
      "timed_out",
      "generation_failed",
    ])
    .optional(),
  draft: websiteReviewSchema.optional(),
  companyDraft: websiteReviewSchema
    .extend({ kind: z.literal("psu_company_review_draft") })
    .optional(),
  offeringCount: z.enum(["single", "multiple", "uncertain"]).optional(),
  offeringCountReason: z.string().optional(),
  competitorSuggestions: z.array(z.string().min(1).max(200)).max(10).optional(),
  productCompetitorSuggestions: z.array(z.string()).optional(),
  productUnavailable: z.boolean().optional(),
  productDeleted: z.boolean().optional(),
  companySaved: z.boolean().optional(),
  unavailable: z.array(z.string()).optional(),
  offeringId: id("offering").optional(),
});
export type PsuJob = z.infer<typeof jobSchema>;

export type PsuPreparation =
  | {
      mode: "create";
      kind?: "company" | "product";
      depth?: "summary" | "detailed";
      offeringId?: string;
      expectedUpdatedAt?: string;
      brandId: string;
      workingLabel: string;
      orientation: string;
      websiteUrls?: string[];
      includeWebResearch?: boolean;
    }
  | {
      mode: "refresh";
      offeringId: string;
      expectedUpdatedAt: string;
      workingLabel: string;
      orientation: string;
      websiteUrls?: string[];
      includeWebResearch?: boolean;
    };
const companyVersion = z.object({
  versionId: id("event"),
  definition: z.record(z.union([z.string(), z.array(z.string())])),
});
const companySchema = z.object({
  workspaceId: id("workspace"),
  brandId: id("brand"),
  brandName: z.string(),
  websiteUrl: z.string(),
  current: companyVersion.extend({ approved: z.boolean() }).nullable(),
  approved: companyVersion.nullable(),
  primaryOfferingId: id("offering").nullable(),
});
export type CompanyState = z.infer<typeof companySchema>;
export const deletionPreviewSchema = z.object({workspaceId:id("workspace"),kind:z.enum(["company","product","generation","product-draft"]),id:z.string(),name:z.string(),token:z.string().length(64),permanent:z.literal(true),counts:z.array(z.object({collection:z.string(),label:z.string(),count:z.number()})),blockers:z.array(z.string())});
export type ProfileDeletionPreview = z.infer<typeof deletionPreviewSchema>;
export function createPsuGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request);
  const root = (w: string) =>
    `/api/v1/hvm/workspaces/${id("workspace").parse(w)}`;
  const scoped = <T extends { workspaceId: string }>(w: string, v: T) => {
    if (v.workspaceId !== w) throw new DataError("invalid");
    return v;
  };
  return {
    async deletionPreview(w:string, kind:"company"|"product"|"generation"|"product-draft", targetId:string, signal:AbortSignal) {
      return scoped(w,deletionPreviewSchema.parse(await http(root(w)+"/psu/deletion-preview",signal,{method:"POST",body:{kind,id:targetId},timeoutMs:60000,rateLimitRetries:0})));
    },
    async deleteProfile(w:string, preview:ProfileDeletionPreview, confirmation:string, signal:AbortSignal) {
      return scoped(w,z.object({workspaceId:id("workspace"),deleted:z.literal(true)}).parse(await http(root(w)+"/psu/delete",signal,{method:"POST",body:{kind:preview.kind,id:preview.id,token:preview.token,name:preview.name,confirmation},timeoutMs:60000,rateLimitRetries:0})));
    },
    async referenceData(w: string, s: AbortSignal) {
      const item = z.object({
        code: z.string().min(1),
        name: z.string().min(1),
        description: z.string(),
      });
      return scoped(
        w,
        z
          .object({
            workspaceId: id("workspace"),
            industries: z.array(item),
            regions: z.array(item),
          })
          .parse(await http(root(w) + "/psu/reference-data", s)),
      );
    },
    async company(w: string, brandId: string, s: AbortSignal) {
      const result = scoped(
        w,
        companySchema.parse(
          await http(root(w) + "/psu/company/" + id("brand").parse(brandId), s),
        ),
      );
      if (result.brandId !== brandId) throw new DataError("invalid");
      return result;
    },
    async saveCompany(
      w: string,
      brandId: string,
      input: {
        requestKey: string;
        expectedVersionId: string | null;
        definition: Record<string, unknown>;
        jobId?: string;
        draftDigest?: string;
      },
      s: AbortSignal,
    ) {
      return http(
        root(w) + "/psu/company/" + id("brand").parse(brandId) + "/save",
        s,
        { method: "POST", body: input },
      );
    },
    async approveCompany(
      w: string,
      brandId: string,
      versionId: string,
      s: AbortSignal,
    ) {
      return http(
        root(w) + "/psu/company/" + id("brand").parse(brandId) + "/approve",
        s,
        { method: "POST", body: { versionId } },
      );
    },
    async primaryProduct(
      w: string,
      brandId: string,
      offeringId: string,
      expectedOfferingId: string | null,
      s: AbortSignal,
    ) {
      return http(
        root(w) + "/psu/company/" + id("brand").parse(brandId) + "/primary",
        s,
        { method: "POST", body: { offeringId, expectedOfferingId } },
      );
    },
    async job(w: string, jobId: string, s: AbortSignal) {
      return scoped(
        w,
        jobSchema.parse(
          await http(root(w) + "/psu/" + id("event").parse(jobId), s),
        ),
      );
    },
    async jobs(w: string, s: AbortSignal) {
      const result = z
        .object({
          workspaceId: id("workspace"),
          generationAvailable: z.boolean(),
          items: z.array(jobSchema),
          hasMore: z.boolean(),
        })
        .parse(await http(root(w) + "/psu", s));
      scoped(w, result);
      result.items.forEach((item) => scoped(w, item));
      return result;
    },
    async createProduct(
      w: string,
      body: {
        requestKey: string;
        brandId: string;
        definition: Record<string, unknown>;
      },
      s: AbortSignal,
    ) {
      return z
        .object({ offeringId: id("offering") })
        .parse(
          await http(root(w) + "/psu/products", s, { method: "POST", body }),
        );
    },
    async generate(
      w: string,
      input: Extract<PsuPreparation, { mode: "create" }>,
      requestKey: string,
      s: AbortSignal,
    ) {
      const { mode, ...body } = input;
      void mode;
      return http(root(w) + "/psu", s, {
        method: "POST",
        body: { ...body, requestKey },
      });
    },
    async saveReview(
      w: string,
      job: PsuJob,
      fields: { field: string; value: string | string[] }[],
      s: AbortSignal,
    ) {
      scoped(w, job);
      if (!job.draft) throw new DataError("invalid");
      return http(root(w) + "/psu/" + job.id + "/save", s, {
        method: "POST",
        body: { draftDigest: job.draft.digest, fields },
      });
    },
    async update(
      w: string,
      o: PsuOffering,
      definition: Record<string, unknown>,
      s: AbortSignal,
    ) {
      scoped(w, o);
      return http(root(w) + "/offerings/update", s, {
        method: "POST",
        body: { id: o.id, expectedUpdatedAt: o.updatedAt, definition },
      });
    },
    async revision(
      w: string,
      o: PsuOffering,
      revision: number,
      s: AbortSignal,
    ) {
      scoped(w, o);
      const result = z
        .object({
          workspaceId: id("workspace"),
          entityId: id("offering"),
          revision: version,
          snapshot: offeringSchema,
        })
        .parse(
          await http(root(w) + `/offerings/${o.id}/revisions/${revision}`, s),
        );
      if (result.entityId !== o.id || result.revision !== revision)
        throw new DataError("invalid");
      scoped(w, result);
      return scoped(w, result.snapshot);
    },
    async brands(w: string, s: AbortSignal) {
      return z
        .object({
          brands: z.array(
            z.object({
              id: id("brand"),
              workspaceId: id("workspace"),
              name: z.string(),
            }),
          ),
        })
        .parse(await http(root(w) + "/brands", s))
        .brands.map((b) => scoped(w, b));
    },
    async offerings(w: string, s: AbortSignal) {
      const r = z
        .object({ items: z.array(offeringSchema), hasMore: z.boolean() })
        .parse(
          await http(root(w) + "/offerings", s, { query: { limit: 100 } }),
        );
      if (r.hasMore) throw new DataError("unavailable");
      return r.items.map((o) => scoped(w, o));
    },
    async revise(w: string, o: PsuOffering, s: AbortSignal) {
      scoped(w, o);
      return http(root(w) + "/offerings/revise", s, {
        method: "POST",
        body: { id: o.id, expectedUpdatedAt: o.updatedAt },
      });
    },
    async approvedVersion(w: string, o: PsuOffering, s: AbortSignal) {
      scoped(w, o);
      if (!o.approvedRevision) throw new DataError("invalid");
      const row = z
        .object({
          workspaceId: id("workspace"),
          entityId: id("offering"),
          revision: version,
          snapshot: offeringSchema,
        })
        .parse(
          await http(
            root(w) + `/offerings/${o.id}/revisions/${o.approvedRevision}`,
            s,
          ),
        );
      if (
        row.workspaceId !== w ||
        row.entityId !== o.id ||
        row.revision !== o.approvedRevision ||
        row.snapshot.id !== o.id ||
        row.snapshot.status !== "approved" ||
        row.snapshot.revision !== o.approvedRevision
      )
        throw new DataError("invalid");
      return scoped(w, row.snapshot);
    },
    async approve(w: string, o: PsuOffering, s: AbortSignal) {
      scoped(w, o);
      return http(root(w) + "/offerings/approve", s, {
        method: "POST",
        body: { id: o.id, expectedUpdatedAt: o.updatedAt },
      });
    },
  };
}
export type PsuGateway = ReturnType<typeof createPsuGateway>;
