import { z } from "zod";
import type { AuthSession } from "../auth/session";
import { createTransport } from "./transport";
export const trackingSettings = z.object({
  origin: z.string(),
  brandId: z.string(),
  enabled: z.boolean(),
  testOnly: z.boolean(),
  retentionDays: z.number(),
  policyConfirmed: z.boolean(),
  paths: z.array(z.string()).default([]),
  events: z.array(z.string()),
});
const site = trackingSettings.extend({
  id: z.string(),
  version: z.number(),
  verification: z.string(),
  verifiedAt: z.string().nullable(),
  revoked: z.boolean(),
  lastReceivedAt: z.string().nullable(),
});
const state = z.object({
  available: z.boolean(),
  canManage: z.boolean(),
  base: z.string(),
  brands: z.array(z.object({ id: z.string(), name: z.string() })),
  sites: z.array(site),
});
export type TrackingState = z.infer<typeof state>;
export type TrackingSite = z.infer<typeof site>;
export type TrackingSettings = z.infer<typeof trackingSettings>;
export function createWebsiteTrackingGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const call = createTransport(base, session, request),
    path = (w: string) => `/api/v1/hvm/workspaces/${w}/website-tracking`;
  return {
    read: async (w: string, signal: AbortSignal) =>
      state.parse(await call(path(w), signal)),
    change: async (w: string, body: unknown, signal: AbortSignal) =>
      state.parse(
        await call(path(w), signal, {
          method: "POST",
          body,
          rateLimitRetries: 0,
        }),
      ),
  };
}
export type WebsiteTrackingGateway = ReturnType<
  typeof createWebsiteTrackingGateway
>;
