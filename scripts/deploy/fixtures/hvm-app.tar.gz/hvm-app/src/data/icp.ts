import { createStrategyGateway } from "./contact-strategy";
import { createResearchGateway } from "./research-documents";
import { createEligibilityGateway } from "./icp-eligibility";
import { z } from "zod";
import { canonicalId } from "./operating/models";
import { createTransport } from "./transport";
import { DataError } from "./gateway";
import type { AuthSession } from "../auth/session";

export const profileFields = {
  essentialFit: "Essential fit requirements",
  desirableFit: "Desirable characteristics",
  evidenceRequirements: "Evidence needed to establish fit",
  refreshCriteria: "When to refresh research",
  unknownHandling: "How to handle missing information",

  characteristics: "Buyer roles, titles and characteristics",
  problems: "Problems and jobs to be done",
  desiredOutcomes: "Desired outcomes and success measures",
  buyingTriggers: "Buying triggers",
  goodFitIndicators: "Good fit indicators",
  badFitIndicators: "Poor fit and exclusions",
  commercialCharacteristics: "Commercial value and revenue criteria",
  operationalCharacteristics:
    "Responsibilities, constraints and operating needs",
  technologyCharacteristics: "Technology requirements",
  unknowns: "Assumptions and details to clarify",
  researchCriteria: "Pain signals and evidence to research",
  adoptionReadiness: "Readiness to adopt",
  targetingCoverage: "Targeting requirements and review notes",
} as const;
export const accountFields = {
  organisationTypes: "Organisation types",
  companySizeBands: "Company size",
  industries: "Industries",
  subIndustries: "Specialisms",
  geographies: "Markets and regions",
} as const;
export const consumerFields = {
  demographics: "Relevant audience characteristics",
  geographies: "Markets and regions",
  psychographics: "Motivations",
  values: "Values",
  interests: "Interests",
  lifestyle: "Lifestyle",
  purchasingBehaviour: "Purchasing behaviour",
  priceSensitivity: "Price sensitivity",
  promotionSensitivity: "Promotion sensitivity",
  shoppingBehaviour: "Shopping behaviour",
  researchBehaviour: "Research behaviour",
  acuteProblems: "Immediate problems",
  aspirations: "Aspirations",
  retentionTendencies: "Retention",
  advocacyTendencies: "Advocacy",
  reviewTendencies: "Reviews",
  referralTendencies: "Referrals",
} as const;
const list = z
  .array(z.string().trim().min(1).max(2000))
  .max(40)
  .refine((v) => new Set(v).size === v.length);
const lists = (fields: Record<string, string>) =>
  z.record(list).superRefine((v, ctx) => {
    for (const key of Object.keys(v))
      if (!(key in fields))
        ctx.addIssue({ code: "custom", message: "Unknown field", path: [key] });
  });
export const definitionSchema = z
  .object({
    name: z.string().trim().min(1).max(200),
    description: z.string().trim().min(1).max(10000),
    profileType: z.enum(["b2b", "b2c", "d2c"]),
    ...Object.fromEntries(
      Object.keys(profileFields).map((k) => [k, list.optional()]),
    ),
    accountProfile: lists(accountFields).optional(),
    consumerProfile: lists(consumerFields).optional(),
  })
  .strict()
  .superRefine((v, ctx) => {
    if (
      v.profileType === "b2b"
        ? v.consumerProfile !== undefined
        : v.accountProfile !== undefined
    )
      ctx.addIssue({
        code: "custom",
        message: "Profile type does not match its fields",
      });
  });
export type IcpDefinition = {
  name: string;
  description: string;
  profileType: "b2b" | "b2c" | "d2c";
  accountProfile?: Record<string, string[]>;
  consumerProfile?: Record<string, string[]>;
} & Partial<Record<keyof typeof profileFields, string[]>>;
const recordSchema = z.object({
  id: canonicalId("icp"),
  workspaceId: canonicalId("workspace"),
  offeringId: canonicalId("offering"),
  offer: z
    .object({ id: canonicalId("offer"), revision: z.number().int().positive() })
    .optional(),
  offerLinkStatus: z.enum(["unlinked", "current", "stale"]).optional(),
  updatedAt: z.string().datetime(),
  revision: z.number().int().positive(),
  approvedRevision: z.number().int().positive().optional(),
  status: z.enum(["draft", "approved", "retired"]),
  archived: z.boolean(),
  definition: definitionSchema,
});
export type IcpRecord = Omit<z.infer<typeof recordSchema>, "definition"> & {
  definition: IcpDefinition;
};
const productSchema = z.object({
  brandId: z.string().optional(),
  id: canonicalId("offering"),
  workspaceId: canonicalId("workspace"),
  status: z.enum(["draft", "approved", "retired"]),
  approvedRevision: z.number().optional(),
  definition: z.object({
    name: z.string(),
    businessModel: z.string().optional(),
  }),
});
export type IcpProduct = z.infer<typeof productSchema>;
export const icpOfferSchema = z.object({
  id: canonicalId("offer"),
  workspaceId: canonicalId("workspace"),
  offeringId: canonicalId("offering"),
  approvedRevision: z.number().int().positive().optional(),
  archived: z.boolean(),
  definition: z.object({ name: z.string() }),
});
export type IcpOffer = z.infer<typeof icpOfferSchema>;
export function createIcpGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request);
  const root = (w: string) =>
    `/api/v1/hvm/workspaces/${canonicalId("workspace").parse(w)}`;
  const scoped = <T extends { workspaceId: string }>(
    w: string,
    value: T,
  ): T => {
    if (value.workspaceId !== w) throw new DataError("invalid");
    return value;
  };
  return {
    ...createEligibilityGateway(base, session, request),
    research: createResearchGateway(base, session, request),
    strategies: createStrategyGateway(base, session, request),
    async importProgress(w: string, jobId: string, signal: AbortSignal) {
      return z
        .object({
          reconciled: z.boolean().optional(),
          batches: z.array(
            z.object({
              index: z.number(),
              importId: z.string(),
              verified: z.literal(true),
              counts: z.object({
                total: z.number(),
                created: z.number(),
                duplicate: z.number(),
                rejected: z.number(),
                updated: z.number(),
              }),
            }),
          ),
        })
        .parse(
          await http(root(w) + "/icp/imports/progress/" + jobId, signal, {
            rateLimitRetries: 2,
          }),
        );
    },
    async importObservations(
      w: string,
      query: {
        companyId?: string;
        personId?: string;
        notification?: string;
        offset: number;
      },
      signal: AbortSignal,
    ) {
      return z
        .object({
          items: z.array(
            z.object({
              id: z.string(),
              origin: z.object({
                sheet: z.string(),
                row: z.number(),
                scope: z.string(),
                notification: z.string().optional(),
                relatedName: z.string().optional(),
                relatedRegistration: z.string().optional(),
              }),
              fields: z.array(
                z.object({
                  label: z.string(),
                  raw: z.string(),
                  type: z.string(),
                  value: z.unknown(),
                  unit: z.string().nullable().optional(),
                }),
              ),
            }),
          ),
          hasMore: z.boolean(),
        })
        .parse(
          await http(root(w) + "/icp/imports/observations", signal, { query }),
        );
    },
    async previewImport(w: string, body: unknown, signal: AbortSignal) {
      return importPreviewSchema.parse(
        await http(root(w) + "/icp/imports/preview", signal, {
          rateLimitRetries: 2,
          method: "POST",
          body,
        }),
      );
    },
    async commitImport(w: string, body: unknown, signal: AbortSignal) {
      return importReceiptSchema.parse(
        await http(root(w) + "/icp/imports/commit", signal, {
          rateLimitRetries: 2,
          method: "POST",
          body,
          timeoutMs: 60000,
        }),
      );
    },
    async examples(
      w: string,
      type: "company" | "contact",
      q: string,
      signal: AbortSignal,
    ) {
      return z
        .array(exampleSchema)
        .parse(
          await http(root(w) + "/icp/examples", signal, { query: { type, q } }),
        );
    },
    async readSetup(w:string,offeringId:string,offerId:string,signal:AbortSignal) {
      return setupSchema.nullable().parse(await http(root(w)+"/icp/setup",signal,{query:{offeringId,offerId}}));
    },
    async saveSetup(w:string,input:IcpSetupInput,revision:number,signal:AbortSignal) {
      return setupSchema.parse(await http(root(w)+"/icp/setup",signal,{method:"POST",body:{input,revision}}));
    },
    async generate(w: string, body: unknown, signal: AbortSignal) {
      return generationSchema.parse(
        await http(root(w) + "/icp/generations", signal, {
          method: "POST",
          body,
        }),
      );
    },
    async saveGeneration(
      w: string,
      id: string,
      definition: IcpDefinition,
      signal: AbortSignal,
    ) {
      return scoped(
        w,
        recordSchema.parse(
          await http(
            root(w) +
              "/icp/generations/" +
              canonicalId("event").parse(id) +
              "/save",
            signal,
            { method: "POST", body: definition },
          ),
        ),
      ) as IcpRecord;
    },
    async latestGeneration(
      w: string,
      offeringId: string,
      signal: AbortSignal,
      offerId?: string,
    ) {
      return generationSchema.nullable().parse(
        await http(root(w) + "/icp/generations", signal, {
          query: { offeringId, ...(offerId ? { offerId } : {}) },
        }),
      );
    },
    async generation(w: string, id: string, signal: AbortSignal) {
      return generationSchema.parse(
        await http(
          root(w) + "/icp/generations/" + canonicalId("event").parse(id),
          signal,
        ),
      );
    },
    async offers(w: string, offeringId: string, signal: AbortSignal) {
      const result: IcpOffer[] = [];
      for (let offset = 0; offset <= 10000; offset += 100) {
        const data = z
          .object({ items: z.array(icpOfferSchema), hasMore: z.boolean() })
          .parse(
            await http(root(w) + "/offers", signal, {
              query: { offeringId, limit: 100, offset },
            }),
          );
        result.push(
          ...data.items
            .map((row) => scoped(w, row))
            .filter((row) => !row.archived && !!row.approvedRevision),
        );
        if (!data.hasMore) return result;
      }
      throw new DataError("invalid");
    },
    async products(w: string, signal: AbortSignal) {
      const result: IcpProduct[] = [];
      for (let offset = 0; offset <= 10000; offset += 100) {
        const data = z
          .object({ items: z.array(productSchema), hasMore: z.boolean() })
          .parse(
            await http(root(w) + "/offerings", signal, {
              query: { offset, limit: 100 },
            }),
          );
        result.push(...data.items.map((v) => scoped(w, v)));
        if (!data.hasMore) return result;
      }
      throw new DataError("invalid");
    },
    async list(
      w: string,
      offeringId: string,
      archived: boolean,
      signal: AbortSignal,
    ) {
      const result: IcpRecord[] = [];
      for (let offset = 0; offset <= 10000; offset += 100) {
        const data = z
          .object({ items: z.array(recordSchema), hasMore: z.boolean() })
          .parse(
            await http(root(w) + "/ideal-customer-profiles", signal, {
              query: {
                offeringId: canonicalId("offering").parse(offeringId),
                archived: String(archived),
                limit: 100,
                offset,
              },
            }),
          );
        result.push(...data.items.map((v) => scoped(w, v) as IcpRecord));
        if (!data.hasMore) return result;
      }
      throw new DataError("invalid");
    },
    async mutate(
      w: string,
      operation: "create" | "update" | "revise" | "approve" | "archive",
      body: unknown,
      signal: AbortSignal,
    ) {
      return scoped(
        w,
        recordSchema.parse(
          await http(
            root(w) + "/ideal-customer-profiles/" + operation,
            signal,
            { method: "POST", body },
          ),
        ),
      ) as IcpRecord;
    },
  };
}
export type IcpGateway = Omit<
  ReturnType<typeof createIcpGateway>,
  | "readSetup"
  | "saveSetup"
  | "discoveryLatest"
  | "discover"
  | "discovery"
  | "research"
  | "strategies"
  | "importProgress"
  | "importObservations"
  | "policies"
  | "savePolicy"
  | "updatePolicy"
  | "deletePolicyDrafts"
  | "approvePolicy"
  | "identify"
> &
  Partial<
    Pick<
      ReturnType<typeof createIcpGateway>,
      | "readSetup"
      | "saveSetup"
      | "discoveryLatest"
      | "discover"
      | "discovery"
      | "research"
      | "strategies"
      | "importProgress"
      | "importObservations"
      | "policies"
      | "savePolicy"
      | "updatePolicy"
      | "deletePolicyDrafts"
      | "approvePolicy"
      | "identify"
    >
  >;

const exampleSchema = z.object({
  id: z.string(),
  name: z.string(),
  type: z.enum(["company", "contact"]),
});
export type IcpExample = z.infer<typeof exampleSchema>;
const setupInputSchema = z.object({
  offeringId:z.string(),offer:z.object({id:z.string(),revision:z.number()}),profileType:z.enum(["b2b","b2c","d2c"]).nullable(),instructions:z.string(),customerUrls:z.array(z.string()).optional(),researchDocuments:z.array(z.object({id:z.string(),revision:z.number()}).passthrough()).optional(),examples:z.array(exampleSchema.extend({reason:z.string()})),
});
export type IcpSetupInput=z.infer<typeof setupInputSchema>;
const setupSchema=z.object({input:setupInputSchema,revision:z.number()});
const generationSchema = z.object({
  input: setupInputSchema.partial({offer:true}).extend({examples:z.array(z.object({id:z.string(),type:z.enum(["company","contact"]),reason:z.string(),name:z.string().optional()}))}).optional(),
  failure:z.object({stage:z.string(),code:z.string(),correlationId:z.string()}).optional(),
  savedId: canonicalId("icp").optional(),
  id: canonicalId("event"),
  status: z.enum(["generating", "review", "failed", "interrupted"]),
  definition: definitionSchema.optional(),
  rationale: z.string().optional(),
});
export type IcpGeneration = z.infer<typeof generationSchema>;
const importPreviewSchema = z.object({
  digest: z.string(),
  counts: z.object({
    total: z.number(),
    created: z.number(),
    duplicate: z.number(),
    rejected: z.number(),
  }),
  rows: z.array(
    z.object({
      row: z.number(),
      status: z.enum(["create", "existing", "review", "skip"]),
      issues: z.array(z.string()),
      unchanged: z.boolean().optional(),
      candidates: z
        .array(z.object({ id: z.string(), name: z.string() }))
        .optional(),
      companyId: z.string().optional(),
      personId: z.string().optional(),
      values: z.record(z.unknown()),
    }),
  ),
});
export type ImportPreview = z.infer<typeof importPreviewSchema>;
const importReceiptSchema = z.object({
  importId: canonicalId("import"),
  verified: z.literal(true),
  counts: z.object({
    total: z.number(),
    created: z.number(),
    updated: z.number(),
    duplicate: z.number(),
    rejected: z.number(),
  }),
  results: z.array(
    z.object({
      row: z.number(),
      status: z.string(),
      companyId: z.string().optional(),
      personId: z.string().optional(),
    }),
  ),
});
export type ImportReceipt = z.infer<typeof importReceiptSchema>;
