import { z } from "zod";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
export const outcomeDefinition = z.object({
  name: z.string(),
  description: z.string(),
  brandId: z.string(),
  campaignId: z.string().nullable(),
  sourceName: z.string(),
  expectedEvent: z.string(),
  mapping: z.object({
    eventId: z.string(),
    subjectId: z.string(),
    occurredAt: z.string(),
    eventType: z.string(),
    campaignId: z.string().optional(),
  }),
});
export const outcomeState = z.object({
  canManage: z.boolean(),
  brands: z.array(z.object({ id: z.string(), name: z.string() })),
  campaigns: z.array(
    z.object({ id: z.string(), name: z.string(), brandId: z.string() }),
  ),
  definitions: z.array(
    z.object({
      id: z.string(),
      version: z.number(),
      definition: outcomeDefinition,
      enabled: z.boolean(),
      archived: z.boolean(),
      testedAt: z.string().nullable(),
      connectionTestedAt: z.string().nullable().optional(),
      lastReceivedAt: z.string().nullable().optional(),
    }),
  ),
  evidence: z.array(
    z.object({
      id: z.string(),
      outcomeId: z.string(),
      outcomeName: z.string(),
      occurredAt: z.string(),
      receivedAt: z.string(),
      campaignId: z.string().nullable(),
      attribution: z.string(),
      testOnly: z.boolean(),
      retracted: z.boolean(),
      reviewNote: z.string(),
    }),
  ),
  campaignsTruncated: z.boolean(),
  definitionsTruncated: z.boolean(),
  evidenceTruncated: z.boolean(),
});
export type OutcomeDefinition = z.infer<typeof outcomeDefinition>;
export type OutcomeState = z.infer<typeof outcomeState>;
export const businessOutcomeReport = z.object({
  configured: z.number(),
  receiving: z.number(),
  confirmed: z.number(),
  attributed: z.number(),
  unattributed: z.number(),
  truncated: z.boolean(),
  byOutcome: z.array(
    z.object({ id: z.string(), name: z.string(), count: z.number() }),
  ),
});
export function createBusinessOutcomesGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const call = createTransport(base, session, request),
    path = (w: string) => `/api/v1/hvm/workspaces/${w}/outcomes`;
  return {
    endpoint: (w: string, id: string) =>
      `${base.replace(/\/$/, "")}/api/v1/public/outcomes/${encodeURIComponent(w)}/${encodeURIComponent(id)}`,
    read: async (w: string, signal: AbortSignal) =>
      outcomeState.parse(await call(path(w), signal)),
    change: async (w: string, body: unknown, signal: AbortSignal) =>
      z
        .object({ state: outcomeState, token: z.string().optional() })
        .parse(
          await call(path(w), signal, {
            method: "POST",
            body,
            rateLimitRetries: 0,
          }),
        ),
  };
}
export type BusinessOutcomesGateway = ReturnType<
  typeof createBusinessOutcomesGateway
>;
