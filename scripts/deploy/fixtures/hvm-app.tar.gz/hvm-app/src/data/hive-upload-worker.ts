import { parseWorkbook } from "./hive-upload-parser";
self.onmessage = async (event: MessageEvent<ArrayBuffer>) => {
  try {
    self.postMessage({ sheets: await parseWorkbook(event.data) });
  } catch (error) {
    self.postMessage({
      error: error instanceof Error ? error.message : "Could not read workbook",
    });
  }
};
