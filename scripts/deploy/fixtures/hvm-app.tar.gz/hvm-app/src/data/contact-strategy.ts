import { z } from "zod";
import { createTransport } from "./transport";
import { canonicalId } from "./operating/models";
import type { AuthSession } from "../auth/session";
const template = z.object({
  id: z.string(),
  version: z.number(),
  key: z.string(),
  category: z.string(),
  name: z.string(),
  description: z.string(),
  type: z.string(),
  objective: z.string().optional(),
  applicability: z.string().optional(),
  enforcement: z.string().optional(),
  configuration: z.array(z.string()),
});
const policy = z.object({
  id: z.string(),
  key: z.string(),
  version: z.number(),
  status: z.enum(["draft", "recorded", "withdrawn", "superseded"]),
  createdAt: z.string(),
  source: z.object({ reference: z.string() }),
  clauses: z.array(z.object({ key: z.string(), statement: z.string() })),
});
export type StrategyTemplate = z.infer<typeof template>;
export type StrategyPolicy = z.infer<typeof policy>;
export function createStrategyGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request),
    root = (w: string) =>
      `/api/v1/hvm/workspaces/${canonicalId("workspace").parse(w)}/contact-strategies`;
  return {
    async interpret(
      w: string,
      key: string,
      instruction: string,
      requestKey: string,
      signal: AbortSignal,
      name?: string,
    ) {
      return z
        .object({
          statement: z.string(),
          explanation: z.string(),
          conflicts: z.array(z.string()),
          questions: z.array(z.string()),
        })
        .parse(
          await http(root(w) + "/interpret", signal, {
            method: "POST",
            body: { key, instruction, requestKey, ...(name ? {name} : {}) },
            timeoutMs: 60000,
            rateLimitRetries: 0,
          }),
        );
    },
    async list(w: string, signal: AbortSignal) {
      return z
        .object({
          templates: z.array(template),
          policies: z.array(policy),
          reviews: z
            .array(
              z.object({
                key: z.string(),
                createdAt: z.string(),
                proposal: z.object({
                  statement: z.string(),
                  explanation: z.string(),
                  conflicts: z.array(z.string()),
                  questions: z.array(z.string()),
                }),
              }),
            )
            .optional(),
          interpretationAvailable: z.boolean().optional(),
        })
        .parse(await http(root(w), signal));
    },
    async change(
      w: string,
      key: string,
      expectedVersion: number,
      operation: "save" | "approve" | "deactivate" | "remove",
      statement: string | undefined,
      signal: AbortSignal,
      name?: string,
    ) {
      return policy.parse(
        await http(root(w), signal, {
          method: "POST",
          body: {
            key,
            ...(name ? {name} : {}),
            expectedVersion,
            operation,
            ...(statement === undefined ? {} : { statement }),
          },
        }),
      );
    },
  };
}
export type StrategyGateway = ReturnType<typeof createStrategyGateway>;
