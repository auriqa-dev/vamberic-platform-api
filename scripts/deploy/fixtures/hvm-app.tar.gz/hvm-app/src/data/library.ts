import { record } from "./content-strategy-model";
import { z } from "zod";
import type { AuthSession } from "../auth/session";
import { createTransport } from "./transport";
export const indexedPage = z.object({
  url: z.string(),
  canonical: z.string(),
  title: z.string(),
  description: z.string(),
  language: z.string(),
  region: z.string(),
  source: z.string(),
  modifiedAt: z.string(),
  discoveredAt: z.string(),
  status: z.string(),
  ingestion: z.string(),
  assetId: z.string().optional(),
  error: z.string().optional(),
  alternates: z.array(z.object({ language: z.string(), url: z.string() })),
});
export const discoveryJob = z.object({
  id: z.string(),
  version: z.number(),
  state: z.object({
    brandId: z.string(),
    root: z.string(),
    pages: z.array(indexedPage),
    status: z.string(),
    warnings: z.array(z.string()),
    updatedAt: z.string(),
  }),
  recommendation: z.object({
    mode: z.string(),
    eligiblePages: z.number(),
    partial: z.boolean(),
    languages: z.array(z.string()),
    reason: z.string(),
    volumeNote: z.string(),
  }),
});
export type DiscoveryJob = z.infer<typeof discoveryJob>;
export function createLibraryGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request),
    root = (w: string) =>
      `/api/v1/hvm/workspaces/${encodeURIComponent(w)}/content-strategy/library`;
  return {
    async discovery(w: string, id: string, signal: AbortSignal) {
      return discoveryJob.parse(
        await http(root(w) + `/discovery/${encodeURIComponent(id)}`, signal),
      );
    },
    async asset(w: string, id: string, signal: AbortSignal) {
      return record.parse(
        await http(root(w) + `/assets/${encodeURIComponent(id)}`, signal),
      );
    },
    async search(w: string, q: string, signal: AbortSignal) {
      return z
        .object({
          matches: z.array(
            z.object({ id: z.string(), contentTextId: z.string() }),
          ),
          more: z.boolean(),
        })
        .parse(
          await http(root(w) + "/search", signal, { query: { q } }),
        );
    },
    async manageOffers(
      w: string,
      body: { offerIds: string[]; expectedVersion: number; requestKey: string },
      signal: AbortSignal,
    ) {
      return await http(root(w) + "/planning", signal, {
        method: "POST",
        body,
      });
    },
    async planning(w: string, signal: AbortSignal) {
      return await http(root(w) + "/planning", signal);
    },
    async list(w: string, signal: AbortSignal) {
      return z
        .array(discoveryJob)
        .parse(await http(root(w) + "/discovery", signal));
    },
    async start(
      w: string,
      body: {
        brandId: string;
        url: string;
        smallSiteThreshold: number;
        mode?: "website" | "page";
        requestKey: string;
      },
      signal: AbortSignal,
    ) {
      return z
        .object({ id: z.string() })
        .parse(
          await http(root(w) + "/discovery", signal, { method: "POST", body }),
        );
    },
    async step(w: string, id: string, signal: AbortSignal) {
      return discoveryJob.parse(
        await http(
          root(w) + `/discovery/${encodeURIComponent(id)}/continue`,
          signal,
          { method: "POST", body: {}, timeoutMs: 60000 },
        ),
      );
    },
    async importPage(
      w: string,
      id: string,
      url: string,
      requestKey: string,
      signal: AbortSignal,
      selectionReason = "Selected by the user from the reviewed discovery scope",
    ) {
      return await http(root(w) + "/import", signal, {
        method: "POST",
        body: { id, url, requestKey, selectionReason },
        timeoutMs: 60000,
      });
    },
  };
}
