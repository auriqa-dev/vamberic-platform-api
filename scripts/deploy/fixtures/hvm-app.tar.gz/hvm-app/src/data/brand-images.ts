import { z } from "zod";
import { createTransport } from "./transport";
import { DataError } from "./gateway";
const id = (prefix: string) => z.string().regex(new RegExp(`^${prefix}_[0-7][0-9abcdefghjkmnpqrstvwxyz]{25}$`));
const kit = z.object({ id: id("brandkit"), workspaceId: id("workspace"), brandId: id("brand"), status: z.enum(["draft", "approved", "retired"]), updatedAt: z.string().datetime(), assets: z.array(z.object({ name: z.string(), type: z.string(), altText: z.string().optional(), status: z.string(), object: z.object({ key: z.string() }) })) });
export const imageTypes = [["logo", "Logo"], ["photography", "Photography"], ["product_imagery", "Product image"], ["icon_set", "Icons"], ["illustration", "Illustration"], ["graphic", "Graphic"], ["background", "Background"], ["email_header", "Email header"], ["email_footer", "Email footer"]] as const;
export type ImageType = (typeof imageTypes)[number][0];
export type ImageKit = { id: string; status: "draft" | "approved" | "retired"; updatedAt: string; assets: { name: string; type: string; altText?: string; imageId?: string }[] };
export interface BrandImagesGateway {
  list(w: string, b: string, signal: AbortSignal): Promise<ImageKit[]>;
  upload(w: string, b: string, k: ImageKit | undefined, input: { name: string; type: ImageType; altText: string; file: File }, signal: AbortSignal): Promise<void>;
  bulk(w: string,b: string,k: ImageKit,imageIds: string[],type: ImageType | undefined,signal: AbortSignal): Promise<void>;
  update(w: string, b: string, k: ImageKit, imageId: string, input: { name: string; type: ImageType; altText: string; file?: File }, signal: AbortSignal): Promise<void>;
  remove(w: string, b: string, k: ImageKit, imageId: string, signal: AbortSignal): Promise<void>;
  image(w: string, b: string, k: string, imageId: string, signal: AbortSignal): Promise<string>;
}
export function createBrandImagesGateway(read: ReturnType<typeof createTransport>): BrandImagesGateway {
  const root = (w: string, b: string) => `/api/v1/hvm/workspaces/${id("workspace").parse(w)}/brands/${id("brand").parse(b)}`;
  return {
    async list(w, b, signal) {
      const result = z.object({ kits: z.array(kit) }).parse(await read(root(w,b)+"/kits", signal));
      if (result.kits.some(k => k.workspaceId !== w || k.brandId !== b)) throw new DataError("invalid");
      return result.kits.filter(k => k.status === "approved").map(k => ({ id: k.id, status: k.status, updatedAt: k.updatedAt, assets: k.assets.filter(a => a.status === "approved").map(a => ({ name: a.name, type: a.type, altText: a.altText,
        imageId: new RegExp(`^brand-images/${w}/${b}/(?:brandkit_[0-7][0-9abcdefghjkmnpqrstvwxyz]{25}|images)/([a-f0-9]{64})\\.png$`).exec(a.object.key)?.[1] })) }));
    },
    async upload(w,b,k,input,signal) {
      const base64 = await imageBase64(input.file);
      await read(root(w,b)+"/images", signal, { method: "POST", timeoutMs: 60000, body: { expectedKitId: k?.id ?? null, expectedUpdatedAt: k?.updatedAt, name: input.name, type: input.type, altText: input.altText, contentType: input.file.type, base64 } });
    },
    async bulk(w,b,k,imageIds,type,signal) {
      z.array(z.string().regex(/^[a-f0-9]{64}$/)).min(1).max(100).parse(imageIds);
      await read(root(w,b)+"/images",signal,{method:"POST",body:{operation:type ? "bulk-update" : "bulk-delete",expectedKitId:k.id,expectedUpdatedAt:k.updatedAt,imageIds,...(type ? {type} : {})}});
    },
    async update(w,b,k,imageId,input,signal) {
      z.string().regex(/^[a-f0-9]{64}$/).parse(imageId);
      const file = input.file ? { contentType: input.file.type, base64: await imageBase64(input.file) } : {};
      await read(root(w,b)+"/images", signal, { method: "POST", timeoutMs: 60000, body: {
        operation: "update", expectedKitId: k.id, expectedUpdatedAt: k.updatedAt, imageId,
        name: input.name, type: input.type, altText: input.altText, ...file,
      } });
    },
    async remove(w,b,k,imageId,signal) {
      z.string().regex(/^[a-f0-9]{64}$/).parse(imageId);
      await read(root(w,b)+"/images", signal, { method: "POST", body: {
        operation: "delete", expectedKitId: k.id, expectedUpdatedAt: k.updatedAt, imageId,
      } });
    },
    async image(w,b,k,imageId,signal) {
      z.string().regex(/^[a-f0-9]{64}$/).parse(imageId);
      const result = z.object({ contentType: z.literal("image/png"), base64: z.string().max(6990508).regex(/^[A-Za-z0-9+/]+=*$/) }).parse(await read(root(w,b)+`/kits/${id("brandkit").parse(k)}/images/${imageId}`,signal));
      return `data:image/png;base64,${result.base64}`;
    },
  };
}

async function imageBase64(file: File): Promise<string> {
      if (!file.size || file.size > 5*1024*1024 || !["image/png","image/jpeg","image/webp"].includes(file.type)) throw new DataError("invalid");
      const base64 = await new Promise<string>((resolve,reject) => { const reader = new FileReader(); reader.onerror = reject; reader.onload = () => resolve(String(reader.result).split(",")[1]!); reader.readAsDataURL(file); });
  return base64;
}
