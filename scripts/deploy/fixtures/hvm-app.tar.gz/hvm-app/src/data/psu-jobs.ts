import type { PsuJob } from "./psu";

/** Keep saved history on the server; the editor shows only the newest attempt per target. */
export function latestPsuJobs(jobs: PsuJob[]): PsuJob[] {
  const latest = new Map<string, PsuJob>();
  for (const job of [...jobs].sort((a, b) => b.createdAt.localeCompare(a.createdAt))) {
    const key = JSON.stringify([
      job.input.brandId,
      job.input.kind === "company" ? "company" : "product",
      job.input.kind === "company" ? "" : job.input.offeringId ?? job.input.websiteUrls?.[0] ?? job.id,
      job.input.kind === "company" ? "summary" : job.input.depth ?? "detailed",
    ]);
    if (!latest.has(key)) latest.set(key, job);
  }
  return [...latest.values()];
}
