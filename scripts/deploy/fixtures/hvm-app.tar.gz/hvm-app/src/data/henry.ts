import { z } from "zod";
import type { AuthSession } from "../auth/session";
import { createTransport } from "./transport";
import {
  workspaceHenryRequest,
  workspaceHenryReply,
  workspaceHenryTurn,
} from "./henry-model";
export function createHenryGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request),
    root = (w: string) =>
      `/api/v1/hvm/workspaces/${encodeURIComponent(w)}/henry`;
  return {
    async list(w: string, brandId: string, signal: AbortSignal) {
      return z
        .object({
          brands: z.array(z.object({ id: z.string(), name: z.string() })),
          available: z.boolean(),
          turns: z.array(workspaceHenryTurn),
        })
        .parse(
          await http(
            root(w),
            signal,
            { query: { brandId } },
          ),
        );
    },
    async ask(
      w: string,
      input: z.infer<typeof workspaceHenryRequest>,
      signal: AbortSignal,
    ) {
      return workspaceHenryReply.parse(
        await http(root(w), signal, {
          method: "POST",
          body: workspaceHenryRequest.parse(input),
          timeoutMs: 60000,
          rateLimitRetries: 0,
        }),
      );
    },
  };
}
export type HenryGateway = ReturnType<typeof createHenryGateway>;
