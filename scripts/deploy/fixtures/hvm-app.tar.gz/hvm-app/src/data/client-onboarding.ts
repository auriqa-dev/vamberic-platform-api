import { z } from "zod";
import type { createTransport } from "./transport";
const id = (prefix: string) =>
  z.string().regex(new RegExp(`^${prefix}_[0-9a-hjkmnp-tv-z]{26}$`));
const label = z.string().trim().min(1).max(200);
export const onboardingDetails = z
  .object({
    intake: z
      .object({
        organisationName: label,
        websiteUrl: z.string().url().max(2048),
        currentMarketingPlatform: label.optional(),
        currentContactCount: z.number().int().nonnegative().safe().optional(),
        contactCountDescription: z.string().trim().min(1).max(1000).optional(),
        growthExpectation: z.string().trim().min(1).max(1000).optional(),
        otherTools: z.array(label).max(40),
      })
      .strict(),
    workspaceName: label,
    brandName: label,
    brandSlug: z.string().regex(/^[a-z0-9][a-z0-9-]{0,99}$/),
  })
  .strict();
const human = z
  .object({ type: z.literal("human"), id: z.string(), issuer: z.string() })
  .strict();
const revision = z.number().int().positive().safe(),
  hash = z.string().regex(/^[a-f0-9]{64}$/);
const binding = z
  .object({
    onboardingId: id("clientonboarding"),
    partnerId: id("partner"),
    intakeRevision: revision,
    intakeDigest: hash,
    quoteRevision: revision,
    quoteDigest: hash,
  })
  .strict();
export const onboardingRecord = z
  .object({
    id: id("clientonboarding"),
    partnerId: id("partner"),
    createScope: hash,
    createDigest: hash,
    revision,
    executionSerial: z.number().int().nonnegative().safe(),
    details: onboardingDetails,
    proposal: z
      .object({
        version: z.literal(1),
        treatment: z.literal("internal"),
        scope: z.literal("hvm_platform_and_agent_services"),
        customerChargeMinor: z.literal(0),
        basis: z.literal("empress_exemption_required"),
        externalServicesIncluded: z.literal(false),
      })
      .strict(),
    binding,
    approval: z
      .object({
        version: z.literal(1),
        revision,
        status: z.enum(["active", "revoked"]),
        binding,
        treatment: z.literal("internal"),
        scope: z.literal("hvm_platform_and_agent_services"),
        reason: z.string(),
        approvedBy: human,
        approvedAt: z.string().datetime(),
        validUntil: z.string().datetime().optional(),
      })
      .strict()
      .optional(),
    result: z
      .object({
        organisationId: id("org"),
        workspaceId: id("workspace"),
        brandId: id("brand"),
        partnerId: id("partner"),
      })
      .strict()
      .optional(),
    createdBy: human,
    createdAt: z.string().datetime(),
    updatedAt: z.string().datetime(),
  })
  .strict();
export type OnboardingRecord = z.infer<typeof onboardingRecord>;
export type OnboardingDetails = z.infer<typeof onboardingDetails>;
export type OnboardingMutation = {
  requestKey: string;
  expectedRevision: number;
  action: "save" | "approve" | "revoke" | "provision";
  details?: OnboardingDetails;
  reason?: string;
};
export function onboardingGateway(http: ReturnType<typeof createTransport>) {
  const root = (partner?: string) =>
    partner
      ? `/api/v1/hvm/partners/${id("partner").parse(partner)}/client-onboarding`
      : "/api/v1/hvm/empress/client-onboarding";
  return {
    async list(
      partner: string | undefined,
      signal: AbortSignal,
      after?: string,
    ) {
      return z
        .object({
          items: z.array(onboardingRecord).max(50),
          next: id("clientonboarding").nullable(),
        })
        .strict()
        .parse(await http(root(partner), signal, { query: { after } }));
    },
    async mutate(
      partner: string | undefined,
      recordId: string | undefined,
      body: OnboardingMutation,
      signal: AbortSignal,
    ) {
      return onboardingRecord.parse(
        await http(
          root(partner) +
            (recordId ? `/${id("clientonboarding").parse(recordId)}` : ""),
          signal,
          { method: "POST", body },
        ),
      );
    },
  };
}
