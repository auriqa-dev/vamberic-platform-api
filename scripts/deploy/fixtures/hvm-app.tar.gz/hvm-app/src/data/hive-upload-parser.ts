import type { UploadSheet } from "./hive-upload";
export function sheet(name: string, rows: string[][], rowNumbers?: number[]): UploadSheet {
  const indices = rows.flatMap((r, i) => r.some((c) => c.trim()) ? [i] : []);
  const nonempty = indices.map(i => rows[i]!);
  const headers = nonempty.shift()?.map((v) => v.trim()) ?? [];
  if (
    !headers.length ||
    headers.length > 500 ||
    headers.some((h) => !h || h.length > 500) ||
    new Set(headers).size !== headers.length
  )
    throw new Error(
      "Use up to 500 unique column headings, with no blank headings.",
    );
  if (nonempty.length > 250000)
    throw new Error("Choose a file with up to 250,000 rows for this import.");
  if (
    nonempty.some(
      (r) => r.length > headers.length || r.some((c) => c.length > 12000),
    )
  )
    throw new Error(
      "A row has too many columns or a cell is longer than 12,000 characters.",
    );
  return {
    name,
    headers,
    sourceRows: indices.slice(1).map(i => rowNumbers?.[i] ?? i + 1),
    rows: nonempty.map((r) => headers.map((_, i) => r[i] ?? "")),
  };
}
export async function parseWorkbook(
  buffer: ArrayBuffer,
): Promise<UploadSheet[]> {
  // ZIP central directory preflight prevents oversized expansion before XML expansion.
  const bytes = new Uint8Array(buffer);
  const zip = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let expanded = 0,
    entries = 0;
  for (let i = 0; i + 46 <= zip.byteLength; i++) {
    if (zip.getUint32(i, true) !== 0x02014b50) continue;
    expanded += zip.getUint32(i + 24, true);
    entries++;
    if (expanded > 512 * 1024 * 1024 || entries > 10000)
      throw new Error(
        "This workbook expands beyond the supported size. Export the relevant sheets as CSV.",
      );
    i +=
      45 +
      zip.getUint16(i + 28, true) +
      zip.getUint16(i + 30, true) +
      zip.getUint16(i + 32, true);
  }
  if (!entries) throw new Error("This is not a supported XLSX workbook.");
  const [{ default: JSZip }, { SaxesParser }] = await Promise.all([
    import("jszip"),
    import("saxes"),
  ]);
  const archive = await JSZip.loadAsync(bytes);
  const xml = async (path: string) => {
    const file = archive.file(path);
    if (!file) throw new Error(`Workbook is missing ${path}.`);
    const text = await file.async("string");
    if (text.length > 256 * 1024 * 1024 || /<!DOCTYPE|<!ENTITY/i.test(text))
      throw new Error("Unsupported workbook XML.");
    return text;
  };
  const strings: string[] = [];
  if (archive.file("xl/sharedStrings.xml")) {
    const parser = new SaxesParser();
    let current = "",
      inText = false;
    parser.on("opentag", (tag) => {
      if (tag.name === "si") current = "";
      if (tag.name === "t") inText = true;
    });
    parser.on("text", (text) => {
      if (inText) current += text;
    });
    parser.on("closetag", (tag) => {
      if (tag.name === "t") inText = false;
      if (tag.name === "si") {
        if (current.length > 12000)
          throw new Error("A cell exceeds 12,000 characters.");
        strings.push(current);
      }
    });
    parser.write(await xml("xl/sharedStrings.xml")).close();
  }
  const links = new Map<string, string>();
  const rels = new SaxesParser();
  rels.on("opentag", (tag) => {
    if (tag.name === "Relationship" && tag.attributes.TargetMode !== "External")
      links.set(String(tag.attributes.Id), String(tag.attributes.Target));
  });
  rels.write(await xml("xl/_rels/workbook.xml.rels")).close();
  const sheets: { name: string; id: string }[] = [];
  let date1904 = false;
  const wb = new SaxesParser();
  wb.on("opentag", (tag) => {
    if (tag.name === "sheet")
      sheets.push({
        name: String(tag.attributes.name),
        id: String(tag.attributes["r:id"]),
      });
    if (tag.name === "workbookPr")
      date1904 = ["1", "true"].includes(String(tag.attributes.date1904));
  });
  wb.write(await xml("xl/workbook.xml")).close();
  if (sheets.length > 50) throw new Error("Choose up to 50 worksheets.");
  const formats = new Map<number, string>(),
    styles: number[] = [];
  if (archive.file("xl/styles.xml")) {
    const sp = new SaxesParser();
    let inXfs = false;
    sp.on("opentag", (t) => {
      if (t.name === "numFmt")
        formats.set(
          Number(t.attributes.numFmtId),
          String(t.attributes.formatCode),
        );
      if (t.name === "cellXfs") inXfs = true;
      if (t.name === "xf" && inXfs) styles.push(Number(t.attributes.numFmtId));
    });
    sp.on("closetag", (t) => {
      if (t.name === "cellXfs") inXfs = false;
    });
    sp.write(await xml("xl/styles.xml")).close();
  }
  const output: UploadSheet[] = [];
  let total = 0;
  for (const entry of sheets) {
    const target = links.get(entry.id);
    if (!target) throw new Error("Missing worksheet relationship.");
    const path = target.startsWith("/") ? target.slice(1) : `xl/${target}`;
    if (path.includes("..")) throw new Error("Unsupported worksheet path.");
    const rows: string[][] = [];
    const rowNumbers: number[] = [];
    let sourceRow = 0;
    let row: string[] = [],
      column = 0,
      kind = "",
      style = 0,
      value = "",
      inline = "",
      capture = "",
      hasCell = false;
    const parser = new SaxesParser();
    parser.on("opentag", (tag) => {
      if (tag.name === "row") {
        sourceRow = Number(tag.attributes.r ?? sourceRow + 1);
        row = [];
      }
      if (tag.name === "c") {
        const ref = String(tag.attributes.r ?? "").match(/^[A-Z]+/);
        if (!ref) throw new Error("Missing cell reference.");
        column =
          [...ref[0]].reduce((n, c) => n * 26 + c.charCodeAt(0) - 64, 0) - 1;
        kind = String(tag.attributes.t ?? "");
        style = Number(tag.attributes.s ?? 0);
        value = "";
        inline = "";
        hasCell = true;
      }
      if (tag.name === "f")
        throw new Error(
          "Replace spreadsheet formulas with their values before importing.",
        );
      if (hasCell && (tag.name === "v" || tag.name === "t")) capture = tag.name;
    });
    parser.on("text", (text) => {
      if (capture === "v") value += text;
      if (capture === "t") inline += text;
    });
    parser.on("closetag", (tag) => {
      if (tag.name === "v" || tag.name === "t") capture = "";
      if (tag.name === "c") {
        let result =
          kind === "s"
            ? (strings[Number(value)] ?? "")
            : kind === "inlineStr"
              ? inline
              : kind === "b"
                ? value === "1"
                  ? "Yes"
                  : "No"
                : value;
        const fmt = styles[style] ?? 0,
          pattern = formats.get(fmt) ?? "";
        if (kind !== "s" && kind !== "inlineStr" && kind !== "b" && value) {
          if (/^0+$/.test(pattern))
            result = value.padStart(pattern.length, "0");
          else if (
            (fmt >= 14 && fmt <= 22) ||
            /[yd]/i.test(pattern.replace(/"[^"]*"|\[[^\]]*\]/g, ""))
          ) {
            const n = Number(value);
            if (Number.isFinite(n))
              result = new Date(
                Date.UTC(
                  date1904 ? 1904 : 1899,
                  date1904 ? 0 : 11,
                  date1904 ? 1 : 30,
                ) +
                  n * 86400000,
              )
                .toISOString()
                .slice(0, 10);
          }
        }
        if (result) {
          if (column >= 200)
            throw new Error("Use up to 200 populated columns per worksheet.");
          if (result.length > 12000)
            throw new Error("A cell exceeds 12,000 characters.");
          row[column] = result;
        }
        hasCell = false;
      }
      if (tag.name === "row" && row.some((v) => v?.trim())) {
        rowNumbers.push(sourceRow);
        rows.push(Array.from({ length: row.length }, (_, i) => row[i] ?? ""));
        total++;
        if (total > 500000)
          throw new Error(
            "This workbook contains more than 500,000 populated rows.",
          );
      }
    });
    parser.write(await xml(path)).close();
    if (rows.length) output.push(sheet(entry.name, rows, rowNumbers));
  }
  return output;
}
