import { z } from "zod";
import { createTransport } from "./transport";
import type { AuthSession } from "../auth/session";
export const ga4State = z.object({ available: z.boolean(), canManage: z.boolean(), status: z.string(), updatedAt: z.string().nullable(), property: z.object({ name: z.string(), displayName: z.string(), timeZone: z.string().nullable(), currencyCode: z.string().nullable() }).nullable(), lastCheckedAt: z.string().nullable(), hasReportRows: z.boolean().nullable() });
export const ga4Properties = z.object({ properties: z.array(z.object({ property: z.string(), displayName: z.string(), accountName: z.string() })), nextPageToken: z.string().nullable() });
export type Ga4State = z.infer<typeof ga4State>;
export type Ga4Properties = z.infer<typeof ga4Properties>;
export function createGa4Gateway(base: string, session: Pick<AuthSession, "getAccessToken" | "invalidate">, request: typeof fetch = fetch) {
  const call = createTransport(base, session, request), path = (w: string) => `/api/v1/hvm/workspaces/${w}/ga4`;
  const post = (w: string, action: string, body: unknown, signal: AbortSignal) => call(`${path(w)}/${action}`, signal, { method: "POST", body, timeoutMs: 60000, rateLimitRetries: 0 });
  return {
    read: async (w: string, signal: AbortSignal) => ga4State.parse(await call(path(w), signal)),
    connect: async (w: string, expectedUpdatedAt: string | null, signal: AbortSignal) => z.object({ url: z.string().url(), state: z.string(), browserSecret: z.string() }).parse(await post(w, "connect", { expectedUpdatedAt }, signal)),
    discover: async (w: string, action: "finish" | "properties", body: unknown, signal: AbortSignal) => ga4Properties.parse(await post(w, action, body, signal)),
    change: async (w: string, action: "select" | "test" | "disconnect", body: unknown, signal: AbortSignal) => ga4State.parse(await post(w, action, body, signal)),
  };
}
export type Ga4Gateway = ReturnType<typeof createGa4Gateway>;
