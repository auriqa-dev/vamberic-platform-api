import { z } from "zod";
import type { AuthSession } from "../auth/session";
import { createTransport } from "./transport";
import { canonicalId } from "./operating/models";
export const consumerFacts = z.object({
  country: z.string(),
  region: z.string(),
  needs: z.array(z.string()),
  interests: z.array(z.string()),
  purchaseStage: z.enum([
    "",
    "exploring",
    "comparing",
    "ready_to_buy",
    "existing_customer",
  ]),
  source: z.string(),
  observedOn: z.string(),
});
export type ConsumerFacts = z.infer<typeof consumerFacts>;
const record = z
  .object({ updatedAt: z.string(), facts: consumerFacts.nullable() })
  .nullable();
export type ConsumerFactsRecord = z.infer<typeof record>;
export function createConsumerFactsGateway(
  base: string,
  session: Pick<AuthSession, "getAccessToken" | "invalidate">,
  request: typeof fetch = fetch,
) {
  const http = createTransport(base, session, request);
  const root = (w: string, id: string) =>
    `/api/v1/hvm/workspaces/${canonicalId("workspace").parse(w)}/records/contacts/${canonicalId("person").parse(id)}/consumer-facts`;
  return {
    async read(w: string, id: string, signal: AbortSignal) {
      return record.parse(await http(root(w, id), signal));
    },
    async save(
      w: string,
      id: string,
      expectedUpdatedAt: string | null,
      facts: ConsumerFacts | null,
      signal: AbortSignal,
    ) {
      return record.parse(
        await http(root(w, id), signal, {
          method: "POST",
          body: { expectedUpdatedAt, facts },
        }),
      );
    },
  };
}
export type ConsumerFactsGateway = ReturnType<
  typeof createConsumerFactsGateway
>;
