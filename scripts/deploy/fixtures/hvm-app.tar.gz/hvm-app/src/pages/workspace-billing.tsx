import { useHenryBinding } from "../components/workspace-henry";
import { useEffect, useState, useRef } from "react";
import { useOperating } from "../data/operating/context";
import { Failure } from "../components/ui";
export function WorkspaceBilling({
  workspaceId,
  governance = false,
}: {
  workspaceId?: string;
  governance?: boolean;
}) {
  const keys = useRef(new Map<string, string>());
  const api = useOperating();
  const [draft, setDraft] = useState(workspaceId ?? "");
  const [selected, setSelected] = useState(workspaceId ?? "");
  const [revision, setRevision] = useState(0),
    [reason, setReason] = useState("");
  const [record, setRecord] = useState<{
    revision: number;
    effective: { treatment: string };
  }>();
  const [error, setError] = useState<unknown>();
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!api || !selected) return;
    const c = new AbortController();
    setRecord(undefined);
    setError(undefined);
    api
      .workspaceBilling(selected, governance, c.signal)
      .then((v) => {
        if (!c.signal.aborted) setRecord(v);
      })
      .catch((e) => {
        if (!c.signal.aborted) setError(e);
      });
    return () => c.abort();
  }, [api, selected, governance, revision]);
  useHenryBinding({key:"billing",summary:JSON.stringify({billingTreatment:record?.effective.treatment??"not loaded",instruction:"Explain the displayed billing treatment only. Client administrators cannot grant themselves discounts or exemptions. Do not change charges or claim provider costs are exempt."})});
  if (!api) return null;
  return (
    <section className="panel">
      {governance && <h1>Workspace exemptions</h1>}
      {governance && (
        <form className="details-form"
          onSubmit={(e) => {
            e.preventDefault();
            setSelected(draft);
            setRevision((x) => x + 1);
          }}
        >
          <label>
            Client workspace ID
            <input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              required
            />
          </label>
          <button disabled={busy}>Read billing status</button>
        </form>
      )}
      {record && (
        <>
          <p>
            {record.effective.treatment === "internal"
              ? "Your workspace is exempt from HVM platform and agent service charges."
              : "Existing commercial terms apply."}
          </p>
          <p>
            Third-party services may still incur charges. Provider usage is recorded
            and execution budgets still apply.
          </p>
        </>
      )}
      {governance && record && (
        <form className="details-form"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            setError(undefined);
            try {
              const body = {
                action:
                  record.effective.treatment === "internal"
                    ? ("revoke" as const)
                    : ("approve" as const),
                expectedRevision: record.revision,
                reason,
              };
              const pin = JSON.stringify({ selected, ...body });
              if (!keys.current.has(pin))
                keys.current.set(pin, crypto.randomUUID());
              await api.setWorkspaceBilling(
                selected,
                { ...body, requestKey: keys.current.get(pin)! },
                new AbortController().signal,
              );
              setReason("");
              setRevision((x) => x + 1);
            } catch (e) {
              setError(e);
            } finally {
              setBusy(false);
            }
          }}
        >
          <label>
            Reason
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
              maxLength={1000}
            />
          </label>
          <button disabled={busy || !reason.trim()}>
            {record.effective.treatment === "internal"
              ? "Revoke exemption"
              : "Approve internal exemption"}
          </button>
        </form>
      )}
      {error ? <Failure error={error} /> : null}
    </section>
  );
}
