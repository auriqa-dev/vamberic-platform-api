import {ResearchEvidencePanel} from "../components/research-evidence";
import type {ResearchGateway} from "../data/research";
import {UnlinkedEmailHistory} from "../components/unlinked-email-history";
import {ContactHistory} from "../components/contact-context";
import { useHenryBinding, henryFields, applyHenryFields } from "../components/workspace-henry";
import { ConsumerCharacteristics } from "../components/consumer-facts";
import { HiveImport } from "../components/hive-import";
import type { IcpGateway } from "../data/icp";
import { useEffect, useState, useRef } from "react";
import { useSearchParams } from "react-router-dom";
import type {
  ContactManagementGateway,
  ManagedRecord,
  RecordKind,
  RecordPage,
} from "../data/contact-management";
import { DataError } from "../data/gateway";
function TrashIcon() {
  return (
    <svg
      aria-hidden="true"
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7" />
    </svg>
  );
}
const contactColumns = [
  "Email",
  "Last engagement date",
  "Lifecycle stage",
  "Job title",
  "Company (primary)",
];
const organisationColumns = [
  "Lifecycle stage",
  "Phone number",
  "Last activity date",
  "City",
  "Country/Region",
  "Industry",
];
function countryName(code?: string) {
  if (!code) return "";
  try {
    return (
      new Intl.DisplayNames(["en"], { type: "region" }).of(
        code.toUpperCase(),
      ) ?? code
    );
  } catch {
    return code;
  }
}
const contactLabels = {
  firstName: "First name",
  lastName: "Last name",
  title: "Job title",
  email: "Email",
  phone: "Phone",
  organisationId: "Organisation",
};
const organisationLabels = {
  name: "Organisation name",
  website: "Website",
  industry: "Industry",
  country: "Country code",
  region: "Region",
  type: "Relationship",
  description: "Description",
};
function message(e: unknown) {
  return e instanceof DataError
    ? e.code === "conflict"
      ? "This record may have changed or duplicate an existing record. Check for an existing name, website, email or phone, then reopen the record before retrying."
      : e.code === "denied"
        ? "You do not have access to this record. Check your workspace and sign-in."
        : e.code === "invalid"
          ? "Check the fields and try again."
          : "We couldn’t complete that request. Your changes have not been confirmed. Please try again."
    : "We couldn’t complete that request. Please try again.";
}
const engaged = (v: string | null) =>
  v
    ? new Intl.DateTimeFormat("en-GB", {
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date(v))
    : "No engagement recorded";
export function ContactManagementPage({
  api,
  workspaceId,
  importApi,
  research,
}: {
  api?: ContactManagementGateway;
  importApi?: IcpGateway;
  research?:ResearchGateway;
  workspaceId: string;
}) {
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkConfirm, setBulkConfirm] = useState(false);
  const bulkLock = useRef(false);
  const [showImport, setShowImport] = useState(false);
  const [params, setParams] = useSearchParams(),
    kind: RecordKind =
      params.get("view") === "organisations" ? "organisations" : "contacts",
    id = params.get("record") ?? "",
    edit = params.get("edit") === "true",
    deleted = params.get("deleted") === "true",
    search = params.get("q") ?? "",
    offset = Math.max(0, Number(params.get("offset")) || 0);
  const [term, setTerm] = useState(search),
    [page, setPage] = useState<RecordPage>(),
    [row, setRow] = useState<ManagedRecord>(),
    [fields, setFields] = useState<Record<string, string>>({}),
    [error, setError] = useState(""),
    [errors, setErrors] = useState<Record<string, string>>({}),
    [notice, setNotice] = useState(""),
    [loading, setLoading] = useState(true),
    [busy, setBusy] = useState(false),
    [editing, setEditing] = useState(false),
    [confirm, setConfirm] = useState<ManagedRecord>(),
    [refresh, setRefresh] = useState(0),
    [orgSearch, setOrgSearch] = useState(""),
    [orgs, setOrgs] = useState<ManagedRecord[]>([]),
    [orgError, setOrgError] = useState("");
  const focus = useRef<HTMLHeadingElement>(null),
    mutation = useRef<AbortController | null>(null);
  useEffect(() => () => mutation.current?.abort(), []);
  useHenryBinding({key:"contacts",summary:JSON.stringify({view:kind,search,openRecord:row?{id:row.id,name:row.name}:null,records:(page?.items??[]).map(r=>({id:r.id,name:r.name}))}),
    editor:page?.canWrite&&editing&&!busy&&!loading?{key:`crm:${kind}:${id}:${row?.updatedAt??"new"}`,title:`${kind==="contacts"?"Contact":"Organisation"} details`,fields:henryFields(Object.fromEntries(Object.entries(fields).filter(([key])=>!['organisationId','type'].includes(key))))}:undefined,
    apply:changes=>{setFields(applyHenryFields(fields,changes));setErrors({});},
    actions:busy||!page?.canWrite?[]:[{id:"crm:contacts",label:"View contacts",run:()=>navigate({view:"contacts",record:undefined,edit:undefined})},{id:"crm:organisations",label:"View organisations",run:()=>navigate({view:"organisations",record:undefined,edit:undefined})},{id:"crm:new",label:"Add a record",run:()=>navigate({record:"new",edit:"true"})},{id:"crm:upload",label:"Upload records and email history",run:()=>setShowImport(true)},...(page?.items??[]).map(r=>({id:`crm:${r.id}`,label:`Review ${r.name}`,run:()=>navigate({record:r.id,edit:"true"})}))],
  });
  const noun = kind === "contacts" ? "contact" : "organisation";
  function navigate(values: Record<string, string | undefined>) {
    if (bulkLock.current) return;
    setError("");
    const next = new URLSearchParams(params);
    for (const [k, v] of Object.entries(values)) {
      if (v) next.set(k, v);
      else next.delete(k);
    }
    setParams(next);
  }
  useEffect(() => {
    setSelectedIds(new Set());
    setBulkConfirm(false);
  }, [workspaceId, kind, search, offset, deleted, id]);
  useEffect(() => {
    setTerm(search);
  }, [search]);
  useEffect(() => {
    if (!api) return;
    const c = new AbortController();
    setLoading(true);
    setError((current) => current.startsWith("We couldn’t load the saved records.") ? "" : current);
    setPage(undefined);
    setRow(undefined);
    setConfirm(undefined);
    setEditing(id === "new" || edit);
    setErrors({});
    setOrgs([]);
    setOrgError("");
    setOrgSearch("");
    const list = api.list(
      workspaceId,
      kind,
      { search, offset, archived: deleted },
      c.signal,
    );
    Promise.all([
      list,
      id && id !== "new"
        ? api.read(workspaceId, kind, id, c.signal)
        : Promise.resolve(undefined),
    ])
      .then(([p, r]) => {
        if (c.signal.aborted) return;
        setPage(p);
        setRow(r);
        const labels = kind === "contacts" ? contactLabels : organisationLabels;
        setFields(
          Object.fromEntries(
            Object.keys(labels).map((k) => [
              k,
              String(
                r?.[k as keyof ManagedRecord] ??
                  (k === "type" ? "prospect" : ""),
              ),
            ]),
          ),
        );
      })
      .catch(() => {
        if (!c.signal.aborted) setError("We couldn’t load the saved records. Retry loading the list; you do not need to import the file again.");
      })
      .finally(() => {
        if (!c.signal.aborted) {
          setLoading(false);
          focus.current?.focus();
        }
      });
    return () => c.abort();
  }, [api, workspaceId, kind, id, edit, deleted, search, offset, refresh]);
  if (!api)
    return (
      <p role="alert">Contact management is unavailable in this environment.</p>
    );
  const canWrite = page?.canWrite === true;
  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!api || busy) return;
    const validation: Record<string, string> = {};
    const required = kind === "contacts" ? "firstName" : "name";
    if (!fields[required]?.trim()) validation[required] = "Enter a name.";
    if (fields.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email))
      validation.email = "Enter a valid email address.";
    if (fields.phone && !/^[+\d\s().-]{5,100}$/.test(fields.phone))
      validation.phone = "Enter a valid phone number.";
    if (fields.website) {
      try {
        const u = new URL(fields.website);
        if (!["http:", "https:"].includes(u.protocol)) throw Error();
      } catch {
        validation.website =
          "Enter a full website address, starting with https://.";
      }
    }
    if (fields.country && !/^[a-z]{2}$/i.test(fields.country))
      validation.country = "Use a two-letter code, such as GB.";
    setErrors(validation);
    if (Object.keys(validation).length) return;
    setBusy(true);
    setError("");
    const c = new AbortController();
    mutation.current = c;
    try {
      const saved = await api.save(
        workspaceId,
        kind,
        row?.id,
        fields,
        row?.updatedAt,
        c.signal,
      );
      setNotice(`${kind === "contacts" ? "Contact" : "Organisation"} saved.`);
      setEditing(false);
      if (id === "new") navigate({ record: saved.id, edit: undefined });
      else {
        navigate({ edit: undefined });
        setRefresh((v) => v + 1);
      }
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  async function remove(target: ManagedRecord, restore = false) {
    if (!api || busy) return;
    setBusy(true);
    setError("");
    const c = new AbortController();
    mutation.current = c;
    try {
      await api.archive(workspaceId, kind, target, restore, c.signal);
      setConfirm(undefined);
      setSelectedIds((previous) => {
        const next = new Set(previous);
        next.delete(target.id);
        return next;
      });
      setNotice(
        restore
          ? "Record restored."
          : "Record moved to Deleted. Linked records and history were kept.",
      );
      if (id) navigate({ record: undefined, edit: undefined });
      else setRefresh((v) => v + 1);
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  async function removeSelected() {
    if (!api || busy || bulkLock.current) return;
    const targets = (page?.items ?? []).filter(
      (item) => selectedIds.has(item.id) && !item.archived,
    );
    if (!targets.length) return;
    bulkLock.current = true;
    setBusy(true);
    setError("");
    const controller = new AbortController();
    mutation.current = controller;
    const failed: string[] = [];
    const removed = new Set<string>();
    for (const target of targets) {
      if (controller.signal.aborted) break;
      try {
        await api.archive(workspaceId, kind, target, false, controller.signal);
        removed.add(target.id);
      } catch {
        failed.push(target.name);
      }
    }
    if (!controller.signal.aborted) {
      setSelectedIds(
        new Set(
          targets
            .filter((target) => !removed.has(target.id))
            .map((target) => target.id),
        ),
      );
      setBulkConfirm(false);
      setNotice(
        `${removed.size} of ${targets.length} records moved to Deleted. You can restore them from Show deleted.`,
      );
      if (failed.length)
        setError(
          `Could not delete: ${failed.join(", ")}. These records remain selected. Review them and retry.`,
        );
      setRefresh((v) => v + 1);
    }
    bulkLock.current = false;
    setBusy(false);
  }
  async function findOrganisations() {
    if (!api) return;
    setOrgError("");
    try {
      const r = await api.list(
        workspaceId,
        "organisations",
        { search: orgSearch },
        new AbortController().signal,
      );
      setOrgs(r.items);
      if (!r.items.length)
        setOrgError(
          "No matching organisations. Create one in the Organisations view first.",
        );
    } catch {
      setOrgError("Couldn’t load organisations. Try again.");
    }
  }
  return (
    <section className="cm-page" aria-label="Contact management">
      <div className="cm-toolbar">
        <div className="cm-toggle" role="group" aria-label="Record type">
          {(["contacts", "organisations"] as const).map((k) => (
            <button
              key={k}
              type="button"
              aria-pressed={kind === k}
              disabled={busy}
              onClick={() => {
                setNotice("");
                navigate({
                  view: k,
                  record: undefined,
                  offset: undefined,
                  q: undefined,
                  deleted: undefined,
                });
              }}
            >
              {k === "contacts" ? "Contacts" : "Organisations"}
            </button>
          ))}
        </div>
        {!id && canWrite && !deleted && (
          <div className="cm-actions">
            {importApi && (
              <button
                type="button"
                onClick={() => {
                  setShowImport(!showImport);
                  setNotice("");
                  if (showImport) setRefresh((v) => v + 1);
                }}
              >
                {showImport ? "Close upload" : "Upload records and email history"}
              </button>
            )}
            <button
              className="button"
              onClick={() => navigate({ record: "new" })}
            >
              Add {noun}
            </button>
          </div>
        )}
      </div>
      {!id && showImport && importApi && (
        <div className="icp-page">
          <HiveImport
            api={importApi}
            w={workspaceId}
            onFileSelected={() => setNotice("")}
            onImported={({ checkedRows }) => {
              setNotice(
                `Import complete: ${checkedRows} rows checked. Saved records are available below; emails appear in contact history or unlinked email review.`,
              );
              setRefresh((value) => value + 1);
            }}
          />
        </div>
      )}
      {!id && <UnlinkedEmailHistory key={`${workspaceId}:${refresh}`} api={api} w={workspaceId} canWrite={canWrite}/>}
      {notice && (
        <p role="status" className="cm-notice">
          {notice}
        </p>
      )}
      {error && (
        <div role="alert" className="cm-error">
          <p>{error}</p>
          {!editing && (
            <button onClick={() => setRefresh((v) => v + 1)}>Retry</button>
          )}
        </div>
      )}
      {loading ? (
        <p role="status">Loading {noun} records…</p>
      ) : !page && error ? (
        <p role="status">Saved records could not be displayed.</p>
      ) : id ? (
        <>
          <button
            className="cm-back"
            disabled={busy}
            onClick={() => navigate({ record: undefined, edit: undefined })}
          >
            ← Back to {kind}
          </button>
          <header className="cm-detail-heading">
            <div>
              <h2 ref={focus} tabIndex={-1}>
                {id === "new"
                  ? `New ${noun}`
                  : (row?.name ?? "Record unavailable")}
              </h2>
              {row && (
                <p>
                  Last engaged: {engaged(row.lastEngagedAt)}
                  {row.archived ? " · Deleted" : ""}
                </p>
              )}
            </div>
            {row && canWrite && !editing && (
              <div className="cm-actions">
                {row.archived ? (
                  <button disabled={busy} onClick={() => remove(row, true)}>
                    Restore
                  </button>
                ) : (
                  <>
                    <button className="button" onClick={() => setEditing(true)}>
                      Edit
                    </button>
                    <button onClick={() => setConfirm(row)}>Delete</button>
                  </>
                )}
              </div>
            )}
          </header>
          {row && !row.archived && !editing && <ResearchEvidencePanel api={research} w={workspaceId} type={kind==="contacts"?"people":"organisations"} id={row.id}/> }
          {row && !row.archived && !editing && <ContactHistory key={`history:${kind}:${row.id}`} api={api.context} w={workspaceId} kind={kind} id={row.id} canWrite={canWrite}/> }
          {kind === "contacts" && row && !row.archived && !editing && <ConsumerCharacteristics key={`consumer:${row.id}`} api={api.consumer} w={workspaceId} personId={row.id} canWrite={canWrite} />}
          {(row || id === "new") &&
            (editing && canWrite ? (
              <form
                onSubmit={save}
                className="cm-form"
                aria-label={`${noun} form`}
              >
                <div className="cm-fields">
                  {Object.entries(
                    kind === "contacts" ? contactLabels : organisationLabels,
                  ).map(([key, label]) => (
                    <div
                      key={key}
                      className={
                        key === "description" || key === "organisationId"
                          ? "cm-field cm-full"
                          : "cm-field"
                      }
                    >
                      <label htmlFor={`cm-${key}`}>
                        {label}
                        {key === "firstName" || key === "name" ? " *" : ""}
                      </label>
                      {key === "organisationId" ? (
                        <>
                          <div className="cm-org-search">
                            <input
                              aria-label="Search organisations"
                              value={orgSearch}
                              onChange={(e) => setOrgSearch(e.target.value)}
                              placeholder="Find an existing organisation"
                              disabled={busy}
                            />
                            <button
                              type="button"
                              disabled={busy}
                              onClick={findOrganisations}
                            >
                              Search
                            </button>
                          </div>
                          <select
                            id={`cm-${key}`}
                            disabled={busy}
                            value={fields[key] ?? ""}
                            onChange={(e) =>
                              setFields({ ...fields, [key]: e.target.value })
                            }
                          >
                            <option value="">No organisation linked</option>
                            {fields[key] &&
                              !orgs.some((o) => o.id === fields[key]) && (
                                <option value={fields[key]}>
                                  {row?.organisationName ??
                                    "Current organisation"}
                                </option>
                              )}
                            {orgs.map((o) => (
                              <option key={o.id} value={o.id}>
                                {o.name}
                              </option>
                            ))}
                          </select>
                          {orgError && <p role="status">{orgError}</p>}
                          <small>
                            Links this contact to an existing organisation.
                            Other relationships are kept.
                          </small>
                        </>
                      ) : key === "description" ? (
                        <textarea
                          id={`cm-${key}`}
                          rows={4}
                          maxLength={10000}
                          value={fields[key] ?? ""}
                          disabled={busy}
                          onChange={(e) =>
                            setFields({ ...fields, [key]: e.target.value })
                          }
                        />
                      ) : key === "type" ? (
                        <select
                          id={`cm-${key}`}
                          value={fields[key]}
                          disabled={busy}
                          onChange={(e) =>
                            setFields({ ...fields, [key]: e.target.value })
                          }
                        >
                          {[
                            "prospect",
                            "customer",
                            "partner",
                            "vendor",
                            "other",
                          ].map((t) => (
                            <option key={t} value={t}>
                              {t[0]!.toUpperCase() + t.slice(1)}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          id={`cm-${key}`}
                          type={
                            key === "email"
                              ? "email"
                              : key === "phone"
                                ? "tel"
                                : "text"
                          }
                          required={key === "name" || key === "firstName"}
                          maxLength={
                            key === "website"
                              ? 2000
                              : key === "email"
                                ? 254
                                : key === "country"
                                  ? 2
                                  : [
                                        "firstName",
                                        "lastName",
                                        "phone",
                                        "region",
                                      ].includes(key)
                                    ? 100
                                    : ["title", "industry"].includes(key)
                                      ? 200
                                      : 300
                          }
                          value={fields[key] ?? ""}
                          disabled={busy}
                          aria-invalid={!!errors[key]}
                          aria-describedby={
                            errors[key] ? `cm-error-${key}` : undefined
                          }
                          onChange={(e) =>
                            setFields({ ...fields, [key]: e.target.value })
                          }
                        />
                      )}
                      {errors[key] && (
                        <small id={`cm-error-${key}`} className="cm-error">
                          {errors[key]}
                        </small>
                      )}
                    </div>
                  ))}
                </div>
                <p className="cm-help">
                  Saving contact details does not grant marketing permission.
                </p>
                <div className="cm-actions">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => {
                      if (row) {
                        setEditing(false);
                        setRefresh((v) => v + 1);
                      } else navigate({ record: undefined, edit: undefined });
                    }}
                  >
                    Cancel
                  </button>
                  <button className="button" type="submit" disabled={busy}>
                    {busy ? "Saving…" : `Save ${noun}`}
                  </button>
                </div>
              </form>
            ) : row ? (
              <dl className="cm-details">
                {Object.entries(
                  kind === "contacts"
                    ? { ...contactLabels, organisationId: "Organisation" }
                    : {
                        ...organisationLabels,
                        registration: "Registration number",
                      },
                ).map(([key, label]) => (
                  <div
                    key={key}
                    className={key === "description" ? "cm-full" : ""}
                  >
                    <dt>{label}</dt>
                    <dd>
                      {(key === "organisationId"
                        ? row.organisationName
                        : row[key as keyof ManagedRecord]) || "Not recorded"}
                    </dd>
                  </div>
                ))}
              </dl>
            ) : null)}
        </>
      ) : (
        <>
          <form
            className="cm-search"
            onSubmit={(e) => {
              e.preventDefault();
              navigate({ q: term.trim() || undefined, offset: undefined });
            }}
          >
            <label htmlFor="cm-search">Search {kind}</label>
            <div>
              <input
                id="cm-search"
                value={term}
                onChange={(e) => setTerm(e.target.value)}
                placeholder={
                  kind === "contacts"
                    ? "Name, organisation, email or phone"
                    : "Name or website"
                }
              />
              <button type="submit">Search</button>
              {search && (
                <button
                  type="button"
                  onClick={() => navigate({ q: undefined, offset: undefined })}
                >
                  Clear
                </button>
              )}
            </div>
          </form>
          <div className="cm-toolbar">
            <p>Most recently engaged first · {page?.total ?? 0} records</p>
            <label className="cm-check">
              <input
                type="checkbox"
                checked={deleted}
                onChange={(e) =>
                  navigate({
                    deleted: e.target.checked ? "true" : undefined,
                    offset: undefined,
                  })
                }
              />
              Show deleted
            </label>
          </div>
          <details className="cm-help cm-sort-help">
            <summary>About engagement order</summary>
            <p>
              Engagement uses recorded connected calls, sent/received emails,
              held meetings and communications. Organisations use interactions
              linked directly to them. Records without engagement appear last.
            </p>
          </details>
          {!page?.items.length ? (
            <div className="cm-empty">
              <h2 ref={focus} tabIndex={-1}>
                {search
                  ? "No matching records"
                  : deleted
                    ? "No deleted records"
                    : `No ${kind} yet`}
              </h2>
              <p>
                {search
                  ? "Try a different name or identifier."
                  : deleted
                    ? "Deleted records can be restored here."
                    : `Add your first ${noun} to get started.`}
              </p>
            </div>
          ) : (
            <>
              {canWrite && !deleted && (
                <div className="cm-selection-bar">
                  <span>
                    {selectedIds.size
                      ? `${selectedIds.size} selected on this page`
                      : "Select records to delete"}
                  </span>
                  {selectedIds.size > 0 && (
                    <>
                      <button
                        disabled={busy}
                        onClick={() => setBulkConfirm(true)}
                      >
                        <TrashIcon /> Delete selected ({selectedIds.size})
                      </button>
                      <button
                        disabled={busy}
                        onClick={() => setSelectedIds(new Set())}
                      >
                        Clear selection
                      </button>
                    </>
                  )}
                </div>
              )}
              <div
                className="cm-table-scroll"
                role="region"
                aria-label="Scrollable records table"
                tabIndex={0}
              >
                <table
                  className={`cm-table ${kind === "contacts" ? "cm-contacts-table" : "cm-organisations-table"}`}
                >
                  <caption className="sr-only">
                    {kind} ordered by most recent engagement
                  </caption>
                  <thead>
                    <tr>
                      {canWrite && !deleted && (
                        <th scope="col" className="cm-select-cell">
                          <input
                            type="checkbox"
                            aria-label="Select all records on this page"
                            disabled={busy}
                            checked={
                              page.items.length > 0 &&
                              page.items.every((r) => selectedIds.has(r.id))
                            }
                            ref={(element) => {
                              if (element)
                                element.indeterminate =
                                  selectedIds.size > 0 &&
                                  !page.items.every((r) =>
                                    selectedIds.has(r.id),
                                  );
                            }}
                            onChange={(e) =>
                              setSelectedIds(
                                e.target.checked
                                  ? new Set(page.items.map((r) => r.id))
                                  : new Set(),
                              )
                            }
                          />
                        </th>
                      )}
                      <th scope="col" className="cm-name-cell">
                        {kind === "contacts" ? "Name" : "Company name"}
                      </th>
                      {(kind === "contacts"
                        ? contactColumns
                        : organisationColumns
                      ).map((h) => (
                        <th key={h} scope="col">
                          {h}
                        </th>
                      ))}
                      <th scope="col">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {page.items.map((r) => (
                      <tr key={r.id} aria-selected={selectedIds.has(r.id)}>
                        {canWrite && !deleted && (
                          <td className="cm-select-cell">
                            <input
                              type="checkbox"
                              aria-label={`Select ${r.name}`}
                              disabled={busy}
                              checked={selectedIds.has(r.id)}
                              onChange={(e) => {
                                const next = new Set(selectedIds);
                                if (e.target.checked) next.add(r.id);
                                else next.delete(r.id);
                                setSelectedIds(next);
                              }}
                            />
                          </td>
                        )}
                        <th scope="row" className="cm-name-cell">
                          <button
                            className="cm-record-link"
                            onClick={() => navigate({ record: r.id })}
                          >
                            {r.name}
                          </button>
                        </th>
                        {(kind === "contacts"
                          ? [
                              r.email,
                              engaged(r.lastEngagedAt),
                              r.lifecycleStage,
                              r.title,
                              r.organisationName,
                            ]
                          : [
                              r.lifecycleStage?.replaceAll("_", " "),
                              r.phone,
                              r.lastActivityAt ? engaged(r.lastActivityAt) : "",
                              r.city,
                              [countryName(r.country), r.region]
                                .filter(Boolean)
                                .join(" / "),
                              r.industry,
                            ]
                        ).map((v, i) => (
                          <td key={i}>
                            <span className="cm-cell" title={v}>
                              {v || "—"}
                            </span>
                          </td>
                        ))}
                        <td>
                          <div className="cm-actions">
                            {canWrite &&
                              (r.archived ? (
                                <button
                                  disabled={busy}
                                  onClick={() => remove(r, true)}
                                  aria-label={`Restore ${r.name}`}
                                >
                                  Restore
                                </button>
                              ) : (
                                <>
                                  <button
                                    onClick={() => {
                                      navigate({ record: r.id, edit: "true" });
                                    }}
                                    aria-label={`View and edit ${r.name}`}
                                  >
                                    Edit
                                  </button>
                                  <button
                                    disabled={busy}
                                    className="cm-delete-icon"
                                    title={`Delete ${r.name}`}
                                    onClick={() => setConfirm(r)}
                                    aria-label={`Delete ${r.name}`}
                                  >
                                    <TrashIcon />
                                  </button>
                                </>
                              ))}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="cm-help">
                Scroll horizontally for more fields. “—” means no value is
                recorded.
              </p>
            </>
          )}
          <nav className="cm-pagination" aria-label="Record pages">
            <button
              disabled={!offset}
              onClick={() =>
                navigate({ offset: String(Math.max(0, offset - 25)) })
              }
            >
              Previous
            </button>
            <span>
              {page?.total
                ? `${offset + 1}–${Math.min(offset + 25, page.total)} of ${page.total}`
                : "0 records"}
            </span>
            <button
              disabled={!page || offset + 25 >= page.total}
              onClick={() => navigate({ offset: String(offset + 25) })}
            >
              Next
            </button>
          </nav>
        </>
      )}
      {bulkConfirm && (
        <div
          className="cm-confirm"
          role="alertdialog"
          aria-labelledby="cm-bulk-title"
        >
          <h2 id="cm-bulk-title">
            Delete {selectedIds.size} selected records?
          </h2>
          <p>
            Only selected records on this page will move to Deleted. Linked
            records and history are kept, and you can restore them later.
          </p>
          <ul>
            {page?.items
              .filter((r) => selectedIds.has(r.id))
              .map((r) => (
                <li key={r.id}>{r.name}</li>
              ))}
          </ul>
          <div className="cm-actions">
            <button disabled={busy} onClick={() => void removeSelected()}>
              {busy ? "Deleting…" : "Confirm selected deletion"}
            </button>
            <button disabled={busy} onClick={() => setBulkConfirm(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}
      {confirm && (
        <div
          className="cm-confirm"
          role="alertdialog"
          aria-modal="false"
          aria-labelledby="cm-delete-title"
        >
          <h2 id="cm-delete-title">Delete {confirm.name}?</h2>
          <p>
            This moves the {noun} to Deleted. You can restore it later. Linked
            records, interactions and permissions will be kept.
          </p>
          <div className="cm-actions">
            <button disabled={busy} onClick={() => remove(confirm)}>
              {busy ? "Deleting…" : "Confirm delete"}
            </button>
            <button disabled={busy} onClick={() => setConfirm(undefined)}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
