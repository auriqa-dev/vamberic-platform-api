import {ResearchEvidencePanel} from "../components/research-evidence";
import type {ResearchGateway} from "../data/research";
import { OfferSummary } from "../components/offer-summary";
import { OfferReview } from "../components/offer-review";
import { Status } from "../components/ui";
import {
  useHenryBinding,
  useHenryAvailable,
  useHenryBrand,
  henryFields,
  applyHenryFields,
} from "../components/workspace-henry";
import { ResearchDocuments } from "../components/research-documents";
import type { ResearchSelection } from "../data/research-documents";
import { OfferRefinement } from "../components/offer-refinement";
import type { BriefJob } from "../data/offer/brief";
import { OfferBrief } from "../components/offer-brief";
import { OfferMethodology } from "../components/offer-methodology";
import { useCallback, useEffect, useRef, useState } from "react";
import type {
  Fields,
  OfferGateway,
  OfferBundle,
  OfferRecord,
  OfferJob,
} from "../data/offer";
import type { IcpGateway, IcpProduct, IcpRecord } from "../data/icp";
import {
  OfferFields,
  OfferValidation,
  missingOfferFields,
  OfferLines,
  fieldLabel,
  listLines,
  type FieldSpec,
} from "../components/offer-fields";
import specifications from "../data/offer/fields.json";
import { DataError } from "../data/gateway";
function commercialModels(definition: Record<string, unknown>) {
  const terms = definition.commercialTerms as
    { options?: { pricingModel?: string }[] } | undefined;
  return (
    [
      ...new Set(
        (terms?.options ?? []).map((o) => fieldLabel(o.pricingModel ?? "")),
      ),
    ].join(", ") || "To confirm"
  );
}
const sections = {
  "Offer summary": [] as string[],
  Proposition: [
    "name",
    "headlineProposition",
    "valueProposition",
    "promise",
    "differentiators",
    "whyChooseThisOffer",
    "competitivePositioning",
  ],
  "Packaging & terms": [
    "commercialTerms",
    "components",
    "incentives",
    "customerCommitments",
    "eligibilityCriteria",
    "exclusions",
    "capacityConstraints",
    "geographicConstraints",
  ],
  "Proof & confidence": [
    "riskReduction",
    "objections",
    "proofPoints",
    "evidenceRequirements",
    "supportableClaims",
  ],
  "Qualification & handover": ["conversionOutcome", "intermediateOutcomes", "qualificationCriteria", "desirableQualification", "acceptableUnknowns", "qualificationDisqualifiers", "humanReviewTriggers", "salesReadiness", "handoverRecipient", "handoverRequirements", "afterHandover", "bookingUrl", "meetingPurpose"],
  "Customer journey": [
    "primaryCallToAction",
    "secondaryCallToAction",
    "afterResponse",
    "afterPurchase",
    "onboardingExpectations",
  ],
  "Research & review": ["rationale", "assumptions", "unknowns"],
};
const specs = specifications.definition.properties as Record<string, FieldSpec>;
const qualificationEditor = (definition: Fields): Fields => ({
  ...Object.fromEntries(["conversionOutcome", "intermediateOutcomes", "qualificationCriteria", "desirableQualification", "acceptableUnknowns", "qualificationDisqualifiers", "humanReviewTriggers", "salesReadiness", "handoverRecipient", "handoverRequirements", "afterHandover", "bookingUrl", "meetingPurpose"].map(key => [key, specs[key]?.bsonType === "array" ? [] : ""])),
  ...definition,
});
const problem = (e: unknown) =>
  e instanceof DataError && e.code === "conflict"
    ? "This offer or its sources changed, or its review is incomplete. Your edits remain here. Check the review tab, or reopen the offer to load the latest version."
    : "We couldn’t complete that action. Your edits remain here. Please try again.";
export function OffersPage({
  api,
  icp,
  workspaceId: w,
  research,
}: {
  api?: OfferGateway;
  icp?: IcpGateway;
  workspaceId: string;
  research?:ResearchGateway;
}) {
  const sharedHenry = useHenryAvailable(),
    carriedBrand = useRef(useHenryBrand()).current;
  const [products, setProducts] = useState<IcpProduct[]>([]),
    [product, setProduct] = useState("");
  const [profiles, setProfiles] = useState<IcpRecord[]>([]),
    [buyers, setBuyers] = useState<Awaited<ReturnType<OfferGateway["buyers"]>>>(
      [],
    );
  const [targets, setTargets] = useState<string[]>([]),
    [buyerTargets, setBuyerTargets] = useState<string[]>([]);
  const [rows, setRows] = useState<OfferRecord[]>([]),
    [archived, setArchived] = useState(false),
    [selected, setSelected] = useState<string[]>([]);
  const [permissions, setPermissions] = useState({
    canCreate: false,
    canUpdate: false,
    canApprove: false,
    generationAvailable: false,
  });
  const [startingGeneration, setStartingGeneration] = useState(false);
  const [reviewWorking, setReviewWorking] = useState(false);
  const reviewUnsaved = useCallback(() => setDirty(true), []);
  const [saveError, setSaveError] = useState("");
  const [saveAttempted, setSaveAttempted] = useState(false);
  const [bundle, setBundle] = useState<OfferBundle>(),
    [dirty, setDirty] = useState(false),
    [job, setJob] = useState<OfferJob>(null);
  const [tab, setTab] = useState<keyof typeof sections>("Proposition"),
    [newOffer, setNewOffer] = useState(false);
  const [brief, setBrief] = useState<BriefJob | null>(null);
  const [briefIndex, setBriefIndex] = useState<number | undefined>();
  const [researchingIndex, setResearchingIndex] = useState<number | undefined>();
  const researching = startingGeneration || job?.status === "generating";
  const overview = !bundle && !newOffer;
  useEffect(() => {
    if (!dirty) return;
    const protect = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", protect);
    return () => window.removeEventListener("beforeunload", protect);
  }, [dirty]);

  const [useCustomerPatterns, setUseCustomerPatterns] = useState(true);
  const [researchDocuments, setResearchDocuments] = useState<ResearchSelection>(
    [],
  );
  useEffect(() => {
    setResearchDocuments([]);
  }, [w]);
  const generationKey = useRef({ fingerprint: "", key: "" });
  const [urls, setUrls] = useState("");
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [loading, setLoading] = useState(true);
  const [history, setHistory] =
    useState<Awaited<ReturnType<OfferGateway["revision"]>>>();
  const lock = useRef(false),
    controller = useRef(new AbortController());
  useEffect(() => {
    const c = new AbortController();
    controller.current = c;
    return () => {
      c.abort();
    };
  }, []);
  useEffect(() => {
    if (!api || !icp) {
      setLoading(false);
      return;
    }
    const c = new AbortController();
    Promise.all([icp.products(w, c.signal), api.permissions(w, c.signal)])
      .then(([p, a]) => {
        if (!c.signal.aborted) {
          setProducts(p);
          setProduct(
            p.find((row) => row.id === new URLSearchParams(window.location.search).get("product"))?.id ?? p.find((row) => row.brandId === carriedBrand)?.id ?? p[0]?.id ?? "",
          );
          setPermissions(a);
          setLoading(false);
        }
      })
      .catch((e) => {
        if (!c.signal.aborted) {
          setError(problem(e));
          setLoading(false);
        }
      });
    return () => c.abort();
  }, [api, icp, w, carriedBrand]);
  useEffect(() => {
    if (!api || !icp || !product) return;
    const c = new AbortController();
    setError("");
    setBundle(undefined);
    setDirty(false);
    setSelected([]);
    setTargets([]);
    setBuyerTargets([]);
    setJob(null);
    setHistory(undefined);
    setLoading(true);
    Promise.all([
      api.list(w, product, archived, c.signal),
      icp.list(w, product, false, c.signal),
      api.buyers(w, product, c.signal),
      api.latest(w, product, c.signal),
      api.latestBrief(w, product, c.signal),
    ])
      .then(([r, p, b, j, savedBrief]) => {
        if (!c.signal.aborted) {
          setRows(r);
          setProfiles(p);
          setBuyers(b);
          setJob(j);
          setBrief(savedBrief);
          setNewOffer(false);
          setLoading(false);
        }
      })
      .catch((e) => {
        if (!c.signal.aborted) {
          setError(problem(e));
          setLoading(false);
        }
      });
    return () => c.abort();
  }, [api, icp, w, product, archived]);
  useEffect(() => {
    if (!api || job?.status !== "generating") return;
    const c = new AbortController();
    let timer: ReturnType<typeof setTimeout>;
    const poll = async () => {
      try {
        const j = await api.job(w, job.id, c.signal);
        if (c.signal.aborted) return;
        if (j?.status === "generating") {
          setJob(j);
          timer = setTimeout(poll, 2000);
        } else if (j?.status === "complete" && j.offerId) {
          generationKey.current = { fingerprint: "", key: "" };
          const [b, r] = await Promise.all([
            api.bundle(w, j.offerId, c.signal),
            api.list(w, product, false, c.signal),
          ]);
          if (!c.signal.aborted) {
            setJob(j);
            if (b.offer.archived || b.offer.status === "retired") {
              setBundle(undefined);
              setRows(r);
              setNewOffer(true);
              setNotice("");
              setError(
                "This generation’s offer has been archived or retired. Your brief is saved; start a new generation from it.",
              );
              return;
            }
            setError("");
            setBundle(b);
            setRows(r);
            setDirty(false);
            setNewOffer(false);
            setNotice(
              "Your draft is saved. Review and edit it below before approving.",
            );
          }
        } else {
          setJob(j);
          setError(
            "Generation did not finish. Your saved offers are unchanged. You can try again.",
          );
        }
      } catch (e) {
        if (!c.signal.aborted) {
          setError(problem(e));
          timer = setTimeout(poll, 5000);
        }
      }
    };
    timer = setTimeout(poll, 1000);
    return () => {
      c.abort();
      clearTimeout(timer);
    };
  }, [api, w, job?.id, job?.status, product]);
  const run = async (fn: () => Promise<void>) => {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await fn();
    } catch (e) {
      if (!controller.current.signal.aborted) setError(problem(e));
    } finally {
      lock.current = false;
      if (!controller.current.signal.aborted) setBusy(false);
    }
  };
  const generateFromBrief = (
    confirmedBrief: { id: string; index: number; existingOfferId?: string },
    allowCommercialChanges: boolean,
  ) => {
    if (
      busy ||
      job?.status === "generating" ||
      !permissions.generationAvailable ||
      !products.find((p) => p.id === product)?.approvedRevision
    )
      return;
    void run(async () => {
      setResearchingIndex(confirmedBrief.index);
      setStartingGeneration(true);
      try {
        setJob(null);
        const fingerprint = JSON.stringify({
          product,
          targets,
          buyerTargets,
          confirmedBrief,
          allowCommercialChanges,
          urls,
          researchDocuments,
          useCustomerPatterns,
        });
        if (generationKey.current.fingerprint !== fingerprint)
          generationKey.current = {
            fingerprint,
            key: crypto.randomUUID(),
          };
        const j = await api!.generate(
          w,
          {
            offeringId: product,

            targetIcpIds: targets,
            targetBuyerProfileIds: buyerTargets,
            requestKey: generationKey.current.key,
            useCustomerPatterns,
            instructions: "",
            briefId: confirmedBrief?.id,
            briefOfferIndex: confirmedBrief?.index,
            allowCommercialChanges,
            sourceUrls: listLines(urls),
            researchDocuments,
          },
          controller.current.signal,
        );
        setJob(j);
        if (j?.status !== "generating")
          generationKey.current = { fingerprint: "", key: "" };
        if (j?.status === "complete" && j.offerId) {
          const result = await api!.bundle(
            w,
            j.offerId,
            controller.current.signal,
          );
          if (result.offer.archived || result.offer.status === "retired") {
            setBundle(undefined);
            setNewOffer(true);
            setError(
              "This generation’s offer has been archived or retired. Your brief is saved; start a new generation from it.",
            );
            return;
          }
          setBundle(result);
          setRows(
            await api!.list(w, product, false, controller.current.signal),
          );
          setDirty(false);
          setNewOffer(false);
          setNotice("Your saved draft is ready to review.");
        }
      } finally {
        setStartingGeneration(false);
      }
    });
  };
  const discard = () =>
    !reviewWorking &&
    (!dirty || window.confirm("Discard your unsaved offer edits?"));
  const openOverview = () => {
    if (!discard()) return;
    setBundle(undefined);
    setDirty(false);
    setNewOffer(false);
    setBriefIndex(undefined);
    void api!
      .latestBrief(w, product, controller.current.signal)
      .then(setBrief)
      .catch((e) => setError(problem(e)));
    setError("");
    setNotice("");
    setHistory(undefined);
  };
  const open = (row: OfferRecord) => {
    if (!discard()) return;
    void run(async () => {
      const b = await api!.bundle(w, row.id, controller.current.signal);
      setBundle(b);
      setDirty(false);
      setNewOffer(false);
      setHistory(undefined);
      setTab(b.design?.work.stages.every(s => s.status === "completed") ? "Offer summary" : "Research & review");
    });
  };
  useEffect(() => {
    setSaveError("");
    setSaveAttempted(false);
  }, [bundle?.offer.id]);
  const openedLink = useRef("");
  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get("offer");
    if (!id || openedLink.current === `${w}:${id}` || !api || busy || bundle) return;
    const row = rows.find(r=>r.id===id);
    if (!row) return;
    openedLink.current = `${w}:${id}`;
    void api.bundle(w,id,controller.current.signal).then(b=>{setBundle(b);setTab("Offer summary");}).catch(e=>setError(problem(e)));
  }, [api,w,rows,busy,bundle]);
  const edit = (next: OfferBundle) => {
    setSaveError("");
    setBundle(next);
    setDirty(true);
  };
  const editable =
    !!bundle &&
    bundle.offer.status === "draft" &&
    !bundle.offer.archived &&
    permissions.canUpdate &&
    job?.status !== "generating" &&
    !busy &&
    !reviewWorking;
  const work = bundle?.design?.work;
  const toggle = (
    id: string,
    values: string[],
    setter: (v: string[]) => void,
  ) =>
    setter(
      values.includes(id) ? values.filter((x) => x !== id) : [...values, id],
    );
  const persist = () =>
    run(async () => {
      if (!bundle?.design) return;
      setSaveError("");
      setSaveAttempted(true);
      const missing = missingOfferFields(
        bundle.offer.definition,
        specifications.definition as FieldSpec,
      );
      if (missing.length) {
        setSaveError(
          "Complete these fields before saving: " + missing.join(", "),
        );
        return;
      }
      try {
        const b = await api!.save(
          w,
          {
            id: bundle.offer.id,
            expectedUpdatedAt: bundle.offer.updatedAt,
            designId: bundle.design.id,
            expectedDesignUpdatedAt: bundle.design.updatedAt,
            definition: bundle.offer.definition,
            work: bundle.design.work,
          },
          controller.current.signal,
        );
        setBundle(b);
        setRows((r) => r.map((x) => (x.id === b.offer.id ? b.offer : x)));
        setDirty(false);
        setNotice("Offer saved.");
        setSaveAttempted(false);
      } catch (e) {
        setSaveError(problem(e));
      }
    });
  const transition = (action: "approve" | "revise") =>
    run(async () => {
      if (
        !bundle?.design ||
        !window.confirm(
          action === "approve"
            ? "Approve this offer and its research brief for future HVM decisions? This does not start marketing."
            : "Create a working revision? The current approved version remains available until you approve the replacement.",
        )
      )
        return;
      const b = await api!.transition(
        w,
        {
          id: bundle.offer.id,
          expectedUpdatedAt: bundle.offer.updatedAt,
          expectedDesignUpdatedAt: bundle.design.updatedAt,
          action,
        },
        controller.current.signal,
      );
      setBundle(b);
      setRows((r) => r.map((x) => (x.id === b.offer.id ? b.offer : x)));
      setDirty(false);
      if (action === "approve") setTab("Offer summary");
      setNotice(
        action === "approve" ? "Offer approved." : "Working revision opened.",
      );
    });
  const archiveRows = (ids: string[]) => {
    if (
      !discard() ||
      !window.confirm(
        `Archive ${ids.length} offer${ids.length === 1 ? "" : "s"}? Approved history is retained.`,
      )
    )
      return;
    void run(async () => {
      const failed: string[] = [];
      for (const row of rows.filter((r) => ids.includes(r.id))) {
        try {
          await api!.archive(w, row, controller.current.signal);
        } catch {
          failed.push(String(row.definition.name));
        }
      }
      setRows(await api!.list(w, product, archived, controller.current.signal));
      setBundle(undefined);
      setDirty(false);
      setSelected([]);
      setNotice(
        failed.length
          ? `Could not archive: ${failed.join(", ")}. Other selected offers were archived. Reopen these offers before retrying.`
          : "Offers archived. Their history is retained.",
      );
    });
  };
  const researchFields = Object.fromEntries(
    (work?.stages ?? []).flatMap((s, i) => [
      [`stage${i}Notes`, s.notes],
      [`stage${i}Unknowns`, s.unknowns],
      ...s.groups.flatMap((g, j) =>
        g.key.startsWith("henry_proposal_")
          ? []
          : [[`stage${i}Group${j}`, g.items]],
      ),
    ]),
  );
  useHenryBinding({
    key: "offer-research",
    priority: 70,
    enabled: tab === "Research & review" && !!work,
    brandId: products.find((p) => p.id === product)?.brandId,
    summary: JSON.stringify({
      stages: work?.stages,
      instruction: "Do not invent evidence or mark research complete.",
    }),
    editor:
      editable && bundle
        ? {
            key: `offer-research:${bundle.offer.id}:${bundle.offer.updatedAt}`,
            title: "Targeting and research",
            fields: henryFields(researchFields),
          }
        : undefined,
    apply: (changes) => {
      if (!bundle?.design || !editable) return;
      const next = applyHenryFields(researchFields, changes);
      if (
        Object.values(next).some(
          (v) => !Array.isArray(v) || v.some((x) => typeof x !== "string"),
        )
      )
        throw new Error("Research notes must be text lists.");
      edit({
        ...bundle,
        design: {
          ...bundle.design,
          work: {
            ...bundle.design.work,
            stages: bundle.design.work.stages.map((s, i) => ({
              ...s,
              notes: next[`stage${i}Notes`] as string[],
              unknowns: next[`stage${i}Unknowns`] as string[],
              groups: s.groups.map((g, j) => ({
                ...g,
                items: g.key.startsWith("henry_proposal_")
                  ? g.items
                  : (next[`stage${i}Group${j}`] as string[]),
              })),
            })),
          },
        },
      });
    },
  });
  useHenryBinding({
    key: "offers",
    brandId: products.find((p) => p.id === product)?.brandId,
    summary: JSON.stringify({
      product,
      offers: rows.map((r) => ({
        id: r.id,
        name: r.definition.name,
        status: r.status,
      })),
      current: bundle?.offer.definition,
    }),
    editor:
      editable && bundle
        ? {
            key: `offer:${bundle.offer.id}:${bundle.offer.updatedAt}`,
            title: "Offer draft",
            fields: henryFields(qualificationEditor(bundle.offer.definition)),
          }
        : undefined,
    apply: (changes) => {
      if (!editable || !bundle)
        throw new Error("Open an editable offer draft first.");
      edit({
        ...bundle,
        offer: {
          ...bundle.offer,
          definition: Object.fromEntries(Object.entries(applyHenryFields(qualificationEditor(bundle.offer.definition), changes)).filter(([key, value]) => key in bundle.offer.definition || changes.some(c => c.key === key) || (value !== "" && !(Array.isArray(value) && !value.length)))),
        },
      });
    },
    actions: busy
      ? []
      : [
          ...rows
            .filter((r) => !r.archived)
            .map((r) => ({
              id: `offer:${r.id}`,
              label: `Review offer: ${String(r.definition.name ?? r.id)}`,
              run: () => open(r),
            })),
          {
            id: "offer:new",
            label: "Prepare a new offer",
            run: () => {
              if (discard()) {
                setBundle(undefined);
                setBriefIndex(undefined);
                setNewOffer(true);
              }
            },
          },
        ],
  });
  if (!api || !icp)
    return <p>Offer Architecture is unavailable in this connection.</p>;
  return (
    <section className="offer-page">
      <header>
        {!sharedHenry && <h1>Offer Architecture</h1>}
        <p>
          Shape what you offer, who it is for, and the right next step for them.
        </p>
      </header>
      {error && (
        <p role="alert" className="notice">
          {error}
        </p>
      )}
      {job && (["failed", "interrupted"].includes(job.status) || job.diagnostics?.some(d => d.outcome === "warning")) && (
        <details className="panel">
          <summary>Support details</summary>
          <p>Reference: {job.id}</p>
          {job.diagnostics?.filter(d => d.outcome === "failed" || d.outcome === "warning").map((d, i) => (
            <p key={i}>Step: {d.stage}. Reason: {d.code ?? "unknown"}.
              {d.httpStatus ? ` Provider status: ${d.httpStatus}.` : ""}
              {` Elapsed: ${Math.round(d.elapsedMs / 1000)} seconds.`}
              {d.issues?.map(issue => ` ${issue.field}: ${issue.code}.`).join("")}
            </p>
          ))}
        </details>
      )}
      {notice && (
        <p role="status" className="notice">
          {notice}
        </p>
      )}
      <div className="offer-toolbar offer-filters">
        <label>
          Product or service
          <select
            disabled={busy || reviewWorking || job?.status === "generating"}
            value={product}
            onChange={(e) => {
              if (discard()) {
                setError("");
                setProduct(e.target.value);
              }
            }}
          >
            <option value="">Choose a product</option>
            {products.map((p) => (
              <option value={p.id} key={p.id}>
                {p.definition.name}
              </option>
            ))}
          </select>
        </label>
        <label className="offer-check">
          <input
            type="checkbox"
            checked={archived}
            disabled={busy}
            onChange={(e) => {
              if (discard()) setArchived(e.target.checked);
            }}
          />
          Show archived
        </label>
      </div>
      {loading ? (
        <p role="status">Loading offers…</p>
      ) : !products.length ? (
        <p>Add and approve a product or service first.</p>
      ) : (
        <>
          {overview && (
            <section className="offer-panel offer-overview-objective">
              <details>
                <summary>Commercial objective</summary>
                <p>
                  {brief?.input.intent ||
                    "Describe your commercial objective to Henry to begin."}
                </p>
              </details>
              {permissions.canCreate && !archived && (
                <button
                  className="button secondary"
                  onClick={() => {
                    setBriefIndex(undefined);
                    setNewOffer(true);
                  }}
                  disabled={busy || job?.status === "generating"}
                >
                  Discuss offers with Henry
                </button>
              )}
            </section>
          )}
          {overview && (
            <div className="offer-list">
              <div className="offer-toolbar">
                <h2>Your offers</h2>
                {permissions.canUpdate && !archived && (
                  <button
                    disabled={!selected.length || busy}
                    onClick={() => archiveRows(selected)}
                  >
                    Archive selected ({selected.length})
                  </button>
                )}
              </div>
              {!rows.length && !brief?.interpretation?.offers.length && (
                <p>
                  No offers yet. Discuss your commercial objective with Henry to
                  prepare your first brief.
                </p>
              )}
              <div
                className="offer-table-scroll"
                role="region"
                aria-label="Offers; scroll horizontally to see all columns"
                tabIndex={0}
              >
                <table>
                  <thead>
                    <tr>
                      <th>Select</th>
                      <th>Offer</th>
                      <th>Commercial model</th>
                      <th>Status and version</th>
                      <th>Last updated</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {!archived &&
                      brief?.interpretation?.offers.map((proposal, index) => {
                        const linkedId =
                          brief.linkedOffers?.[String(index)] ??
                          proposal.existingOfferId;
                        if (
                          rows.some(
                            (row) =>
                              row.id === linkedId &&
                              !row.archived &&
                              row.status !== "retired",
                          )
                        )
                          return null;
                        return (
                          <tr key={`${brief.id}:${index}`}>
                            <td>—</td>
                            <td>
                              <button
                                disabled={busy || job?.status === "generating"}
                                onClick={() => {
                                  setBriefIndex(index);
                                  setNewOffer(true);
                                  setError("");
                                  setNotice("");
                                }}
                              >
                                {proposal.brief.name}
                              </button>
                            </td>
                            <td>To confirm</td>
                            <td>
                              {brief.status === "confirmed"
                                ? "Brief approved · Ready to develop"
                                : "Brief · Needs review"}
                            </td>
                            <td>
                              {new Date(brief.updatedAt).toLocaleDateString(
                                "en-GB",
                              )}
                            </td>
                            <td>Open brief to continue</td>
                          </tr>
                        );
                      })}
                    {rows.map((r) => (
                      <tr key={r.id}>
                        <td>
                          <input
                            aria-label={`Select ${r.definition.name}`}
                            type="checkbox"
                            disabled={
                              archived || busy || !permissions.canUpdate
                            }
                            checked={selected.includes(r.id)}
                            onChange={() => toggle(r.id, selected, setSelected)}
                          />
                        </td>
                        <td>
                          <button
                            onClick={() => open(r)}
                            disabled={busy || job?.status === "generating"}
                          >
                            {String(r.definition.name)}
                          </button>
                          <p className="muted">
                            {String(r.definition.headlineProposition ?? "")}
                          </p>
                        </td>
                        <td>{commercialModels(r.definition)}</td>
                        <td>
                          {r.archived ? "Archived" : fieldLabel(r.status)} · v
                          {r.revision}
                          {r.approvedRevision &&
                          r.approvedRevision !== r.revision
                            ? ` · Previously approved v${r.approvedRevision}`
                            : ""}
                        </td>
                        <td>
                          {new Date(r.updatedAt).toLocaleDateString("en-GB")}
                        </td>
                        <td>
                          {permissions.canUpdate && !r.archived && (
                            <button
                              disabled={busy}
                              onClick={() => archiveRows([r.id])}
                            >
                              Archive
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
          {newOffer && !archived && (
            <section className="offer-panel">
              <div className="offer-toolbar">
                <button
                  className="button secondary"
                  disabled={busy || reviewWorking}
                  onClick={openOverview}
                >
                  Back to offers overview
                </button>
              </div>
              <h2>
                {briefIndex === undefined
                  ? "Develop offers with Henry"
                  : "Offer brief"}
              </h2>
              <p>
                Review your proposed offers and choose which to develop next.
                Your saved briefs and offers remain available here.
              </p>
              <OfferBrief
                key={`${product}:${briefIndex ?? "conversation"}`}
                selectedIndex={briefIndex}
                onChange={setBrief}
                onDirty={setDirty}
                onWorking={setReviewWorking}
                api={api}
                w={w}
                product={product}
                onGenerate={generateFromBrief}
                researching={researching}
                researchingIndex={researchingIndex}
                generationDisabled={
                  busy ||
                  job?.status === "generating" ||
                  !permissions.generationAvailable ||
                  !products.find((p) => p.id === product)?.approvedRevision
                }
              />
              <details>
                <summary>Existing customer context (optional)</summary>
                <fieldset>
                  <legend>Existing customer profiles (optional)</legend>
                  {profiles
                    .filter((p) => p.approvedRevision)
                    .map((p) => (
                      <label className="offer-check" key={p.id}>
                        <input
                          type="checkbox"
                          checked={targets.includes(p.id)}
                          disabled={busy}
                          onChange={() => {
                            toggle(p.id, targets, setTargets);
                            setBuyerTargets([]);
                          }}
                        />
                        {p.definition.name}
                      </label>
                    ))}
                  {!profiles.some((p) => p.approvedRevision) && (
                    <p>
                      Your market hypothesis can be developed here. Create an
                      offer-specific customer profile after approving the offer.
                    </p>
                  )}
                </fieldset>
                {buyers.some(
                  (b) => b.approved && targets.includes(b.icpId),
                ) && (
                  <fieldset>
                    <legend>Buyer profiles (optional)</legend>
                    {buyers
                      .filter((b) => b.approved && targets.includes(b.icpId))
                      .map((b) => (
                        <label className="offer-check" key={b.id}>
                          <input
                            type="checkbox"
                            disabled={busy}
                            checked={buyerTargets.includes(b.id)}
                            onChange={() =>
                              toggle(b.id, buyerTargets, setBuyerTargets)
                            }
                          />
                          {b.name}
                        </label>
                      ))}
                  </fieldset>
                )}
              </details>
              <ResearchDocuments
                key={w}
                api={icp?.research}
                w={w}
                selected={researchDocuments}
                onSelect={setResearchDocuments}
                disabled={busy}
              />
              <label className="offer-field">
                Useful public pages (optional)
                <textarea
                  rows={2}
                  value={urls}
                  onChange={(e) => setUrls(e.target.value)}
                  placeholder="One https:// URL per line; up to six pages"
                />
              </label>
              <label className="offer-check">
                <input
                  type="checkbox"
                  checked={useCustomerPatterns}
                  disabled={busy}
                  onChange={(e) => setUseCustomerPatterns(e.target.checked)}
                />
                Include industry and region patterns from existing customer
                organisations, if available
              </label>
              <p className="muted">
                A bounded sample of existing customers can inform the draft; it
                is not a market estimate. Names and contact details are
                excluded.
              </p>
              <p className="muted">
                Research uses public product information. Documents and contact
                uploads remain separate; this does not import prospects or send
                messages.
              </p>
              {!permissions.generationAvailable && (
                <p>Generation is not configured in this environment.</p>
              )}
            </section>
          )}
          {researching && !newOffer && (
            <p role="status" className="offer-panel">
              Researching public sources and preparing your offer… You can
              return to this page while it finishes.
            </p>
          )}
          {bundle && <ResearchEvidencePanel api={research} w={w} type="offers" id={bundle.offer.id}/>}
          {bundle && (
            <article className="offer-panel">
              {
                <button
                  className="button secondary"
                  disabled={
                    busy || reviewWorking || job?.status === "generating"
                  }
                  onClick={openOverview}
                >
                  Back to offers overview
                </button>
              }
              <div className="offer-toolbar offer-heading">
                <h2>{String(bundle.offer.definition.name || "Untitled offer")}</h2>
                <Status>
                  {fieldLabel(bundle.offer.status)}
                  {bundle.offer.archived ? " · Archived" : ""}
                  {dirty ? " · Unsaved edits" : ""}
                </Status>
              </div>
              {bundle.sourceChanged && (
                <p role="alert">
                  An approved source has changed. Generate a fresh draft before
                  approving this offer.
                </p>
              )}
              {bundle.refinement && (
                <OfferRefinement
                  bundle={bundle}
                  editable={editable}
                  onChange={edit}
                />
              )}
              {bundle.design && (
                <details>
                  <summary>How this offer is developed</summary>
                  <OfferMethodology
                    api={api}
                    workspaceId={w}
                    design={bundle.design}
                  />
                </details>
              )}
              <nav className="offer-tabs" aria-label="Offer sections">
                {(Object.keys(sections) as (keyof typeof sections)[]).map(
                  (t) => (
                    <button
                      key={t}
                      aria-pressed={tab === t}
                      onClick={() => setTab(t)}
                    >
                      {t}
                      {saveAttempted &&
                        sections[t].some(
                          (k) =>
                            missingOfferFields(bundle.offer.definition, {
                              bsonType: "object",
                              properties: { [k]: specs[k]! },
                              required: specifications.definition.required,
                            }).length > 0,
                        ) &&
                        " · Needs attention"}
                    </button>
                  ),
                )}
              </nav>
              {tab === "Offer summary" && <OfferSummary bundle={bundle} workspaceId={w} dirty={dirty} busy={busy} canRegister={permissions.canUpdate} onRegister={() => void run(async () => {setBundle(await api.registerOutput(w,bundle,controller.current.signal)); setNotice("Offer summary is available in the Library.");})} />}
              {tab !== "Research & review" && tab !== "Offer summary" && (
                <OfferValidation.Provider value={saveAttempted}>
                  <OfferFields
                    required={specifications.definition.required}
                    specs={specs}
                    keys={sections[tab]}
                    value={bundle.offer.definition}
                    disabled={!editable}
                    onChange={(v) =>
                      edit({
                        ...bundle,
                        offer: { ...bundle.offer, definition: v },
                      })
                    }
                  />
                </OfferValidation.Provider>
              )}
              {work && bundle.design && (
                <div hidden={tab !== "Research & review"}>
                  <OfferReview
                    key={bundle.offer.id}
                    onWorking={setReviewWorking}
                    onUnsaved={reviewUnsaved}
                    bundle={bundle}
                    brandId={
                      products.find((p) => p.id === product)?.brandId ?? ""
                    }
                    editable={editable}
                    onSave={async (nextWork) => {
                      if (!bundle.design || lock.current)
                        throw new Error("Wait for the current save to finish.");
                      lock.current = true;
                      setBusy(true);
                      setError("");
                      try {
                        const saved = await api.save(
                          w,
                          {
                            id: bundle.offer.id,
                            expectedUpdatedAt: bundle.offer.updatedAt,
                            designId: bundle.design.id,
                            expectedDesignUpdatedAt: bundle.design.updatedAt,
                            definition: bundle.offer.definition,
                            work: nextWork,
                          },
                          controller.current.signal,
                        );
                        setBundle(saved);
                        setRows((old) =>
                          old.map((r) =>
                            r.id === saved.offer.id ? saved.offer : r,
                          ),
                        );
                        setDirty(false);
                        setNotice(
                          "Your review is saved. Offer approval is separate.",
                        );
                      } catch {
                        throw new Error(
                          "Could not save this review. Your work remains here. If another session changed the offer, reopen it before continuing.",
                        );
                      } finally {
                        lock.current = false;
                        setBusy(false);
                      }
                    }}
                  />
                  <details>
                    <summary>
                      Targeting, research and supporting evidence
                    </summary>
                    <h3>Targeting and research brief</h3>
                    <p>
                      Guidance for future research and decisions. An approved
                      brief does not select prospects or start communications.
                    </p>
                    <div className="offer-fields">
                      {work.stages.flatMap((s) =>
                        s.groups
                          .filter((g) => !g.key.startsWith("henry_proposal_"))
                          .map((g) => (
                            <label
                              className="offer-field"
                              key={s.stageKey + g.key}
                            >
                              {fieldLabel(g.name)}
                              <OfferLines
                                rows={4}
                                disabled={!editable}
                                value={g.items}
                                onChange={(items) =>
                                  edit({
                                    ...bundle,
                                    design: {
                                      ...bundle.design!,
                                      work: {
                                        ...work,
                                        stages: work.stages.map((x) =>
                                          x.stageKey === s.stageKey
                                            ? {
                                                ...x,
                                                groups: x.groups.map((y) =>
                                                  y.key === g.key
                                                    ? { ...y, items }
                                                    : y,
                                                ),
                                              }
                                            : x,
                                        ),
                                      },
                                    },
                                  })
                                }
                              />
                            </label>
                          )),
                      )}
                    </div>
                    <details>
                      <summary>Competitor comparison and evidence</summary>
                      {work.competitiveAnalysis ? (
                        <OfferFields
                          specs={
                            specifications.competition.properties as Record<
                              string,
                              FieldSpec
                            >
                          }
                          value={work.competitiveAnalysis}
                          disabled={!editable}
                          onChange={(v) =>
                            edit({
                              ...bundle,
                              design: {
                                ...bundle.design!,
                                work: { ...work, competitiveAnalysis: v },
                              },
                            })
                          }
                        />
                      ) : (
                        <p>
                          No supported comparison was found. Add relevant public
                          competitor or substitute pages when generating a fresh
                          draft. Approval requires a supported comparison.
                        </p>
                      )}
                    </details>
                  </details>
                </div>
              )}
              <footer className="offer-toolbar">
                {saveError && (
                  <p role="alert" className="offer-save-error">
                    {saveError}
                  </p>
                )}
                {editable && (
                  <button
                    className="button-primary"
                    disabled={!dirty || busy}
                    onClick={() => void persist()}
                  >
                    Save changes
                  </button>
                )}
                {bundle.offer.status === "draft" &&
                  !bundle.offer.archived &&
                  permissions.canApprove && (
                    <button
                      disabled={
                        busy ||
                        dirty ||
                        bundle.sourceChanged ||
                        !work?.competitiveAnalysis ||
                        !work.stages.length ||
                        work.stages.some(
                          (s) =>
                            s.status !== "completed" ||
                            !s.decisionRationale?.trim(),
                        )
                      }
                      onClick={() => void transition("approve")}
                    >
                      Approve offer
                    </button>
                  )}
                {bundle.offer.status === "approved" &&
                  !bundle.offer.archived &&
                  permissions.canUpdate && (
                    <button
                      disabled={busy}
                      onClick={() => void transition("revise")}
                    >
                      Edit a new revision
                    </button>
                  )}
                {bundle.offer.approvedRevision && (
                  <button
                    disabled={busy}
                    onClick={() =>
                      void run(async () =>
                        setHistory(
                          await api.revision(
                            w,
                            bundle.offer.id,
                            bundle.offer.approvedRevision!,
                            controller.current.signal,
                          ),
                        ),
                      )
                    }
                  >
                    View approved version
                  </button>
                )}
              </footer>
              {editable && (
                <p className="muted">
                  Save anytime. Approval requires completed decisions and
                  supported competitor research in Research & review.
                </p>
              )}
              {history && (
                <section className="offer-panel">
                  <h3>Approved version {history.snapshot.revision}</h3>
                  <OfferFields
                    specs={specs}
                    keys={sections[tab]}
                    value={history.snapshot.definition}
                    disabled
                    onChange={() => {}}
                  />
                </section>
              )}
            </article>
          )}
        </>
      )}
    </section>
  );
}
