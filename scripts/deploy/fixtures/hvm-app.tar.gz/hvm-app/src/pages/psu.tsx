import {ResearchEvidencePanel} from "../components/research-evidence";
import type {ResearchGateway} from "../data/research";
import { PsuResearchProgress } from "../components/psu-research-progress";
import { latestPsuJobs } from "../data/psu-jobs";
import { useHenryBinding, useHenryAvailable, useHenryBrand, henryFields, applyHenryFields } from "../components/workspace-henry";
import { ProfileDelete } from "../components/profile-delete";
import { useCallback, useEffect, useRef, useState } from "react";
import type {
  PsuGateway,
  PsuOffering,
  PsuJob,
  PsuPreparation,
} from "../data/psu";
import type { WebsiteReview } from "../data/psu-website";
import { useRefreshingResource } from "../data/use-refreshing-resource";
import { ProductReview } from "../components/psu-website-review";
import { PsuUnderstanding } from "../components/psu-understanding";
import { Company, PrimaryProduct } from "../components/psu-company";
import { CompanyReferenceProvider } from "../components/company-reference-provider";
import { Empty, Failure, Loading } from "../components/ui";
// Saved detail fields survive edits and job-history pagination. A saved detailed
// job also covers profiles where the reviewer excluded all optional detail fields.
function hasDetailedProfile(offering: PsuOffering, jobs: PsuJob[]) {
  const fields = [
    "whatItIs",
    "whatCustomerBuys",
    "deliverables",
    "desiredOutcomes",
    "deliveryModes",
    "implementationExplanation",
    "technologyRole",
    "supplierRole",
    "customerRole",
    "capabilities",
    "boundaries",
    "explicitExclusions",
    "approvedClaims",
    "buyerNextSteps",
  ];
  return (
    fields.some((field) => {
      const value = offering.definition[field];
      return typeof value === "string"
        ? value.trim().length > 0
        : Array.isArray(value) && value.length > 0;
    }) ||
    jobs.some(
      (job) =>
        job.status === "saved" &&
        job.input.depth === "detailed" &&
        job.offeringId === offering.id,
    )
  );
}
export function PsuPage({
  api,
  workspaceId,
  queen,
  research,
}: {
  api?: PsuGateway;
  workspaceId: string;
  queen: boolean;
  research?:ResearchGateway;
}) {
  return api ? (
    <CompanyReferenceProvider key={workspaceId} api={api} w={workspaceId}>
      <Workspace research={research} api={api} w={workspaceId} queen={queen} />
    </CompanyReferenceProvider>
  ) : (
    <Empty title="Products & services unavailable">
      Please try again shortly.
    </Empty>
  );
}
function Workspace({
  api,
  w,
  queen,
  research,
}: {
  api: PsuGateway;
  w: string;
  queen: boolean;
  research?:ResearchGateway;
}) {
  const sharedHenry=useHenryAvailable(),carriedBrand=useHenryBrand();
  const [includeWebResearch, setWebResearch] = useState(false);
  const [productId, setProductId] = useState("");
  const [generationDepth, setGenerationDepth] = useState<
    "summary" | "detailed"
  >("summary");
  const intake = useRef<HTMLFormElement>(null);
  const [adding, setAdding] = useState(false);
  const [fromCompany, setFromCompany] = useState(false);
  const [tab, setTab] = useState<"company" | "products">("company");
  const [revision, setRevision] = useState(0),
    [brand, setBrand] = useState(carriedBrand),
    [url, setUrl] = useState(""),
    [support, setSupport] = useState(""),
    [name, setName] = useState(""),
    [notes, setNotes] = useState("");
  const [dismissedFailures, setDismissedFailures] = useState<Set<string>>(
    new Set(),
  );
  const [busy, setBusy] = useState(false),
    [error, setError] = useState<unknown>();
  const pending = useRef<AbortController | undefined>(undefined),
    request = useRef<{ body: string; key: string } | undefined>(undefined);
  const refresh = useCallback(() => setRevision((v) => v + 1), []);
  const deleted = useCallback(() => {
    setProductId(""); setFromCompany(false); setAdding(false);
    setName(""); setUrl(""); setNotes(""); setSupport(""); setError(undefined);
    request.current = undefined;
    refresh();
  }, [refresh]);
  const load = useCallback(
    (s: AbortSignal) => {
      void revision;
      return Promise.all([
        api.brands(w, s),
        api.offerings(w, s),
        api.jobs(w, s),
      ]);
    },
    [api, w, revision],
  );
  const state = useRefreshingResource(load);
  const initialJobsLoaded = useRef(false);
  const historicalFailures = useRef(new Set<string>());
  useEffect(() => {
    if (state.state !== "ready" || initialJobsLoaded.current) return;
    initialJobsLoaded.current = true;
    historicalFailures.current = new Set(state.data[2].items.filter(j => ["failed", "interrupted"].includes(j.status)).map(j => j.id));
  }, [state]);
  useEffect(() => {
    if (state.state === "ready" && productId && !state.data[1].some(o => o.id === productId)) {
      setProductId(""); setFromCompany(false); setAdding(false); setName(""); setUrl(""); setNotes(""); setSupport("");
    }
  }, [state, productId]);
  useEffect(() => () => pending.current?.abort(), []);
  const generating =
    state.state === "ready" &&
    state.data[2].items.some((j) => j.status === "generating");
  useEffect(() => {
    if (!generating) return;
    const timer = setInterval(refresh, 3000);
    return () => clearInterval(timer);
  }, [generating, refresh]);
  useHenryBinding({key:"products",brandId:brand || (state.state === "ready" && state.data[0].length === 1 ? state.data[0][0]!.id : ""),summary:JSON.stringify({tab,productId,url,name,notes}),
    editor:tab==="products"&&adding&&!busy?{key:`product-input:${productId||"new"}`,title:"Product generation details",fields:henryFields({name,url,notes})}:undefined,
    apply:changes=>{const next=applyHenryFields({name,url,notes},changes);setName(next.name);setUrl(next.url);setNotes(next.notes);},
    actions:busy?[]:[{id:"psu:company",label:"Review company",run:()=>setTab("company")},{id:"psu:products",label:"Review products and services",run:()=>setTab("products")},{id:"psu:add",label:"Add a product",run:()=>{setTab("products");setAdding(true);}}],
  });
  if (state.state === "loading") return <Loading />;
  if (state.state === "error") return <Failure error={state.error} />;
  const [brands, offerings, jobs] = state.data,
    selected = brand || (brands.length === 1 ? brands[0]!.id : "");
  const product = offerings.find(
    (o) =>
      o.id === productId && o.brandId === selected && o.status !== "retired",
  );
  const needsGeneration = product
    ? !hasDetailedProfile(product, jobs.items)
    : fromCompany;
  async function startGeneration(
    input: Extract<PsuPreparation, { mode: "create" }>,
  ) {
    if (pending.current || generating) return;
    const c = new AbortController();
    pending.current = c;
    setBusy(true);
    setError(undefined);
    setDismissedFailures(
      (previous) =>
        new Set([
          ...previous,
          ...jobs.items
            .filter(
              (j) =>
                j.input.brandId === selected &&
                ["failed", "interrupted"].includes(j.status),
            )
            .map((j) => j.id),
        ]),
    );
    const body = JSON.stringify(input);
    if (request.current?.body !== body)
      request.current = { body, key: crypto.randomUUID() };
    try {
      await api.generate(w, input, request.current!.key, c.signal);
      if (!c.signal.aborted) {
        request.current = undefined;
        refresh();
      }
    } catch (e) {
      if (!c.signal.aborted) setError(e);
    } finally {
      pending.current = undefined;
      if (!c.signal.aborted) setBusy(false);
    }
  }
  return (
    <div className="psu-workspace">
      {tab==="products"&&productId&&<ResearchEvidencePanel api={research} w={w} type="offerings" id={productId}/>}
      <header className="psu-intro">
        {!sharedHenry && <h1>Company, products &amp; services</h1>}
        <p>Build a clear, agreed description of what your business offers.</p>
        <label className="psu-brand-selector">
          Brand
          <select
            required
            value={selected}
            onChange={(e) => {
              setBrand(e.target.value);
              setProductId("");
              setAdding(false);
              setFromCompany(false);
              setUrl("");
              setName("");
              setNotes("");
              setSupport("");
            }}
          >
            <option value="">Select brand</option>
            {brands.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
        </label>
      </header>
      <div
        className="tabs psu-company-tabs"
        role="tablist"
        aria-label="Company and products"
        onKeyDown={(e) => {
          if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(e.key))
            return;
          e.preventDefault();
          const next =
            e.key === "Home"
              ? "company"
              : e.key === "End"
                ? "products"
                : tab === "company"
                  ? "products"
                  : "company";
          setTab(next);
          const buttons =
            e.currentTarget.querySelectorAll<HTMLButtonElement>("button");
          buttons[next === "company" ? 0 : 1]?.focus();
        }}
      >
        <button
          role="tab"
          id="company-tab"
          aria-controls="company-products-panel"
          tabIndex={tab === "company" ? 0 : -1}
          aria-selected={tab === "company"}
          onClick={() => setTab("company")}
        >
          Company
        </button>
        <button
          role="tab"
          id="products-tab"
          aria-controls="company-products-panel"
          tabIndex={tab === "products" ? 0 : -1}
          aria-selected={tab === "products"}
          onClick={() => setTab("products")}
        >
          Products &amp; services
        </button>
      </div>
      <div
        id="company-products-panel"
        role="tabpanel"
        aria-labelledby={tab === "company" ? "company-tab" : "products-tab"}
      >
        {tab === "company" ? (
          selected ? (
            <Company
              key={selected}
              api={api}
              w={w}
              brandId={selected}
              jobs={jobs.items.filter((j) => j.input.brandId === selected)}
              available={jobs.generationAvailable}
              generating={generating}
              queen={queen}
              refresh={refresh}
              onProduct={(value) => {
                if (value !== undefined) {
                  setUrl(value);
                  setProductId("");
                  setFromCompany(true);
                  setGenerationDepth("summary");
                  setName(brands.find((b) => b.id === selected)?.name ?? "");
                  setNotes("");
                  setSupport("");
                }
                setTab("products");
              }}
            />
          ) : (
            <p>Select a brand to view its company details.</p>
          )
        ) : (
          <>
            <div className="psu-product-toolbar">
              <label>
                Product or service
                <select
                  value={product?.id ?? ""}
                  onChange={(e) => {
                    const next = offerings.find((o) => o.id === e.target.value);
                    setFromCompany(false);
                    setProductId(next?.id ?? "");
                    setGenerationDepth("summary");
                    setUrl(String(next?.definition.websiteUrl ?? ""));
                    setName(String(next?.definition.name ?? ""));
                    setNotes("");
                    setSupport("");
                    setError(undefined);
                  }}
                >
                  <option value="">Select a product or service</option>
                  {offerings
                    .filter(
                      (o) => o.brandId === selected && o.status !== "retired",
                    )
                    .map((o) => (
                      <option key={o.id} value={o.id}>
                        {String(o.definition.name)}
                      </option>
                    ))}
                </select>
              </label>
              <button
                type="button"
                disabled={!selected || adding}
                onClick={() => setAdding(true)}
              >
                Add Product
              </button>
            </div>
            {adding && (
              <NewProduct
                key={`new-product:${selected}`}
                api={api}
                w={w}
                brandId={selected}
                onCancel={() => setAdding(false)}
                onCreated={(id, website, label) => {
                  setAdding(false);
                  setGenerationDepth("summary");
                  setFromCompany(false);
                  setProductId(id);
                  setUrl(website);
                  setName(label);
                  setNotes("");
                  setSupport("");
                  refresh();
                }}
              />
            )}
            {needsGeneration && generationDepth === "detailed" && product && (
              <div className="panel">
                <h2>
                  Detailed product profile · {String(product.definition.name)}
                </h2>
                <p>
                  Use your saved summary and website to explore what customers
                  buy, delivery, responsibilities, technology, scope and claims.
                  Review the result before approving it.
                </p>
              </div>
            )}
            {needsGeneration && (
              <form
                ref={intake}
                className="panel psu-intake"
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (pending.current || (!product && !fromCompany)) return;
                  const input = {
                    mode: "create" as const,
                    depth: ((
                      e.nativeEvent as SubmitEvent
                    ).submitter?.getAttribute("data-depth") === "detailed"
                      ? "detailed"
                      : generationDepth) as "summary" | "detailed",
                    brandId: selected,
                    ...(product
                      ? {
                          offeringId: product.id,
                          expectedUpdatedAt: product.updatedAt,
                        }
                      : {}),
                    workingLabel:
                      name.trim() ||
                      brands.find((b) => b.id === selected)?.name ||
                      "Product or service",
                    orientation: notes,
                    includeWebResearch,
                    websiteUrls: [
                      url.trim(),
                      ...support
                        .split("\n")
                        .map((v) => v.trim())
                        .filter(Boolean),
                    ],
                  };
                  await startGeneration(input);
                }}
              >
                <h2>
                  {generationDepth === "detailed"
                    ? "Generate the detailed profile"
                    : "Generate a product summary"}
                </h2>
                {!product && !fromCompany && (
                  <p>
                    Select a product above, or use Add Product to create one.
                  </p>
                )}
                {fromCompany && !product && (
                  <p>
                    We’ll save a short product summary for review. You can
                    generate the deeper product details as a separate step.
                  </p>
                )}
                <fieldset
                  disabled={busy || generating || (!product && !fromCompany)}
                >
                  <legend className="sr-only">Product details</legend>
                  <label className="psu-research-option"><input type="checkbox" checked={includeWebResearch} onChange={e=>setWebResearch(e.target.checked)} /> Also find independent mentions and comparisons</label>
                  <label>
                    Product or service URL
                    <input
                      type="url"
                      pattern="https://.*"
                      required
                      maxLength={2048}
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                    />
                  </label>
                  <button
                    className="button"
                    disabled={
                      busy ||
                      generating ||
                      !jobs.generationAvailable ||
                      !selected ||
                      (!product && !fromCompany) ||
                      !url.trim()
                    }
                  >
                    {busy || generating
                      ? "Generating…"
                      : generationDepth === "detailed"
                        ? "Generate detailed product profile"
                        : "Generate Summary"}
                  </button>
                  {product && generationDepth === "summary" && (
                    <button
                      type="submit"
                      className="button secondary"
                      style={{ gridColumn: "1 / -1", justifySelf: "start" }}
                      data-depth="detailed"
                      disabled={
                        busy ||
                        generating ||
                        !jobs.generationAvailable ||
                        !url.trim()
                      }
                    >
                      Generate detailed product profile
                    </button>
                  )}
                  <details>
                    <summary>Additional context (optional)</summary>
                    <details>
                      <summary>Add supporting pages (optional)</summary>
                      <label>
                        Up to five additional public page URLs, one per line
                        <textarea
                          maxLength={10244}
                          value={support}
                          onChange={(e) => setSupport(e.target.value)}
                        />
                      </label>
                    </details>
                    <label>
                      Product or service name (optional)
                      <input
                        maxLength={200}
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                      />
                    </label>
                    <label>
                      What should we know? (optional)
                      <textarea
                        maxLength={4000}
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                      />
                    </label>
                  </details>
                </fieldset>
                <p>
                  We’ll read the public pages and suggest details for you to
                  review.
                </p>
                {!jobs.generationAvailable && (
                  <p>
                    AI generation is temporarily unavailable. You can still
                    view, edit and approve saved products.
                  </p>
                )}
                {error ? <Failure error={error} /> : null}
              </form>
            )}
            {busy && (
              <div className="panel" role="status">
                Starting your product summary…
              </div>
            )}
            {latestPsuJobs(jobs.items)
              .filter((j) => (!busy && !generating) || j.status === "generating")
              .filter(
                (job) =>
                  !["failed", "interrupted"].includes(job.status) ||
                  (!busy &&
                    !generating &&
                    !dismissedFailures.has(job.id) &&
                    !jobs.items.some(
                      (newer) =>
                        newer.createdAt > job.createdAt &&
                        newer.input.brandId === job.input.brandId &&
                        newer.input.kind === job.input.kind &&
                        (job.input.offeringId
                          ? newer.input.offeringId === job.input.offeringId
                          : newer.input.websiteUrls[0] ===
                            job.input.websiteUrls[0]),
                    )),
              )
              .filter(
                (j) =>
                  j.input.brandId === selected &&
                  j.status !== "saved" &&
                  !j.productDeleted &&
                  (j.input.kind !== "company" || j.draft),
              )
              .map((job) => (
                <section key={job.id}>
                  <PsuResearchProgress job={job} />
                  {job.draft ? (
                    <>
                      {job.status === "review" && <p role="status">
                        Generation has finished. Review the suggestions below, then save your product draft.
                      </p>}
                      <ProductReview
                        headerAction={queen && job.status === "review" ? <ProfileDelete api={api} w={w} kind="product-draft" id={job.id} name={job.input.workingLabel || "Generated product"} onDeleted={deleted} /> : undefined}
                        competitorSuggestions={
                          job.input.kind === "company"
                            ? job.productCompetitorSuggestions
                            : job.competitorSuggestions
                        }
                        key={job.id}
                        researching={job.status !== "review"}
                        draft={{
                          ...job.draft,
                          fields: [
                            ...job.draft.fields,
                            ...(job.input.depth === "detailed"
                              ? Object.entries(
                                  offerings.find(
                                    (o) => o.id === job.input.offeringId,
                                  )?.definition ?? {},
                                )
                                  .filter(
                                    ([field]) =>
                                      field !== "websiteUrl" &&
                                      !job.draft!.fields.some(
                                        (f) => f.binding.field === field,
                                      ),
                                  )
                                  .map(([field, value]) => ({
                                    binding: {
                                      field,
                                      value: value as string | string[],
                                    },
                                    basis: "interpretation" as const,
                                    support: [],
                                  }))
                              : []),
                            ...(job.draft.fields.some(
                              (f) => f.binding.field === "websiteUrl",
                            )
                              ? []
                              : [
                                  {
                                    binding: {
                                      field: "websiteUrl",
                                      value: job.input.websiteUrls[0] ?? "",
                                    },
                                    basis: "interpretation" as const,
                                    support: [],
                                  },
                                ]),
                          ],
                        }}
                        onSave={(rows, s) =>
                          api.saveReview(
                            w,
                            job,
                            rows
                              .filter((r) => r.included)
                              .map((r) => r.binding),
                            s,
                          )
                        }
                        onChanged={refresh}
                      />
                      {job.unavailable?.length ? (
                        <p>
                          Some pages could not be read:{" "}
                          {job.unavailable.join(", ")}
                        </p>
                      ) : null}
                    </>
                  ) : job.status === "generating" ? null : (
                    <div className="panel">
                      <h2>{job.input.workingLabel}</h2>
                      {!historicalFailures.current.has(job.id) && <p>
                        {productFailureMessage(job.failureCode)} No new product
                        draft was saved.
                      </p>}
                      <button
                        onClick={() => {
                          setBrand(job.input.brandId);
                          setProductId(job.input.offeringId ?? "");
                          setFromCompany(!job.input.offeringId);
                          setAdding(false);
                          setError(undefined);
                          setName(job.input.workingLabel);
                          setNotes(job.input.orientation);
                          setUrl(job.input.websiteUrls[0] ?? "");
                          setSupport(job.input.websiteUrls.slice(1).join("\n"));
                        }}
                      >
                        Use these details again
                      </button>
                    </div>
                  )}
                </section>
              ))}
            {jobs.hasMore && <p>Showing the latest 100 generation requests.</p>}
            {selected && offerings.some((o) => o.brandId === selected) && (
              <PrimaryProduct
                key={`primary-product:${selected}`}
                api={api}
                w={w}
                brandId={selected}
                products={offerings.filter(
                  (o) => o.brandId === selected && o.status !== "retired",
                )}
              />
            )}
            <section className="panel">
              <h2>Your products/services</h2>
              {!offerings.some((o) => o.brandId === selected) && (
                <Empty title="Your first product starts here">
                  Use Add Product to create your first product or service.
                </Empty>
              )}
              {offerings
                .filter((o) => o.brandId === selected)
                .map((o) => (
                  <Offering
                    key={`${o.id}:${o.updatedAt}`}
                    api={api}
                    w={w}
                    offering={o}
                    queen={queen}
                    hasDetail={hasDetailedProfile(o, jobs.items)}
                    detailBusy={busy || generating}
                    detailError={productId === o.id ? error : undefined}
                    onDetail={() => {
                      setProductId(o.id);
                      setFromCompany(false);
                      setGenerationDepth("detailed");
                      setUrl(String(o.definition.websiteUrl ?? ""));
                      setName(String(o.definition.name));
                      setNotes("");
                      setSupport("");
                      setError(undefined);
                      const savedUrl = String(
                        o.definition.websiteUrl ?? "",
                      ).trim();
                      if (savedUrl) {
                        void startGeneration({
                          mode: "create",
                          depth: "detailed",
                          brandId: selected,
                          offeringId: o.id,
                          expectedUpdatedAt: o.updatedAt,
                          workingLabel: String(o.definition.name),
                          orientation: "",
                          websiteUrls: [savedUrl],
                        });
                        return;
                      }
                      requestAnimationFrame(() => {
                        intake.current?.scrollIntoView({
                          behavior: "smooth",
                          block: "start",
                        });
                        intake.current
                          ?.querySelector<HTMLInputElement>("input[type=url]")
                          ?.focus({ preventScroll: true });
                      });
                    }}
                    refresh={refresh}
                    onDeleted={deleted}
                  />
                ))}
            </section>
          </>
        )}
      </div>
    </div>
  );
}
function Offering({
  onDeleted,
  api,
  w,
  offering: o,
  queen,
  refresh,
  onDetail,
  detailBusy,
  hasDetail,
  detailError,
}: {
  api: PsuGateway;
  w: string;
  offering: PsuOffering;
  onDeleted: () => void;
  queen: boolean;
  refresh: () => void;
  onDetail: () => void;
  detailBusy: boolean;
  hasDetail: boolean;
  detailError?: unknown;
}) {
  const [editing, setEditing] = useState(false);
  useHenryBinding({key:`product:${o.id}`,summary:JSON.stringify({product:o.definition.name,definition:o.definition}),
    actions:!detailBusy?[{id:`product:edit:${o.id}`,label:`Edit ${o.definition.name}`,run:()=>setEditing(true)}]:[],
  });
  const draft: WebsiteReview = {
    kind: "psu_website_review_draft",
    version: 1,
    approval: "not_approved",
    digest: "0".repeat(64),
    fields: Object.entries(o.definition)
      .filter(([, v]) => typeof v === "string" || Array.isArray(v))
      .map(([field, value]) => ({
        binding: { field, value: value as string | string[] },
        basis: "interpretation",
        support: [],
      })),
    unknowns: [],
    questions: [],
  };
  return (
    <article className="panel">
      <div className="profile-card-heading"><h3>{String(o.definition.name)}</h3>{queen && <ProfileDelete api={api} w={w} kind="product" id={o.id} name={String(o.definition.name)} onDeleted={onDeleted} />}</div>
      <p>
        {o.status === "approved" ? "Approved" : "Draft"} · Version {o.revision}
      </p>
      {o.status !== "retired" && !hasDetail && (
        <div className="form-actions psu-detail-actions">
          <button className="button" onClick={onDetail} disabled={detailBusy}>
            {detailBusy ? "Generating…" : "Build detailed product profile"}
          </button>
        </div>
      )}
      {detailError ? <Failure error={detailError} /> : null}
      {editing ? (
        <ProductReview
          editing
          draft={draft}
          onSave={(rows, s) =>
            api.update(
              w,
              o,
              Object.fromEntries(
                rows
                  .filter((r) => r.included)
                  .map((r) => [r.binding.field, r.binding.value]),
              ),
              s,
            )
          }
          onChanged={refresh}
        />
      ) : (
        <PsuUnderstanding definition={o.definition} />
      )}
      {o.status === "draft" && !editing && (
        <button onClick={() => setEditing(true)}>Edit details</button>
      )}
      {queen && o.status === "draft" && !editing && (
        <Action
          label="Approve product or service"
          perform={(s) => api.approve(w, o, s)}
          onChanged={refresh}
        />
      )}
      {o.status === "approved" && (
        <Action
          label="Create a new draft to edit"
          perform={(s) => api.revise(w, o, s)}
          onChanged={refresh}
        />
      )}
      {o.evidence?.length ? <Evidence api={api} w={w} offering={o} /> : null}
      {o.approvedRevision && <History api={api} w={w} offering={o} />}
    </article>
  );
}
function History({
  api,
  w,
  offering: o,
}: {
  api: PsuGateway;
  w: string;
  offering: PsuOffering;
}) {
  const [selected, setSelected] = useState(o.approvedRevision!),
    [snapshot, setSnapshot] = useState<PsuOffering>(),
    [error, setError] = useState<unknown>();
  return (
    <details>
      <summary>
        Version history
        {o.status === "draft" ? " — the approved version remains active" : ""}
      </summary>
      <select
        aria-label="Approved version"
        value={selected}
        onChange={(e) => setSelected(Number(e.target.value))}
      >
        {Array.from({ length: o.approvedRevision! }, (_, i) => i + 1).map(
          (n) => (
            <option key={n} value={n}>
              Version {n}
            </option>
          ),
        )}
      </select>
      <Action
        label="View version"
        perform={async (s) => {
          try {
            setSnapshot(await api.revision(w, o, selected, s));
            setError(undefined);
          } catch (e) {
            setError(e);
          }
        }}
        onChanged={() => {}}
      />
      {snapshot && <PsuUnderstanding definition={snapshot.definition} />}{" "}
      {error ? <Failure error={error} /> : null}
    </details>
  );
}
function Action({
  label,
  perform,
  onChanged,
}: {
  label: string;
  perform: (s: AbortSignal) => Promise<unknown>;
  onChanged: () => void;
}) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState<unknown>();
  const pending = useRef<AbortController | undefined>(undefined);
  useEffect(() => () => pending.current?.abort(), []);
  return (
    <>
      <button
        disabled={busy}
        onClick={async () => {
          if (pending.current) return;
          const c = new AbortController();
          pending.current = c;
          setBusy(true);
          setError(undefined);
          try {
            await perform(c.signal);
            if (!c.signal.aborted) onChanged();
          } catch (e) {
            if (!c.signal.aborted) setError(e);
          } finally {
            pending.current = undefined;
            if (!c.signal.aborted) setBusy(false);
          }
        }}
      >
        {busy ? "Working…" : label}
      </button>
      {error ? <Failure error={error} /> : null}
    </>
  );
}

function Evidence({
  api,
  w,
  offering,
}: {
  api: PsuGateway;
  w: string;
  offering: PsuOffering;
}) {
  const [drafts, setDrafts] = useState<WebsiteReview[]>([]),
    [error, setError] = useState<unknown>();
  return (
    <details>
      <summary>Sources and review history</summary>
      <p>
        Sources support the original suggestions. Your later edits are recorded
        separately.
      </p>
      <Action
        label="View source excerpts"
        perform={async (s) => {
          try {
            const ids = [
              ...new Set(
                (offering.evidence ?? [])
                  .map((e) => e.sourceReference)
                  .filter((v): v is string => !!v?.startsWith("psu_review:"))
                  .map((v) => v.slice(11)),
              ),
            ];
            const jobs = await Promise.all(ids.map((id) => api.job(w, id, s)));
            setDrafts(jobs.flatMap((j) => (j.draft ? [j.draft] : [])));
            setError(undefined);
          } catch (e) {
            setError(e);
          }
        }}
        onChanged={() => {}}
      />
      {drafts
        .flatMap((d) => d.fields)
        .map((f, i) => (
          <section key={i}>
            <h4>{f.binding.field.replace(/([A-Z])/g, " $1")}</h4>
            {f.support.map((source, n) => (
              <div key={n}>
                <blockquote>{source.quote}</blockquote>
                <a href={source.url} target="_blank" rel="noopener noreferrer">
                  View original source
                </a>
              </div>
            ))}
          </section>
        ))}
      <ul>
        {offering.evidence?.map((e, i) => (
          <li key={i}>
            {e.field.replace(/([A-Z])/g, " $1")} ·{" "}
            {e.verification.replaceAll("_", " ")} ·{" "}
            {new Date(e.observedAt).toLocaleDateString()}
          </li>
        ))}
      </ul>
      {error ? <Failure error={error} /> : null}
    </details>
  );
}

function NewProduct({
  api,
  w,
  brandId,
  onCancel,
  onCreated,
}: {
  api: PsuGateway;
  w: string;
  brandId: string;
  onCancel: () => void;
  onCreated: (id: string, url: string, name: string) => void;
}) {
  const [name, setName] = useState(""),
    [description, setDescription] = useState(""),
    [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false),
    [error, setError] = useState<unknown>();
  const request = useRef<{ body: string; key: string } | undefined>(undefined);
  const saving = useRef(false);
  return (
    <form
      className="panel psu-intake"
      aria-label="New product"
      onSubmit={async (e) => {
        e.preventDefault();
        if (saving.current) return;
        saving.current = true;
        setBusy(true);
        setError(undefined);
        const definition = {
          name: name.trim(),
          description: description.trim(),
          ...(url.trim() ? { websiteUrl: url.trim() } : {}),
        };
        const body = JSON.stringify({ brandId, definition });
        if (request.current?.body !== body)
          request.current = { body, key: crypto.randomUUID() };
        try {
          const result = await api.createProduct(
            w,
            { brandId, definition, requestKey: request.current.key },
            new AbortController().signal,
          );
          onCreated(result.offeringId, url.trim(), name.trim());
        } catch (e) {
          setError(e);
        } finally {
          saving.current = false;
          setBusy(false);
        }
      }}
    >
      <h2>Add Product</h2>
      <label>
        Product name
        <input
          required
          maxLength={200}
          value={name}
          disabled={busy}
          onChange={(e) => setName(e.target.value)}
        />
      </label>
      <label>
        Short description
        <textarea
          required
          maxLength={10000}
          value={description}
          disabled={busy}
          onChange={(e) => setDescription(e.target.value)}
        />
      </label>
      <label>
        Product URL (optional)
        <input
          type="url"
          pattern="https://.*"
          maxLength={2048}
          value={url}
          disabled={busy}
          onChange={(e) => setUrl(e.target.value)}
        />
      </label>
      {error ? <Failure error={error} /> : null}
      <div className="psu-product-toolbar">
        <button
          className="button"
          disabled={busy || !name.trim() || !description.trim()}
        >
          {busy ? "Saving…" : "Save Product"}
        </button>
        <button type="button" disabled={busy} onClick={onCancel}>
          Cancel
        </button>
      </div>
    </form>
  );
}

export function productFailureMessage(code?: PsuJob["failureCode"]) {
  switch (code) {
    case "sources_unavailable":
      return "We couldn’t read this page. Check that it is publicly accessible, or try another product page.";
    case "output_evidence_invalid":
      return "We couldn’t verify the product draft against the website. Try generating again or use a more detailed product page.";
    case "timed_out":
      return "Preparing the product details took too long. Please try again.";
    case "service_configuration":
      return "A service configuration problem prevented generation. Please contact support; changing your URL won’t fix this.";
    case "service_unavailable":
      return "The drafting service is temporarily unavailable. Please try again shortly.";
    case "output_invalid":
    case "output_format_invalid":
    case "output_model_mismatch":
      return "The drafting service returned a response we couldn’t process. Please try again; if this continues, contact support.";
    default:
      return "We couldn’t complete the product draft. Please try again; if this continues, contact support.";
  }
}
