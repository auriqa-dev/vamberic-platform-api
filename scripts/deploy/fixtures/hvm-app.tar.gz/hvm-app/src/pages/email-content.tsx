import { Link, useLocation } from "react-router-dom";
import { EmailBrief } from "../components/email-brief";
import { EmailPresentation } from "../components/email-presentation";
import { useEffect, useRef, useState } from "react";
import type { ContentGateway, ContentBundle } from "../data/content-strategy";
import type {
  ContactManagementGateway,
  ManagedRecord,
} from "../data/contact-management";
import type { CampaignGateway, Campaign } from "../data/campaigns";
import type { EmailRecord } from "../data/email-content-model";
import {
  useHenryBinding,
  henryFields,
  applyHenryFields,
} from "../components/workspace-henry";
import { DataError } from "../data/gateway";
import "../styles/email-content.css";
type Candidate = {
  id: string;
  title: string;
  url: string;
  version: number;
  description: string;
};
export function EmailContentPage({
  api,
  contacts,
  campaigns,
  workspaceId: w,
}: {
  api?: ContentGateway;
  contacts?: ContactManagementGateway;
  campaigns?: CampaignGateway;
  workspaceId: string;
}) {
  const location = useLocation();
  const [bundle, setBundle] = useState<ContentBundle>(),
    [templateBrand, setTemplateBrand] = useState(""),
    [templateId, setTemplateId] = useState(""),
    [rows, setRows] = useState<EmailRecord[]>([]),
    [campaignList, setCampaignList] = useState<Campaign[]>([]),
    [campaignId, setCampaignId] = useState(""),
    [briefId, setBriefId] = useState(""),
    [contactId, setContactId] = useState(""),
    [people, setPeople] = useState<ManagedRecord[]>([]),
    [search, setSearch] = useState(""),
    [instruction, setInstruction] = useState(""),
    [selected, setSelected] = useState<EmailRecord>(),
    [draft, setDraft] = useState<EmailRecord["content"]>(),
    [candidates, setCandidates] = useState<Candidate[]>([]),
    [cta, setCta] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [history, setHistory] = useState<EmailRecord[]>(),
    [checked, setChecked] = useState<string[]>([]),
    [available, setAvailable] = useState(false);
  const running = useRef(false);
  const generationAttempt = useRef<
    { signature: string; key: string } | undefined
  >(undefined);
  const brief = bundle?.records.find((r) => r.id === briefId),
    campaign = campaignList.find((r) => r.id === campaignId);
  useEffect(() => {
    const c = new AbortController();
    if (api)
      void Promise.all([
        api.list(w, c.signal),
        api.email.list(w, c.signal),
        campaigns?.list(w, c.signal),
      ])
        .then(([b, e, cp]) => {
          if(c.signal.aborted) return;
          const query=new URLSearchParams(location.search);
          const requestedCampaign=cp?.campaigns.find(r=>r.id===query.get('campaign') && r.status==='ready');
          if(requestedCampaign) setCampaignId(requestedCampaign.id);
          setBundle(b);
          setTemplateBrand((current) => b.brands.some((brand) => brand.id === current) ? current : b.brands.length === 1 ? b.brands[0]!.id : "");
          setRows(e.records);
          setAvailable(e.generationAvailable);
          setCampaignList(
            cp?.campaigns.filter((r) => r.status === "ready") ?? [],
          );
        })
        .catch(() => {
          if (!c.signal.aborted)
            setError("Could not load email drafts. Refresh to retry.");
        });
    return () => c.abort();
  }, [api, campaigns, w, location.search]);
  useEffect(() => {
    const c = new AbortController();
    setCandidates([]);
    if (api && briefId)
      void api.email
        .candidates(w, briefId, c.signal)
        .then(setCandidates)
        .catch(() => {
          if (!c.signal.aborted)
            setError(
              "CTA candidates are unavailable. Check the approved brief and Library.",
            );
        });
    return () => c.abort();
  }, [api, w, briefId]);
  useEffect(()=>{
    const controller=new AbortController();
    const id=new URLSearchParams(location.search).get('contact');
    if(contacts && id) void contacts.read(w,'contacts',id,controller.signal).then(person=>{
      if(!controller.signal.aborted){setPeople([person]);setContactId(person.id);}
    }).catch(()=>{if(!controller.signal.aborted)setError('The selected campaign contact is unavailable. Choose a current contact.');});
    return()=>controller.abort();
  },[contacts,w,location.search]);
  async function run(fn: (s: AbortSignal) => Promise<void>) {
    if (running.current) return;
    running.current = true;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await fn(new AbortController().signal);
    } catch (e) {
      setError(
        e instanceof DataError
          ? (e.userMessage ?? "The request could not be completed.")
          : "The request could not be completed. Saved drafts are retained.",
      );
    } finally {
      running.current = false;
      setBusy(false);
    }
  }
  function select(r: EmailRecord) {
    setSelected(r);
    setDraft(r.content);
    setBriefId(r.briefId);
    setContactId(r.contactId);
    setCampaignId(r.campaignId);
    setCta(r.content.ctaAssetId);
    setHistory(undefined);
    setError("");
  }
  function display(r: EmailRecord) {
    setRows((old) =>
      [r, ...old.filter((x) => x.id !== r.id)].filter(
        (x) => x.status !== "removed",
      ),
    );
    if (r.status === "removed") {
      setSelected(undefined);
      setDraft(undefined);
    } else select(r);
  }
  async function generate(message = instruction) {
    if (!api || !brief || !contactId) return;
    await run(async (signal) => {
      const signature = JSON.stringify([
        w,
        briefId,
        brief.version,
        contactId,
        campaignId,
        campaign?.version,
        message,
        cta,
        selected?.id,
        selected?.version,
        draft,
      ]);
      if (generationAttempt.current?.signature !== signature)
        generationAttempt.current = { signature, key: crypto.randomUUID() };
      const r = await api.email.generate(
        w,
        {
          requestKey: generationAttempt.current.key,
          briefId,
          briefVersion: brief.version,
          contactId,
          campaignId,
          campaignVersion: campaign?.version ?? 0,
          instruction: message,
          ctaAssetId: cta,
          draftId: selected?.id ?? "",
          expectedVersion: selected?.version ?? 0,
          ...(selected && draft ? { currentDraft: draft } : {}),
        },
        signal,
      );
      generationAttempt.current = undefined;
      display(r);
      setNotice("Draft saved. Nothing has been sent.");
    });
  }
  async function save(operation: "save" | "approve" | "remove") {
    if (!api || !selected || !draft) return;
    if (
      operation === "remove" &&
      !window.confirm("Remove this draft? Its audit history will be retained.")
    )
      return;
    await run(async (signal) => {
      display(
        await api.email.save(
          w,
          selected.id,
          {
            requestKey: crypto.randomUUID(),
            expectedVersion: selected.version,
            operation,
            ...(operation === "save" ? { content: draft } : {}),
          },
          signal,
        ),
      );
      setNotice(
        operation === "approve"
          ? "Content approved. This does not authorise sending."
          : "Saved.",
      );
    });
  }
  useHenryBinding({
    key: "email-content",
    brandId:
      selected?.brandId ??
      (brief?.data.scope as { brandId?: string } | undefined)?.brandId,
    summary: `Campaign: ${campaign?.setup.name ?? "none"}. Recipient: ${people.find(p=>p.id===contactId)?.name ?? selected?.recipientName ?? "not chosen"}. Email draft creation only; never send. Selected brief: ${brief?.data.title ?? "none"}. CTA choices: ${candidates.map((c) => `${c.id}: ${c.title}`).join("; ")}. ${selected?.brandNotice ?? ""}`,
    editor: draft
      ? {
          key: selected!.id,
          title: "Email draft",
          fields: henryFields({
            subject: draft.subject,
            body: draft.body,
            ctaText: draft.ctaText,
          }),
        }
      : undefined,
    apply: (changes) =>
      setDraft((old) =>
        old
          ? {
              ...old,
              ...applyHenryFields(
                { subject: old.subject, body: old.body, ctaText: old.ctaText },
                changes,
              ),
            }
          : old,
      ),
    actions: [
      {
        id: "prepare-email",
        label: selected ? "Refine email draft" : "Create email preview",
        run: (message) => {
          void generate(message);
        },
      },
    ],
  });
  const dirty =
    !!draft && JSON.stringify(draft) !== JSON.stringify(selected?.content);
  const ctaUrl = draft?.ctaAssetId
    ? (candidates.find((c) => c.id === draft.ctaAssetId)?.url ??
      (draft.ctaAssetId === selected?.content.ctaAssetId
        ? selected.ctaUrl
        : ""))
    : "";
  return (
    <div className="email-content">
      {campaign && <p>Preparing email for {campaign.setup.name}. <Link to={`${location.pathname.replace(/email-content\/?$/, 'campaigns')}${location.search}`}>Return to campaign review</Link></p>}

      <p>
        Create and review a personalised email. This page does not send messages
        or enrol contacts.
      </p>
      {!selected && api && (
        <details className="panel">
          <summary>Email templates</summary>
          {(bundle?.brands.length ?? 0) > 1 ? <label>
            Brand
            <select
              value={templateBrand}
              onChange={(e) => setTemplateBrand(e.target.value)}
            >
              <option value="">Choose a brand</option>
              {bundle?.brands.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>
          </label> : <p className="muted">Brand: {bundle?.brands[0]?.name ?? "Loading…"}</p>}
          {templateBrand && (
            <EmailPresentation
              api={api.email.templates}
              workspaceId={w}
              brandId={templateBrand}
              draftId=""
              draftVersion={0}
              disabled
            />
          )}
        </details>
      )}
      <section className="panel">
        <h2>Prepare an email</h2>
        {api && bundle && templateBrand && <EmailBrief key={w+templateBrand} api={api} bundle={bundle} workspaceId={w} brandId={templateBrand} onSaved={async record=>{setBundle(await api.list(w,new AbortController().signal));if(record.status==="approved")setBriefId(record.id);}}/>}
        <div className="email-fields">
          <label>
            Approved email brief
            <select
              value={briefId}
              disabled={busy || !!selected}
              onChange={(e) => {
                setBriefId(e.target.value);
                setCta("");
              }}
            >
              <option value="">Select a brief</option>
              {bundle?.records
                .filter(
                  (r) =>
                    r.kind === "brief" &&
                    (!templateBrand || (r.data.scope as {brandId?: string})?.brandId === templateBrand) &&
                    r.status === "approved" &&
                    /email/i.test(String(r.data.channel)),
                )
                .map((r) => (
                  <option key={r.id} value={r.id}>
                    {String(r.data.title)}
                  </option>
                ))}
            </select>
          </label>
          <label>
            Campaign (optional for a preview)
            <select
              value={campaignId}
              disabled={busy || !!selected}
              onChange={(e) => setCampaignId(e.target.value)}
            >
              <option value="">Standalone preview</option>
              {campaignList.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.setup.name}
                </option>
              ))}
            </select>
          </label>
          <div>
            <label htmlFor="email-contact-search">Find a contact</label>
            <div className="email-search">
              <input
                id="email-contact-search"
                value={search}
                disabled={busy || !!selected}
                onChange={(e) => setSearch(e.target.value)}
              />
              <button
                disabled={busy || !!selected}
                onClick={() =>
                  void run(async (s) => {
                    if (contacts)
                      setPeople(
                        (await contacts.list(w, "contacts", { search }, s))
                          .items,
                      );
                  })
                }
              >
                Search
              </button>
            </div>
          </div>
          <label>
            Contact
            <select
              value={contactId}
              disabled={busy || !!selected}
              onChange={(e) => setContactId(e.target.value)}
            >
              <option value="">Select one contact</option>
              {selected && !people.some((p) => p.id === selected.contactId) && (
                <option value={selected.contactId}>
                  {selected.recipientName}
                </option>
              )}
              {people.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} {p.organisationName ? `— ${p.organisationName}` : ""}
                </option>
              ))}
            </select>
          </label>
          <label className="email-wide">
            Tell Henry what this email should achieve
            <textarea
              value={instruction}
              onChange={(e) => setInstruction(e.target.value)}
              rows={3}
              placeholder="For example: introduce this offer using relevant evidence, and invite them to read a useful comparison."
            />
          </label>
          <label className="email-wide">
            Preferred CTA page
            <select
              value={cta}
              disabled={busy}
              onChange={(e) => {
                setCta(e.target.value);
                setDraft((d) => (d ? { ...d, ctaAssetId: e.target.value } : d));
              }}
            >
              <option value="">Let Henry select an appropriate page</option>
              {candidates.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.title}
                </option>
              ))}
            </select>
          </label>
        </div>
        <p className="muted">
          Only current public Library pages approved for email use are offered.
          If none are available, ingest and review the relevant pages in the
          Library first. A reply-based CTA may be appropriate.
        </p>
        <div className="email-actions">
          <button
            className="button"
            disabled={busy || !available || !brief || !contactId}
            onClick={() => void generate()}
          >
            {busy
              ? "Henry is working…"
              : selected
                ? "Refine draft"
                : "Generate email preview"}
          </button>
          {selected && (
            <button
              disabled={busy}
              onClick={() => {
                setSelected(undefined);
                setDraft(undefined);
                setHistory(undefined);
                setInstruction("");
              }}
            >
              New preview
            </button>
          )}
        </div>
      </section>
      {error && (
        <p role="alert" className="error">
          {error}
        </p>
      )}
      {notice && <p role="status">{notice}</p>}
      {busy && (
        <p role="status">
          Henry is preparing your request. Your saved work is retained.
        </p>
      )}
      {selected && draft && (
        <section className="panel">
          <h2>
            {selected.status === "approved"
              ? "Approved email content"
              : "Review email draft"}
          </h2>
          <p>
            {selected.recipientName} · Version {selected.version} ·{" "}
            {selected.brandNotice}
          </p>
          <div className="email-editor">
            <div>
              <label>
                Subject
                <input
                  value={draft.subject}
                  onChange={(e) =>
                    setDraft({ ...draft, subject: e.target.value })
                  }
                />
              </label>
              <label>
                Email body
                <textarea
                  rows={12}
                  value={draft.body}
                  onChange={(e) => setDraft({ ...draft, body: e.target.value })}
                />
              </label>
              <label>
                CTA page
                <select
                  value={draft.ctaAssetId}
                  onChange={(e) => (
                    setCta(e.target.value),
                    setDraft({ ...draft, ctaAssetId: e.target.value })
                  )}
                >
                  <option value="">Reply-based / no link</option>
                  {candidates.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.title}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                CTA text
                <input
                  value={draft.ctaText}
                  onChange={(e) =>
                    setDraft({ ...draft, ctaText: e.target.value })
                  }
                />
              </label>
              <p>{draft.ctaRationale}</p>
              <label>
                Review issues (resolve before approval)
                <textarea
                  rows={3}
                  value={draft.reviewIssues.join("\n")}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      reviewIssues: e.target.value.split("\n").filter(Boolean),
                    })
                  }
                />
              </label>
            </div>
            {api && (
              <EmailPresentation
                api={api.email.templates}
                workspaceId={w}
                brandId={selected.brandId}
                draftId={selected.id}
                draftVersion={selected.version}
                disabled={dirty}
                onSelect={setTemplateId}
              />
            )}
          </div>
          <div className="email-actions">
            {selected.status === "approved" && !dirty && (
              <a
                className="button"
                href={`communications?draft=${encodeURIComponent(selected.id)}&template=${encodeURIComponent(templateId)}`}
              >
                Review delivery
              </a>
            )}
            <button disabled={busy || !dirty} onClick={() => void save("save")}>
              Save changes
            </button>
            {selected.status !== "approved" && (
              <button
                className="button"
                disabled={busy || dirty || draft.reviewIssues.length > 0}
                onClick={() => void save("approve")}
              >
                Approve content
              </button>
            )}
            <button
              disabled={busy}
              onClick={() =>
                void run(async (s) => {
                  if (api)
                    setHistory(await api.email.history(w, selected.id, s));
                })
              }
            >
              Version history
            </button>
            <button disabled={busy} onClick={() => void save("remove")}>
              Delete draft
            </button>
          </div>
          <details>
            <summary>Sources and destination</summary>
            <p>{draft.ctaAssetId ? ctaUrl : "Reply-based / no link"}</p>
            <ul>
              {selected.sourceVersions.map((ref) => (
                <li key={ref.id}>
                  {String(
                    bundle?.records.find((r) => r.id === ref.id)?.data.title ??
                      "Source",
                  )}{" "}
                  · version {ref.version}
                </li>
              ))}
            </ul>
          </details>
          {history && (
            <ul>
              {history.map((h) => (
                <li key={h.version}>
                  Version {h.version} · {h.status} · {h.content.subject}
                  <details>
                    <summary>View saved content</summary>
                    <p style={{ whiteSpace: "pre-wrap" }}>{h.content.body}</p>
                  </details>
                </li>
              ))}
            </ul>
          )}
        </section>
      )}
      <section className="panel">
        <h2>Saved emails</h2>
        {!rows.length ? (
          <p>No email drafts yet.</p>
        ) : (
          <>
            <div className="email-actions">
              <button
                disabled={busy || !checked.length}
                onClick={() =>
                  void run(async (signal) => {
                    const failures: string[] = [];
                    for (const id of checked) {
                      const row = rows.find((r) => r.id === id);
                      if (!row || !api) continue;
                      try {
                        display(
                          await api.email.save(
                            w,
                            id,
                            {
                              requestKey: crypto.randomUUID(),
                              expectedVersion: row.version,
                              operation: "save",
                              content: row.content,
                            },
                            signal,
                          ),
                        );
                      } catch {
                        failures.push(row.content.subject);
                      }
                    }
                    setChecked([]);
                    if (failures.length)
                      setError(
                        `Could not return to draft: ${failures.join(", ")}`,
                      );
                    else setNotice("Selected emails returned to draft.");
                  })
                }
              >
                Return selected to draft
              </button>
              <button
                disabled={busy || !checked.length}
                onClick={() => {
                  if (
                    !window.confirm(`Remove ${checked.length} selected drafts?`)
                  )
                    return;
                  void run(async (s) => {
                    const failures: string[] = [];
                    for (const id of checked) {
                      const r = rows.find((x) => x.id === id);
                      if (!r || !api) continue;
                      try {
                        display(
                          await api.email.save(
                            w,
                            id,
                            {
                              requestKey: crypto.randomUUID(),
                              expectedVersion: r.version,
                              operation: "remove",
                            },
                            s,
                          ),
                        );
                      } catch {
                        failures.push(r.content.subject);
                      }
                    }
                    setChecked([]);
                    if (failures.length)
                      setError(`Not removed: ${failures.join(", ")}`);
                  });
                }}
              >
                Delete selected
              </button>
            </div>
            <div className="email-table">
              <table>
                <thead>
                  <tr>
                    <th>Select</th>
                    <th>Subject</th>
                    <th>Recipient</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.id}>
                      <td>
                        <input
                          type="checkbox"
                          aria-label={`Select ${r.content.subject}`}
                          checked={checked.includes(r.id)}
                          onChange={(e) =>
                            setChecked((old) =>
                              e.target.checked
                                ? [...old, r.id]
                                : old.filter((id) => id !== r.id),
                            )
                          }
                        />
                      </td>
                      <td>{r.content.subject}</td>
                      <td>{r.recipientName}</td>
                      <td>{r.status}</td>
                      <td>
                        <button onClick={() => select(r)}>Open</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </section>
    </div>
  );
}
