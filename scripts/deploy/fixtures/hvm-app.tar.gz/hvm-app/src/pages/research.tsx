import {DataError} from "../data/gateway";
import type {
  ContactManagementGateway,
  ManagedRecord,
  RecordKind,
} from "../data/contact-management";
import { useEffect, useState, useCallback } from "react";
import type {
  ResearchGateway,
  ResearchOverview,
  ResearchDetail,
  OrganisationDossier,
} from "../data/research";
import { useHenryBinding, useHenryBrand } from "../components/workspace-henry";
import "../styles/research.css";
const types = [
  ["company_product", "Company and product"],
  ["market_buyer", "Market and buyer"],
  ["account_discovery", "Find organisations"],
  ["contact_discovery", "Find contacts"],
  ["enrichment", "Enrich records"],
  ["personalisation", "Personalisation"],
  ["content_evidence", "Content and evidence"],
  ["situational", "Situational research"],
  ["knowledge_gap", "Resolve a knowledge gap"],
];
function Finding({
  f,
  evidence,
  onReview,
}: {
  f: ResearchDetail["findings"][number];
  evidence: ResearchDetail["evidence"];
  onReview?: (id: string, body: unknown) => Promise<void>;
}) {
  const [statement, setStatement] = useState(f.statement),
    [note, setNote] = useState(f.reviewNote),
    [saving, setSaving] = useState(false),
    [error, setError] = useState("");
  async function save(decision: string) {
    if (!onReview) return;
    setSaving(true);
    setError("");
    try {
      await onReview(f.id, {
        statement,
        note,
        decision,
        expectedUpdatedAt: f.updatedAt,
      });
    } catch {
      setError("Could not save this finding. Refresh and retry.");
    } finally {
      setSaving(false);
    }
  }
  return (
    <article className="research-finding">
      <h3>
        {f.kind === "fact"
          ? "Source-backed observation"
          : f.kind === "inference"
            ? "Assessment"
            : "Recommendation"}
      </h3>
      {onReview ? (
        <label>
          Finding
          <textarea
            value={statement}
            onChange={(e) => setStatement(e.target.value)}
            rows={3}
          />
        </label>
      ) : (
        <p>{statement}</p>
      )}
      <p>{f.rationale}</p>
      <small>
        {f.decision === "accepted"
          ? "Reviewed"
          : f.decision === "rejected"
            ? "Excluded"
            : "Needs review"}
      </small>
      {onReview && (
        <>
          <label>
            Review note (optional)
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={2}
            />
          </label>
          {(f.decision === "proposed" ||
            statement !== f.statement ||
            note !== f.reviewNote) && (
            <div className="research-actions">
              <button
                disabled={saving || !statement.trim()}
                onClick={() => void save("accepted")}
              >
                {f.decision === "accepted" ? "Save changes" : "Accept finding"}
              </button>
              <button disabled={saving} onClick={() => void save("rejected")}>
                Exclude
              </button>
            </div>
          )}
          {error && <p role="alert">{error}</p>}
        </>
      )}
      <details>
        <summary>Supporting evidence ({f.evidenceIds.length})</summary>
        {evidence
          .filter((e) => f.evidenceIds.includes(e.id))
          .map((e) => (
            <div key={e.id}>
              {e.url ? (
                <a href={e.url} target="_blank" rel="noreferrer">
                  {e.title || e.url}
                </a>
              ) : (
                <strong>{e.title}</strong>
              )}
              <p>{e.extract}</p>
              <small>
                {e.access === "public"
                  ? "Public source"
                  : "Internal workspace source"}
                {e.excerptOnly ? " · Selected excerpts" : ""}
                {e.revision ? ` · Version ${e.revision}` : ""}
              </small>
              {e.restrictions.map((restriction, i) => (
                <p key={i}>{restriction}</p>
              ))}
              <small>
                Retrieved {new Date(e.retrievedAt).toLocaleDateString("en-GB")}
              </small>
            </div>
          ))}
      </details>
    </article>
  );
}
function ResearchCandidate({item,evidence,act,loadDossier}:{loadDossier?:(id:string)=>Promise<OrganisationDossier>;item:ResearchDetail["job"]["discovery"][number];evidence:ResearchDetail["evidence"];act:(id:string,action:"review"|"enrich"|"promote"|"people"|"supplement",body?:unknown)=>Promise<void>}) {
 const [busy,setBusy]=useState(false),[error,setError]=useState(""),[quote,setQuote]=useState(""),[source,setSource]=useState(""),[confirmed,setConfirmed]=useState(false);
 const [dossier,setDossier]=useState<OrganisationDossier>();
 const sources=evidence.filter(e=>item.evidenceIds?.includes(e.id));
 async function run(action:"review"|"enrich"|"promote"|"people"|"supplement",body?:unknown){setBusy(true);setError("");try{await act(item.candidateId!,action,body);}catch(e){setError(e instanceof DataError && e.userMessage ? e.userMessage : "Could not complete this step. Check the candidate and connection before retrying. A previous paid lookup will not be repeated automatically.");}finally{setBusy(false);}}
 return <article className="research-finding"><h4>{item.name}</h4><p>{item.reason}</p><p role="status">{busy?"Working…":item.status.replaceAll("_"," ")}</p>
 {loadDossier&&!["rejected","expired"].includes(item.status)&&<details onToggle={e=>{if(e.currentTarget.open&&!dossier)void loadDossier(item.candidateId!).then(setDossier).catch(()=>setError("Could not load the organisation history. Try reopening this section."));}}><summary>Existing organisation and contact history</summary>{dossier?<><p>{dossier.organisation?dossier.organisation.name:dossier.matchCount?"Multiple organisations match; resolve them before continuing.":"No matching organisation saved in Hive."}</p>{dossier.context&&<p>Lifecycle: {dossier.context.lifecycle}. {Object.values(dossier.context.controls).some(Boolean)?"Contact restrictions apply. Review the saved record before proceeding.":"No explicit contact restrictions recorded. This does not authorise outreach."}</p>}<p>{dossier.contacts.length} existing contacts · {dossier.evidence.length} related evidence records{dossier.hasMore?" · More history is available in Contact Management":""}</p>{dossier.contacts.map(p=><p key={p.id}>{[p.firstName,p.lastName].filter(Boolean).join(" ")}{p.title?` — ${p.title}`:""}</p>)}</>:<p role="status">Loading organisation history…</p>}</details>}
 {item.id&&<a href={`./contacts?view=${item.type==="people"?"contacts":"organisations"}&record=${encodeURIComponent(item.id)}`}>View saved record</a>}
 {item.kind==="person"&&item.status==="candidate"&&<><label>Employment evidence<select value={source} onChange={e=>setSource(e.target.value)}><option value="">Choose a source</option>{sources.filter(e=>e.url).map(e=><option key={e.id} value={e.url}>{e.title||e.url}</option>)}</select></label>
 {sources.filter(e=>e.url===source).map(e=><blockquote key={e.id}>{e.extract}</blockquote>)}
 <label>Relevant quotation<textarea rows={3} value={quote} onChange={e=>setQuote(e.target.value)}/></label><label className="research-check"><input type="checkbox" checked={confirmed} onChange={e=>setConfirmed(e.target.checked)}/>I have checked that this person currently works here and matches the required role.</label>
 <div className="research-actions"><button disabled={busy||!confirmed||!source||quote.trim().length<10} onClick={()=>void run("review",{decision:"verify_employment",review:{sourceUrl:source,quote,observedAt:new Date().toISOString(),currentEmployment:true,roleMatches:true}})}>Confirm employment</button></div></>}
 <div className="research-actions">{((item.kind==="organisation"&&["promoted","matched"].includes(item.status))||(item.kind==="person"&&item.status==="candidate"&&!sources.length))&&<button disabled={busy} onClick={()=>void run("people")}>{item.kind==="person"?"Research current employment":"Research relevant people"}</button>}
 {item.kind==="organisation"&&["promoted","matched"].includes(item.status)&&<button className="secondary" disabled={busy} onClick={()=>{if(confirm("Look for additional people using Lusha after web research? This may consume this client’s provider credits."))void run("supplement");}}>Find additional people</button>}
 {item.kind==="organisation"&&["candidate","matched"].includes(item.status)&&<button disabled={busy} onClick={()=>void run("review",{decision:"select"})}>Select organisation</button>}
 {((item.kind==="organisation"&&item.status==="selected")||item.status==="ready")&&<button disabled={busy} onClick={()=>void run("promote")}>{item.kind==="organisation"?"Save organisation":"Save contact"}</button>}
 {item.status==="verified"&&<button disabled={busy} onClick={()=>{if(confirm("Request a business email using this client’s Lusha account? Lusha may charge credits even if no A+ email is returned."))void run("enrich");}}>Find verified email</button>}
 {["candidate","selected","verified"].includes(item.status)&&<button className="secondary" disabled={busy} onClick={()=>void run("review",{decision:"reject"})}>Exclude candidate</button>}</div>
 {error&&<p role="alert">{error}</p>}</article>;
}
export function ResearchEvidence({
  detail,
  onReview,
  onCandidate,
  loadDossier,
}: {
  loadDossier?:(id:string)=>Promise<OrganisationDossier>;
  onCandidate?:(id:string,action:"review"|"enrich"|"promote"|"people"|"supplement",body?:unknown)=>Promise<void>;
  detail: ResearchDetail;
  onReview?: (id: string, body: unknown) => Promise<void>;
}) {
  return (
    <div className="research-results">
      <p>{detail.job.summary}</p>
      {detail.findings.map((f) => (
        <Finding
          key={f.id + f.updatedAt}
          f={f}
          evidence={detail.evidence}
          onReview={onReview}
        />
      ))}
      {!!detail.job.discovery.length && (
        <section>
          <h3>Records found</h3>
          {detail.job.discovery.map((r, i) => (
            r.candidateId && onCandidate ? <ResearchCandidate key={r.candidateId+"-"+r.status} item={r} evidence={detail.evidence} act={onCandidate} loadDossier={loadDossier}/> : <p key={r.id ?? i}>
              {r.id ? (
                <a
                  href={`./contacts?view=${r.type === "people" ? "contacts" : "organisations"}&record=${encodeURIComponent(r.id)}`}
                >
                  {r.name ?? (r.type === "people" ? "Contact" : "Organisation")}
                </a>
              ) : (
                (r.name ?? "Record to review")
              )}{" "}
              · {r.status}
              {r.reason ? ` — ${r.reason}` : ""}
            </p>
          ))}
        </section>
      )}
      {!!detail.job.gaps.length && (
        <section>
          <h3>Still to establish</h3>
          <ul>
            {detail.job.gaps.map((g, i) => (
              <li key={i}>{g}</li>
            ))}
          </ul>
        </section>
      )}
      {!detail.findings.length && !!detail.evidence.length && (
        <details>
          <summary>Retained sources ({detail.evidence.length})</summary>
          <p>These sources remain saved when a run stops. Sources are evidence, not automatically qualified organisations or contacts. Review any saved candidates before adding them to Hive; campaign research and engagement are coordinated by NBA.</p>
          {detail.evidence.map((e) => (
            <p key={e.id}>{e.title}</p>
          ))}
        </details>
      )}
    </div>
  );
}
function RefreshPolicyCard({
  p,
  busy,
  save,
  remove,
}: {
  p: ResearchOverview["policies"][number];
  busy: boolean;
  save: (body: unknown) => void;
  remove: () => void;
}) {
  const [name, setName] = useState(p.name),
    [days, setDays] = useState(p.intervalDays),
    [mode, setMode] = useState(p.mode),
    [trigger, setTrigger] = useState(p.trigger);
  const body = {
    id: p.id,
    expectedUpdatedAt: p.updatedAt,
    name,
    intervalDays: days,
    mode,
    trigger,
    request: p.request,
    enabled: p.enabled,
  };
  return (
    <article className="research-finding">
      <h3>{p.name}</h3>
      <p>
        {p.mode === "scheduled"
          ? `Every ${p.intervalDays} days`
          : `When ${p.trigger.replaceAll(".", " ")}`}{" "}
        · {p.enabled ? "Enabled" : "Disabled"}
      </p>
      {p.error && <p role="alert">{p.error}</p>}
      <details>
        <summary>Edit refresh policy</summary>
        <div className="research-options-content">
          <label>
            Name
            <input value={name} onChange={(e) => setName(e.target.value)} />
          </label>
          <div className="research-grid">
            <label>
              Run mode
              <select value={mode} onChange={(e) => setMode(e.target.value)}>
                <option value="scheduled">Scheduled</option>
                <option value="triggered">On a relevant change</option>
              </select>
            </label>
            {mode === "scheduled" ? (
              <label>
                Days between refreshes
                <input
                  type="number"
                  min={1}
                  max={365}
                  value={days}
                  onChange={(e) => setDays(Number(e.target.value))}
                />
              </label>
            ) : (
              <label>
                Trigger
                <select
                  value={trigger}
                  onChange={(e) => setTrigger(e.target.value)}
                >
                  <option value="contact.created">Contact created</option>
                  <option value="contact.enriched">Contact updated</option>
                  <option value="organisation.updated">
                    Organisation updated
                  </option>
                  <option value="context.changed">
                    Contact context changed
                  </option>
                </select>
              </label>
            )}
          </div>
          <button
            disabled={busy || !name.trim() || days < 1 || days > 365}
            onClick={() => save(body)}
          >
            Save policy changes
          </button>
        </div>
      </details>
      <div className="research-actions">
        <button
          disabled={busy}
          onClick={() => save({ ...body, enabled: !p.enabled })}
        >
          {p.enabled ? "Disable" : "Enable"}
        </button>
        <button disabled={busy} onClick={remove}>
          Remove policy
        </button>
      </div>
    </article>
  );
}
export function ResearchPage({
  api,
  records,
  workspaceId: w,
}: {
  api?: ResearchGateway;
  records?: ContactManagementGateway;
  workspaceId: string;
}) {
  const carriedBrand = useHenryBrand();
  const [data, setData] = useState<ResearchOverview>(),
    [detail, setDetail] = useState<ResearchDetail>(),
    [tab, setTab] = useState("activity"),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [objective, setObjective] = useState(""),
    [brand, setBrand] = useState(carriedBrand),
    [type, setType] = useState("company_product"),
    [urls, setUrls] = useState(""),
    [web, setWeb] = useState(false),
    [selected, setSelected] = useState<string[]>([]),
    [contexts, setContexts] = useState<string[]>([]),
    [assets, setAssets] = useState<string[]>([]),
    [policyMode, setPolicyMode] = useState("scheduled"),
    [intervalDays, setIntervalDays] = useState(30),
    [trigger, setTrigger] = useState("contact.created");
  const [documents, setDocuments] = useState<string[]>([]);
  const [recordKind, setRecordKind] = useState<RecordKind>("organisations"),
    [recordSearch, setRecordSearch] = useState(""),
    [recordResults, setRecordResults] = useState<ManagedRecord[]>([]),
    [recordTargets, setRecordTargets] = useState<
      { type: string; id: string; name: string }[]
    >([]);
  const refresh = useCallback(async () => {
    if (!api) return;
    const d = await api.list(w, new AbortController().signal);
    setData(d);
    setBrand((b) =>
      d.brands.some((row) => row.id === b) ? b : d.brands[0]?.id || "",
    );
  }, [api, w]);
  useEffect(() => {
    void refresh().catch(() =>
      setError("Research could not be loaded. Try again."),
    );
  }, [refresh]);
  const detailId = detail?.job.id;
  const active = data?.jobs.some((j) =>
    ["queued", "running"].includes(j.status),
  );
  useEffect(() => {
    if (!active || !api) return;
    const timer = setInterval(() => {
      void refresh().catch(() => {});
      if (detailId)
        void api
          .read(w, detailId, new AbortController().signal)
          .then(setDetail)
          .catch(() => {});
    }, 3000);
    return () => clearInterval(timer);
  }, [active, api, w, detailId, refresh]);
  const request = () => ({
    objective,
    type,
    scope: {
      brandId: brand,
      products: (data?.choices.offerings ?? [])
        .filter((r) => contexts.includes(r.id))
        .map(({ id, revision }) => ({ id, revision })),
      offers: (data?.choices.offers ?? [])
        .filter((r) => contexts.includes(r.id))
        .map(({ id, revision }) => ({ id, revision })),
      audiences: (data?.choices.ideal_customer_profiles ?? [])
        .filter((r) => contexts.includes(r.id))
        .map(({ id, revision }) => ({ id, revision })),
    },
    documents: (data?.documents ?? [])
      .filter((d) => documents.includes(d.id))
      .map(({ id, revision }) => ({ id, revision })),
    libraryAssetIds: assets,
    urls: urls.split(/\s+/).filter(Boolean),
    destinations: [
      ...recordTargets.map(({ type, id }) => ({ type, id })),
      ...Object.entries(data?.choices ?? {}).flatMap(([kind, rows]) =>
        rows
          .filter((r) => contexts.includes(r.id))
          .map((r) => ({ type: kind, id: r.id })),
      ),
    ],
    sourceMode: web ? "web" : "existing",
    freshnessDays: 30,
  });
  async function act(f: () => Promise<unknown>) {
    setError("");
    setBusy(true);
    try {
      await f();
      await refresh();
    } catch {
      setError(
        "This action could not complete. Your entries are retained; refresh and try again.",
      );
    } finally {
      setBusy(false);
    }
  }
  async function start(value = objective) {
    if (!api) return;
    await act(async () => {
      const j = await api.start(w, {
        ...request(),
        objective: value,
        requestKey: crypto.randomUUID(),
      });
      setDetail(await api.read(w, j.id, new AbortController().signal));
      setTab("activity");
    });
  }
  useHenryBinding({
    key: "research",
    brandId: brand,
    summary: `Research activity. Current objective: ${objective}. ${data?.jobs.length ?? 0} research requests. Findings require review and never authorise communications.`,
    actions: [
      {
        id: "research.request",
        label: "Start research",
        run: (value) => {
          setObjective(value);
          void start(value);
        },
      },
    ],
  });
  if (!api) return <p>Research is unavailable.</p>;
  return (
    <div className="research-page">
      <header>
        <p>
          Find evidence, understand changes and keep your business context
          current.
        </p>
      </header>
      <div className="research-tabs" role="tablist" aria-label="Research views">
        {["activity", "history", "configuration"].map((t) => (
          <button
            key={t}
            role="tab"
            tabIndex={tab === t ? 0 : -1}
            onKeyDown={(e) => {
              const tabs = ["activity", "history", "configuration"],
                i = tabs.indexOf(t);
              const next =
                e.key === "ArrowRight"
                  ? (i + 1) % 3
                  : e.key === "ArrowLeft"
                    ? (i + 2) % 3
                    : e.key === "Home"
                      ? 0
                      : e.key === "End"
                        ? 2
                        : -1;
              if (next >= 0) {
                e.preventDefault();
                setTab(tabs[next]!);
                (
                  e.currentTarget.parentElement?.querySelectorAll("button")[
                    next
                  ] as HTMLButtonElement | undefined
                )?.focus();
              }
            }}
            aria-selected={tab === t}
            onClick={() => setTab(t)}
          >
            {t[0]!.toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>
      {error && <p role="alert">{error}</p>}
      {tab === "activity" && (
        <section className="research-panel">
          <h2>What do you need to find out?</h2>
          <p>Manual research saves findings and candidates for review. It does not enrol contacts or start campaign outreach. Campaign research is requested through its NBA workflow.</p>
          <label>Offer (optional for workspace-wide research)
            <select value={(data?.choices.offers ?? []).find((o) => contexts.includes(o.id))?.id ?? ""} onChange={(e) => setContexts((current) => [...current.filter((id) => !(data?.choices.offers ?? []).some((o) => o.id === id)), ...(e.target.value ? [e.target.value] : [])])}>
              <option value="">Workspace-wide research</option>
              {(data?.choices.offers ?? []).filter((o) => !o.brandId || o.brandId === brand).map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
            </select>
          </label>
          <div className="research-grid">
            {(data?.brands.length ?? 0) > 1 ? <label>
              Brand
              <select
                value={brand}
                onChange={(e) => {
                  setBrand(e.target.value);
                  setContexts([]);
                  setAssets([]);
                  setRecordTargets([]);
                }}
              >
                {data?.brands.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </label> : <p className="muted">Brand: {data?.brands.find((b) => b.id === brand)?.name ?? "Loading…"}</p>}
            <label>
              Research purpose
              <select value={type} onChange={(e) => setType(e.target.value)}>
                {types.map(([id, label]) => (
                  <option key={id} value={id}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <label>
            Objective
            <textarea
              rows={3}
              value={objective}
              onChange={(e) => setObjective(e.target.value)}
              placeholder="What should Henry investigate, and why?"
            />
          </label>
          <label>
            Supporting public URLs (optional)
            <textarea
              rows={2}
              value={urls}
              onChange={(e) => setUrls(e.target.value)}
            />
          </label>
          <label className="research-check">
            <input
              type="checkbox"
              checked={web}
              onChange={(e) => setWeb(e.target.checked)}
            />
            Search public sources and read websites
          </label>
          <details className="research-options">
            <summary>Add context and sources (optional)</summary>
            <div className="research-options-content">
              <fieldset>
                <legend>Approved context</legend>
                <div className="research-grid">
                  {Object.entries(data?.choices ?? {}).map(([kind, rows]) => (
                    <label key={kind}>
                      {kind === "offerings"
                        ? "Products"
                        : kind === "offers"
                          ? "Offers"
                          : "Audiences"}
                      <select
                        multiple
                        value={contexts.filter((id) =>
                          rows.some((r) => r.id === id),
                        )}
                        onChange={(e) => {
                          const ids = [...e.target.selectedOptions].map(
                            (o) => o.value,
                          );
                          setContexts((c) => [
                            ...c.filter((id) => !rows.some((r) => r.id === id)),
                            ...ids,
                          ]);
                        }}
                      >
                        {rows
                          .filter((r) => !r.brandId || r.brandId === brand)
                          .map((r) => (
                            <option key={r.id} value={r.id}>
                              {r.name}
                            </option>
                          ))}
                      </select>
                    </label>
                  ))}
                </div>
              </fieldset>
              <label>
                Library sources
                <select
                  multiple
                  value={assets}
                  onChange={(e) =>
                    setAssets([...e.target.selectedOptions].map((o) => o.value))
                  }
                >
                  {data?.assets
                    .filter((a) => a.brandId === brand)
                    .map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.name}
                      </option>
                    ))}
                </select>
              </label>
              {!!data?.documents?.length && (
                <label>
                  Reviewed research documents
                  <select
                    multiple
                    value={documents}
                    onChange={(e) =>
                      setDocuments(
                        [...e.target.selectedOptions].map((o) => o.value),
                      )
                    }
                  >
                    {data.documents.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name}
                      </option>
                    ))}
                  </select>
                </label>
              )}
              {records && (
                <fieldset>
                  <legend>
                    Contacts or organisations to research (optional)
                  </legend>
                  <div className="research-grid">
                    <label>
                      Record type
                      <select
                        value={recordKind}
                        onChange={(e) => {
                          setRecordKind(e.target.value as RecordKind);
                          setRecordResults([]);
                        }}
                      >
                        <option value="organisations">Organisations</option>
                        <option value="contacts">Contacts</option>
                      </select>
                    </label>
                    <label>
                      Find a record
                      <input
                        value={recordSearch}
                        onChange={(e) => setRecordSearch(e.target.value)}
                      />
                    </label>
                  </div>
                  <button
                    disabled={busy || recordSearch.trim().length < 2}
                    onClick={() =>
                      void act(async () => {
                        const result = await records.list(
                          w,
                          recordKind,
                          { search: recordSearch },
                          new AbortController().signal,
                        );
                        setRecordResults(result.items);
                      })
                    }
                  >
                    Search records
                  </button>
                  {recordResults.map((r) => (
                    <label className="research-check" key={r.id}>
                      <input
                        type="checkbox"
                        checked={recordTargets.some((t) => t.id === r.id)}
                        onChange={(e) =>
                          setRecordTargets((t) =>
                            e.target.checked
                              ? [
                                  ...t,
                                  {
                                    id: r.id,
                                    name: r.name,
                                    type:
                                      recordKind === "contacts"
                                        ? "people"
                                        : "organisations",
                                  },
                                ]
                              : t.filter((x) => x.id !== r.id),
                          )
                        }
                      />
                      {r.name}
                    </label>
                  ))}
                  {!!recordTargets.length && (
                    <p>
                      Selected: {recordTargets.map((t) => t.name).join(", ")}
                    </p>
                  )}
                </fieldset>
              )}
            </div>
          </details>
          <p>
            Existing evidence is reused where current. Findings do not change
            approved strategy or authorise outreach. Discovery prepares candidates for review before creating
            source-backed contacts and organisations; ambiguous matches are kept
            for review.
          </p>
          <button
            className="button"
            disabled={
              busy ||
              !brand ||
              objective.trim().length < 3 ||
              !data?.generationAvailable
            }
            onClick={() => void start()}
          >
            {busy ? "Working…" : "Start research"}
          </button>
          {data && !data.generationAvailable && (
            <p>Research generation is not configured.</p>
          )}
        </section>
      )}
      {tab !== "configuration" && (
        <section className="research-panel">
          <h2>
            {tab === "activity" ? "Research activity" : "Research history"}
          </h2>
          {!!selected.length && (
            <button
              disabled={busy}
              onClick={() => {
                if (
                  !confirm(
                    `Archive ${selected.length} research requests? Evidence is retained.`,
                  )
                )
                  return;
                void act(async () => {
                  const failed: string[] = [];
                  for (const id of selected) {
                    const j = data?.jobs.find((j) => j.id === id);
                    if (j)
                      try {
                        await api.change(w, id, {
                          action: "archive",
                          expectedUpdatedAt: j.updatedAt,
                        });
                      } catch {
                        failed.push(id);
                      }
                  }
                  setSelected(failed);
                  if (failed.length)
                    setError(
                      `${failed.length} requests could not be archived. Refresh and retry.`,
                    );
                });
              }}
            >
              Archive selected ({selected.length})
            </button>
          )}
          <div className="research-table">
            <table>
              <thead>
                <tr>
                  <th>Select</th>
                  <th>Objective</th>
                  <th>Status</th>
                  <th>Progress</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {data?.jobs
                  .filter((j) =>
                    tab === "history"
                      ? [
                          "completed",
                          "partial",
                          "failed",
                          "cancelled",
                        ].includes(j.status)
                      : true,
                  )
                  .map((j) => (
                    <tr key={j.id}>
                      <td>
                        <input
                          aria-label={`Select ${j.request.objective}`}
                          type="checkbox"
                          checked={selected.includes(j.id)}
                          onChange={(e) =>
                            setSelected((s) =>
                              e.target.checked
                                ? [...s, j.id]
                                : s.filter((id) => id !== j.id),
                            )
                          }
                        />
                      </td>
                      <th>
                        <p className="research-objective">{j.request.objective}</p>
                        <button
                          aria-label={`Open research: ${j.request.objective}`}
                          onClick={() =>
                            void act(async () =>
                              setDetail(
                                await api.read(
                                  w,
                                  j.id,
                                  new AbortController().signal,
                                ),
                              ),
                            )
                          }
                        >
                          Open
                        </button>
                      </th>
                      <td>
                        {{
                          queued: "Queued",
                          running: "Working",
                          partial: "Needs review",
                          completed: "Ready for review",
                          failed: "Needs attention",
                          cancelled: "Cancelled",
                        }[j.status] ?? j.status}
                      </td>
                      <td
                        role={
                          ["queued", "running"].includes(j.status)
                            ? "status"
                            : undefined
                        }
                      >
                        {j.phase}
                      </td>
                      <td>
                        {["queued", "running"].includes(j.status) ? (
                          <>
                            <button
                              disabled={busy}
                              onClick={() =>
                                void act(() => api.continue(w, j.id))
                              }
                            >
                              Resume
                            </button>
                            <button
                              disabled={busy}
                              onClick={() =>
                                void act(() =>
                                  api.change(w, j.id, {
                                    action: "cancel",
                                    expectedUpdatedAt: j.updatedAt,
                                  }),
                                )
                              }
                            >
                              Cancel
                            </button>
                          </>
                        ) : ["failed", "partial"].includes(j.status) ? (
                          <button
                            disabled={busy}
                            onClick={() =>
                              void act(async () => {
                                setDetail(undefined);
                                const retry = await api.change(w, j.id, {
                                  action: "retry",
                                  expectedUpdatedAt: j.updatedAt,
                                });
                                setDetail(
                                  await api.read(
                                    w,
                                    retry.id,
                                    new AbortController().signal,
                                  ),
                                );
                              })
                            }
                          >
                            Retry
                          </button>
                        ) : null}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
          {data && !data.jobs.length && (
            <p>No research yet. Ask Henry or start with an objective above.</p>
          )}
        </section>
      )}
      {tab === "configuration" && (
        <section className="research-panel">
          <h2>Refresh policies</h2>
          <p>
            Policies reuse the current request form. New policies are disabled
            until explicitly enabled. External integrations retain their
            separate permissions and budgets.
          </p>
          {!data?.workerEnabled && (
            <p role="status">
              Background research is not enabled in this environment. You can
              prepare policies; they will not run until background processing is
              enabled.
            </p>
          )}
          <div className="research-grid">
            <label>
              Run mode
              <select
                value={policyMode}
                onChange={(e) => setPolicyMode(e.target.value)}
              >
                <option value="scheduled">Scheduled refresh</option>
                <option value="triggered">On a relevant change</option>
              </select>
            </label>
            {policyMode === "scheduled" ? (
              <label>
                Days between refreshes
                <input
                  type="number"
                  min={1}
                  max={365}
                  value={intervalDays}
                  onChange={(e) => setIntervalDays(Number(e.target.value))}
                />
              </label>
            ) : (
              <label>
                Trigger
                <select
                  value={trigger}
                  onChange={(e) => setTrigger(e.target.value)}
                >
                  <option value="contact.created">Contact created</option>
                  <option value="contact.enriched">Contact updated</option>
                  <option value="organisation.updated">
                    Organisation updated
                  </option>
                  <option value="context.changed">
                    Contact context changed
                  </option>
                </select>
              </label>
            )}
          </div>
          <button
            disabled={busy || !brand || objective.trim().length < 3}
            onClick={() =>
              void act(() =>
                api.policy(w, {
                  name: objective.slice(0, 200),
                  enabled: false,
                  mode: policyMode,
                  intervalDays,
                  trigger,
                  request: request(),
                }),
              )
            }
          >
            Save refresh policy
          </button>
          {data?.policies.map((p) => (
            <RefreshPolicyCard
              key={p.id + p.updatedAt}
              p={p}
              busy={busy}
              save={(body) => void act(() => api.policy(w, body))}
              remove={() => {
                if (confirm("Remove this refresh policy?"))
                  void act(() => api.removePolicy(w, p.id, p.updatedAt));
              }}
            />
          ))}
          <p>
            Provider configuration is managed through Integrations. Lusha and
            other paid providers are not called without their existing
            permissions.
          </p>
        </section>
      )}
      {detail && (
        <section className="research-panel">
          <h2>{detail.job.request.objective}</h2>
          <p role="status">{detail.job.phase}</p>
          {detail.job.error && <p role="alert">{detail.job.error}</p>}
          <ResearchEvidence
            detail={detail}
            loadDossier={id=>api.dossier(w,id)}
            onCandidate={async(id,action,body)=>{const result=await api.candidate(w,id,action,body);const next=action==="people"&&(result as {id?:string})?.id;setDetail(await api.read(w,next||detail.job.id,new AbortController().signal));await refresh();}}
            onReview={async (id, body) => {
              await api.review(w, id, body);
              setDetail(
                await api.read(w, detail.job.id, new AbortController().signal),
              );
            }}
          />
          {detail.job.usage.map((u, i) => (
            <p key={i}>
              Usage: {u.inputTokens.toLocaleString()} input tokens ·{" "}
              {u.outputTokens.toLocaleString()} output tokens
            </p>
          ))}
        </section>
      )}
    </div>
  );
}
