import { useEffect, useRef, useState } from "react";
import { Link, useLocation, useSearchParams } from "react-router-dom";
import type {
  PerformanceGateway,
  PerformanceState,
  PerformanceReport,
  BaselineNotes,
} from "../data/performance";
import { useHenryBinding } from "../components/workspace-henry";
import { MeasurementPanel } from "../components/measurement";
import "../styles/performance.css";
import { DataError } from "../data/gateway";
const metricLabels = {
  sessions: "Sessions",
  totalUsers: "Users",
  newUsers: "New users",
  screenPageViews: "Page / screen views",
  engagedSessions: "Engaged sessions",
  keyEvents: "GA4 key events",
} as const;
const number = (v: number | null | undefined) =>
  v == null
    ? "Unavailable"
    : v.toLocaleString("en-GB", { maximumFractionDigits: 1 });
const duration = (w: { startDate: string; endDate: string }) =>
  +new Date(w.endDate) - +new Date(w.startDate);
const emptyNotes: BaselineNotes = {
  label: "Before campaign launch",
  customerCount: null,
  customerNote: "",
};
export function PerformancePage({
  api,
  workspaceId: w,
}: {
  api?: PerformanceGateway;
  workspaceId: string;
}) {
  const [params] = useSearchParams(),
    location = useLocation();
  const [state, setState] = useState<PerformanceState>(),
    [data, setData] = useState<PerformanceReport>();
  const [window, setWindow] = useState({ startDate: "", endDate: "" }),
    [campaignId, setCampaignId] = useState(params.get("campaign") || "");
  const [notes, setNotes] = useState<BaselineNotes>(emptyNotes),
    [editingBaseline, setEditingBaseline] = useState(false);
  const [tagField, setTagField] = useState<
      "sessionCampaignId" | "sessionCampaignName"
    >("sessionCampaignId"),
    [tagValue, setTagValue] = useState("");
  const [retry, setRetry] = useState(0);
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState("");
  const controller = useRef<AbortController | null>(null),
    lock = useRef(false),
    saveKey = useRef<{ body: string; key: string } | null>(null);
  const root = location.pathname.replace(/\/performance\/?$/, ""),
    query = location.pathname.startsWith("/client")
      ? `?workspace=${encodeURIComponent(w)}`
      : "";
  const baseline = state?.baseline,
    traffic = data?.analytics?.traffic;
  const comparable = Boolean(
    !data?.campaign &&
    baseline &&
    data?.analytics &&
    baseline.snapshot.analytics.property.name ===
      data.analytics.property.name &&
    baseline.snapshot.analytics.traffic.timeZone ===
      data.analytics.traffic.timeZone &&
    duration(baseline.snapshot.window) === duration(data.window),
  );
  function savedReport(r: PerformanceReport) {
    setData(r);
    setTagField(r.mapping?.filter?.field || "sessionCampaignId");
    setTagValue(r.mapping?.filter?.value || "");
  }
  useEffect(() => {
    const c = new AbortController();
    controller.current = c;
    lock.current = true;
    setBusy(true);
    setError("");
    if (!api) {
      setBusy(false);
      lock.current = false;
      return () => c.abort();
    }
    void (async () => {
      try {
        const s = await api.read(w, c.signal);
        if (c.signal.aborted) return;
        setState(s);
        setWindow(s.defaultWindow);
        setNotes(s.baseline?.notes || emptyNotes);
        const r = await api.report(
          w,
          {
            window: s.defaultWindow,
            ...(params.get("campaign")
              ? { campaignId: params.get("campaign") }
              : {}),
          },
          c.signal,
        );
        if (!c.signal.aborted) savedReport(r);
      } catch (e) {
        if (!c.signal.aborted)
          setError(
            e instanceof DataError ? e.userMessage || "Performance data could not load. Refresh and retry." : e instanceof Error ? e.message : "Performance data could not load.",
          );
      } finally {
        if (!c.signal.aborted) {
          setBusy(false);
          lock.current = false;
        }
      }
    })();
    return () => {
      c.abort();
      controller.current?.abort();
      lock.current = false;
    };
    // The workspace owns this view. Changing filters loads only through Refresh report.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [api, w, retry]);
  async function run(task: (signal: AbortSignal) => Promise<void>) {
    if (lock.current || !api) return;
    lock.current = true;
    setBusy(true);
    setError("");
    setNotice("");
    const c = new AbortController();
    controller.current?.abort();
    controller.current = c;
    try {
      await task(c.signal);
    } catch (e) {
      if (!c.signal.aborted)
        setError(
          e instanceof DataError
            ? e.userMessage || "The operation failed. Refresh and retry."
            : e instanceof Error
            ? e.message
            : "The operation failed. Refresh and retry.",
        );
    } finally {
      if (!c.signal.aborted) {
        lock.current = false;
        setBusy(false);
      }
    }
  }
  async function refresh() {
    await run(async (signal) => {
      const s = await api!.read(w, signal);
      const r = await api!.report(
        w,
        { window, ...(campaignId ? { campaignId } : {}) },
        signal,
      );
      if (signal.aborted) return;
      setState(s);
      savedReport(r);
      setNotice("Report refreshed from its sources.");
    });
  }
  async function saveBaseline(action: "capture" | "correct" | "archive") {
    if (!state || !data) return;
    if (
      action === "archive" &&
      !globalThis.confirm(
        "Archive this baseline? Its evidence history is retained.",
      )
    )
      return;
    if (
      action === "capture" &&
      baseline &&
      !globalThis.confirm(
        "Replace the active baseline with a fresh snapshot for this report period? The previous evidence is retained.",
      )
    )
      return;
    await run(async (signal) => {
      const body = {
        action,
        expectedVersion: state.baselineVersion,
        ...(action === "capture" ? { window: data.window } : {}),
        ...(action !== "archive" ? { notes } : {}),
      };
      const serial = JSON.stringify(body);
      if (saveKey.current?.body !== serial)
        saveKey.current = { body: serial, key: crypto.randomUUID() };
      const s = await api!.baseline(
        w,
        { ...body, requestId: saveKey.current.key },
        signal,
      );
      if (signal.aborted) return;
      setState(s);
      setNotes(s.baseline?.notes || emptyNotes);
      setEditingBaseline(false);
      saveKey.current = null;
      setNotice(
        action === "archive"
          ? "Baseline archived; history retained."
          : "Saved baseline displayed below.",
      );
    });
  }
  async function saveAttribution(remove = false) {
    if (!data?.campaign) return;
    await run(async (signal) => {
      await api!.attribution(
        w,
        {
          campaignId: data.campaign!.id,
          expectedVersion: data.mapping?.id ?? null,
          filter: remove ? null : { field: tagField, value: tagValue },
        },
        signal,
      );
      const r = await api!.report(
        w,
        { window: data.window, campaignId: data.campaign!.id },
        signal,
      );
      if (signal.aborted) return;
      savedReport(r);
      setNotice(
        remove
          ? "Campaign tag unlinked."
          : "Campaign tag saved and report refreshed.",
      );
    });
  }
  function exportReport() {
    if (!data) return;
    const { measurement, ...report } = data;
    const content = JSON.stringify(
      {
        ...report,
        measurement: {
          metrics: measurement.metrics,
          truncated: measurement.truncated,
          updatedAt: measurement.updatedAt,
        },
        baseline: state?.baseline ?? null,
      },
      null,
      2,
    );
    const url = URL.createObjectURL(
      new Blob([content], { type: "application/json" }),
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = `hvm-performance-${data.window.startDate}-${data.window.endDate}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
  useHenryBinding({
    key: "performance",
    summary: JSON.stringify({
      scope: data?.campaign?.name || "Overall workspace",
      window: data?.window,
      property: data?.analytics?.property,
      traffic: traffic?.totals,
      warnings: traffic?.warnings,
      baseline: baseline
        ? {
            notes: baseline.notes,
            window: baseline.snapshot.window,
            traffic: baseline.snapshot.analytics.traffic.totals,
          }
        : null,
      outcomes: data?.measurement.metrics,
      availability: data?.analyticsError,
      limitations:
        "GA4 users are not identified contacts. Key events are not confirmed customers. Customer baseline is user-reported. HVM outcome day boundaries are UTC. Suggestions do not save baselines or send campaigns.",
    }),
    editor: editingBaseline
      ? {
          key: "performance-baseline",
          title: "Baseline business context",
          fields: [
            { key: "label", label: "Baseline label", value: notes.label },
            {
              key: "customerCount",
              label: "Business-confirmed customer total",
              value: notes.customerCount?.toString() || "",
            },
            {
              key: "customerNote",
              label: "Source and as-of date",
              value: notes.customerNote,
            },
          ],
        }
      : undefined,
    apply: (changes) =>
      setNotes((old) => {
        const next = { ...old };
        for (const c of changes) {
          if (c.key === "label") next.label = c.value.slice(0, 120);
          if (c.key === "customerNote")
            next.customerNote = c.value.slice(0, 2000);
          if (
            c.key === "customerCount" &&
            (c.value === "" || /^\d+$/.test(c.value))
          )
            next.customerCount = c.value === "" ? null : Number(c.value);
        }
        return next;
      }),
    actions: [
      {
        id: "review_baseline",
        label: "Prepare baseline details for review",
        run: () => setEditingBaseline(true),
      },
    ],
  });
  if (!api)
    return (
      <p role="status">
        Performance reporting is unavailable in this environment.
      </p>
    );
  return (
    <div className="performance-page">
      <p>
        Website traffic, campaign outcomes and a saved starting point. Ask Henry
        to explain the evidence or prepare baseline details.
      </p>
      <form
        className="panel performance-controls"
        onSubmit={(e) => {
          e.preventDefault();
          void refresh();
        }}
      >
        <label>
          Report scope
          <select
            value={campaignId}
            disabled={busy}
            onChange={(e) => setCampaignId(e.target.value)}
          >
            <option value="">Overall workspace</option>
            {state?.campaigns.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Start date
          <input
            type="date"
            required
            value={window.startDate}
            disabled={busy}
            onChange={(e) =>
              setWindow({ ...window, startDate: e.target.value })
            }
          />
        </label>
        <label>
          End date
          <input
            type="date"
            required
            value={window.endDate}
            disabled={busy}
            onChange={(e) => setWindow({ ...window, endDate: e.target.value })}
          />
        </label>
        <button className="button" disabled={busy || !state}>
          {busy ? "Loading…" : "Refresh report"}
        </button>
      </form>
      {state?.campaignsTruncated && (
        <p role="status">
          Campaign list is limited to the latest 2,000 setup records.
        </p>
      )}
      {error && (
        <p role="alert">
          {error} {data ? "The previous report remains below." : ""}
        </p>
      )}
      {error && !state && (
        <button
          className="button"
          disabled={busy}
          onClick={() => setRetry((v) => v + 1)}
        >
          Retry loading
        </button>
      )}
      {notice && <p role="status">{notice}</p>}
      {data && (
        <>
          <div className="performance-heading">
            <div>
              <h2>
                {data.campaign
                  ? `${data.campaign.name} performance`
                  : "Overall performance"}
              </h2>
              <p>
                {data.window.startDate} to {data.window.endDate} · Retrieved{" "}
                {new Date(data.fetchedAt).toLocaleString("en-GB")}
              </p>
            </div>
            <button className="button secondary" onClick={exportReport}>
              Export evidence
            </button>
          </div>
          {data.campaign && (
            <section className="panel">
              <h3>Campaign traffic attribution</h3>
              {data.mapping?.automatic ? <p>HVM automatically tags this campaign’s email CTA links and matches them to the GA4 property selected in campaign preparation. Test email tags are separate. To change the reporting property, review and save campaign preparation.</p> : <>
              <p>
                Match one exact GA4 session campaign tag. Use a unique tag for
                this HVM campaign; matching a shared name combines all traffic
                carrying that name. This does not edit or send campaign links.
              </p>
              {data.campaignTags.length > 0 && (
                <label>
                  Known GA4 campaign tags
                  <select
                    disabled={busy || !state?.canManage}
                    value=""
                    onChange={(e) => {
                      const tag = data.campaignTags[Number(e.target.value)];
                      if (tag) {
                        setTagField(tag.field);
                        setTagValue(tag.value);
                      }
                    }}
                  >
                    <option value="">
                      Choose the campaign used in your links
                    </option>
                    {data.campaignTags.map((t, i) => (
                      <option key={`${t.field}:${t.value}`} value={i}>
                        {t.label} ({t.value})
                      </option>
                    ))}
                  </select>
                </label>
              )}
              <div className="performance-controls">
                <label>
                  Match by
                  <select
                    disabled={!state?.canManage || busy}
                    value={tagField}
                    onChange={(e) =>
                      setTagField(e.target.value as typeof tagField)
                    }
                  >
                    <option value="sessionCampaignId">
                      Campaign ID (utm_id)
                    </option>
                    <option value="sessionCampaignName">
                      Campaign name (utm_campaign)
                    </option>
                  </select>
                </label>
                <label>
                  Exact tag value
                  <input
                    disabled={!state?.canManage || busy}
                    value={tagValue}
                    maxLength={200}
                    onChange={(e) => setTagValue(e.target.value)}
                  />
                </label>
                <button
                  className="button"
                  disabled={busy || !state?.canManage || !tagValue.trim()}
                  onClick={() => void saveAttribution()}
                >
                  Save tag and refresh
                </button>
                {data.mapping && !data.mapping.removed && (
                  <button
                    className="button secondary"
                    disabled={busy || !state?.canManage}
                    onClick={() => void saveAttribution(true)}
                  >
                    Unlink tag
                  </button>
                )}
              </div>
              {data.mapping?.filter && !data.mapping.removed && (
                <p>
                  Saved match: {data.mapping.filter.value}. Bound to the
                  property selected when saved.
                </p>
              )}
              </>}
            </section>
          )}
          <section aria-label="Website performance">
            <h3>Website traffic</h3>
            {data.analyticsError && (
              <p role="status">
                {data.analyticsError}{" "}
                <Link to={`${root}/integrations${query}`}>
                  Open Integrations
                </Link>
              </p>
            )}
            {traffic && (
              <>
                <p>
                  {data.analytics!.property.displayName} · {traffic.timeZone}.
                  Includes traffic collected by this GA4 property; GA4’s own
                  filters determine internal/test traffic inclusion. Recent data
                  may still change.
                </p>
                {!traffic.totals && (
                  <p role="status">
                    Google returned no report rows. This does not establish that
                    tracking is installed or that traffic is zero.
                  </p>
                )}
                {!!traffic.warnings.length && (
                  <ul>
                    {traffic.warnings.map((x) => (
                      <li key={x}>{x}</li>
                    ))}
                  </ul>
                )}
                <div className="performance-metrics">
                  {Object.entries(metricLabels).map(([key, label]) => {
                    const k = key as keyof typeof metricLabels,
                      v = traffic.totals?.[k],
                      b = baseline?.snapshot.analytics.traffic.totals?.[k];
                    return (
                      <article className="panel" key={key}>
                        <h4>{label}</h4>
                        <p className="performance-number">{number(v)}</p>
                        {comparable && b != null && v != null && (
                          <small>
                            Baseline {number(b)} ·{" "}
                            {b === 0
                              ? "Percentage change unavailable from zero"
                              : `${(((v - b) / b) * 100).toFixed(1)}% change`}
                          </small>
                        )}
                      </article>
                    );
                  })}
                </div>
                <p>
                  Users are GA4 users, not CRM contacts. GA4 key events follow
                  the property configuration and are not confirmed sales or
                  qualified leads. Unique users are queried for the whole
                  period, never summed across rows.
                </p>
                {traffic.daily.rows.length > 0 && (
                  <section className="panel">
                    <h4>Daily sessions</h4>
                    <div
                      className="performance-bars"
                      role="img"
                      aria-label={`Daily sessions for ${data.window.startDate} to ${data.window.endDate}. Exact values in the table below.`}
                    >
                      {traffic.daily.rows.map((r) => (
                        <span
                          key={r.dimensions[0]}
                          title={`${r.dimensions[0]}: ${number(r.metrics.sessions)} sessions`}
                          style={{
                            height: `${Math.max(1, (r.metrics.sessions / Math.max(1, ...traffic.daily.rows.map((d) => d.metrics.sessions))) * 100)}%`,
                          }}
                        />
                      ))}
                    </div>
                    <details>
                      <summary>
                        Daily figures ({traffic.daily.rows.length} reported
                        days)
                      </summary>
                      <TrafficTable rows={traffic.daily.rows} label="Date" />
                    </details>
                    <p className="muted">
                      Only days returned by GA4 are shown; missing days are not
                      filled with invented zeros.
                    </p>
                  </section>
                )}
                <div className="performance-breakdowns">
                  <section className="panel">
                    <h4>Traffic sources</h4>
                    <TrafficTable
                      rows={traffic.sources.rows}
                      label="Source / medium"
                    />
                    {traffic.sources.truncated && (
                      <p>
                        Partial breakdown; total metrics above are queried
                        separately.
                      </p>
                    )}
                  </section>
                  <section className="panel">
                    <h4>GA4 campaigns</h4>
                    <TrafficTable
                      rows={traffic.campaigns.rows}
                      label="Campaign ID · name"
                    />
                    {traffic.campaigns.truncated && (
                      <p>
                        Partial breakdown; total metrics above are queried
                        separately.
                      </p>
                    )}
                  </section>
                </div>
              </>
            )}
          </section>
          {!data.campaign && (
            <section className="panel" aria-label="Saved baseline">
              <h3>Saved baseline</h3>
              {baseline ? (
                <>
                  <h4>{baseline.notes.label}</h4>
                  <p>
                    {baseline.snapshot.window.startDate} to{" "}
                    {baseline.snapshot.window.endDate} ·{" "}
                    {baseline.snapshot.analytics.property.displayName} ·
                    Captured{" "}
                    {new Date(baseline.capturedAt).toLocaleString("en-GB")}
                  </p>
                  <p>
                    Sessions:{" "}
                    {number(
                      baseline.snapshot.analytics.traffic.totals?.sessions,
                    )}{" "}
                    · Users:{" "}
                    {number(
                      baseline.snapshot.analytics.traffic.totals?.totalUsers,
                    )}{" "}
                    · Business-confirmed customers:{" "}
                    {number(baseline.notes.customerCount)}
                  </p>
                  <p>
                    {baseline.notes.customerNote ||
                      "No business customer total supplied."}
                  </p>
                  <p className="muted">
                    Customer count is a declared business fact, not derived from
                    the contact count or GA4. Stored evidence stays fixed;
                    corrections and replacement retain prior history.
                  </p>
                  {!comparable && (
                    <p>
                      Percentage comparison requires the same GA4 property and
                      equal-length periods.
                    </p>
                  )}
                </>
              ) : (
                <p>
                  No baseline saved. Load a pre-campaign period, add the
                  business context, then capture its evidence.
                </p>
              )}
              {state?.canManage ? (
                <>
                  <div className="performance-actions">
                    <button
                      className="button secondary"
                      disabled={busy}
                      onClick={() => setEditingBaseline((v) => !v)}
                    >
                      {editingBaseline
                        ? "Close details"
                        : "Review baseline details"}
                    </button>
                    {baseline && (
                      <button
                        className="button secondary"
                        disabled={busy}
                        onClick={() => void saveBaseline("archive")}
                      >
                        Archive baseline
                      </button>
                    )}
                  </div>
                  {editingBaseline && (
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        void saveBaseline("capture");
                      }}
                    >
                      <div className="performance-controls">
                        <label>
                          Baseline label
                          <input
                            required
                            maxLength={120}
                            value={notes.label}
                            onChange={(e) =>
                              setNotes({ ...notes, label: e.target.value })
                            }
                          />
                        </label>
                        <label>
                          Business-confirmed customers (optional)
                          <input
                            type="number"
                            min="0"
                            max="100000000"
                            step="1"
                            value={notes.customerCount ?? ""}
                            onChange={(e) =>
                              setNotes({
                                ...notes,
                                customerCount:
                                  e.target.value === ""
                                    ? null
                                    : Number(e.target.value),
                              })
                            }
                          />
                        </label>
                      </div>
                      <label>
                        Customer source, as-of date and coverage
                        <textarea
                          required={notes.customerCount !== null}
                          maxLength={2000}
                          value={notes.customerNote}
                          onChange={(e) =>
                            setNotes({ ...notes, customerNote: e.target.value })
                          }
                        />
                      </label>
                      <p>
                        Capture uses the displayed report period,{" "}
                        {data.window.startDate} to {data.window.endDate}, and
                        reads a fresh GA4 snapshot. Choose dates before campaign
                        activity for a true before picture.
                      </p>
                      <div className="performance-actions">
                        {baseline && (
                          <button
                            type="button"
                            className="button secondary"
                            disabled={busy}
                            onClick={() => void saveBaseline("correct")}
                          >
                            Save business-context correction
                          </button>
                        )}
                        <button
                          className="button"
                          disabled={busy || !traffic?.totals}
                        >
                          {baseline
                            ? "Replace baseline snapshot"
                            : "Capture baseline"}
                        </button>
                      </div>
                    </form>
                  )}
                </>
              ) : (
                <p>
                  Workspace management permission is required to capture or
                  change the baseline.
                </p>
              )}
            </section>
          )}
          <section>
            <h3>HVM campaign outcomes</h3>
            <p>
              Period uses UTC day boundaries. Accepted emails, reviewed replies
              and supported outcomes come from HVM. Test communications are
              excluded. These counts are separate from GA4 visitor metrics.
            </p>
            <section aria-label="Confirmed business outcomes">
              <h4>Confirmed business outcomes</h4>
              {data.businessOutcomes ? <><p>{data.businessOutcomes.configured} outcomes configured · {data.businessOutcomes.receiving} receiving evidence. {!data.businessOutcomes.receiving && "Receiving is off; recorded counts do not establish that no outcomes occurred."}</p><p>{data.businessOutcomes.confirmed} source-confirmed outcomes · {data.businessOutcomes.attributed} attributed · {data.businessOutcomes.unattributed} unattributed{data.businessOutcomes.truncated ? " (partial: first 10,000)" : ""}.</p>
                <ul>{data.businessOutcomes.byOutcome.map(o => <li key={o.id}>{o.name}: {o.count}</li>)}</ul>
                <p>Unique account/outcome references reported by connected sources. Test and retracted evidence is excluded. {data.campaign ? "Only evidence with this campaign’s matching reference is included." : "Unattributed outcomes remain in the overall total."} GA4 key events and website clicks are separate.</p></> : <p>Outcome reporting is unavailable on this API version.</p>}
              <Link to={`${root}/integrations${query}`}>Define outcomes and connect evidence in Integrations</Link>
            </section>
            <MeasurementPanel data={data.measurement} headingLevel={4} />
          </section>
        </>
      )}
    </div>
  );
}
function TrafficTable({
  rows,
  label,
}: {
  rows: NonNullable<
    PerformanceReport["analytics"]
  >["traffic"]["sources"]["rows"];
  label: string;
}) {
  return rows.length ? (
    <>
      <div
        className="performance-table"
        tabIndex={0}
        role="region"
        aria-label={label}
      >
        <table>
          <thead>
            <tr>
              <th>{label}</th>
              <th>Sessions</th>
              <th>Users</th>
              <th>Engaged sessions</th>
            </tr>
          </thead>
          <tbody>
            {rows.slice(0, 50).map((r, i) => (
              <tr key={i}>
                <th scope="row">{r.dimensions.join(" · ")}</th>
                <td>{number(r.metrics.sessions)}</td>
                <td>{number(r.metrics.totalUsers)}</td>
                <td>{number(r.metrics.engagedSessions)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {rows.length > 50 && (
        <p>
          Showing 50 of {rows.length} returned rows. Export evidence for all
          returned rows.
        </p>
      )}
    </>
  ) : (
    <p>No report rows returned for this breakdown.</p>
  );
}
