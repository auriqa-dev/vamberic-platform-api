import {ResearchEvidencePanel} from "../components/research-evidence";
import type {ResearchGateway} from "../data/research";
import { useHenryBinding, useHenryBrand, henryFields, applyHenryFields } from "../components/workspace-henry";
import { IcpEligibility } from "../components/icp-eligibility";
import { IcpGenerationPanel } from "../components/icp-generation";
import { useEffect, useRef, useState } from "react";
import {
  accountFields,
  consumerFields,
  definitionSchema,
  profileFields,
  type IcpDefinition,
  type IcpGateway,
  type IcpProduct,
  type IcpRecord,
  type IcpOffer,
} from "../data/icp";
import { DataError } from "../data/gateway";
import type { PsuGateway } from "../data/psu";
const empty = (): IcpDefinition => ({
  name: "",
  description: "",
  profileType: "b2b",
  accountProfile: {},
});
const split = (value: string) => [
  ...new Set(
    value
      .split("\n")
      .map((v) => v.trim())
      .filter(Boolean),
  ),
];
function message(error: unknown) {
  return error instanceof DataError && error.code === "conflict"
    ? "This profile changed elsewhere. Your edits are still here. Reopen the profile to load the latest version before saving."
    : "We couldn’t complete that action. Your edits are still here. Please try again.";
}
export function IcpPage({
  api,
  psu,
  workspaceId: w,
  research,
}: {
  api?: IcpGateway;
  psu?: PsuGateway;
  workspaceId: string;
  research?:ResearchGateway;
}) {
  const [tool, setTool] = useState<"profiles" | "generate">("profiles");
  const [generationId, setGenerationId] = useState<string>();
  const carriedBrand=useRef(useHenryBrand()).current;
  const [products, setProducts] = useState<IcpProduct[]>([]);
  const [product, setProduct] = useState("");
  const [offers, setOffers] = useState<IcpOffer[]>([]);
  const [offerId, setOfferId] = useState("");
  const [link, setLink] = useState<{ id: string; revision: number }>();
  const [records, setRecords] = useState<IcpRecord[]>([]);
  const [selected, setSelected] = useState<IcpRecord>();
  const [editing, setEditing] = useState(false);
  const [definition, setDefinition] = useState<IcpDefinition>(empty);
  const [typeChosen, setTypeChosen] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [archived, setArchived] = useState(false);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [reload, setReload] = useState(0);
  const [refs, setRefs] = useState({
    industries: [] as string[],
    regions: [] as string[],
  });
  const lock = useRef(false);
  const alive = useRef(true);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);
  useEffect(() => {
    const controller = new AbortController();
    if (!api) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError("");
    api
      .products(w, controller.signal)
      .then((rows) => {
        if (!controller.signal.aborted) {
          setProducts(rows);
          setProduct((previous) => previous || rows.find(p=>p.brandId===carriedBrand)?.id || rows[0]?.id || "");
          setLoading(false);
        }
      })
      .catch((e) => {
        if (!controller.signal.aborted) {
          setLoading(false);
          setError(message(e));
        }
      });
    return () => controller.abort();
  }, [api, w, reload, carriedBrand]);
  useEffect(() => {
    const controller = new AbortController();
    if (psu)
      psu
        .referenceData(w, controller.signal)
        .then((data) => {
          if (!controller.signal.aborted)
            setRefs({
              industries: data.industries.map((r) => r.name),
              regions: data.regions.map((r) => r.name),
            });
        })
        .catch(() => {
          if (!controller.signal.aborted)
            setError(
              "Industry and region lists could not be loaded. Retry to load the lists; your selections are retained.",
            );
        });
    return () => controller.abort();
  }, [psu, w, reload]);
  useEffect(() => {
    const controller = new AbortController();
    if (!api || !product) return;
    setLoading(true);
    setRecords([]);
    api
      .list(w, product, archived, controller.signal)
      .then((rows) => {
        if (!controller.signal.aborted) {
          setRecords(rows);
          setLoading(false);
        }
      })
      .catch((e) => {
        if (!controller.signal.aborted) {
          setError(message(e));
          setLoading(false);
        }
      });
    return () => controller.abort();
  }, [api, w, product, archived, reload]);
  useEffect(() => {
    const controller = new AbortController();
    setOffers([]);
    if (!api || !product) return;
    api
      .offers(w, product, controller.signal)
      .then((rows) => {
        if (controller.signal.aborted) return;
        setOffers(rows);
        setOfferId((previous) =>
          rows.some((row) => row.id === previous)
            ? previous
            : rows.length === 1
              ? rows[0]!.id
              : "",
        );
      })
      .catch(() => {
        if (!controller.signal.aborted)
          setError(
            "Approved offers could not be loaded. Retry loading before creating a profile.",
          );
      });
    return () => controller.abort();
  }, [api, w, product, reload]);
  const chosenOffer = offers.find((row) => row.id === offerId);
  const offerContext = chosenOffer?.approvedRevision
    ? { id: chosenOffer.id, revision: chosenOffer.approvedRevision }
    : undefined;
  const visibleRecords = records.filter(
    (row) => !row.offer || !offerId || row.offer.id === offerId,
  );
  const mayLeave = () =>
    !dirty || window.confirm("Discard your unsaved profile changes?");
  const open = (row?: IcpRecord) => {
    if (!mayLeave()) return;
    setGenerationId(undefined);
    setSelected(row);
    setLink(row ? row.offer : offerContext);
    setDefinition(row ? structuredClone(row.definition) : empty());
    setTypeChosen(Boolean(row));
    setTool("profiles");
    setEditing(true);
    setDirty(false);
    setError("");
    setNotice("");
  };
  const change = (next: IcpDefinition) => {
    setDefinition(next);
    setDirty(true);
    setNotice("");
  };
  const mutate = async (
    operation: "create" | "update" | "revise" | "approve" | "archive",
  ) => {
    if (!api || lock.current) return;
    if (["create", "update", "revise"].includes(operation) && !typeChosen) { setError("Choose a customer type before saving this profile."); return; }
    if (
      (operation === "create" || operation === "update") &&
      !definitionSchema.safeParse(definition).success
    ) {
      setError(
        "Enter a profile name and description. Use up to 40 different entries per list, with no more than 2,000 characters per entry.",
      );
      return;
    }
    if (
      operation === "archive" &&
      !window.confirm(
        "Archive this profile? It will remain available in archived profiles.",
      )
    )
      return;
    lock.current = true;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const body =
        operation === "create"
          ? { offeringId: product, offer: link, definition }
          : {
              id: selected!.id,
              expectedUpdatedAt: selected!.updatedAt,
              ...(operation === "update"
                ? { definition, ...(link ? { offer: link } : {}) }
                : {}),
            };
      const row =
        operation === "create" && generationId
          ? await api.saveGeneration(
              w,
              generationId,
              definition,
              new AbortController().signal,
            )
          : await api.mutate(w, operation, body, new AbortController().signal);
      if (!alive.current) return;
      setSelected(row);
      setLink(row.offer);
      setDefinition(structuredClone(row.definition));
      setDirty(false);
      setNotice(
        operation === "approve"
          ? "Profile approved."
          : operation === "archive"
            ? "Profile archived."
            : operation === "revise"
              ? "New draft ready to edit. The previous approved version is retained."
              : "Profile saved.",
      );
      setReload((n) => n + 1);
    } catch (e) {
      if (alive.current) setError(message(e));
    } finally {
      lock.current = false;
      if (alive.current) setBusy(false);
    }
  };
  useHenryBinding({key:"icp",brandId:products.find(p=>p.id===product)?.brandId,summary:JSON.stringify({product,offerId,profiles:records.map(r=>({id:r.id,name:r.definition.name,status:r.status})),current:definition}),
    editor:editing&&!busy&&selected?.status!=="approved"&&selected?.status!=="retired"?{key:`icp:${selected?.id??"new"}:${selected?.updatedAt??"new"}`,title:"Ideal customer profile",fields:henryFields({...Object.fromEntries(Object.keys(profileFields).map(k=>[k,[]])),...definition})}:undefined,
    apply:changes=>{setDefinition(definitionSchema.parse(applyHenryFields({...Object.fromEntries(Object.keys(profileFields).map(k=>[k,[]])),...definition},changes)));setDirty(true);},
    actions:busy?[]:[{id:"icp:generate",label:"Prepare customer profile generation",run:()=>{if(mayLeave())setTool("generate");}},...records.map(r=>({id:`icp:${r.id}`,label:`Review profile: ${r.definition.name}`,run:()=>{if(mayLeave()){setSelected(r);setLink(r.offer);setDefinition(structuredClone(r.definition));setEditing(true);setTool("profiles");setDirty(false);}}}))],
  });
  if (!api)
    return <p>Ideal customer profiles are unavailable in this environment.</p>;
  const readOnly =
    selected?.status === "approved" || selected?.status === "retired";
  return (
    <div className="icp-page">
      <p>Define the customers who are a good fit for each approved offer.</p>
      <div className="icp-toolbar">
        <label>
          Product or service
          <select
            disabled={busy || loading}
            value={product}
            onChange={(e) => {
              if (mayLeave()) {
                setProduct(e.target.value);
                setOfferId("");
                setOffers([]);
                setEditing(false);
                setSelected(undefined);
                setDirty(false);
                setError("");
              }
            }}
          >
            {!products.length && <option value="">No products yet</option>}
            {products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.definition.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Approved offer
          <select
            value={offerId}
            disabled={busy}
            onChange={(e) => {
              if (mayLeave()) {
                setOfferId(e.target.value);
                setEditing(false);
                setSelected(undefined);
                setDirty(false);
                setTool("profiles");
                setError("");
              }
            }}
          >
            <option value="">
              {offers.length
                ? "Choose an offer"
                : "Approve an offer in Offer Architecture first"}
            </option>
            {offers.map((row) => (
              <option key={row.id} value={row.id}>
                {row.definition.name} · Version {row.approvedRevision}
              </option>
            ))}
          </select>
        </label>
        {records.length > 0 && (
          <button
            type="button"
            disabled={!offerContext || busy || loading}
            onClick={() => open()}
          >
            Add
          </button>
        )}
        {records.length > 0 && tool !== "generate" && (
          <button
            type="button"
            disabled={!offerContext || busy}
            onClick={() => {
              if (mayLeave()) {
                setTool("generate");
                setEditing(false);
                setDirty(false);
              }
            }}
          >
            Generate ICP
          </button>
        )}
      </div>
      {error && (
        <div role="alert" className="icp-feedback">
          {error}{" "}
          <button
            type="button"
            disabled={busy}
            onClick={() => setReload((n) => n + 1)}
          >
            Retry loading
          </button>
        </div>
      )}
      {notice && <p role="status">{notice}</p>}
      {loading && <p role="status">Loading profiles…</p>}
      {!loading && !products.length && (
        <p>
          Add a product in Company & products before creating its customer
          profiles.
        </p>
      )}
      {offerContext &&
        (tool === "generate" ||
          (!loading &&
            !visibleRecords.length &&
            !editing &&
            !archived &&
            !!product)) && (
          <IcpGenerationPanel
            key={product + offerId}
            api={api}
            w={w}
            product={product}
            offer={offerContext}
            initialType={
              products.find((p) => p.id === product)?.definition.businessModel
            }
            onUse={(d, id) => {
              setGenerationId(id);
              setLink(offerContext);
              setSelected(undefined);
              setDefinition(d);
              setTypeChosen(true);
              setEditing(true);
              setDirty(true);
              setTool("profiles");
              setError("");
            }}
          />
        )}
      <section className="panel icp-list" aria-label="Your profiles">
        <div className="icp-toolbar">
          <h2>Your profiles</h2>
          <label className="icp-check">
            <input
              type="checkbox"
              checked={archived}
              disabled={busy}
              onChange={(e) => setArchived(e.target.checked)}
            />
            Show archived
          </label>
        </div>
        {!loading && !records.length && (
          <p>
            {archived
              ? "No archived profiles."
              : "Your first customer profile starts here."}
          </p>
        )}
        {visibleRecords.map((row) => (
          <button
            key={row.id}
            type="button"
            className="icp-record"
            disabled={busy}
            onClick={() => open(row)}
          >
            <strong>{row.definition.name}</strong>
            <span>
              {row.status} · Version {row.revision} ·{" "}
              {row.offer
                ? row.offerLinkStatus === "stale"
                  ? "Offer changed — review needed"
                  : "Offer version " + row.offer.revision
                : "Needs offer association"}
            </span>
          </button>
        ))}
      </section>
      {!editing && (
        <><section className="panel"><h2>Targeting from your approved profiles</h2><p>Your profiles describe customer fit, pain signals, readiness and exclusions. Campaigns uses this context for research; you do not need to recreate it as matching rules.</p><p>Overlapping offers are governed by Contact Strategy. A possible match does not authorise outreach.</p></section><details><summary>Existing eligibility policies</summary><IcpEligibility api={api} w={w} profiles={records} offers={offers} readOnly /></details></>
      )}
      {editing && (
        <section className="panel icp-editor" aria-label="Profile editor">
          <div className="icp-toolbar">
            <h2>
              {selected ? selected.definition.name : "New customer profile"}
            </h2>
            <span>
              {selected
                ? `${selected.status} · Version ${selected.revision}`
                : "Draft"}
            </span>
          </div>
          {selected?.approvedRevision && selected.status === "draft" && (
            <p>
              Approved version {selected.approvedRevision} remains in use until
              you approve this draft.
            </p>
          )}
          {selected && <ResearchEvidencePanel api={research} w={w} type="ideal_customer_profiles" id={selected.id}/>}
          {selected && !selected.offer && (
            <p role="status">
              This existing profile has no offer association. Its content and
              history are preserved.{" "}
              {readOnly
                ? "Create a new draft to link it to an approved offer."
                : "Choose an offer below when you are ready to review its fit."}
            </p>
          )}
          {selected?.offerLinkStatus === "stale" && (
            <p role="status">
              The approved offer has changed. Review this profile in a new draft
              before linking it to the current offer version.
            </p>
          )}
          <fieldset disabled={busy || readOnly}>
            <label>
              Offer for this profile
              <select
                disabled={!!generationId}
                value={link ? link.id + ":" + link.revision : ""}
                onChange={(e) => {
                  const row = offers.find(
                    (row) =>
                      row.id + ":" + row.approvedRevision === e.target.value,
                  );
                  if (row?.approvedRevision) {
                    setLink({ id: row.id, revision: row.approvedRevision });
                    setDirty(true);
                  }
                }}
              >
                <option value="">Choose an approved offer</option>
                {link &&
                  !offers.some(
                    (row) =>
                      row.id === link.id &&
                      row.approvedRevision === link.revision,
                  ) && (
                    <option value={link.id + ":" + link.revision}>
                      Previous offer version {link.revision} — review required
                    </option>
                  )}
                {offers.map((row) => (
                  <option
                    key={row.id}
                    value={row.id + ":" + row.approvedRevision}
                  >
                    {row.definition.name} · Version {row.approvedRevision}
                  </option>
                ))}
              </select>
            </label>
            <div className="icp-grid">
              <label>
                Profile name
                <input
                  maxLength={200}
                  value={definition.name}
                  onChange={(e) =>
                    change({ ...definition, name: e.target.value })
                  }
                />
              </label>
              <label>
                Customer type
                <select
                  value={typeChosen ? definition.profileType : ""}
                  onChange={(e) => {
                    const type = e.target.value as IcpDefinition["profileType"];
                    if (!type) return;
                    if (
                      typeChosen && type !== definition.profileType &&
                      !window.confirm(
                        "Change customer type? Fields for the previous customer type will be cleared.",
                      )
                    )
                      return;
                    setTypeChosen(true);
                    const {
                      accountProfile: _account,
                      consumerProfile: _consumer,
                      ...base
                    } = definition;
                    void _account;
                    void _consumer;
                    change({
                      ...base,
                      profileType: type,
                      ...(type === "b2b"
                        ? { accountProfile: {} }
                        : { consumerProfile: {} }),
                    });
                  }}
                >
                  <option value="" disabled>Choose a customer type</option>
                  <option value="b2b">Businesses (B2B)</option>
                  <option value="b2c">Consumers (B2C)</option>
                  <option value="d2c">Direct to consumers (D2C)</option>
                </select>
              </label>
              <label className="icp-wide">
                Profile description
                <textarea
                  rows={3}
                  maxLength={10000}
                  value={definition.description}
                  onChange={(e) =>
                    change({ ...definition, description: e.target.value })
                  }
                />
              </label>
            </div>
            <h3>
              {definition.profileType === "b2b"
                ? "Target organisations"
                : "Target customers"}
            </h3>
            <div className="icp-grid">
              {Object.entries(
                definition.profileType === "b2b"
                  ? accountFields
                  : consumerFields,
              ).map(([key, label]) => {
                const group =
                  definition.profileType === "b2b"
                    ? "accountProfile"
                    : "consumerProfile";
                const value = definition[group]?.[key] ?? [];
                const update = (values: string[]) =>
                  change({
                    ...definition,
                    [group]: { ...definition[group], [key]: values },
                  });
                return key === "industries" || key === "geographies" ? (
                  <ReferenceSelect
                    key={key}
                    label={label}
                    values={value}
                    options={
                      key === "industries" ? refs.industries : refs.regions
                    }
                    onChange={update}
                  />
                ) : (
                  <ListField
                    key={key}
                    label={label}
                    values={value}
                    onChange={update}
                  />
                );
              })}
            </div>
            <h3>Needs and fit</h3>
            <p>
              Describe what makes a good customer. Buying triggers indicate
              timing; they do not replace fit.
            </p>
            <div className="icp-grid">
              {Object.entries(profileFields).map(([key, label]) => (
                <ListField
                  key={key}
                  label={label}
                  values={definition[key as keyof typeof profileFields] ?? []}
                  onChange={(values) =>
                    change({ ...definition, [key]: values })
                  }
                />
              ))}
            </div>
          </fieldset>
          <div className="icp-actions">
            {!readOnly && (
              <button
                className="button"
                type="button"
                disabled={
                  busy || (!selected && !link) || (!dirty && !!selected)
                }
                onClick={() => void mutate(selected ? "update" : "create")}
              >
                {busy ? "Saving…" : "Save draft"}
              </button>
            )}
            {selected?.status === "draft" && (
              <button
                type="button"
                disabled={busy || dirty}
                onClick={() => void mutate("approve")}
              >
                Approve profile
              </button>
            )}
            {selected?.status === "approved" && (
              <button
                type="button"
                disabled={busy}
                onClick={() => void mutate("revise")}
              >
                Edit new version
              </button>
            )}
            {selected && selected.status !== "retired" && (
              <button
                type="button"
                disabled={busy || dirty}
                onClick={() => void mutate("archive")}
              >
                Archive profile
              </button>
            )}
          </div>
          {dirty && selected && (
            <p>Save your changes before approving or archiving.</p>
          )}
        </section>
      )}
    </div>
  );
}
function ListField({
  label,
  values,
  onChange,
}: {
  label: string;
  values: string[];
  onChange: (v: string[]) => void;
}) {
  const [text, setText] = useState(values.join("\n"));
  useEffect(() => {
    setText((previous) =>
      split(previous).join("\n") === values.join("\n")
        ? previous
        : values.join("\n"),
    );
  }, [values]);
  return (
    <label>
      {label}
      <textarea
        rows={3}
        value={text}
        onChange={(e) => {
          setText(e.target.value);
          onChange(split(e.target.value));
        }}
      />
      <small>One item per line. Leave blank if unknown.</small>
    </label>
  );
}
function ReferenceSelect({
  label,
  values,
  options,
  onChange,
}: {
  label: string;
  values: string[];
  options: string[];
  onChange: (v: string[]) => void;
}) {
  const [search, setSearch] = useState("");
  return (
    <div className="icp-reference">
      <label>
        {label}
        <input
          type="search"
          placeholder={`Search ${label.toLowerCase()}`}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </label>
      <div className="icp-chips">
        {values.map((v) => (
          <span key={v}>
            {v}
            <button
              type="button"
              aria-label={`Remove ${v}`}
              onClick={() => onChange(values.filter((x) => x !== v))}
            >
              ×
            </button>
          </span>
        ))}
      </div>
      <select
        aria-label={`Add ${label.toLowerCase()}`}
        value=""
        onChange={(e) => {
          if (e.target.value) {
            onChange([...values, e.target.value]);
            setSearch("");
          }
        }}
      >
        <option value="">Choose an option…</option>
        {options
          .filter(
            (v) =>
              !values.includes(v) &&
              v.toLowerCase().includes(search.toLowerCase()),
          )
          .map((v) => (
            <option key={v}>{v}</option>
          ))}
      </select>
    </div>
  );
}
