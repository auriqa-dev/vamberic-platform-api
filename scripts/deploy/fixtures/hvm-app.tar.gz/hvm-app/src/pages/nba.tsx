import { useLocation } from "react-router-dom";
import { MeasurementPanel } from "../components/measurement";
import type {
  ContactManagementGateway,
  ManagedRecord,
} from "../data/contact-management";
import { useCallback, useEffect, useRef, useState } from "react";
import type { Campaign, CampaignGateway } from "../data/campaigns";
import type {
  NbaGateway,
  NbaOverview,
  NbaRecord,
  NbaDecision,
} from "../data/nba";
import { DataError } from "../data/gateway";
import { useHenryBinding } from "../components/workspace-henry";
import "../styles/nba.css";
const label = (value: string) => value.replaceAll("_", " ");
export function NbaPage({
  api,
  campaigns,
  records,
  workspaceId: w,
}: {
  api?: NbaGateway;
  campaigns?: CampaignGateway;
  records?: ContactManagementGateway;
  workspaceId: string;
}) {
  const [overview, setOverview] = useState<NbaOverview>(),
    [choices, setChoices] = useState<Campaign[]>([]),
    [campaignId, setCampaignId] = useState(""),
    [instruction, setInstruction] = useState(""),
    [selected, setSelected] = useState<NbaRecord>(),
    [draft, setDraft] = useState<NbaDecision | null>(null),
    [history, setHistory] = useState<NbaRecord[]>(),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [subjectType, setSubjectType] = useState<
      "campaign" | "organisation" | "person"
    >("campaign"),
    [subjectRecord, setSubjectRecord] = useState<ManagedRecord>(),
    [search, setSearch] = useState(""),
    [recordResults, setRecordResults] = useState<ManagedRecord[]>([]),
    [checked, setChecked] = useState<string[]>([]);
  const controller = useRef<AbortController | null>(null),
    key = useRef(crypto.randomUUID());
  const load = useCallback(
    async (signal: AbortSignal) => {
      if (!api || !campaigns) return;
      const [o, c] = await Promise.all([
        api.list(w, signal),
        campaigns.list(w, signal),
      ]);
      if (!signal.aborted) {
        setOverview(o);
        setChoices(c.campaigns.filter((c) => c.status === "ready"));
      }
    },
    [api, campaigns, w],
  );
  useEffect(() => {
    const c = new AbortController();
    void load(c.signal).catch(() => {
      if (!c.signal.aborted) setError("NBA could not be loaded. Please retry.");
    });
    return () => {
      c.abort();
      controller.current?.abort();
    };
  }, [load]);
  const location = useLocation();
  useEffect(() => {
    const q = new URLSearchParams(location.search),
      campaign = q.get("campaign"),
      contact = q.get("contact");
    const c = new AbortController();
    if (campaign) setCampaignId(campaign);
    if (contact && records) {
      setSubjectType("person");
      records
        .read(w, "contacts", contact, c.signal)
        .then((r) => {
          if (!c.signal.aborted) {
            setSubjectRecord(r);
            setInstruction(
              "Reconsider the next action using the latest communication outcomes and approved campaign criteria. Do not infer sending authority.",
            );
          }
        })
        .catch(() => {
          if (!c.signal.aborted)
            setError(
              "Could not open this contact. Select it from Hive to continue.",
            );
        });
    }
    return () => c.abort();
  }, [location.search, w, records]);
  const campaign = choices.find((c) => c.id === campaignId);
  const selectedCampaign = choices.find((c) => c.id === selected?.campaignId);
  const select = (r: NbaRecord) => {
    setSelected(r);
    setCampaignId(r.campaignId);
    setDraft(r.decision);
    setHistory(undefined);
    setError("");
  };
  async function run(action: (signal: AbortSignal) => Promise<void>) {
    if (controller.current) return;
    const c = new AbortController();
    controller.current = c;
    setBusy(true);
    setError("");
    try {
      await action(c.signal);
    } catch (e) {
      if (!c.signal.aborted)
        setError(
          e instanceof DataError && e.userMessage
            ? e.userMessage
            : "The request could not be completed. Saved work is retained; refresh to check its status.",
        );
    } finally {
      if (!c.signal.aborted) setBusy(false);
      controller.current = null;
    }
  }
  async function preview() {
    if (!api || !campaign) return;
    await run(async (signal) => {
      const record = await api.preview(
        w,
        {
          requestKey: key.current,
          campaignId: campaign.id,
          campaignVersion: campaign.version,
          subject:
            subjectType === "campaign"
              ? { type: "campaign" }
              : { type: subjectType, id: subjectRecord?.id },
          instruction,
        },
        signal,
      );
      if (!signal.aborted) {
        select(record);
        key.current = crypto.randomUUID();
        await load(signal);
      }
    });
  }
  async function change(
    action: "revise" | "reject" | "cancel" | "approve" | "pause" | "resume",
  ) {
    if (!api || !selected) return;
    if (
      action === "cancel" &&
      !window.confirm("Cancel this decision? Its history will be retained.")
    )
      return;
    await run(async (signal) => {
      const record = await api.change(
        w,
        selected.id,
        {
          requestKey: crypto.randomUUID(),
          expectedVersion: selected.version,
          action,
          ...(action === "revise" ? { decision: draft } : {}),
          reason: "",
        },
        signal,
      );
      if (!signal.aborted) {
        select(record);
        await load(signal);
      }
    });
  }
  const active = overview?.decisions.some((r) =>
    ["scheduled", "running", "waiting", "generating"].includes(r.state),
  );
  useEffect(() => {
    if (!api || !active || busy) return;
    const c = new AbortController();
    let polling = false;
    const timer = setInterval(() => {
      if (polling) return;
      polling = true;
      void api
        .list(w, c.signal)
        .then((o) => {
          if (c.signal.aborted) return;
          setOverview(o);
          const current = o.decisions.find((r) => r.id === selected?.id);
          if (
            current &&
            current.version !== selected?.version &&
            JSON.stringify(draft) === JSON.stringify(selected?.decision)
          ) {
            setSelected(current);
            setDraft(current.decision);
          }
        })
        .catch(() => {})
        .finally(() => {
          polling = false;
        });
    }, 10000);
    return () => {
      c.abort();
      clearInterval(timer);
    };
  }, [api, w, active, busy, selected, draft]);
  async function bulk(action: "pause" | "cancel") {
    if (
      !api ||
      !window.confirm(
        `${action === "cancel" ? "Cancel" : "Pause"} ${checked.length} selected decisions? History is retained.`,
      )
    )
      return;
    await run(async (signal) => {
      const failures: string[] = [];
      for (const id of checked) {
        const row = overview?.decisions.find((r) => r.id === id);
        if (!row) continue;
        try {
          await api.change(
            w,
            id,
            {
              requestKey: crypto.randomUUID(),
              expectedVersion: row.version,
              action,
            },
            signal,
          );
        } catch {
          failures.push(row.decision?.outcome ?? "Decision");
        }
      }
      const refreshed = await api.list(w, signal);
      if (signal.aborted) return;
      setOverview(refreshed);
      setChecked([]);
      const current = refreshed.decisions.find((r) => r.id === selected?.id);
      if (current) select(current);
      if (failures.length)
        setError(
          `Some decisions could not be changed: ${failures.join("; ")}. Refresh and review their current states.`,
        );
    });
  }
  useHenryBinding({
    key: "nba",
    brandId: campaign?.setup.brandId,
    summary: `Next Best Action decision preview. Campaign: ${campaign?.setup.name ?? "Choose a campaign"}. Selected decision: ${JSON.stringify(selected?.decision ?? null)}. ${overview?.executionMessage ?? "Execution unavailable"}. Measurement: ${JSON.stringify(overview?.measurement?.feedback ?? [])}`,
    editor: {
      key: "nba-instruction",
      title: "NBA objective",
      fields: [
        {
          key: "instruction",
          label: "What should Henry consider?",
          value: instruction,
        },
      ],
    },
    apply: (changes) => {
      const c = changes.find((c) => c.key === "instruction");
      if (c) {
        setInstruction(c.value.slice(0, 4000));
        key.current = crypto.randomUUID();
      }
    },
    actions: [
      {
        id: "nba.preview",
        label: "Review NBA preview request",
        run: (objective) => {
          setInstruction(objective.slice(0, 4000));
          key.current = crypto.randomUUID();
        },
      },
    ],
  });
  if (!api || !campaigns)
    return <p>Next Best Action is not available in this environment.</p>;
  const workspaceLink = (section: string) =>
    window.location.pathname.startsWith("/client/")
      ? `/client/${section}?workspace=${encodeURIComponent(w)}`
      : `/queen/clients/${encodeURIComponent(w)}/${section}`;
  const closed =
    selected &&
    ["completed", "cancelled", "rejected", "superseded"].includes(
      selected.state,
    );
  const managed =
    !!selected &&
    ["scheduled", "running", "waiting", "paused"].includes(selected.state);
  const dirty = JSON.stringify(draft) !== JSON.stringify(selected?.decision);
  return (
    <section className="nba-page" aria-label="Next Best Action">
      <p>
        Ask Henry what to do next, then review the recommendation and its
        evidence.
      </p>
      <p role="status" className="nba-notice">
        {overview?.executionMessage ?? "Loading NBA…"}
      </p>
      <form
        className="nba-panel"
        onSubmit={(e) => {
          e.preventDefault();
          void preview();
        }}
      >
        <h2>Preview the next action</h2>
        <p>
          A preview saves a recommendation. It does not enrol contacts, spend
          enrichment credits or send messages.
        </p>
        <label>
          Campaign
          <select
            value={campaignId}
            disabled={busy}
            onChange={(e) => {
              setCampaignId(e.target.value);
              key.current = crypto.randomUUID();
            }}
          >
            <option value="">Choose an approved campaign</option>
            {choices.map((c) => (
              <option key={c.id} value={c.id}>
                {c.setup.name}
              </option>
            ))}
          </select>
        </label>
        {overview && !choices.length && (
          <p>Approve a campaign setup before previewing its next action.</p>
        )}
        {records && (
          <fieldset>
            <legend>Preview scope</legend>
            <label>
              Consider
              <select
                value={subjectType}
                disabled={busy}
                onChange={(e) => {
                  setSubjectType(e.target.value as typeof subjectType);
                  setSubjectRecord(undefined);
                  setRecordResults([]);
                  key.current = crypto.randomUUID();
                }}
              >
                <option value="campaign">Campaign acquisition</option>
                <option value="organisation">An organisation in Hive</option>
                <option value="person">A contact in Hive</option>
              </select>
            </label>
            {subjectType !== "campaign" && (
              <>
                <label>
                  Find a record
                  <input
                    value={search}
                    disabled={busy}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </label>
                <button
                  type="button"
                  disabled={busy || search.trim().length < 2}
                  onClick={() =>
                    void run(async (signal) => {
                      const result = await records.list(
                        w,
                        subjectType === "person" ? "contacts" : "organisations",
                        { search },
                        signal,
                      );
                      if (!signal.aborted) setRecordResults(result.items);
                    })
                  }
                >
                  Search records
                </button>
                {subjectRecord && (
                  <p>
                    Selected: <strong>{subjectRecord.name}</strong>
                  </p>
                )}
                <ul className="nba-list">
                  {recordResults.map((r) => (
                    <li key={r.id}>
                      <button
                        type="button"
                        disabled={busy}
                        aria-pressed={subjectRecord?.id === r.id}
                        onClick={() => {
                          setSubjectRecord(r);
                          key.current = crypto.randomUUID();
                        }}
                      >
                        {r.name}
                        {r.organisationName ? ` — ${r.organisationName}` : ""}
                      </button>
                    </li>
                  ))}
                </ul>
              </>
            )}
          </fieldset>
        )}
        <label>
          What should Henry consider?
          <textarea
            value={instruction}
            maxLength={4000}
            rows={3}
            onChange={(e) => {
              setInstruction(e.target.value);
              key.current = crypto.randomUUID();
            }}
            disabled={busy}
          />
        </label>
        <div className="nba-actions">
          <button
            className="button"
            type="submit"
            disabled={
              busy ||
              !campaign ||
              (subjectType !== "campaign" && !subjectRecord)
            }
          >
            Preview next action
          </button>
          <button type="button" disabled={busy} onClick={() => void run(load)}>
            Refresh saved decisions
          </button>
        </div>
        {busy && (
          <p role="status">
            Working on your request. Your saved decisions remain available.
          </p>
        )}
        {error && <p role="alert">{error}</p>}
      </form>
      <div className="nba-layout">
        <section className="nba-panel">
          <MeasurementPanel data={overview?.measurement} compact />
          <h2>Saved decisions</h2>
          <p>
            <a href={workspaceLink("campaigns")}>Review campaigns</a>
          </p>
          {overview?.decisions.length === 0 && <p>No decisions yet.</p>}
          {checked.length > 0 && (
            <div className="nba-actions">
              <button disabled={busy} onClick={() => void bulk("pause")}>
                Pause selected
              </button>
              <button disabled={busy} onClick={() => void bulk("cancel")}>
                Cancel selected
              </button>
            </div>
          )}
          <p>
            Decision history is retained for audit. Cancel stops future work.
          </p>
          <ul className="nba-list">
            {overview?.decisions.map((r) => (
              <li key={r.id}>
                {!["completed", "cancelled", "rejected", "superseded"].includes(
                  r.state,
                ) && (
                  <label className="nba-check">
                    <input
                      type="checkbox"
                      checked={checked.includes(r.id)}
                      disabled={busy}
                      onChange={(e) =>
                        setChecked((ids) =>
                          e.target.checked
                            ? [...ids, r.id]
                            : ids.filter((id) => id !== r.id),
                        )
                      }
                    />
                    Select decision
                  </label>
                )}
                <button
                  type="button"
                  aria-pressed={selected?.id === r.id}
                  onClick={() => select(r)}
                  disabled={busy}
                >
                  <strong>{r.decision?.outcome ?? "Decision preview"}</strong>
                  <span>
                    {label(r.state)} ·{" "}
                    {new Date(r.updatedAt).toLocaleString("en-GB")}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </section>
        {selected && (
          <section className="nba-panel" aria-label="Selected decision">
            <h2>{selected.decision?.outcome ?? "Decision preview"}</h2>
            <p>
              {label(selected.state)} · Version {selected.version}
            </p>
            {selected.blockers.length > 0 && (
              <ul>
                {selected.blockers.map((b, i) => (
                  <li key={i}>{b}</li>
                ))}
              </ul>
            )}
            {!!selected.decision?.policyAssessments?.length && (
              <details>
                <summary>Contact strategy checks</summary>
                <ul>{selected.decision.policyAssessments.map(a => (
                  <li key={a.policyId}>{a.applies ? label(a.effect) : "Not applicable"}: {a.reason} (version {a.version})</li>
                ))}</ul>
                <p>These checks do not authorise sending or activate prospecting.</p>
              </details>
            )}
            {draft && (
              <>
                <p>
                  <strong>Proposed action:</strong> {label(draft.action)}
                </p>
                <label>
                  Reason
                  <textarea
                    rows={4}
                    value={draft.reason}
                    disabled={busy || !!closed || managed}
                    onChange={(e) =>
                      setDraft({ ...draft, reason: e.target.value })
                    }
                  />
                </label>
                <label>
                  Instruction
                  <textarea
                    rows={4}
                    value={draft.instruction}
                    disabled={busy || !!closed || managed}
                    onChange={(e) =>
                      setDraft({ ...draft, instruction: e.target.value })
                    }
                  />
                </label>
                {(draft.action === "wait" || draft.dueAt) && (
                  <label>
                    Review at (your local time)
                    <input
                      type="datetime-local"
                      disabled={busy || !!closed || managed}
                      value={
                        draft.dueAt
                          ? new Date(
                              Date.parse(draft.dueAt) -
                                new Date(draft.dueAt).getTimezoneOffset() *
                                  60000,
                            )
                              .toISOString()
                              .slice(0, 16)
                          : ""
                      }
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          dueAt: e.target.value
                            ? new Date(e.target.value).toISOString()
                            : null,
                        })
                      }
                    />
                    <small>
                      The saved time controls the wait. Review any timing
                      mentioned in the instruction before approval.
                    </small>
                  </label>
                )}
                {draft.awaitEvent && draft.awaitEvent !== "none" && (
                  <p>
                    Reconsider when relevant {label(draft.awaitEvent)} changes
                    are available.
                  </p>
                )}
                <h3>Missing information</h3>
                {draft.missingInformation.length ? (
                  <ul>
                    {draft.missingInformation.map((v, i) => (
                      <li key={i}>{v}</li>
                    ))}
                  </ul>
                ) : (
                  <p>
                    No additional gaps reported. This is not execution
                    permission.
                  </p>
                )}
                <h3>Alternatives considered</h3>
                <ul>
                  {draft.alternatives.map((v, i) => (
                    <li key={i}>{v}</li>
                  ))}
                </ul>
                <details>
                  <summary>Evidence and context versions</summary>
                  <ul>
                    {selected.contextVersions.map((v, i) => (
                      <li key={i}>
                        {label(v.type)} · {v.id} · {v.version}
                      </li>
                    ))}
                  </ul>
                </details>
              </>
            )}
            {selected.researchSummary && (
              <section>
                <h3>Research result</h3>
                <p>{selected.researchSummary}</p>
                <p>
                  Review the supporting evidence in{" "}
                  <a href={workspaceLink("research")}>Research</a> before using
                  it for engagement.
                </p>
              </section>
            )}
            {["scheduled", "running", "waiting"].includes(selected.state) && (
              <p role="status">
                {selected.state === "scheduled"
                  ? "Scheduled with the NBA worker."
                  : selected.state === "running"
                    ? "Henry is reviewing the available research."
                    : "Waiting for a change in the approved context."}{" "}
                No messages will be sent.
              </p>
            )}
            <div className="nba-actions">
              {!closed && (
                <>
                  {overview?.executionAvailable &&
                    !dirty &&
                    selected.blockers.length === 0 &&
                    ["proposed", "review_required"].includes(
                      selected.state,
                    ) && (
                      <button
                        className="button"
                        disabled={busy}
                        onClick={() => void change("approve")}
                      >
                        Approve next action
                      </button>
                    )}
                  {["scheduled", "running", "waiting"].includes(
                    selected.state,
                  ) && (
                    <button
                      disabled={busy}
                      onClick={() => void change("pause")}
                    >
                      Pause
                    </button>
                  )}
                  {selected.state === "paused" && (
                    <button
                      className="button"
                      disabled={busy || !overview?.executionAvailable}
                      onClick={() => void change("resume")}
                    >
                      Resume
                    </button>
                  )}
                  {draft &&
                    !managed &&
                    JSON.stringify(draft) !==
                      JSON.stringify(selected.decision) && (
                      <button
                        className="button"
                        disabled={busy}
                        onClick={() => void change("revise")}
                      >
                        Save changes
                      </button>
                    )}
                  <button
                    disabled={busy || managed}
                    onClick={() => void change("reject")}
                  >
                    Reject
                  </button>
                  <button disabled={busy} onClick={() => void change("cancel")}>
                    Cancel decision
                  </button>
                </>
              )}
              {!managed && (
                <button
                  disabled={busy || !selectedCampaign}
                  onClick={() =>
                    void run(async (signal) => {
                      const result = await api.preview(
                        w,
                        {
                          requestKey: crypto.randomUUID(),
                          campaignId: selected.campaignId,
                          campaignVersion: selectedCampaign!.version,
                          subject: selected.subject,
                          instruction: selected.instruction,
                        },
                        signal,
                      );
                      if (!signal.aborted) {
                        select(result);
                        await load(signal);
                      }
                    })
                  }
                >
                  Reconsider decision
                </button>
              )}
              <button
                disabled={busy}
                onClick={() =>
                  void run(async (signal) => {
                    const result = await api.history(w, selected.id, signal);
                    if (!signal.aborted) setHistory(result.history);
                  })
                }
              >
                View history
              </button>
            </div>
            {history && (
              <ol>
                {history.map((r) => (
                  <li key={r.version}>
                    Version {r.version}: {label(r.state)} —{" "}
                    {new Date(r.updatedAt).toLocaleString("en-GB")}
                  </li>
                ))}
              </ol>
            )}
          </section>
        )}
      </div>
    </section>
  );
}
