import { MeasurementPanel } from "../components/measurement";
import {
  EmailPresentation,
  EmailPreview,
} from "../components/email-presentation";
import { useEffect, useRef, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  categories,
  type CommunicationsGateway,
  type CommunicationsBundle,
  type Communication,
  type CommunicationReply,
} from "../data/communications";
import { DataError } from "../data/gateway";
import { useHenryBinding } from "../components/workspace-henry";
import "../styles/communications.css";
const label = (s: string) => s.replaceAll("_", " ");
export function CommunicationsPage({
  api,
  workspaceId: w,
}: {
  api?: CommunicationsGateway;
  workspaceId: string;
}) {
  const [bundle, setBundle] = useState<CommunicationsBundle>(),
    [selected, setSelected] = useState<Communication>(),
    [reply, setReply] = useState<CommunicationReply>(),
    [filter, setFilter] = useState("all"),
    [archived, setArchived] = useState(false),
    [draftId, setDraftId] = useState(""),
    [templateId, setTemplateId] = useState(""),
    [replyToId, setReplyToId] = useState(""),
    [pointId, setPointId] = useState(""),
    [testOnly, setTestOnly] = useState(true),
    [testRecipient, setTestRecipient] = useState(""),
    [purpose, setPurpose] = useState("marketing"),
    [reason, setReason] = useState(""),
    [due, setDue] = useState(""),
    [responseDue, setResponseDue] = useState(""),
    [returnAt, setReturnAt] = useState(""),
    [legal, setLegal] = useState(false),
    [platform, setPlatform] = useState(false),
    [assessments, setAssessments] = useState<
      Record<string, { effect: string; reason: string }>
    >({}),
    [clearRestriction, setClearRestriction] = useState(false),
    [category, setCategory] = useState<string>("unclear"),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [checked, setChecked] = useState<string[]>([]);
  useEffect(() => {
    setResponseDue("");
  }, [selected?.id]);
  useEffect(() => {
    setCategory(reply?.interpretation.category ?? "unclear");
    setReturnAt("");
    setClearRestriction(false);
    setReason("");
  }, [reply?.id]);
  const reviewPanel = useRef<HTMLElement | null>(null);
  useEffect(() => {
    if (selected) reviewPanel.current?.focus();
  }, [selected?.id]);
  const running = useRef(false),
    attempt = useRef<{ signature: string; key: string } | undefined>(undefined);
  const location = useLocation();
  const path = (section: string) =>
    location.pathname.replace(/communications\/?$/, section) + location.search;
  async function load(s: AbortSignal) {
    if (api) {
      const b = await api.list(w, s);
      if (s.aborted) return;
      setBundle(b);
      setError("");
      const requested = new URLSearchParams(location.search).get("draft");
      if (requested && b.drafts.some((d) => d.id === requested))
        setDraftId(requested);
      setSelected((old) =>
        b.records.find(
          (r) =>
            r.id ===
            (new URLSearchParams(location.search).get("communication") ||
              old?.id),
        ),
      );
      setReply((old) =>
        b.replies.find(
          (r) =>
            r.id ===
            (new URLSearchParams(location.search).get("reply") || old?.id),
        ),
      );
    }
  }
  useEffect(() => {
    const c = new AbortController();
    setBundle(undefined);
    setSelected(undefined);
    setReply(undefined);
    setError("");
    void load(c.signal).catch((e: unknown) => {
      if (!c.signal.aborted)
        setError(e instanceof DataError && e.userMessage ? e.userMessage : "Could not load Communications. Refresh to retry.");
    });
    return () => c.abort();
  }, [api, w]);
  useEffect(() => {
    if (
      !bundle?.records.some((r) =>
        ["scheduled", "sending", "unknown"].includes(r.status),
      )
    )
      return;
    const c = new AbortController();
    const timer = setInterval(() => {
      if (!running.current) void load(c.signal).catch(() => {});
    }, 10000);
    return () => {
      clearInterval(timer);
      c.abort();
    };
  }, [api, w, bundle?.records]);
  async function run(fn: (s: AbortSignal) => Promise<void>) {
    if (running.current) return;
    running.current = true;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await fn(new AbortController().signal);
    } catch (e) {
      setError(
        e instanceof DataError
          ? (e.userMessage ?? "Could not complete the request.")
          : "Could not complete the request. Refresh the saved status before retrying.",
      );
    } finally {
      setBusy(false);
      running.current = false;
    }
  }
  const draft = bundle?.drafts.find((d) => d.id === draftId);
  function open(r: Communication) {
    setSelected(r);
    setReply(undefined);
    setReason("");
    setDue("");
    setLegal(false);
    setPlatform(false);
    setAssessments({});
    setError("");
  }
  async function create() {
    if (!api || !draft) return;
    await run(async (s) => {
      const input = {
        replyToId,
        templateId,
        draftId,
        draftVersion: draft.version,
        contactPointId: pointId,
        testOnly,
        ...(testOnly ? { testRecipient } : {}),
        purpose,
      };
      const signature = JSON.stringify(input);
      if (attempt.current?.signature !== signature)
        attempt.current = { signature, key: crypto.randomUUID() };
      const row = await api.create(
        w,
        { ...input, requestKey: attempt.current.key },
        s,
      );
      attempt.current = undefined;
      await load(s);
      open(row);
      setNotice("Delivery review saved. Nothing has been sent.");
    });
  }
  async function mutate(operation: string) {
    if (!api || !selected) return;
    if (
      operation === "approve" &&
      !window.confirm(
        `Approve delivery from ${selected.sender} to ${selected.recipient}${selected.testOnly ? " (test email)" : ""}${due ? " at the selected time" : " now"}?`,
      )
    )
      return;
    await run(async (s) => {
      const row = await api.mutate(
        w,
        selected.id,
        {
          operation,
          expectedVersion: selected.version,
          reason: reason || "Reviewed communication status",
          ...(operation === "approve"
            ? {
                ...(due ? { dueAt: new Date(due).toISOString() } : {}),
                ...(responseDue
                  ? { responseDueAt: new Date(responseDue).toISOString() }
                  : {}),
                legalConfirmed: legal,
                platformConfirmed: platform,
                assessments: (bundle?.policies ?? []).map((p) => ({
                  policyId: p.id,
                  version: p.version,
                  effect: assessments[p.id]?.effect ?? "deferred",
                  reason: assessments[p.id]?.reason ?? "Not assessed",
                })),
              }
            : {}),
        },
        s,
      );
      await load(s);
      setSelected(row);
      setNotice(
        operation === "approve"
          ? "Delivery queued. Execution checks run again before sending."
          : "Saved.",
      );
    });
  }
  async function bulk(operation: "cancel" | "archive") {
    if (!api) return;
    if (
      !window.confirm(
        `${operation === "cancel" ? "Cancel" : "Archive"} ${checked.length} selected communications? Sent emails cannot be recalled.`,
      )
    )
      return;
    await run(async (s) => {
      const failed: string[] = [];
      for (const r of bundle?.records.filter((r) => checked.includes(r.id)) ??
        []) {
        try {
          await api.mutate(
            w,
            r.id,
            {
              operation,
              expectedVersion: r.version,
              reason: "Bulk " + operation,
            },
            s,
          );
        } catch {
          failed.push(r.rendered.subject);
        }
      }
      await load(s);
      setChecked([]);
      if (failed.length)
        setError(
          "Could not update: " +
            failed.join(", ") +
            ". Open each record to review its status.",
        );
      else setNotice("Selected records updated.");
    });
  }
  useHenryBinding({
    key: "communications",
    brandId: selected?.draft.brandId,
    summary: JSON.stringify({
      measurement: bundle?.measurement,
      purpose:
        "Review delivery and replies. Recommendations never authorise sending. Use Email Content Creation to edit copy. No tracking or qualification is inferred.",
      communication: selected
        ? {
            status: selected.status,
            subject: selected.rendered.subject,
            sender: selected.sender,
            recipient: selected.recipient,
            testOnly: selected.testOnly,
            notice: selected.notice,
          }
        : null,
      reply: reply
        ? {
            from: reply.message.from,
            text: reply.message.text,
            interpretation: reply.interpretation,
          }
        : null,
    }),
    actions: [
      {
        id: "refresh-communications",
        label: "Refresh saved communications",
        run: () => {
          void run(load);
        },
      },
    ],
  });
  const rows =
    bundle?.records.filter(
      (r) =>
        (archived || !r.archived) &&
        (filter === "all" || filter === "replies" || filter === r.status),
    ) ?? [];
  return (
    <div className="communications">
      <p>
        Review individual emails, authorise delivery and handle replies. Sending
        permission is separate from content approval.
      </p>
      <div className="communication-toolbar">
        <span>
          {bundle ? `${bundle.mailbox.email ?? "No connected mailbox"} · ${label(bundle.mailbox.status)}` : error ? "Mailbox status unavailable" : "Loading mailbox and communications…"}
        </span>
        <Link to={path("integrations")}>Manage mailbox</Link>
        <button disabled={busy} onClick={() => void run(load)}>
          Refresh
        </button>
        <button
          disabled={busy || bundle?.mailbox.status !== "connected"}
          onClick={() =>
            void run(async (s) => {
              if (api) setBundle(await api.sync(w, s));
              setNotice("Reply status checked.");
            })
          }
        >
          Check replies
        </button>
      </div>
      <details className="panel" open={!bundle?.records.length}>
        <summary>Prepare delivery from an approved email</summary>
        <div className="communication-fields">
          <label>
            Approved email
            <select
              value={draftId}
              onChange={(e) => {
                setDraftId(e.target.value);
                setPointId("");
              }}
            >
              <option value="">Choose an approved draft</option>
              {bundle?.drafts.filter(d=>!new URLSearchParams(location.search).get("campaign") || d.campaignId===new URLSearchParams(location.search).get("campaign")).map((d) => (
                <option key={d.id} value={d.id}>
                  {d.content.subject} — {d.recipientName}
                </option>
              ))}
            </select>
          </label>
          <label>
            Delivery purpose
            <select
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
            >
              <option value="marketing">Marketing / nurture</option>
              <option value="acquisition">Acquisition</option>
              <option value="service">Service</option>
            </select>
          </label>
          <label className="communication-check">
            <input
              type="checkbox"
              checked={testOnly}
              onChange={(e) => setTestOnly(e.target.checked)}
            />
            Send only to a controlled test inbox
          </label>
          {testOnly ? (
            <label>
              Test recipient
              <select
                value={testRecipient}
                onChange={(e) => setTestRecipient(e.target.value)}
              >
                <option value="">Choose your test mailbox</option>
                {bundle?.mailbox.testRecipients.map((v) => (
                  <option key={v}>{v}</option>
                ))}
              </select>
            </label>
          ) : (
            <label>
              Contact email address
              <select
                value={pointId}
                onChange={(e) => setPointId(e.target.value)}
              >
                <option value="">Choose an address</option>
                {draft?.points.map((p) => (
                  <option
                    key={p.id}
                    value={p.id}
                    disabled={p.suppressed || p.leftOrganisation}
                  >
                    {p.value}
                    {p.suppressed || p.leftOrganisation ? " — restricted" : ""}
                  </option>
                ))}
              </select>
            </label>
          )}
          <label>
            Conversation
            <select
              value={replyToId}
              onChange={(e) => setReplyToId(e.target.value)}
            >
              <option value="">New conversation</option>
              {bundle?.replies
                .filter(
                  (r) =>
                    r.reviewed &&
                    r.associated &&
                    r.contactId === draft?.contactId &&
                    r.testOnly === testOnly,
                )
                .map((r) => (
                  <option key={r.id} value={r.id}>
                    Reply: {r.message.subject}
                  </option>
                ))}
            </select>
          </label>
        </div>
        <p className="muted">
          Test sends use the real draft but substitute the selected test
          recipient. They do not count as campaign engagement or trigger
          ordinary NBA follow-up.
        </p>
        {api && draft && (
          <EmailPresentation
            key={draft.id}
            api={api.templates}
            workspaceId={w}
            brandId={draft.brandId}
            draftId={draft.id}
            draftVersion={draft.version}
            initialChoice={
              new URLSearchParams(location.search).get("template") || ""
            }
            onSelect={setTemplateId}
          />
        )}
        <div className="communication-actions">
          <Link to={path("email-content")}>Create or edit email content</Link>
          <button
            className="button"
            disabled={
              busy ||
              !draft ||
              !(testOnly ? testRecipient : pointId) ||
              bundle?.mailbox.status !== "connected"
            }
            onClick={() => void create()}
          >
            Prepare delivery review
          </button>
        </div>
      </details>
      <div className="communication-toolbar">
        <label>
          Show
          <select value={filter} onChange={(e) => setFilter(e.target.value)}>
            {[
              "all",
              "awaiting_review",
              "scheduled",
              "accepted",
              "replies",
              "failed",
              "unknown",
              "blocked",
              "cancelled",
            ].map((v) => (
              <option key={v} value={v}>
                {label(v)}
              </option>
            ))}
          </select>
        </label>
        <label className="communication-check">
          <input
            type="checkbox"
            checked={archived}
            onChange={(e) => setArchived(e.target.checked)}
          />
          Show archived
        </label>
        {checked.length > 0 && (
          <>
            <button disabled={busy} onClick={() => void bulk("cancel")}>
              Cancel selected
            </button>
            <button disabled={busy} onClick={() => void bulk("archive")}>
              Archive selected
            </button>
          </>
        )}
      </div>
      {filter !== "replies" && (
        <div className="table-scroll">
          <table>
            <caption>Communications — most recently updated first</caption>
            <thead>
              <tr>
                <th>Select</th>
                <th>Email</th>
                <th>Recipient</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td>
                    <input
                      type="checkbox"
                      aria-label={`Select ${r.rendered.subject}`}
                      checked={checked.includes(r.id)}
                      onChange={(e) =>
                        setChecked((v) =>
                          e.target.checked
                            ? [...v, r.id]
                            : v.filter((id) => id !== r.id),
                        )
                      }
                    />
                  </td>
                  <td>
                    {r.rendered.subject}
                    {r.testOnly && <small>Test only</small>}
                  </td>
                  <td>{r.recipient}</td>
                  <td>
                    {label(r.status)}
                    {r.archived ? " · archived" : ""}
                  </td>
                  <td>
                    <button onClick={() => open(r)}>Review</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {bundle && !rows.length && <p>No communications in this view.</p>}
        </div>
      )}
      {selected && (
        <section ref={reviewPanel} tabIndex={-1} className="panel">
          <h2>{selected.rendered.subject}</h2>
          <p>
            <strong>{label(selected.status)}</strong> ·{" "}
            {selected.testOnly ? "Test delivery" : "Contact delivery"}
          </p>
          <dl>
            <dt>From</dt>
            <dd>{selected.sender}</dd>
            <dt>To</dt>
            <dd>{selected.recipient}</dd>
            <dt>Approved content version</dt>
            <dd>{selected.draft.version}</dd>
          </dl>
          <EmailPreview rendered={selected.rendered} />
          <p>{selected.notice}</p>
          {selected.rendered.notice && <p>{selected.rendered.notice}</p>}
          <Link to={path("email-content")}>
            Edit through Email Content Creation
          </Link>
          <p className="muted">
            Changing the approved content or recipient requires a new delivery
            review. Sent content cannot be edited or recalled.
          </p>
          {["awaiting_review", "blocked", "failed"].includes(
            selected.status,
          ) && (
            <>
              <label>
                Reason for delivery / review
                <textarea
                  rows={3}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                />
              </label>
              <label>
                Send after (optional, your local time)
                <input
                  type="datetime-local"
                  value={due}
                  onChange={(e) => setDue(e.target.value)}
                />
              </label>
              {!selected.testOnly && (
                <>
                  <label className="communication-check">
                    <input
                      type="checkbox"
                      checked={legal}
                      onChange={(e) => setLegal(e.target.checked)}
                    />
                    I have reviewed the lawful basis and permission for this
                    recipient and purpose.
                  </label>
                  <label className="communication-check">
                    <input
                      type="checkbox"
                      checked={platform}
                      onChange={(e) => setPlatform(e.target.checked)}
                    />
                    This individual email is permitted by the connected
                    provider’s rules.
                  </label>
                  {bundle?.policies.map((p) => (
                    <fieldset key={p.id}>
                      <legend>{p.title}</legend>
                      <details>
                        <summary>View recorded strategy</summary>
                        <ul>
                          {(Array.isArray(p.details.clauses)
                            ? p.details.clauses
                            : []
                          ).map((c, i) => (
                            <li key={i}>
                              {String(
                                c.statement ??
                                  "Review the recorded strategy in Contact Strategy.",
                              )}
                            </li>
                          ))}
                        </ul>
                      </details>
                      <label>
                        Assessment
                        <select
                          value={assessments[p.id]?.effect ?? "deferred"}
                          onChange={(e) =>
                            setAssessments((a) => ({
                              ...a,
                              [p.id]: {
                                ...a[p.id],
                                reason: a[p.id]?.reason ?? "",
                                effect: e.target.value,
                              },
                            }))
                          }
                        >
                          <option value="deferred">Requires review</option>
                          <option value="permitted">
                            This action meets the strategy
                          </option>
                          <option value="not_applicable">
                            Not applicable to this action
                          </option>
                          <option value="prohibited">Do not send</option>
                        </select>
                      </label>
                      <label>
                        Supporting reason
                        <textarea
                          rows={2}
                          value={assessments[p.id]?.reason ?? ""}
                          onChange={(e) =>
                            setAssessments((a) => ({
                              ...a,
                              [p.id]: {
                                effect: a[p.id]?.effect ?? "deferred",
                                reason: e.target.value,
                              },
                            }))
                          }
                        />
                      </label>
                    </fieldset>
                  ))}
                </>
              )}
              <label>
                Review if no reply by (optional)
                <input
                  type="datetime-local"
                  value={responseDue}
                  onChange={(e) => setResponseDue(e.target.value)}
                />
                <small>
                  Choose a response window allowed by the contact strategy. NBA
                  will reconsider; it will not automatically send.
                </small>
              </label>
              <div className="communication-actions">
                <button
                  className="button"
                  disabled={
                    busy ||
                    !reason.trim() ||
                    (!selected.testOnly &&
                      (!legal ||
                        !platform ||
                        bundle?.policies.some(
                          (p) =>
                            !assessments[p.id]?.reason.trim() ||
                            !["permitted", "not_applicable"].includes(
                              assessments[p.id]?.effect ?? "",
                            ),
                        )))
                  }
                  onClick={() => void mutate("approve")}
                >
                  Approve delivery
                </button>
              </div>
            </>
          )}
          <div className="communication-actions">
            {["awaiting_review", "scheduled", "failed", "blocked"].includes(
              selected.status,
            ) && (
              <button disabled={busy} onClick={() => void mutate("cancel")}>
                Cancel delivery
              </button>
            )}
            {["sending", "unknown"].includes(selected.status) && (
              <button disabled={busy} onClick={() => void mutate("reconcile")}>
                Check Gmail outcome
              </button>
            )}
            {["accepted", "failed", "blocked", "cancelled"].includes(
              selected.status,
            ) && (
              <button
                disabled={busy}
                onClick={() =>
                  void mutate(selected.archived ? "restore" : "archive")
                }
              >
                {selected.archived ? "Restore record" : "Archive record"}
              </button>
            )}
          </div>
        </section>
      )}
      {(filter === "all" || filter === "replies") && (
        <section className="panel">
          <h2>Replies</h2>
          {bundle && !bundle.replies.length && <p>No replies received yet.</p>}
          {bundle?.replies.map((r) => (
            <div className="communication-reply-row" key={r.id}>
              <div>
                <strong>{r.message.subject}</strong>
                <p>
                  {r.message.from} · {r.reviewed ? "Reviewed" : "Needs review"}
                  {r.testOnly ? " · Test only" : ""}
                </p>
              </div>
              <button
                onClick={() => {
                  setReply(r);
                  setClearRestriction(false);
                  setCategory(r.interpretation.category);
                  setReason("");
                  setSelected(undefined);
                }}
              >
                Review reply
              </button>
            </div>
          ))}
        </section>
      )}
      {reply && (
        <section className="panel">
          <h2>Review reply</h2>
          <p>
            {reply.message.from} ·{" "}
            {new Date(reply.message.occurredAt).toLocaleString()}
          </p>
          <h3>{reply.message.subject}</h3>
          <div className="communication-preview">
            {reply.message.text ||
              "No plain-text body was available. Inspect the original in Gmail."}
          </div>
          <p>
            {reply.associated
              ? "Linked to the intended contact."
              : "Association needs review. Confirm this reply belongs to the intended contact; no identity is merged automatically."}
          </p>
          <label>
            Interpretation
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              {categories.map((v) => (
                <option key={v} value={v}>
                  {label(v)}
                </option>
              ))}
            </select>
          </label>
          <p>{reply.interpretation.reason}</p>
          {category === "out_of_office" && (
            <label>
              Confirmed return date (optional)
              <input
                type="datetime-local"
                value={returnAt}
                onChange={(e) => setReturnAt(e.target.value)}
              />
              <small>
                Use only a date supported by the reply. This schedules
                reconsideration, not an email.
              </small>
            </label>
          )}
          <label>
            Review reason
            <textarea
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />
          </label>
          <label className="communication-check">
            <input
              type="checkbox"
              checked={clearRestriction}
              onChange={(e) => setClearRestriction(e.target.checked)}
            />
            Clear a restriction caused by this reply only, if the original
            interpretation was incorrect.
          </label>
          <p className="muted">
            Reviewing a reply does not send an answer, qualify a lead or confirm
            a booking. Contact restrictions remain in force until explicitly
            reviewed.
          </p>
          <div className="communication-actions">
            <Link to={path("contacts")}>Review contact restrictions</Link>
            <Link to={path("nba")}>Review next action with NBA</Link>
            <button
              className="button"
              disabled={busy || !reason.trim()}
              onClick={() =>
                void run(async (s) => {
                  if (api) {
                    await api.review(
                      w,
                      reply.id,
                      {
                        expectedVersion: reply.version,
                        category,
                        reason,
                        clearRestriction,
                        ...(category === "out_of_office" && returnAt
                          ? { returnAt: new Date(returnAt).toISOString() }
                          : {}),
                        ...(!reply.associated
                          ? { personId: reply.proposedContactId }
                          : {}),
                      },
                      s,
                    );
                    await load(s);
                    setNotice("Reply reviewed. No follow-up has been sent.");
                  }
                })
              }
            >
              Save reply review
            </button>
          </div>
        </section>
      )}
      <MeasurementPanel data={bundle?.measurement} />
      {busy && (
        <p role="status">
          Working on your request. Saved records are retained.
        </p>
      )}
      {error && (
        <p role="alert" className="error">
          {error}
        </p>
      )}
      {notice && <p role="status">{notice}</p>}
    </div>
  );
}
