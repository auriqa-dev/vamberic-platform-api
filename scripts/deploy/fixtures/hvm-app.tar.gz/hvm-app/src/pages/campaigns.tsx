import { CampaignJourney } from "../components/campaign-journey";
import { MeasurementPanel } from "../components/measurement";
import { CampaignMeetings } from "../components/campaign-meetings";
import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import type {
  Campaign,
  CampaignAudience,
  CampaignDetail,
  CampaignGateway,
  CampaignOverview,
  CampaignSetup,
} from "../data/campaigns";
import { useHenryBinding, useHenryBrand } from "../components/workspace-henry";
import "../styles/campaigns.css";
const empty = (brandId = ""): CampaignSetup => ({
  name: "",
  objective: "",
  brandId,
  products: [],
  offers: [],
  audiences: [],
  source: "both",
  purpose: "acquisition",
  researchPriority: "",
  urls: [],
  channels: [],
  goal: "",
  target: null,
  owner: "",
  timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
  startDate: "",
  endDate: "",
  schedule: "",
  assetIds: [],
  contentRecordIds: [],
  overlapPolicy: "",
});
const labels: Record<string, string> = {
  draft: "Draft",
  ready: "Setup approved",
  paused: "Paused",
  archived: "Archived",
};
const textFields = [
  ["name", "Campaign name"],
  ["objective", "Commercial objective"],
  ["researchPriority", "Research priorities"],
  ["goal", "Success measure"],
  ["owner", "Campaign owner"],
  ["schedule", "Operating schedule"],
  ["overlapPolicy", "Overlap policy proposal"],
  ["organisationPriorities", "Organisation priorities and exclusions"],
  ["researchRefresh", "When to revisit organisations or find new people"],
  ["bookingUrl", "Booking page override"],
  ["meetingPurpose", "Meeting purpose override"],
  ["handoverRecipient", "Handover recipient override"],
  ["enrichmentPolicy", "Enrichment allocation priorities"],
] as const;
export function CampaignsPage({
  api,
  workspaceId: w,
}: {
  api?: CampaignGateway;
  workspaceId: string;
}) {
  const location = useLocation();
  const henryBrand = useHenryBrand();
  const performancePath = location.pathname.replace(/\/campaigns(?:\/.*)?$/, "/performance");
  const [overview, setOverview] = useState<CampaignOverview>(),
    [selected, setSelected] = useState<Campaign>(),
    [detail, setDetail] = useState<CampaignDetail>();
  const [draft, setDraft] = useState<CampaignSetup>(empty()),
    [editing, setEditing] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [tab, setTab] = useState("overview"),
    [checked, setChecked] = useState<string[]>([]),
    [showArchived, setShowArchived] = useState(false),
    [days, setDays] = useState("30");
  const [audience, setAudience] = useState<CampaignAudience>(),
    [audienceOffset, setAudienceOffset] = useState(0),
    [organisationIds, setOrganisationIds] = useState<string[]>([]);
  const lock = useRef(false),
    active = useRef(true),
    saveKey = useRef(crypto.randomUUID());
  const [audienceEntity, setAudienceEntity] = useState<
    "organisations" | "people"
  >("organisations");
  useEffect(() => {
    active.current = true;
    return () => {
      active.current = false;
    };
  }, []);
  const load = useCallback(
    async (signal: AbortSignal) => {
      if (api) {
        const data = await api.list(w, signal);
        if (!signal.aborted) {
          setOverview(data);
          const requested=new URLSearchParams(location.search).get('campaign');
          if(requested)setSelected(data.campaigns.find(c=>c.id===requested));
        }
      }
    },
    [api, w, location.search],
  );
  useEffect(() => {
    const c = new AbortController();
    void load(c.signal).catch(() => {
      if (!c.signal.aborted)
        setError("Campaigns could not be loaded. Please retry.");
    });
    return () => c.abort();
  }, [load]);
  useEffect(() => {
    if (!api || !selected || editing) return;
    const c = new AbortController();
    const refresh = () =>
      api
        .read(w, selected.id, c.signal)
        .then((d) => {
          if (!c.signal.aborted) setDetail(d);
        })
        .catch(() => {
          if (!c.signal.aborted)
            setError(
              "Live activity could not be refreshed. Your saved campaign is unchanged.",
            );
        });
    void refresh();
    const timer = setInterval(() => {
      if (!document.hidden) void refresh();
    }, 5000);
    return () => {
      c.abort();
      clearInterval(timer);
    };
  }, [api, w, selected, editing]);
  useEffect(() => {
    if (!api || !selected || tab !== "audience" || editing) return;
    const c = new AbortController();
    void api
      .audience(w, selected.id, audienceOffset, c.signal, audienceEntity)
      .then((a) => {
        if (!c.signal.aborted) setAudience(a);
      })
      .catch(() => {
        if (!c.signal.aborted)
          setError("Existing audience records could not be loaded.");
      });
    return () => c.abort();
  }, [api, w, selected, tab, editing, audienceOffset, audienceEntity]);
  const update = (next: CampaignSetup) => {
    setDraft(next);
    saveKey.current = crypto.randomUUID();
    setError("");
  };
  useHenryBinding({
    key: "campaigns",
    priority: editing ? 30 : 0,
    brandId: editing ? draft.brandId : selected?.setup.brandId,
    summary: `Available approved choices: ${JSON.stringify(Object.fromEntries(Object.entries(overview?.choices.choices ?? {}).map(([key,rows])=>[key,rows?.filter(r=>!r.brandId || r.brandId===(editing?draft.brandId:selected?.setup.brandId || henryBrand)).slice(0,20)])))}. Campaign setup and research monitoring. ${overview?.campaigns.length ?? 0} campaigns. Campaign setup is not launch or sending permission. Use the guided campaign preparation for recipient review, automatic tracking and launch review. Campaign: ${selected?.setup.name ?? "new"}.`,
    editor: editing
      ? {
          key: `campaign:${selected?.id ?? "new"}`,
          title: "Campaign setup",
          fields: [...textFields.map(([key, label]) => ({key,label,value:draft[key] ?? ""})),
            ...([['products','offerings','Products'],['offers','offers','Offers'],['audiences','ideal_customer_profiles','Audiences']] as const).map(([key,entity,label])=>({key,label:`${label}: approved names, one per line`,value:draft[key].map(ref=>overview?.choices.choices[entity]?.find(x=>x.id===ref.id)?.name ?? '').join('\n')}))],
        }
      : undefined,
    apply: (changes) => {
      const next = { ...draft };
      for (const c of changes) {
        if (textFields.some(([key]) => key === c.key))
          next[c.key as (typeof textFields)[number][0]] = c.value;
      }
      for(const [key,entity] of [['products','offerings'],['offers','offers'],['audiences','ideal_customer_profiles']] as const) {
        const change=changes.find(c=>c.key===key);
        if(change){
          const names=change.value.split('\n').map(x=>x.trim()).filter(Boolean);
          const resolved=names.map(name=>overview?.choices.choices[entity]?.filter(x=>x.name.toLowerCase()===name.toLowerCase() && (!x.brandId || x.brandId===next.brandId)) ?? []);
          if(resolved.some(matches=>matches.length!==1)){setError('Henry’s selection could not be matched to one approved record. Review the choices below.');return;}
          next[key]=resolved.map(matches=>({id:matches[0]!.id,revision:matches[0]!.revision}));
        }
      }
      update(next);
    },
    actions: [
      ...(overview?.campaigns.filter(c=>c.status!=='archived').slice(0,20).map(c=>({id:`campaign.review_${c.id}`,label:`Review ${c.setup.name}`,run:()=>{setSelected(c);setEditing(false);}})) ?? []),
      {
        id: "campaign.prepare",
        label: "Prepare campaign setup",
        run: (objective) => {
          setSelected(undefined);
          update({
            ...empty(henryBrand || (overview?.choices.brands.length===1?overview.choices.brands[0]?.id:undefined)),
            objective,
            overlapPolicy: overview?.overlapStatement ?? "",
          });
          setEditing(true);
        },
      },
    ],
  });
  async function act(work: () => Promise<void>) {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await work();
    } catch (e) {
      if (active.current)
        setError(
          e instanceof Error
            ? e.message
            : "The request failed. Your edits are retained.",
        );
    } finally {
      lock.current = false;
      if (active.current) setBusy(false);
    }
  }
  async function change(action: string, row = selected) {
    if (!api) return;
    await act(async () => {
      const saved = await api.change(w, row?.id, {
        requestKey: action === "save" ? saveKey.current : crypto.randomUUID(),
        expectedVersion: row?.version ?? 0,
        action,
        ...(action === "save" ? { setup: draft } : {}),
      });
      await load(new AbortController().signal);
      if (!active.current) return;
      setSelected(action === "delete" ? undefined : saved);
      setDetail(undefined);
      setEditing(false);
      setNotice(
        action === "approve"
          ? "Setup approved. Continue with recipient review and launch preparation. No emails queued."
          : "Campaign changes saved.",
      );
    });
  }
  async function bulk(action: "delete" | "archive") {
    if (
      !api ||
      !window.confirm(
        `${action === "delete" ? "Delete unused drafts" : "Archive campaigns"}: ${checked.length} selected?`,
      )
    )
      return;
    await act(async () => {
      const failures: string[] = [];
      for (const row of overview?.campaigns.filter((r) =>
        checked.includes(r.id),
      ) ?? []) {
        try {
          await api.change(w, row.id, {
            requestKey: crypto.randomUUID(),
            expectedVersion: row.version,
            action,
          });
        } catch {
          failures.push(row.setup.name);
        }
      }
      await load(new AbortController().signal);
      setChecked([]);
      if (failures.length)
        setError(
          `Could not ${action}: ${failures.join(", ")}. Other selected records were updated. Active research or retained history may prevent this action.`,
        );
      else setNotice("Selected campaigns updated.");
    });
  }
  function open(row: Campaign) {
    setSelected(row);
    setDetail(undefined);
    setTab("overview");
    setAudience(undefined);
    setOrganisationIds([]);
    setAudienceOffset(0);
    setEditing(false);
    setError("");
  }
  function edit(row?: Campaign) {
    setSelected(row);
    update(
      row?.setup ?? {
        ...empty(henryBrand || (overview?.choices.brands.length===1?overview.choices.brands[0]?.id:undefined)),
        overlapPolicy: overview?.overlapStatement ?? "",
      },
    );
    setEditing(true);
    setNotice("");
  }
  const choose = (
    kind: "products" | "offers" | "audiences",
    id: string,
    revision: number,
    on: boolean,
  ) =>
    update({
      ...draft,
      [kind]: on
        ? [...draft[kind], { id, revision }]
        : draft[kind].filter((r) => r.id !== id),
    });
  if (!api) return <p>Campaigns is unavailable.</p>;
  const jobs = (detail?.jobs ?? []).filter(
    (j) =>
      days === "all" ||
      Date.parse(j.updatedAt) >= Date.now() - Number(days) * 86400000,
  );
  return (
    <div className="campaign-page">
      <header className="campaign-toolbar">
        <p>Coordinate your objectives, offers and research in one place.</p>
        {!selected && !editing && (
          <button className="button" onClick={() => edit()}>
            Add campaign
          </button>
        )}
        {(selected || editing) && (
          <button
            onClick={() => {
              if (editing && !window.confirm("Leave these unsaved changes?"))
                return;
              setSelected(undefined);
              setEditing(false);
              setDetail(undefined);
            }}
          >
            Campaigns overview
          </button>
        )}
      </header>
      {notice && <p role="status">{notice}</p>}
      {!overview && <p role="status">Loading campaigns…</p>}
      {!selected && !editing && overview && (
        <>
          <div className="campaign-toolbar">
            <label>
              <input
                type="checkbox"
                checked={showArchived}
                onChange={(e) => setShowArchived(e.target.checked)}
              />{" "}
              Show archived
            </label>
            {checked.length > 0 && (
              <div className="campaign-actions">
                <span>{checked.length} selected</span>
                <button disabled={busy} onClick={() => void bulk("archive")}>
                  Archive selected
                </button>
                <button disabled={busy} onClick={() => void bulk("delete")}>
                  Delete drafts
                </button>
              </div>
            )}
          </div>
          <div className="campaign-list">
            {overview.campaigns
              .filter((c) => showArchived || c.status !== "archived")
              .map((c) => (
                <article className="panel campaign-toolbar" key={c.id}>
                  <label>
                    <input
                      type="checkbox"
                      checked={checked.includes(c.id)}
                      aria-label={`Select ${c.setup.name}`}
                      onChange={(e) =>
                        setChecked(
                          e.target.checked
                            ? [...checked, c.id]
                            : checked.filter((id) => id !== c.id),
                        )
                      }
                    />
                  </label>
                  <button className="campaign-record" onClick={() => open(c)}>
                    <strong>{c.setup.name}</strong>
                    <span>
                      {c.setup.objective || "Objective not yet entered"}
                    </span>
                  </button>
                  <span>{labels[c.status] ?? c.status}</span>
                </article>
              ))}
          </div>
          {!overview.campaigns.length && (
            <section className="panel">
              <h2>Your first campaign starts here</h2>
              <p>
                Describe your objective to Henry, then select the offers and
                customer profiles you want to work with.
              </p>
            </section>
          )}
        </>
      )}
      {editing && overview && (
        <form
          className="panel campaign-form"
          onSubmit={(e) => {
            e.preventDefault();
            void change("save");
          }}
        >
          <h2>{selected ? "Edit campaign" : "Campaign setup"}</h2>
          <p>
            Save a draft at any time. Approval checks current product, offer and
            ICP versions. Henry can help refine the fields below.
          </p>
          <div className="campaign-grid">
            <label>
              Campaign name
              <input
                required
                maxLength={200}
                value={draft.name}
                onChange={(e) => update({ ...draft, name: e.target.value })}
              />
            </label>
            {overview.choices.brands.length > 1 ? <label>
              Brand
              <select
                value={draft.brandId}
                onChange={(e) =>
                  update({
                    ...draft,
                    brandId: e.target.value,
                    products: [],
                    offers: [],
                    audiences: [],
                    assetIds: [],
                  })
                }
              >
                <option value="">Choose a brand</option>
                {overview.choices.brands.map((b) => (
                  <option value={b.id} key={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </label> : <p className="muted">Brand: {overview.choices.brands[0]?.name}</p>}
            <label>
              Campaign purpose
              <select
                value={draft.purpose ?? "acquisition"}
                onChange={(e) =>
                  update({
                    ...draft,
                    purpose: e.target.value as CampaignSetup["purpose"],
                  })
                }
              >
                <option value="acquisition">Acquisition</option>
                <option value="retention">Retention</option>
                <option value="reactivation">Reactivation</option>
                <option value="education">Education</option>
                <option value="cross_sell">Cross-sell</option>
                <option value="other">Other</option>
              </select>
            </label>
            <label className="campaign-wide">
              Commercial objective
              <textarea
                rows={3}
                maxLength={2000}
                value={draft.objective}
                onChange={(e) =>
                  update({ ...draft, objective: e.target.value })
                }
              />
            </label>
            {(
              [
                ["products", "Products"],
                ["offers", "Eligible offers"],
                ["audiences", "Approved customer profiles"],
              ] as const
            ).map(([kind, title]) => (
              <fieldset key={kind}>
                <legend>{title}</legend>
                {(
                  overview.choices.choices[
                    kind === "products"
                      ? "offerings"
                      : kind === "audiences"
                        ? "ideal_customer_profiles"
                        : "offers"
                  ] ?? []
                )
                  .filter((c) => !c.brandId || c.brandId === draft.brandId)
                  .map((c) => (
                    <label className="campaign-check" key={c.id}>
                      <input
                        type="checkbox"
                        checked={draft[kind].some((r) => r.id === c.id)}
                        onChange={(e) =>
                          choose(kind, c.id, c.revision, e.target.checked)
                        }
                      />
                      {c.name} · v{c.revision}
                    </label>
                  ))}
                {!overview.choices.choices[
                  kind === "products"
                    ? "offerings"
                    : kind === "audiences"
                      ? "ideal_customer_profiles"
                      : "offers"
                ]?.length && <p>No approved records available.</p>}
              </fieldset>
            ))}
            <label>
              How should NBA work?
              <select
                value={draft.operatingMode ?? ""}
                onChange={(e) =>
                  update({
                    ...draft,
                    operatingMode: e.target
                      .value as CampaignSetup["operatingMode"],
                  })
                }
              >
                <option value="">Choose operating mode</option>
                <option value="opportunity_development">
                  Develop new opportunities
                </option>
                <option value="engagement_management">
                  Manage existing engagements
                </option>
                <option value="both">Both</option>
              </select>
              <small>
                Configuration only. Saving or approving does not activate NBA or
                send communications.
              </small>
            </label>
            {textFields
              .filter(([key]) =>
                [
                  "organisationPriorities",
                  "researchRefresh",
                  "enrichmentPolicy",
                ].includes(key),
              )
              .map(([key, label]) => (
                <label className="campaign-wide" key={key}>
                  {label}
                  <textarea
                    rows={3}
                    maxLength={2000}
                    value={draft[key] ?? ""}
                    onChange={(e) =>
                      update({ ...draft, [key]: e.target.value })
                    }
                  />
                </label>
              ))}
            <fieldset className="campaign-wide">
              <legend>Optional enrichment allocation</legend>
              <p>
                These allocations cannot grant provider access or exceed the
                workspace allowance shared across campaigns. Existing Hive
                contacts do not consume enrichment credits. Actual provider
                consumption determines usage; one request may cost more than one
                credit. Exhaustion pauses enrichment only.
              </p>
              <div className="campaign-grid">
                {(
                  [
                    ["dailyEmailFetchLimit", "Maximum email fetches per day"],
                    [
                      "monthlyCreditAllocation",
                      "Monthly provider credit allocation",
                    ],
                  ] as const
                ).map(([key, label]) => (
                  <label key={key}>
                    {label}
                    <input
                      type="number"
                      min="1"
                      step="1"
                      value={draft[key] ?? ""}
                      onChange={(e) =>
                        update({
                          ...draft,
                          [key]: e.target.value
                            ? Number(e.target.value)
                            : undefined,
                        })
                      }
                    />
                  </label>
                ))}
              </div>
            </fieldset>
            <fieldset className="campaign-wide campaign-spaced">
              <legend>Booking and handover overrides</legend>
              <p>
                Leave blank to inherit each offer’s settings. A booking link
                click is not a confirmed meeting. Booking confirmation is manual
                until an integration is connected.
              </p>
              {textFields
                .filter(([key]) =>
                  [
                    "bookingUrl",
                    "meetingPurpose",
                    "handoverRecipient",
                  ].includes(key),
                )
                .map(([key, label]) => (
                  <label key={key}>
                    {label}
                    <input
                      type={key === "bookingUrl" ? "url" : "text"}
                      value={draft[key] ?? ""}
                      onChange={(e) =>
                        update({ ...draft, [key]: e.target.value })
                      }
                    />
                  </label>
                ))}
            </fieldset>
            <label>
              Candidate sources (consumer ICPs: existing records only)
              <select
                value={draft.source}
                onChange={(e) =>
                  update({
                    ...draft,
                    source: e.target.value as CampaignSetup["source"],
                  })
                }
              >
                <option value="both">Hive and new discovery</option>
                <option value="existing">Existing Hive</option>
                <option value="discovery">New discovery</option>
              </select>
            </label>
            <label className="campaign-wide">
              Research priorities
              <textarea
                rows={3}
                maxLength={2000}
                value={draft.researchPriority}
                onChange={(e) =>
                  update({ ...draft, researchPriority: e.target.value })
                }
              />
              <small>
                Approved ICP details are supplied automatically. Describe which
                signals matter now.
              </small>
            </label>
            <label className="campaign-wide">
              Public source URLs (optional, one per line)
              <textarea
                rows={2}
                value={draft.urls.join("\n")}
                onChange={(e) =>
                  update({
                    ...draft,
                    urls: e.target.value.split("\n").filter(Boolean),
                  })
                }
              />
            </label>
            <fieldset>
              <legend>Intended channels</legend>
              <p>
                These channels can be recorded for planning. Automated delivery
                is not connected; other channels are not yet supported here.
              </p>
              {(["email", "website", "linkedin", "chat"] as const).map((c) => (
                <label className="campaign-check" key={c}>
                  <input
                    type="checkbox"
                    checked={draft.channels.includes(c)}
                    onChange={(e) =>
                      update({
                        ...draft,
                        channels: e.target.checked
                          ? [...draft.channels, c]
                          : draft.channels.filter((v) => v !== c),
                      })
                    }
                  />
                  {c} — execution not connected
                </label>
              ))}
            </fieldset>
            <fieldset>
              <legend>Supporting Library assets</legend>
              {overview.choices.assets
                .filter((a) => a.brandId === draft.brandId)
                .map((a) => (
                  <label className="campaign-check" key={a.id}>
                    <input
                      type="checkbox"
                      checked={draft.assetIds.includes(a.id)}
                      onChange={(e) =>
                        update({
                          ...draft,
                          assetIds: e.target.checked
                            ? [...draft.assetIds, a.id]
                            : draft.assetIds.filter((id) => id !== a.id),
                        })
                      }
                    />
                    {a.name}
                  </label>
                ))}
              <small>Using evidence does not approve it for publication.</small>
            </fieldset>
            <fieldset className="campaign-wide">
              <legend>Content Strategy and execution briefs</legend>
              {overview.contentChoices
                .filter((c) => c.brandId === draft.brandId)
                .map((c) => (
                  <label className="campaign-check" key={c.id}>
                    <input
                      type="checkbox"
                      checked={draft.contentRecordIds.includes(c.id)}
                      onChange={(e) =>
                        update({
                          ...draft,
                          contentRecordIds: e.target.checked
                            ? [...draft.contentRecordIds, c.id]
                            : draft.contentRecordIds.filter(
                                (id) => id !== c.id,
                              ),
                        })
                      }
                    />
                    {c.name} · {c.status}
                  </label>
                ))}
              {!overview.contentChoices.some(
                (c) => c.brandId === draft.brandId,
              ) && (
                <p>No Content Strategy or briefs available for this brand.</p>
              )}
            </fieldset>
            <label>
              Success measure
              <textarea
                rows={2}
                value={draft.goal}
                maxLength={1000}
                onChange={(e) => update({ ...draft, goal: e.target.value })}
              />
            </label>
            <label>
              Target (optional)
              <input
                type="number"
                min={1}
                step={1}
                value={draft.target ?? ""}
                onChange={(e) =>
                  update({
                    ...draft,
                    target: e.target.value ? Number(e.target.value) : null,
                  })
                }
              />
            </label>
            <label>
              Owner
              <input
                value={draft.owner}
                maxLength={200}
                onChange={(e) => update({ ...draft, owner: e.target.value })}
              />
            </label>
            <label>
              Timezone
              <input
                value={draft.timezone}
                onChange={(e) => update({ ...draft, timezone: e.target.value })}
              />
            </label>
            <label>
              Start date (optional)
              <input
                type="date"
                value={draft.startDate}
                onChange={(e) =>
                  update({ ...draft, startDate: e.target.value })
                }
              />
            </label>
            <label>
              End date (optional)
              <input
                type="date"
                value={draft.endDate}
                onChange={(e) => update({ ...draft, endDate: e.target.value })}
              />
            </label>
            <label className="campaign-wide">
              Operating schedule (planning only)
              <textarea
                rows={2}
                value={draft.schedule}
                maxLength={500}
                onChange={(e) => update({ ...draft, schedule: e.target.value })}
              />
            </label>
            <label className="campaign-wide">
              Overlap policy proposal
              <textarea
                rows={4}
                maxLength={2000}
                value={draft.overlapPolicy}
                onChange={(e) =>
                  update({ ...draft, overlapPolicy: e.target.value })
                }
              />
              <small>
                This is a proposal. Review and approve the workspace policy in
                Contact Strategy; campaign approval does not activate it.
              </small>
            </label>
          </div>
          <div className="campaign-actions">
            <button
              type="button"
              disabled={busy}
              onClick={() => setEditing(false)}
            >
              Cancel
            </button>
            <button className="button" disabled={busy || !draft.brandId}>
              {busy ? "Saving…" : "Save draft"}
            </button>
          </div>
          {error && <p role="alert">{error}</p>}
        </form>
      )}
      {selected && !editing && (
        <>
          <section className="panel">
            <div className="campaign-toolbar">
              <h2>{selected.setup.name}</h2>
              <span>
                {labels[selected.status] ?? selected.status} · v
                {selected.version}
              </span>
              <button onClick={() => edit(selected)}>Edit campaign</button>
            </div>
            <p>{selected.setup.objective}</p>
            <p>
              <strong>Communications:</strong> {detail?.execution || "Loading execution status…"}
            </p>
            <div className="campaign-actions">
              {["draft", "paused"].includes(selected.status) && (
                <button
                  className="button"
                  disabled={busy}
                  onClick={() => void change("approve")}
                >
                  Approve setup
                </button>
              )}
              {selected.status === "ready" && (
                <button
                  className="button"
                  disabled={busy || !overview?.choices.generationAvailable}
                  onClick={() =>
                    void act(async () => {
                      await api.research(
                        w,
                        selected.id,
                        selected.version,
                        audienceEntity === "organisations"
                          ? organisationIds
                          : [],
                        audienceEntity === "people" ? organisationIds : [],
                      );
                      setDetail(
                        await api.read(
                          w,
                          selected.id,
                          new AbortController().signal,
                        ),
                      );
                      setNotice(
                        "Research requested. Repeated clicks recover the same request for this setup version.",
                      );
                    })
                  }
                >
                  Research audience
                </button>
              )}
              {selected.status === "ready" && (
                <button disabled={busy} onClick={() => void change("pause")}>
                  Pause campaign
                </button>
              )}
              {selected.status !== "archived" && (
                <button
                  disabled={busy}
                  onClick={() => {
                    if (
                      window.confirm(
                        "Archive this campaign and retain its history?",
                      )
                    )
                      void change("archive");
                  }}
                >
                  Archive
                </button>
              )}
              {selected.status === "draft" && (
                <button
                  disabled={busy}
                  onClick={() => {
                    if (
                      window.confirm(
                        "Delete this unused draft? Research history prevents deletion.",
                      )
                    )
                      void change("delete");
                  }}
                >
                  Delete draft
                </button>
              )}
            </div>
            <h3>Readiness for NBA configuration</h3>
            {detail?.readiness.length === 0 &&
              !detail.preparation?.some((o) => o.gaps.length) && (
                <p>
                  Campaign setup is complete. Continue with recipient review,
                  tracking and launch approval below.
                </p>
              )}
            {detail?.preparation?.map((o) => (
              <section key={o.offerId}>
                <h4>{o.name}</h4>
                <p>Outcome: {o.conversionOutcome || "Not defined"}</p>
                {(o.bookingUrl || o.meetingPurpose) && <p>Booking: {o.bookingUrl || "Not configured"} · {o.meetingPurpose}</p>}
                {o.handoverRecipient && <p>Handover: {o.handoverRecipient}</p>}
                {o.gaps.map((g) => (
                  <p key={g}>{g}</p>
                ))}
              </section>
            ))}
            {detail?.readiness.map((r) => (
              <p key={r}>{r}</p>
            ))}
            {error && <p role="alert">{error}</p>}
          </section>
          {api && <CampaignJourney key={`${w}:${selected.id}:${selected.version}`} api={api} workspaceId={w} campaign={selected} onEdit={()=>edit(selected)} />}
          <nav className="campaign-tabs" aria-label="Campaign views">
            {[
              "overview",
              "audience",
              "content",
              "activity",
              "meetings",
              "settings",
            ].map((t) => (
              <button
                aria-current={tab === t ? "page" : undefined}
                onClick={() => setTab(t)}
                key={t}
              >
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </button>
            ))}
          </nav>
          {!detail ? (
            <p role="status">Loading campaign activity…</p>
          ) : (
            <>
              {tab === "overview" && (
                <>
                  <div className="campaign-toolbar">
                    <label>
                      Research activity period
                      <select
                        value={days}
                        onChange={(e) => setDays(e.target.value)}
                      >
                        <option value="7">Last 7 days</option>
                        <option value="30">Last 30 days</option>
                        <option value="all">All time</option>
                      </select>
                    </label>
                    <small>
                      Last refreshed{" "}
                      {new Date(detail.updatedAt).toLocaleTimeString()} ·
                      updates every 5 seconds
                    </small>
                  </div>
                  <div className="campaign-grid">
                    <section className="panel">
                      <h3>Research progress</h3>
                      {[
                        ["Requests", jobs.length],
                        [
                          "Working",
                          jobs.filter((j) =>
                            ["queued", "running"].includes(j.status),
                          ).length,
                        ],
                        [
                          "Completed",
                          jobs.filter((j) => j.status === "completed").length,
                        ],
                        [
                          "Need attention",
                          jobs.filter((j) =>
                            ["partial", "failed"].includes(j.status),
                          ).length,
                        ],
                      ].map(([label, count]) => (
                        <div className="campaign-metric" key={label}>
                          <span>{label}</span>
                          <strong>{count}</strong>
                        </div>
                      ))}
                      <p>
                        Requests updated in the selected period. These are
                        operational states, not conversion stages.
                      </p>
                    </section>
                    <section className="panel">
                      <h3>Campaign goal</h3>
                      <p className="muted">
                        Your success measure is recorded below. Automatic
                        measurement of this outcome is not yet connected.
                      </p>
                      <p>{selected.setup.goal || "Not yet defined"}</p>
                      <p>
                        {selected.setup.target
                          ? `Target: ${selected.setup.target}. `
                          : ""}
                        Outcome tracking not connected.
                      </p>
                      <h3>Audience discovered</h3>
                      <p>
                        {detail.organisations} organisations · {detail.contacts}{" "}
                        contacts
                      </p>
                      <small>
                        Unique saved identities from this campaign's research,
                        all time. Discovery does not mean qualified or under
                        management.
                      </small>
                    </section>
                  </div>
                  <Link className="button" to={`${performancePath}?${location.pathname.startsWith("/client") ? `workspace=${encodeURIComponent(w)}&` : ""}campaign=${encodeURIComponent(selected!.id)}`}>Open campaign performance dashboard</Link>
                  <MeasurementPanel data={detail.measurement} />
                  <section className="panel">
                    <h3>Recorded campaign stages</h3>
                    {detail.metrics.map((m) => (
                      <div className="campaign-metric" key={m.kind}>
                        <span>{m.label}</span>
                        <span>
                          {m.value === null
                            ? "Not yet measured"
                            : `${m.value} ${m.unit}`}
                        </span>
                      </div>
                    ))}
                    <p>
                      All-time unique contacts per stage. Metrics appear only
                      from recorded execution events; stages may overlap. Opens
                      are tracking signals, not proof of human attention.
                    </p>
                  </section>
                </>
              )}
              {tab === "audience" && (
                <>
                  <section className="panel">
                    <h3>Existing audience records</h3>
                    <label>
                      Record type
                      <select
                        value={audienceEntity}
                        onChange={(e) => {
                          setAudienceEntity(
                            e.target.value as "organisations" | "people",
                          );
                          setOrganisationIds([]);
                          setAudienceOffset(0);
                          setAudience(undefined);
                        }}
                      >
                        <option value="organisations">
                          Organisations (business audiences)
                        </option>
                        <option value="people">
                          Contacts (consumer audiences)
                        </option>
                      </select>
                    </label>
                    <p>
                      Consumer research assesses existing contacts only. This
                      does not grant permission to contact them.
                    </p>
                    <p>
                      Choose up to 20 records for one research request. An
                      existing record does not establish permission to contact
                      or mean it is under management.
                    </p>
                    <p>
                      {organisationIds.length} selected. Use Research audience
                      above to assess this selection.
                    </p>
                    <div className="campaign-table">
                      <table>
                        <thead>
                          <tr>
                            <th>Select</th>
                            <th>
                              {audienceEntity === "people"
                                ? "Contact"
                                : "Organisation"}
                            </th>
                            {audienceEntity === "organisations" && (
                              <th>Contacts</th>
                            )}
                            <th>Current management context</th>
                            <th>Latest research</th>
                          </tr>
                        </thead>
                        <tbody>
                          {audience?.items.map((a) => (
                            <tr key={a.id}>
                              <td>
                                <input
                                  type="checkbox"
                                  aria-label={`Research ${a.name}`}
                                  checked={organisationIds.includes(a.id)}
                                  disabled={
                                    !organisationIds.includes(a.id) &&
                                    organisationIds.length >= 20
                                  }
                                  onChange={(e) =>
                                    setOrganisationIds(
                                      e.target.checked
                                        ? [...organisationIds, a.id]
                                        : organisationIds.filter(
                                            (id) => id !== a.id,
                                          ),
                                    )
                                  }
                                />
                              </td>
                              <td>
                                {a.name}
                                <br />
                                <small>{a.domain}</small>
                              </td>
                              {audienceEntity === "organisations" && (
                                <td>{a.contacts}</td>
                              )}
                              <td>{a.management}</td>
                              <td>
                                {a.lastEvidenceAt
                                  ? new Date(
                                      a.lastEvidenceAt,
                                    ).toLocaleDateString()
                                  : "No linked evidence"}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <div className="campaign-actions">
                      <button
                        disabled={!audienceOffset}
                        onClick={() =>
                          setAudienceOffset(Math.max(0, audienceOffset - 50))
                        }
                      >
                        Previous
                      </button>
                      <span>Page {Math.floor(audienceOffset / 50) + 1}</span>
                      <button
                        disabled={!audience?.more}
                        onClick={() => setAudienceOffset(audienceOffset + 50)}
                      >
                        Next
                      </button>
                    </div>
                  </section>
                  <section className="panel">
                    <h3>Offer fit assessments</h3>
                    <p>
                      These are research proposals, not qualification or an
                      instruction to contact. Multiple offers can fit the same
                      organisation or contact.
                    </p>
                    {detail.assessments?.map((a) => (
                      <article key={a.id}>
                        <h4>
                          {audience?.items.find(
                            (o) => o.id === (a.personId || a.organisationId),
                          )?.name ??
                            (a.personId ? "Contact" : "Organisation")}{" "}
                          ·{" "}
                          {overview?.choices.choices.offers?.find(
                            (o) => o.id === a.offerId,
                          )?.name ?? "Offer"}
                        </h4>
                        <p>
                          {a.fit.replaceAll("_", " ")}
                          {a.stale
                            ? " · Earlier setup version — reassess before use"
                            : ""}
                        </p>
                        <p>{a.rationale}</p>
                        {a.unknowns.map((u) => (
                          <p key={u}>{u}</p>
                        ))}
                      </article>
                    ))}
                    <h3>Research findings</h3>
                    <p>
                      {detail.evidenceCount} distinct evidence items. Review
                      suggestions before treating them as approved facts.
                    </p>
                    {detail.findings.map((f) => (
                      <article key={f.id}>
                        <h4>
                          {f.kind === "fact"
                            ? "Source-backed observation"
                            : "Assessment or recommendation"}{" "}
                          · {f.decision}
                        </h4>
                        <p>{f.statement}</p>
                        <p>{f.rationale}</p>
                      </article>
                    ))}
                    {!detail.findings.length && (
                      <p>
                        No findings yet. Approve the setup and request audience
                        research.
                      </p>
                    )}
                  </section>
                </>
              )}
              {tab === "content" && (
                <section className="panel">
                  <h3>Supporting content</h3>
                  {selected.setup.contentRecordIds.map((id) => (
                    <p key={id}>
                      {overview?.contentChoices.find((c) => c.id === id)
                        ?.name ?? "Content unavailable — review required"}
                    </p>
                  ))}
                  {selected.setup.assetIds.map((id) => (
                    <p key={id}>
                      {overview?.choices.assets.find((a) => a.id === id)
                        ?.name ?? "Asset unavailable — review required"}
                    </p>
                  ))}
                  {!selected.setup.assetIds.length && (
                    <p>No supporting Library assets selected.</p>
                  )}
                  <p>
                    Content and channel approval are separate from campaign
                    setup approval.
                  </p>
                </section>
              )}
              {tab === "activity" && (
                <section className="panel">
                  <h3>Research activity</h3>
                  {detail.jobs.map((j) => (
                    <article key={j.id}>
                      <h4>
                        {j.phase} · {j.status}
                      </h4>
                      <p>{j.summary}</p>
                      {j.error && <p role="alert">{j.error}</p>}
                      {j.gaps.map((g) => (
                        <p key={g}>{g}</p>
                      ))}
                      <small>{new Date(j.updatedAt).toLocaleString()}</small>
                    </article>
                  ))}
                  {!detail.jobs.length && <p>No research requests yet.</p>}
                  <p>
                    Use Research to inspect evidence, continue or cancel
                    individual jobs.
                  </p>
                  <Link
                    to={
                      window.location.pathname.startsWith("/queen/")
                        ? `/queen/clients/${w}/research`
                        : `/client/research?workspace=${w}`
                    }
                  >
                    Open Research
                  </Link>
                </section>
              )}
              {tab === "meetings" && (
                <CampaignMeetings
                  key={detail.id}
                  api={api}
                  workspaceId={w}
                  detail={detail}
                  onSaved={async () =>
                    setDetail(
                      await api.read(
                        w,
                        detail.id,
                        new AbortController().signal,
                      ),
                    )
                  }
                />
              )}
              {tab === "settings" && (
                <section className="panel">
                  <h3>Operating settings</h3>
                  <p>
                    NBA mode:{" "}
                    {selected.setup.operatingMode?.replaceAll("_", " ") ||
                      "Not selected"}
                  </p>
                  {textFields
                    .filter(([key]) =>
                      [
                        "organisationPriorities",
                        "researchRefresh",
                        "enrichmentPolicy",
                      ].includes(key),
                    )
                    .map(([key, label]) => (
                      <p key={key}>
                        <strong>{label}:</strong>{" "}
                        {selected.setup[key] || "Not specified"}
                      </p>
                    ))}
                  <p>
                    Daily email fetch allocation:{" "}
                    {selected.setup.dailyEmailFetchLimit ??
                      "Workspace/provider policy"}
                    . Monthly credit allocation:{" "}
                    {selected.setup.monthlyCreditAllocation ??
                      "Workspace/provider policy"}
                    .
                  </p>
                  <p>Owner: {selected.setup.owner || "Not specified"}</p>
                  <p>Timezone: {selected.setup.timezone}</p>
                  <p>
                    Schedule: {selected.setup.schedule || "Not specified"}{" "}
                    (planning only)
                  </p>
                  <h3>Overlap policy proposal</h3>
                  <p>{selected.setup.overlapPolicy}</p>
                  <p>
                    Workspace Contact Strategy policies govern future decisions.
                    This proposal has not been activated by saving the campaign.
                  </p>
                  <button
                    disabled={busy || !selected.setup.overlapPolicy}
                    onClick={() => {
                      if (
                        !window.confirm(
                          "Save this proposal as a new workspace Contact Strategy draft? Existing approved policy remains unchanged until a separate approval.",
                        )
                      )
                        return;
                      void act(async () => {
                        await api.policy(
                          w,
                          selected.id,
                          selected.version,
                          Math.max(
                            0,
                            ...(overview?.policies ?? [])
                              .filter((p) => p.key === "cs_022")
                              .map((p) => p.version),
                          ),
                        );
                        await load(new AbortController().signal);
                        setNotice(
                          "Overlap policy draft saved. Review it in Contact Strategy before approving it.",
                        );
                      });
                    }}
                  >
                    Prepare policy draft
                  </button>
                  <h3>Existing workspace policies</h3>
                  {(overview?.policies ?? [])
                    .filter(
                      (p) =>
                        p.status === "recorded" &&
                        !(overview?.policies ?? []).some(
                          (n) =>
                            n.key === p.key &&
                            n.status !== "draft" &&
                            n.version > p.version,
                        ),
                    )
                    .map((p) => (
                      <p key={`${p.key}:${p.version}`}>
                        {p.clauses.map((c) => c.statement).join(" ")} · v
                        {p.version}
                      </p>
                    ))}
                  <h3>Integration connections</h3>
                  {overview?.integrations.map((c, i) => (
                    <p key={i}>
                      {c.name}: {c.status}
                    </p>
                  ))}
                  <p>
                    A connected integration does not authorise campaign
                    execution.
                  </p>
                  <h3>Channels</h3>
                  {selected.setup.channels.map((c) => (
                    <p key={c}>{c}: execution not connected</p>
                  ))}
                </section>
              )}
            </>
          )}
        </>
      )}
      {error && !editing && !selected && (
        <div role="alert">
          <p>{error}</p>
          <button
            onClick={() => void act(() => load(new AbortController().signal))}
          >
            Retry
          </button>
        </div>
      )}
    </div>
  );
}
