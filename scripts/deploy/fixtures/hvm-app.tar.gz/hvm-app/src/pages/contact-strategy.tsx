import { ContactStrategyLibrary } from "../components/contact-strategy-library";
import { useEffect, useState } from "react";
import type { IcpGateway, IcpOffer } from "../data/icp";
import { IcpEligibility } from "../components/icp-eligibility";
export function ContactStrategyPage({
  api,
  workspaceId: w,
}: {
  api?: IcpGateway;
  workspaceId: string;
}) {
  const [offers, setOffers] = useState<IcpOffer[]>([]),
    [error, setError] = useState("");
  useEffect(() => {
    const c = new AbortController();
    if (api)
      void (async () => {
        try {
          const products = await api.products(w, c.signal);
          const rows = await Promise.all(
            products.map((p) => api.offers(w, p.id, c.signal)),
          );
          if (!c.signal.aborted) setOffers(rows.flat());
        } catch {
          if (!c.signal.aborted)
            setError(
              "Offer names could not be loaded. Reopen this page to retry.",
            );
        }
      })();
    return () => c.abort();
  }, [api, w]);
  return (
    <div className="icp-page">
      {api?.strategies && (
        <ContactStrategyLibrary key={w} api={api.strategies} w={w} />
      )}
      <h2>Approved offer constraints</h2>
      <p>
        Review the strategic offer constraints that engagement planning must
        respect. Configure and approve these policies in Ideal customer
        profiles.
      </p>
      {error && <p role="alert">{error}</p>}
      {api ? (
        <IcpEligibility
          api={api}
          w={w}
          profiles={[]}
          offers={offers}
          readOnly
        />
      ) : (
        <p>Contact Strategy is unavailable.</p>
      )}
    </div>
  );
}
