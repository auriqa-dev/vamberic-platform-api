import { ZodError } from "zod";
import { useEffect, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useOperating } from "../data/operating/context";
import { DataError } from "../data/gateway";
import { Failure } from "../components/ui";
import type { Access } from "../data/model";
import {
  onboardingDetails,
  type OnboardingRecord,
  type OnboardingMutation,
} from "../data/client-onboarding";
export function ClientOnboarding({
  access,
  governance = false,
}: {
  access: Access;
  governance?: boolean;
}) {
  const owners = access.queen?.partners.filter((p) => p.role === "owner") ?? [];
  const [params] = useSearchParams();
  const [partner, setPartner] = useState(
    params.get("partner") ?? owners[0]?.id ?? "",
  );
  if (
    (governance && !access.platform.empress) ||
    (!governance && !owners.some((p) => p.id === partner))
  )
    return <Failure error={new DataError("denied")} />;
  return (
    <section className="panel operating-form onboarding-form">
      <h1>
        {governance ? "Pre-client exemption approvals" : "Client onboarding"}
      </h1>
      {!governance && !params.get("request") && (
        <label>
          Partner
          <select value={partner} onChange={(e) => setPartner(e.target.value)}>
            {owners.map((p) => (
              <option key={p.id} value={p.id}>
                {p.displayName}
              </option>
            ))}
          </select>
        </label>
      )}
      <OnboardingFlow
        key={governance ? "empress" : partner}
        partner={governance ? undefined : partner}
      />
    </section>
  );
}
function OnboardingFlow({ partner }: { partner?: string }) {
  const gateway = useOperating()?.onboarding;
  const [params, setParams] = useSearchParams();
  const requestedId = params.get("request");
  const directClient = Boolean(partner && requestedId);
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<OnboardingRecord[]>([]),
    [next, setNext] = useState<string | null>(null);
  const [needsRefresh, setNeedsRefresh] = useState(false);
  const [selected, setSelected] = useState<OnboardingRecord>();
  const [error, setError] = useState<unknown>(),
    [busy, setBusy] = useState(false),
    [reason, setReason] = useState("");
  const [values, setValues] = useState({
    organisationName: "",
    websiteUrl: "",
    workspaceName: "",
    brandName: "",
    brandSlug: "",
    currentMarketingPlatform: "",
    currentContactCount: "",
    contactCountDescription: "",
    growthExpectation: "",
    otherTools: "",
  });
  const [pending, setPending] = useState<{
    id?: string;
    body: OnboardingMutation;
  }>();
  const controller = useRef<AbortController | undefined>(undefined);
  useEffect(() => {
    const c = new AbortController();
    setLoading(true);
    setSelected(undefined);
    controller.current = c;
    if (gateway)
      gateway
        .list(partner, c.signal)
        .then(async (r) => {
          const seen = new Set<string>();
          while (
            requestedId &&
            !r.items.some((row) => row.id === requestedId) &&
            r.next
          ) {
            if (seen.has(r.next)) throw new Error("Repeated page");
            seen.add(r.next);
            const page = await gateway.list(partner, c.signal, r.next);
            r = { items: [...r.items, ...page.items], next: page.next };
          }
          if (!c.signal.aborted) {
            const requested = r.items.find((row) => row.id === requestedId);
            if (requested) choose(requested);
            setItems(r.items);
            setNext(r.next);
          }
        })
        .catch((e) => {
          if (!c.signal.aborted) setError(e);
        })
        .finally(() => {
          if (!c.signal.aborted) setLoading(false);
        });
    return () => c.abort();
  }, [gateway, partner, requestedId]);
  if (!gateway) return <Failure error={new DataError("pending")} />;
  if (directClient && loading)
    return <p role="status">Loading client onboarding…</p>;
  if (directClient && !selected && !needsRefresh)
    return (
      <>
        <p role="alert">
          {error
            ? "We couldn’t load this client’s onboarding. Please return to My Clients and try again."
            : "This onboarding request is unavailable. Return to My Clients to select a client."}
        </p>
        <Link to="/queen/clients">Back to My Clients</Link>
      </>
    );
  async function send(request: { id?: string; body: OnboardingMutation }) {
    if (busy || !gateway) return;
    setBusy(true);
    setError(undefined);
    setPending(request);
    try {
      const r = await gateway.mutate(
        partner,
        request.id,
        request.body,
        controller.current!.signal,
      );
      if (controller.current?.signal.aborted) return;
      setSelected(r);
      setItems((old) => [r, ...old.filter((i) => i.id !== r.id)]);
      setPending(undefined);
    } catch (e) {
      if (!controller.current?.signal.aborted) {
        setError(e);
        // A definitive conflict did not apply this request. Require a fresh read
        // before another decision; transport/unknown outcomes keep exact retry.
        if (e instanceof DataError && e.code === "conflict") {
          setPending(undefined);
          setSelected(undefined);
          setItems([]);
          setNeedsRefresh(true);
        }
      }
    } finally {
      if (!controller.current?.signal.aborted) setBusy(false);
    }
  }
  function choose(row?: OnboardingRecord) {
    setSelected(row);
    setReason("");
    setError(undefined);
    setValues(
      row
        ? {
            workspaceName: row.details.workspaceName,
            brandName: row.details.brandName,
            brandSlug: row.details.brandSlug,
            organisationName: row.details.intake.organisationName,
            websiteUrl: row.details.intake.websiteUrl,
            currentMarketingPlatform:
              row.details.intake.currentMarketingPlatform ?? "",
            currentContactCount: String(
              row.details.intake.currentContactCount ?? "",
            ),
            contactCountDescription:
              row.details.intake.contactCountDescription ?? "",
            growthExpectation: row.details.intake.growthExpectation ?? "",
            otherTools: row.details.intake.otherTools.join("\n"),
          }
        : {
            organisationName: "",
            websiteUrl: "",
            workspaceName: "",
            brandName: "",
            brandSlug: "",
            currentMarketingPlatform: "",
            currentContactCount: "",
            contactCountDescription: "",
            growthExpectation: "",
            otherTools: "",
          },
    );
  }
  function mutate(action: OnboardingMutation["action"]) {
    try {
      const body: OnboardingMutation = {
        action,
        requestKey: crypto.randomUUID(),
        expectedRevision: selected?.revision ?? 0,
      };
      if (action === "save")
        body.details = onboardingDetails.parse({
          workspaceName: values.workspaceName,
          brandName: values.brandName,
          brandSlug: values.brandSlug,
          intake: {
            organisationName: values.organisationName,
            websiteUrl: values.websiteUrl,
            otherTools: values.otherTools
              .split("\n")
              .map((v) => v.trim())
              .filter(Boolean),
            ...Object.fromEntries(
              [
                "currentMarketingPlatform",
                "contactCountDescription",
                "growthExpectation",
              ]
                .filter((k) => values[k as keyof typeof values])
                .map((k) => [k, values[k as keyof typeof values]]),
            ),
            ...(values.currentContactCount
              ? { currentContactCount: Number(values.currentContactCount) }
              : {}),
          },
        });
      if (action === "approve" || action === "revoke") body.reason = reason;
      void send({ id: selected?.id, body });
    } catch (e) {
      setError(e);
    }
  }
  const frozen = busy || !!pending || needsRefresh;
  return (
    <>
      {directClient && (
        <>
          <Link to="/queen/clients">Back to My Clients</Link>
          <h2>{selected?.details.intake.organisationName}</h2>
        </>
      )}
      {(!directClient || needsRefresh) && (
        <button
          disabled={busy || !!pending}
          onClick={async () => {
            try {
              let r = await gateway.list(partner, controller.current!.signal);
              const seen = new Set<string>();
              while (
                directClient &&
                !r.items.some((i) => i.id === requestedId) &&
                r.next
              ) {
                if (seen.has(r.next)) throw new Error("Repeated page");
                seen.add(r.next);
                const page = await gateway.list(
                  partner,
                  controller.current!.signal,
                  r.next,
                );
                r = { items: [...r.items, ...page.items], next: page.next };
              }
              if (!controller.current?.signal.aborted) {
                setItems(r.items);
                setNext(r.next);
                choose(
                  directClient
                    ? r.items.find((i) => i.id === requestedId)
                    : undefined,
                );
                setNeedsRefresh(false);
                setError(undefined);
              }
            } catch (e) {
              if (!controller.current?.signal.aborted) setError(e);
            }
          }}
        >
          Refresh requests
        </button>
      )}
      <p>
        HVM Platform and Agent services: zero customer charge only after Empress
        approval. External services are excluded. Paid subscriptions are not
        available here. Marketing remains off.
      </p>
      {!directClient && (
        <fieldset disabled={frozen}>
          <legend>Onboarding requests</legend>
          {partner && (
            <button onClick={() => choose()}>New client intake</button>
          )}
          {items.map((r) => (
            <button
              key={r.id}
              onClick={() => {
                if (partner) setParams({ partner, request: r.id });
                else choose(r);
              }}
            >
              {r.details.intake.organisationName} ·{" "}
              {r.result
                ? "Workspace ready"
                : r.approval?.status === "active"
                  ? "Approved — ready to create workspace"
                  : r.approval?.status === "revoked"
                    ? "Approval revoked"
                    : "Awaiting approval"}
            </button>
          ))}
          {next && (
            <button
              onClick={async () => {
                try {
                  const r = await gateway.list(
                    partner,
                    controller.current!.signal,
                    next,
                  );
                  if (!controller.current?.signal.aborted) {
                    setItems((old) => [...old, ...r.items]);
                    setNext(r.next);
                  }
                } catch (e) {
                  if (!controller.current?.signal.aborted) setError(e);
                }
              }}
            >
              More requests
            </button>
          )}
        </fieldset>
      )}
      {partner && selected && !selected.result && (
        <div className="notice">
          <p
            role={
              busy && pending?.body.action === "provision"
                ? "status"
                : undefined
            }
          >
            {busy && pending?.body.action === "provision"
              ? `Creating ${selected.details.intake.organisationName}’s workspace… Please keep this page open.`
              : selected.approval?.status === "active"
                ? `${selected.details.intake.organisationName} is approved. Create the workspace to start client setup.`
                : "Exemption approval is needed before you can create this client’s workspace."}
          </p>
          <button
            disabled={frozen || selected.approval?.status !== "active"}
            onClick={() => mutate("provision")}
          >
            {busy && pending?.body.action === "provision"
              ? "Creating workspace…"
              : "Create workspace and start setup"}
          </button>
        </div>
      )}
      {partner && selected?.result && (
        <div className="notice" role="status">
          <p>
            {selected.details.intake.organisationName}’s workspace is ready.
          </p>
          {/* Reload access after provisioning; the current access snapshot predates this workspace. */}
          <a
            className="button"
            href={`/queen/clients/${selected.result.workspaceId}/setup`}
          >
            Open {selected.details.intake.organisationName} setup
          </a>
        </div>
      )}
      {partner && !selected?.result && (
        <fieldset disabled={frozen}>
          <legend>Client declarations</legend>
          <p>
            Enter the organisation and website once. Workspace and brand names
            are filled in automatically; change them only if they differ.
          </p>
          {Object.keys(values).map((key) => (
            <label key={key}>
              {
                {
                  organisationName: "Organisation name",
                  websiteUrl: "Website URL",
                  workspaceName: "Workspace name",
                  brandName: "Brand name",
                  brandSlug: "Brand URL name",
                  currentMarketingPlatform:
                    "Current marketing platform (optional)",
                  currentContactCount: "Current contact count (optional)",
                  contactCountDescription:
                    "Contact count description (optional)",
                  growthExpectation: "Growth expectation (optional)",
                  otherTools: "Other tools (one per line, optional)",
                }[key]
              }
              {[
                "contactCountDescription",
                "growthExpectation",
                "otherTools",
              ].includes(key) ? (
                <textarea
                  rows={3}
                  value={values[key as keyof typeof values]}
                  onChange={(e) =>
                    setValues((previous) => {
                      const value = e.target.value;
                      if (key !== "organisationName")
                        return { ...previous, [key]: value };
                      return {
                        ...previous,
                        organisationName: value,
                        workspaceName:
                          previous.workspaceName === previous.organisationName
                            ? value
                            : previous.workspaceName,
                        brandName:
                          previous.brandName === previous.organisationName
                            ? value
                            : previous.brandName,
                        brandSlug:
                          previous.brandSlug ===
                          brandUrlName(previous.organisationName)
                            ? brandUrlName(value)
                            : previous.brandSlug,
                      };
                    })
                  }
                />
              ) : (
                <input
                  type={key === "websiteUrl" ? "url" : "text"}
                  inputMode={
                    key === "currentContactCount" ? "numeric" : undefined
                  }
                  value={values[key as keyof typeof values]}
                  onChange={(e) =>
                    setValues((previous) => {
                      const value = e.target.value;
                      if (key !== "organisationName")
                        return { ...previous, [key]: value };
                      return {
                        ...previous,
                        organisationName: value,
                        workspaceName:
                          previous.workspaceName === previous.organisationName
                            ? value
                            : previous.workspaceName,
                        brandName:
                          previous.brandName === previous.organisationName
                            ? value
                            : previous.brandName,
                        brandSlug:
                          previous.brandSlug ===
                          brandUrlName(previous.organisationName)
                            ? brandUrlName(value)
                            : previous.brandSlug,
                      };
                    })
                  }
                />
              )}
              {key === "brandSlug" && (
                <small>
                  Use lowercase letters, numbers and hyphens, for example
                  built-matters.
                </small>
              )}
            </label>
          ))}
          <button onClick={() => mutate("save")}>
            {selected
              ? "Save changes and request approval again"
              : "Request exempt onboarding"}
          </button>
        </fieldset>
      )}
      {selected && (
        <article>
          {!directClient && <h2>{selected.details.intake.organisationName}</h2>}
          <p>
            Revision {selected.revision}; proposal{" "}
            {selected.binding.quoteRevision}. Website declaration:{" "}
            {selected.details.intake.websiteUrl}
          </p>
          <dl>
            {Object.entries(selected.details.intake).map(([key, value]) => (
              <div key={key}>
                <dt>{key}</dt>
                <dd>
                  {Array.isArray(value) ? value.join(", ") : String(value)}
                </dd>
              </div>
            ))}
          </dl>
          <p>
            Workspace: {selected.details.workspaceName}; Brand:{" "}
            {selected.details.brandName}; URL name: {selected.details.brandSlug}
          </p>
          {selected.approval && (
            <p>
              Exemption {selected.approval.status}. No automatic expiry.{" "}
              {selected.approval.reason}
            </p>
          )}
          {selected.result ? (
            <>
              <p>
                Provisioned. Workspace exemption continues until Empress revokes
                it. Workspace: {selected.result.workspaceId}
              </p>
              {!partner && (
                <Link to="/empress/workspace-billing">
                  Manage workspace exemption
                </Link>
              )}
            </>
          ) : partner ? null : (
            <fieldset disabled={frozen}>
              <legend>Empress decision</legend>
              <label>
                Reason
                <textarea
                  value={reason}
                  maxLength={1000}
                  onChange={(e) => setReason(e.target.value)}
                />
              </label>
              <button
                disabled={!reason.trim()}
                onClick={() => mutate("approve")}
              >
                Approve exemption
              </button>
              <button
                disabled={
                  !reason.trim() || selected.approval?.status !== "active"
                }
                onClick={() => mutate("revoke")}
              >
                Revoke approval
              </button>
            </fieldset>
          )}
        </article>
      )}
      {busy && pending?.body.action === "provision" ? null : busy ? (
        <p role="status">Sending your request…</p>
      ) : pending ? (
        <div role="alert" className="notice">
          <h2>We couldn’t confirm the result</h2>
          <p>
            Your request may have been saved, but the app could not verify the
            response. Keep this page open and use Retry exact request. It reuses
            the same request to avoid duplicates. Don’t refresh or start a new
            intake yet.
          </p>
          <button onClick={() => void send(pending)}>
            Retry exact request
          </button>
        </div>
      ) : error ? (
        <OnboardingError error={error} />
      ) : null}
    </>
  );
}

function OnboardingError({ error }: { error: unknown }) {
  if (error instanceof ZodError) {
    const hints: Record<string, string> = {
      organisationName: "Organisation name: enter 1–200 characters.",
      websiteUrl:
        "Website URL: enter a full web address, such as https://example.com (maximum 2,048 characters).",
      workspaceName: "Workspace name: enter 1–200 characters.",
      brandName: "Brand name: enter 1–200 characters.",
      brandSlug:
        "Brand URL name: use 1–100 lowercase letters, numbers or hyphens, starting with a letter or number; for example built-matters. Do not enter a website address.",
      currentMarketingPlatform:
        "Current marketing platform: use at most 200 characters or leave it blank.",
      currentContactCount:
        "Current contact count: enter a non-negative whole number within the supported range, or leave it blank.",
      contactCountDescription:
        "Contact count description: use 1–1,000 characters or leave it blank.",
      growthExpectation:
        "Growth expectation: use 1–1,000 characters or leave it blank.",
      otherTools:
        "Other tools: enter up to 40 tools, one per line, with at most 200 characters each.",
    };
    const messages = [
      ...new Set(
        error.issues.map(
          (issue) =>
            hints[String(issue.path[issue.path[0] === "intake" ? 1 : 0])] ??
            "Check the request details.",
        ),
      ),
    ];
    return (
      <div role="alert" className="notice">
        <h2>Check these details</h2>
        <p>
          This request has not been sent. Correct these fields and try again.
        </p>
        <ul>
          {messages.map((message) => (
            <li key={message}>{message}</li>
          ))}
        </ul>
      </div>
    );
  }
  const code = error instanceof DataError ? error.code : "unavailable";
  const content =
    code === "conflict"
      ? [
          "This request has changed",
          "Select Refresh requests, then reopen the request and review its latest details before trying again.",
        ]
      : code === "denied"
        ? [
            "Onboarding access is unavailable",
            "Check that you are signed in with the correct Queen or Empress access. Contact HVM if access should be available.",
          ]
        : code === "invalid"
          ? [
              "Onboarding information could not be verified",
              "Select Refresh requests to try loading the information again. Contact HVM if this continues.",
            ]
          : [
              "Couldn’t load onboarding requests",
              "Select Refresh requests to try again. Your entered details are still on this page.",
            ];
  return (
    <div role="alert" className="notice">
      <h2>{content[0]}</h2>
      <p>{content[1]}</p>
    </div>
  );
}

function brandUrlName(name: string) {
  return name
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 100);
}
