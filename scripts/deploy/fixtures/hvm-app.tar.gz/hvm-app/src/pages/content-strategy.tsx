import { LibraryPlanning } from "../components/library-planning";
import { LibraryIngestion } from "../components/library-ingestion";
import {
  useHenryBinding,
  useHenryBrand,
  useHenryAvailable,
  henryFields,
  applyHenryFields,
} from "../components/workspace-henry";
import { ContentHenry } from "../components/content-henry";
import { henryResult } from "../data/content-strategy-model";
import { executionBriefText } from "../data/execution-brief-text";
import { useEffect, useState, useRef } from "react";
import { z } from "zod";
import type { ContentGateway, ContentBundle } from "../data/content-strategy";
import {
  schemas,
  scope as scopeSchema,
  contextBrief,
  type Kind,
  type ContentRecord,
} from "../data/content-strategy-model";
import { extractContentFile } from "../data/content-import";
import { Loading, Status, Empty } from "../components/ui";
import "../styles/content-strategy.css";
type Scope = z.infer<typeof scopeSchema>;
const tabs = [
  "Overview",
  "Library",
  "Strategy",
  "Actions",
  "Briefs",
  "Delivery",
  "Executors",
  "Effectiveness",
] as const;
const names: Record<Kind, string> = {
  asset: "asset",
  architecture: "content architecture",
  strategy: "strategy",
  action: "action",
  brief: "brief",
  effectiveness: "measurement",
  executor: "executor",
  execution: "assignment",
};
function initial(schema: z.ZodTypeAny): unknown {
  if (schema instanceof z.ZodDefault) return schema._def.defaultValue();
  if (schema instanceof z.ZodObject)
    return Object.fromEntries(
      Object.entries(schema.shape).map(([k, s]) => [
        k,
        initial(s as z.ZodTypeAny),
      ]),
    );
  if (schema instanceof z.ZodArray) return [];
  if (schema instanceof z.ZodEnum) return schema.options[0];
  if (schema instanceof z.ZodNumber) return 0;
  if (schema instanceof z.ZodBoolean) return false;
  if (schema instanceof z.ZodNullable) return null;
  if (schema instanceof z.ZodUnion) return initial(schema.options[0]);
  return "";
}
const label = (key: string) =>
  key
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replaceAll("url", "URL")
    .replaceAll("Ids", "references")
    .replaceAll("Id", "reference")
    .replace(/^./, (c) => c.toUpperCase());
function Fields({
  schema,
  value,
  onChange,
  path = "field",
}: {
  schema: z.ZodTypeAny;
  value: unknown;
  onChange: (v: unknown) => void;
  path?: string;
}) {
  if (schema instanceof z.ZodDefault)
    return (
      <Fields
        schema={schema.removeDefault()}
        value={value}
        onChange={onChange}
        path={path}
      />
    );
  if (schema instanceof z.ZodObject) {
    const data = (value ?? {}) as Record<string, unknown>;
    const hidden = [
      "scope",
      "sourceRecordIds",
      "sourceAssetIds",
      "sourceDocumentId",
      "sourceMetadata",
      "sourceDocumentRevision",
      "contentHash",
      "fileHash",
      "contentTextId",
      "discoveredAt",
      "modifiedAt",
      "uploadedAt",
      "originalFilename",
      "associations",
      "actionDefinitionId",
      "strategyId",
      "strategyRevision",
      "actionId",
      "briefId",
      "briefVersion",
      "executorId",
      "executionId",
      "assetId",
      "capabilityIds",
      "integrationId",
    ];
    if (data.briefType && data.briefType !== "content")
      hidden.push(
        "classification",
        "personalisation",
        "buyerQuestion",
        "buyerStage",
        "structure",
        "preserve",
        "mayChange",
        "cta",
      );
    const entries = Object.entries(schema.shape).filter(
      ([k]) => !hidden.includes(k),
    );
    const primary = [
      "title",
      "classification",
      "assetType",
      "channel",
      "url",
      "description",
      "text",
      "markdown",
      "assessment",
      "context",
      "objective",
      "audience",
      "messages",
      "format",
      "rationale",
      "priority",
      "feasibility",
      "progress",
      "briefType",
      "workDescription",
      "deliverables",
      "completionCriteria",
      "executorType",
      "capabilities",
      "available",
      "completedAt",
      "externalReference",
      "notes",
      "owner",
      "decisionReason",
      "metric",
      "value",
      "category",
      "source",
      "observedAt",
      "confirmed",
    ];
    const fields = (values: typeof entries) => (
      <div className="content-fields">
        {values.map(([k, s]) => (
          <div
            key={k}
            className={
              s instanceof z.ZodObject ||
              s instanceof z.ZodArray ||
              [
                "text",
                "markdown",
                "assessment",
                "description",
                "objective",
                "rationale",
              ].includes(k)
                ? "content-field content-field-wide"
                : "content-field"
            }
          >
            <label htmlFor={`${path}-${k}`}>{label(k)}</label>
            <Fields
              schema={s as z.ZodTypeAny}
              value={data[k]}
              path={`${path}-${k}`}
              onChange={(v) => onChange({ ...data, [k]: v })}
            />
          </div>
        ))}
      </div>
    );
    if (path !== "field") return fields(entries);
    return (
      <>
        {fields(entries.filter(([k]) => primary.includes(k)))}
        {entries.some(([k]) => !primary.includes(k)) && (
          <details>
            <summary>Evidence, recommendations and detailed guidance</summary>
            {fields(entries.filter(([k]) => !primary.includes(k)))}
          </details>
        )}
      </>
    );
  }

  if (schema instanceof z.ZodArray) {
    const items = (value ?? []) as unknown[];
    if (schema.element instanceof z.ZodString)
      return (
        <textarea
          id={path}
          rows={Math.max(2, Math.min(5, items.length + 1))}
          value={items.join("\n")}
          onChange={(e) => onChange(e.target.value.split("\n").filter(Boolean))}
          placeholder="One item per line"
        />
      );
    return (
      <div className="content-repeat">
        {items.map((v, i) => (
          <details key={i} open={items.length === 1}>
            <summary>
              {String((v as Record<string, unknown>)?.title ?? `Item ${i + 1}`)}
            </summary>
            <Fields
              schema={schema.element}
              value={v}
              path={`${path}-${i}`}
              onChange={(n) => onChange(items.map((a, j) => (j === i ? n : a)))}
            />
            <button
              type="button"
              onClick={() => onChange(items.filter((_, j) => j !== i))}
            >
              Remove item
            </button>
          </details>
        ))}
        <button
          type="button"
          onClick={() => onChange([...items, initial(schema.element)])}
        >
          Add item
        </button>
      </div>
    );
  }
  if (schema instanceof z.ZodEnum)
    return (
      <select
        id={path}
        value={String(value ?? schema.options[0])}
        onChange={(e) => onChange(e.target.value)}
      >
        {schema.options.map((o: string) => (
          <option key={o} value={o}>
            {o.replaceAll("_", " ")}
          </option>
        ))}
      </select>
    );
  if (schema instanceof z.ZodBoolean)
    return (
      <input
        id={path}
        type="checkbox"
        checked={Boolean(value)}
        onChange={(e) => onChange(e.target.checked)}
      />
    );
  if (/-(completedAt|observedAt)$/.test(path)) {
    const date = value ? new Date(String(value)) : undefined;
    const local =
      date && !Number.isNaN(date.getTime())
        ? new Date(date.getTime() - date.getTimezoneOffset() * 60000)
            .toISOString()
            .slice(0, 16)
        : "";
    return (
      <input
        id={path}
        type="datetime-local"
        value={local}
        onChange={(e) =>
          onChange(e.target.value ? new Date(e.target.value).toISOString() : "")
        }
      />
    );
  }
  if (schema instanceof z.ZodNumber || schema instanceof z.ZodNullable)
    return (
      <input
        id={path}
        type="number"
        value={value == null ? "" : Number(value)}
        onChange={(e) =>
          onChange(e.target.value === "" ? null : Number(e.target.value))
        }
      />
    );
  return /title|channel|format|owner|metric|value|observedAt|url|assetType|key$/.test(
    path,
  ) ? (
    <input
      id={path}
      value={String(value ?? "")}
      onChange={(e) => onChange(e.target.value)}
    />
  ) : (
    <textarea
      id={path}
      rows={3}
      value={String(value ?? "")}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}
export function ContentStrategyPage(props: {
  api?: ContentGateway;
  workspaceId: string;
  library?: boolean;
}) {
  return <ContentStrategyWorkspace key={props.workspaceId} {...props} />;
}
function ContentStrategyWorkspace({
  api,
  workspaceId: w,
  library = false,
}: {
  api?: ContentGateway;
  workspaceId: string;
  library?: boolean;
}) {
  const carriedBrand = useRef(useHenryBrand()).current;
  const [data, setData] = useState<ContentBundle>(),
    [tab, setTab] = useState<(typeof tabs)[number]>(
      library ? "Library" : "Overview",
    ),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(""),
    [selected, setSelected] = useState<string[]>([]),
    [instruction, setInstruction] = useState(""),
    [scope, setScope] = useState<Scope>({
      brandId: carriedBrand,
      products: [],
      offers: [],
      audiences: [],
    }),
    [editing, setEditing] = useState<{
      kind: Kind;
      data: Record<string, unknown>;
      record?: ContentRecord;
    }>(),
    [file, setFile] = useState<File>(),
    [outputText, setOutputText] = useState<Record<string,string>>({}),
    [history, setHistory] = useState<ContentRecord[]>(),
    [actionType, setActionType] = useState(""),
    [bulkValue, setBulkValue] = useState(""),
    [librarySearch, setLibrarySearch] = useState(""),
    [textMatches, setTextMatches] = useState<
      { id: string; contentTextId: string }[]
    >([]),
    [libraryType, setLibraryType] = useState(""),
    [libraryStatus, setLibraryStatus] = useState(""),
    [includeArchived, setIncludeArchived] = useState(false);
  const writtenAttempts = useRef(new Map<string,{generate:string;save:string}>());
  const running = useRef(false),
    uploadKey = useRef(crypto.randomUUID()),
    uploadResult = useRef<string | undefined>(undefined);
  useEffect(() => {
    const c = new AbortController();
    if (api)
      void api
        .list(w, c.signal)
        .then((b) => {
          if (!c.signal.aborted) {
            setData(b);
            setScope((s) => {
              const previous = b.conversations?.find((t) =>
                b.brands.some((brand) => brand.id === t.scope.brandId),
              )?.scope;
              if (s.brandId || !previous)
                return { ...s, brandId: s.brandId || b.brands[0]?.id || "" };
              const fresh = (refs: Scope["products"], collection: string) =>
                refs.flatMap((ref) => {
                  const current = b.choices[collection]?.find(
                    (choice) =>
                      choice.id === ref.id &&
                      (!choice.brandId || choice.brandId === previous.brandId),
                  );
                  return current
                    ? [{ id: current.id, revision: current.revision }]
                    : [];
                });
              return {
                brandId: previous.brandId,
                products: fresh(previous.products, "offerings"),
                offers: fresh(previous.offers, "offers"),
                audiences: fresh(previous.audiences, "ideal_customer_profiles"),
              };
            });
          }
        })
        .catch(() => {
          if (!c.signal.aborted)
            setError("Content Strategy could not be loaded. Refresh to retry.");
        });
    return () => c.abort();
  }, [api, w]);
  useEffect(() => {
    const c = new AbortController();
    setTextMatches([]);
    setError((previous) => previous === "Full-text search is unavailable. The visible results match asset metadata only." ? "" : previous);
    if (librarySearch.trim().length < 2 || !api?.library)
      return () => c.abort();
    const timer = setTimeout(() => {
      void api.library
        .search(w, librarySearch, c.signal)
        .then((r) => {
          if (!c.signal.aborted) {
            setTextMatches(r.matches);
            if (r.more)
              setNotice(
                "Search is limited to 500 full-text matches. Narrow your search.",
              );
          }
        })
        .catch(() => {
          if (!c.signal.aborted)
            setError(
              "Full-text search is unavailable. The visible results match asset metadata only.",
            );
        });
    }, 300);
    return () => {
      clearTimeout(timer);
      c.abort();
    };
  }, [api, w, librarySearch]);
  const signal = () => new AbortController().signal;
  async function run(name: string, work: () => Promise<void>) {
    if (running.current) return;
    running.current = true;
    setError("");
    setNotice("");
    setBusy(name);
    try {
      await work();
    } catch (e) {
      setError(
        e instanceof z.ZodError
          ? "Check these fields: " +
              e.issues
                .slice(0, 5)
                .map(
                  (i) =>
                    label(String(i.path.at(-1) ?? "record")) +
                    " — " +
                    i.message,
                )
                .join("; ")
          : e instanceof Error &&
              ["conflict", "invalid", "denied", "unavailable"].includes(
                e.message,
              )
            ? ({
                conflict:
                  "This record or its sources changed. Reload and review the current version before trying again.",
                invalid: "Check the required fields and source selections.",
                denied:
                  "Your session or workspace access needs checking. Sign in again if necessary.",
                unavailable:
                  "This action could not finish. Your saved records are unchanged; refresh to recover any completed proposal.",
              }[e.message] ?? e.message)
            : e instanceof Error
              ? e.message
              : "This action failed. Your saved records are unchanged.",
      );
    } finally {
      running.current = false;
      setBusy("");
    }
  }
  async function reload() {
    if (api) setData(await api.list(w, signal()));
  }
  function newRecord(kind: Kind) {
    setError("");
    setNotice("");
    if (kind === "strategy") {
      const current = data?.records
        .filter(
          (r) =>
            r.kind === "strategy" &&
            (r.data.scope as Scope).brandId === scope.brandId,
        )
        .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0];
      if (current) {
        setEditing({
          kind,
          data: structuredClone(current.data),
          record: current,
        });
        setTab("Strategy");
        return;
      }
    }
    const value = initial(schemas[kind]) as Record<string, unknown>;
    if ("scope" in value) value.scope = scope;
    if (kind === "executor") {
      value.executorType = "human_specialist";
      value.available = true;
    }
    if (kind === "effectiveness") value.observedAt = new Date().toISOString();
    setEditing({ kind, data: value });
    setHistory(undefined);
    setFile(undefined);
    uploadKey.current = crypto.randomUUID();
    uploadResult.current = undefined;
  }
  async function save() {
    if (!api || !editing) return;
    const value = { ...editing.data };
    if (editing.kind === "asset") value.scope = scope;
    if (file && editing.kind === "asset" && !uploadResult.current) {
      const doc = await api.documents.upload(
        w,
        file,
        {
          name: String(value.title || file.name),
          purpose: "Existing content inventory",
          extract: String(value.text).slice(0, 6000),
          provenance: `Uploaded original: ${file.name}`,
          grain: "other",
        },
        uploadKey.current,
        signal(),
      );
      uploadResult.current = doc.id;
      value.sourceDocumentId = doc.id;
    }
    if (file && uploadResult.current)
      value.sourceDocumentId = uploadResult.current;
    const parsed = schemas[editing.kind].parse(value);
    const row = await api.save(
      w,
      {
        kind: editing.kind,
        operation: "save",
        id: editing.record?.id,
        expectedVersion: editing.record?.version ?? 0,
        data: parsed,
        requestKey: crypto.randomUUID(),
      },
      signal(),
    );
    await reload();
    setEditing(undefined);
    setFile(undefined);
    setSelected([row.id]);
    setNotice(`Saved ${names[row.kind]}. It is displayed below for review.`);
  }
  async function change(row: ContentRecord, operation: "approve" | "remove") {
    if (!api) return;
    if (
      !window.confirm(
        operation === "remove"
          ? `Remove “${String(row.data.title)}” from future use? Version history is retained.`
          : `Approve this version of “${String(row.data.title)}”? This does not authorise publication or sending.`,
      )
    )
      return;
    await api.save(
      w,
      {
        id: row.id,
        kind: row.kind,
        expectedVersion: row.version,
        operation,
        requestKey: crypto.randomUUID(),
      },
      signal(),
    );
    await reload();
    setNotice(
      operation === "approve"
        ? "Approved version saved."
        : "Item removed from future use.",
    );
  }
  async function generate(
    task: "context" | "analyse" | "architecture" | "strategy" | "brief",
    ids = selected,
    hint = instruction,
    taskScope = scope,
  ) {
    if (!api) return;
    const currentStrategy = data?.records
      .filter(
        (r) =>
          r.kind === "strategy" &&
          (r.data.scope as Scope).brandId === scope.brandId,
      )
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0];
    if (task === "strategy" && currentStrategy) {
      ids = [...new Set([...ids, currentStrategy.id])];
      const prior = scopeSchema.parse(currentStrategy.data.scope);
      const combine = (
        key: "products" | "offers" | "audiences",
        collection: string,
      ) =>
        [
          ...new Set([...prior[key], ...taskScope[key]].map((r) => r.id)),
        ].flatMap((id) => {
          const row = data?.choices[collection]?.find((r) => r.id === id);
          return row ? [{ id, revision: row.revision }] : [];
        });
      taskScope = {
        ...taskScope,
        products: combine("products", "offerings"),
        offers: combine("offers", "offers"),
        audiences: combine("audiences", "ideal_customer_profiles"),
      };
    }
    const result = await api.generate(
      w,
      {
        task,
        scope: taskScope,
        instruction: hint,
        recordIds: ids,
        requestKey: crypto.randomUUID(),
      },
      signal(),
    );
    if (task === "context") {
      setEditing({
        kind: "strategy",
        record: currentStrategy,
        data: {
          ...(currentStrategy?.data ?? (initial(schemas.strategy) as object)),
          title: "Content strategy",
          scope,
          context: contextBrief.parse(result),
        },
      });
      setTab("Strategy");
    } else {
      const kind = task === "analyse" ? "asset" : task;
      setEditing({
        kind,
        data: result,
        record:
          task === "analyse"
            ? data?.records.find(
                (r) => ids.includes(r.id) && r.kind === "asset",
              )
            : task === "architecture"
              ? data?.records.find(
                  (r) => ids.includes(r.id) && r.kind === "architecture",
                )
              : task === "strategy"
                ? data?.records.find(
                    (r) => ids.includes(r.id) && r.kind === "strategy",
                  )
                : undefined,
      });
      setTab(
        task === "strategy"
          ? "Strategy"
          : task === "brief"
            ? "Briefs"
            : "Library",
      );
    }
    await reload();
    setNotice(
      "Proposal ready. Review and save it below; approval is a separate action.",
    );
  }
  function reviewHenry(
    reply: z.infer<typeof henryResult>,
    target?: NonNullable<ContentBundle["conversations"]>[number]["target"],
  ) {
    if (
      editing &&
      !window.confirm(
        "Replace the open editor with this response? Unsaved edits will be replaced.",
      )
    )
      return;
    const kind = reply.strategy
      ? "strategy"
      : reply.brief
        ? "brief"
        : undefined;
    const value = reply.strategy ?? reply.brief;
    if (kind && value) {
      const record =
        target?.kind === kind
          ? data?.records.find(
              (r) => r.id === target.id && r.version === target.version,
            )
          : undefined;
      if (target?.kind === kind && !record) {
        setError(
          "This response refers to an older version. Select the current record and ask Henry to refine it.",
        );
        return;
      }
      setEditing({ kind, data: value, record });
      setTab(kind === "strategy" ? "Strategy" : "Briefs");
      setNotice(
        "Henry’s proposal is open below. Review and save it; approval is separate.",
      );
    } else if (reply.reviewRecordId) {
      const row = data?.records.find((r) => r.id === reply.reviewRecordId);
      if (!row) {
        setError("That record is unavailable. Refresh to see current work.");
        return;
      }
      setEditing(undefined);
      setSelected([row.id]);
      setTab(
        (
          {
            asset: "Library",
            architecture: "Library",
            strategy: "Strategy",
            action: "Actions",
            brief: "Briefs",
            execution: "Delivery",
            executor: "Executors",
            effectiveness: "Effectiveness",
          } as const
        )[row.kind],
      );
      setNotice(
        `Review “${String(row.data.title)}” below. Use its controls to make or approve a change.`,
      );
    }
  }
  async function askHenry(message: string, conversationId: string) {
    if (!api || running.current)
      throw new Error("Please wait for the current operation.");
    let failure: unknown;
    await run("Henry is preparing a response…", async () => {
      try {
        const candidates =
          data?.records.filter(
            (r) =>
              selected.includes(r.id) &&
              (r.kind === "strategy" || r.kind === "brief"),
          ) ?? [];
        const saved = candidates.length === 1 ? candidates[0] : undefined;
        const base =
          editing ??
          (saved
            ? { kind: saved.kind, data: saved.data, record: saved }
            : undefined);
        const draft =
          base && (base.kind === "strategy" || base.kind === "brief")
            ? {
                kind: base.kind,
                data: schemas[base.kind].parse(base.data),
                recordId: base.record?.id ?? "",
                version: base.record?.version ?? 0,
              }
            : undefined;
        const result = henryResult.parse(
          await api.generate(
            w,
            {
              task: "henry",
              scope,
              instruction: message,
              conversationId,
              draft,
              recordIds: [
                ...new Set([
                  ...selected,
                  ...(draft?.recordId ? [draft.recordId] : []),
                ]),
              ],
              requestKey: crypto.randomUUID(),
            },
            signal(),
          ),
        );
        await reload();
        // The current draft was explicitly supplied for refinement; retain its identity.
        const kind = result.strategy
          ? "strategy"
          : result.brief
            ? "brief"
            : undefined;
        if (kind) {
          setEditing({
            kind,
            data: (result.strategy ?? result.brief)!,
            record: draft?.kind === kind ? base?.record : undefined,
          });
          setTab(kind === "strategy" ? "Strategy" : "Briefs");
          setNotice(
            "Henry’s draft is ready below. Review and save it; nothing has been approved or executed.",
          );
        } else reviewHenry(result);
      } catch (e) {
        failure = e;
        throw e;
      }
    });
    if (failure) throw failure;
  }
  function download(value: unknown, name: string) {
    const blob = new Blob([JSON.stringify(value, null, 2)], {
        type: "application/json",
      }),
      href = URL.createObjectURL(blob),
      a = document.createElement("a");
    a.href = href;
    a.download = name;
    a.click();
    URL.revokeObjectURL(href);
  }
  const sharedHenry = useHenryAvailable();
  const editableHenryContent = editing
    ? Object.fromEntries(
        Object.entries(editing.data).filter(
          ([k]) =>
            ![
              "scope",
              "sources",
              "evidence",
              "provenance",
              "strategyId",
              "briefId",
              "assetId",
              "executionId",
              "executorId",
              "actionTypeId",
              "brandKitVersion",
              "approval",
              "approved",
            ].includes(k) &&
            !k.endsWith("Id") &&
            !k.endsWith("Ids"),
        ),
      )
    : undefined;
  useHenryBinding({
    key: "content-strategy",
    brandId: scope.brandId,
    summary: JSON.stringify({
      tab,
      scope,
      selected,
      records: data?.records
        .slice(0, 30)
        .map((r) => ({
          id: r.id,
          kind: r.kind,
          title: r.data.title,
          status: r.status,
        })),
      instruction,
    }),
    editor:
      editing && !busy && editableHenryContent
        ? {
            key: `content:${editing.kind}:${editing.record?.id ?? "new"}:${editing.record?.updatedAt ?? "new"}`,
            title: `${editing.kind} draft`,
            fields: henryFields(editableHenryContent),
          }
        : undefined,
    apply: (changes) => {
      if (!editing || !editableHenryContent)
        throw new Error("Open a draft first.");
      setEditing({
        ...editing,
        data: {
          ...editing.data,
          ...applyHenryFields(editableHenryContent, changes),
        },
      });
    },
    actions: busy
      ? []
      : [
          ...tabs.map((t) => ({
            id: `content:tab:${t}`,
            label: `Open ${t.toLowerCase()}`,
            run: () => {
              if (editing && !window.confirm("Leave unsaved edits?")) return;
              setEditing(undefined);
              setTab(t);
            },
          })),
          ...(
            [
              "strategy",
              "brief",
              "asset",
              "architecture",
              "execution",
              "executor",
              "effectiveness",
            ] as const
          ).map((kind) => ({
            id: `content:new:${kind}`,
            label: `Prepare ${kind}`,
            run: (objective: string) => {
              if (editing && !window.confirm("Replace unsaved edits?")) return;
              setInstruction(objective);
              newRecord(kind);
            },
          })),
        ],
  });
  if (!api)
    return (
      <Empty title="Content Strategy unavailable">
        Refresh after the application update.
      </Empty>
    );
  if (!data) return error ? <p role="alert">{error}</p> : <Loading />;
  const inBrand = (r: ContentRecord) => {
    const s =
      r.data.scope ??
      data.records.find((n) => n.id === r.data.strategyId)?.data.scope;
    return !s || (s as Scope).brandId === scope.brandId;
  };
  const visible = data.records
    .filter(inBrand)
    .filter(
      (r) =>
        tab !== "Library" ||
        ((includeArchived || !r.data.archived) &&
          (!librarySearch ||
            JSON.stringify(r.data)
              .toLowerCase()
              .includes(librarySearch.toLowerCase()) ||
            textMatches.some(
              (m) => m.id === r.id && m.contentTextId === r.data.contentTextId,
            )) &&
          (!libraryType || r.data.assetType === libraryType) &&
          (!libraryStatus || r.status === libraryStatus)),
    )
    .filter(
      (r) =>
        (!r.data.scope || (r.data.scope as Scope).brandId === scope.brandId) &&
        (tab === "Library"
          ? ["asset", "architecture"].includes(r.kind)
          : tab === "Strategy"
            ? r.kind === "strategy"
            : tab === "Actions"
              ? r.kind === "action"
              : tab === "Briefs"
                ? r.kind === "brief"
                : tab === "Delivery"
                  ? r.kind === "execution"
                  : tab === "Executors"
                    ? r.kind === "executor"
                    : tab === "Effectiveness"
                      ? r.kind === "effectiveness"
                      : r.kind === "strategy"),
    );
  return (
    <div className="content-strategy">
      <p>
        Turn your existing content and evidence into practical next actions.
      </p>
      <section className="content-context">
        <label>
          Brand
          <select
            disabled={!!busy || !!editing}
            value={scope.brandId}
            onChange={(e) => {
              setScope({
                ...scope,
                brandId: e.target.value,
                products: [],
                offers: [],
                audiences: [],
              });
              setSelected([]);
              setEditing(undefined);
            }}
          >
            {data.brands.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
        </label>
        <details>
          <summary>Products, offers and audiences</summary>
          <div className="content-columns">
            {(
              [
                ["products", "offerings"],
                ["offers", "offers"],
                ["audiences", "ideal_customer_profiles"],
              ] as const
            ).map(([key, collection]) => (
              <fieldset key={key}>
                <legend>{label(key)}</legend>
                {data.choices[collection]
                  ?.filter((c) => !c.brandId || c.brandId === scope.brandId)
                  .map((c) => (
                    <label className="content-check" key={c.id}>
                      <input
                        type="checkbox"
                        disabled={
                          !!busy || (!!editing && editing.kind !== "asset")
                        }
                        checked={scope[key].some((r) => r.id === c.id)}
                        onChange={(e) =>
                          setScope({
                            ...scope,
                            [key]: e.target.checked
                              ? [
                                  ...scope[key],
                                  { id: c.id, revision: c.revision },
                                ]
                              : scope[key].filter((r) => r.id !== c.id),
                          })
                        }
                      />
                      {c.name}
                    </label>
                  ))}
                {!data.choices[collection]?.length && (
                  <p>No approved records yet.</p>
                )}
              </fieldset>
            ))}
          </div>
        </details>
      </section>
      {tab !== "Library" && (
        <details className="content-section">
          <summary>
            Choose content and evidence for this task ({selected.length}{" "}
            selected)
          </summary>
          {data.records
            .filter((r) => inBrand(r))
            .map((r) => (
              <label className="content-check" key={r.id}>
                <input
                  type="checkbox"
                  checked={selected.includes(r.id)}
                  onChange={(e) =>
                    setSelected(
                      e.target.checked
                        ? [...selected, r.id]
                        : selected.filter((id) => id !== r.id),
                    )
                  }
                />
                {String(r.data.title)} · {r.kind} · {r.status}
              </label>
            ))}
        </details>
      )}
      {error && (
        <p role="alert" className="content-error">
          {error}
        </p>
      )}
      {notice && <p role="status">{notice}</p>}
      {busy && <Loading label={busy} />}
      {!sharedHenry && (
        <ContentHenry
          key={scope.brandId}
          turns={(data.conversations ?? []).filter(
            (t) => t.scope.brandId === scope.brandId,
          )}
          busy={!!busy}
          available={data.generationAvailable && !!scope.brandId}
          onAsk={askHenry}
          onReview={reviewHenry}
        />
      )}
      <nav className="content-tabs" aria-label="Content Strategy sections">
        {tabs.map((t) => (
          <button
            key={t}
            disabled={!!busy}
            aria-current={tab === t ? "page" : undefined}
            onClick={() => {
              setTab(t);
              setHistory(undefined);
            }}
          >
            {t}
          </button>
        ))}
      </nav>
      {(tab === "Overview" || tab === "Strategy") && (
        <LibraryPlanning
          api={api}
          workspaceId={w}
          brandId={scope.brandId}
          records={data.records}
          onChanged={reload}
          onGap={(instruction) => {
            setInstruction(instruction);
            setTab("Briefs");
          }}
        />
      )}
      {(tab === "Overview" || tab === "Strategy" || tab === "Briefs") && (
        <details className="content-section">
          <summary>Structured generation options</summary>
          <h2>
            {tab === "Briefs"
              ? "What should this brief achieve?"
              : "What would you like to achieve?"}
          </h2>
          <p>
            Select relevant records in the content and evidence selector. Henry
            will propose an editable result using approved business context and
            your selected evidence. Current approved Brand Kit guidance is used
            where available; otherwise the default is neutral British English.
          </p>
          <label htmlFor="content-intent">
            Objectives, priorities and constraints
          </label>
          <textarea
            id="content-intent"
            rows={4}
            value={instruction}
            onChange={(e) => setInstruction(e.target.value)}
            placeholder="What should we focus on, what can we use, and what is not possible yet?"
          />
          <div className="content-actions">
            <button
              disabled={
                !!busy ||
                !instruction ||
                !scope.brandId ||
                !data.generationAvailable
              }
              onClick={() =>
                void run("Interpreting your objectives…", () =>
                  generate("context"),
                )
              }
            >
              Interpret objectives
            </button>
            <button
              className="button"
              disabled={
                !!busy ||
                !instruction ||
                !scope.brandId ||
                !data.generationAvailable
              }
              onClick={() =>
                void run("Preparing your proposal…", () =>
                  generate(tab === "Briefs" ? "brief" : "strategy"),
                )
              }
            >
              {tab === "Briefs"
                ? "Generate brief"
                : "Generate / reassess strategy"}
            </button>
          </div>
        </details>
      )}
      {tab === "Library" && (
        <LibraryIngestion
          api={api}
          workspaceId={w}
          scope={scope}
          website={
            data.brands.find((b) => b.id === scope.brandId)?.website ?? ""
          }
          onChanged={reload}
          records={data.records}
        />
      )}
      {tab === "Library" && (
        <div className="content-actions">
          <button disabled={!!busy} onClick={() => newRecord("asset")}>
            Add content or external link
          </button>
          <button disabled={!!busy} onClick={() => newRecord("architecture")}>
            Import Content Architecture
          </button>
        </div>
      )}
      {tab === "Briefs" && (
        <section className="content-section">
          <button onClick={() => newRecord("brief")}>
            Write execution brief
          </button>
          <p>
            Use a content brief for an asset, or another brief type for PR,
            research, events or specialist work.
          </p>
        </section>
      )}
      {tab === "Executors" && (
        <section className="content-section">
          <h2>People and execution options</h2>
          <p>
            Record a specialist, agency, Queen or client team and the work they
            can do. Applications must already be connected in Integrations.
            Assignment records responsibility; it does not send a brief or
            authorise spending.
          </p>
          <button onClick={() => newRecord("executor")}>Add executor</button>
        </section>
      )}
      {tab === "Delivery" && (
        <section className="content-section">
          <h2>Assigned work</h2>
          <p>
            Assign an approved brief, record progress and register the result.
            Completion and effectiveness are separate.
          </p>
          <button onClick={() => newRecord("execution")}>
            Assign approved brief
          </button>
        </section>
      )}
      {tab === "Effectiveness" && (
        <section className="content-section">
          <p>
            Record sourced measurements. Asset completion, engagement, audience
            response and commercial effectiveness are separate. HVM does not
            infer attribution.
          </p>
          <button onClick={() => newRecord("effectiveness")}>
            Add measurement
          </button>
        </section>
      )}
      {editing && (
        <section className="content-section">
          <h2>Review {names[editing.kind]}</h2>
          <p>
            {editing.kind === "execution"
              ? "Record responsibility and progress. This does not send instructions or commit a budget."
              : editing.kind === "executor"
                ? "Save this resource and its capabilities for assignment. This does not grant the executor app access."
                : "Save your changes, then approve the saved version when ready. Previously approved versions remain in history."}
          </p>
          {file && (
            <p>
              Original file: {file.name}. The original will be stored privately
              when you save.
            </p>
          )}
          {editing.kind === "brief" && (
            <label>
              Related recommendation
              <select
                value={String(editing.data.actionId || "")}
                onChange={(e) =>
                  setEditing({
                    ...editing,
                    data: { ...editing.data, actionId: e.target.value },
                  })
                }
              >
                <option value="">Choose a recommendation</option>
                {data.records
                  .filter((r) => r.kind === "action" && inBrand(r))
                  .map((r) => (
                    <option key={r.id} value={r.id}>
                      {String(r.data.title)} · {r.status}
                    </option>
                  ))}
              </select>
            </label>
          )}
          {editing.kind === "execution" && (
            <div className="content-fields">
              <label>
                Approved execution brief
                <select
                  disabled={Boolean(editing.record)}
                  value={String(editing.data.briefId || "")}
                  onChange={(e) => {
                    const brief = data.records.find(
                      (r) => r.id === e.target.value,
                    );
                    if (brief)
                      setEditing({
                        ...editing,
                        data: {
                          ...editing.data,
                          briefId: brief.id,
                          briefVersion: brief.version,
                          scope: brief.data.scope,
                          title: `Delivery: ${String(brief.data.title)}`,
                        },
                      });
                  }}
                >
                  <option value="">Choose a brief</option>
                  {data.records
                    .filter(
                      (r) =>
                        r.kind === "brief" &&
                        inBrand(r) &&
                        (r.status === "approved" ||
                          r.id === editing.data.briefId),
                    )
                    .map((r) => (
                      <option key={r.id} value={r.id}>
                        {String(r.data.title)} · version {r.version}
                      </option>
                    ))}
                </select>
              </label>
              <label>
                Executor
                <select
                  disabled={Boolean(editing.record)}
                  value={String(editing.data.executorId || "")}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      data: { ...editing.data, executorId: e.target.value },
                    })
                  }
                >
                  <option value="">Choose an executor</option>
                  {data.records
                    .filter(
                      (r) =>
                        r.kind === "executor" &&
                        inBrand(r) &&
                        (r.data.available || r.id === editing.data.executorId),
                    )
                    .map((r) => (
                      <option key={r.id} value={r.id}>
                        {String(r.data.title)} ·{" "}
                        {String(r.data.executorType).replaceAll("_", " ")}
                      </option>
                    ))}
                </select>
              </label>
            </div>
          )}
          {editing.kind === "executor" && (
            <div className="content-fields">
              {editing.data.executorType === "external_application" && (
                <label>
                  Connected application
                  <select
                    value={String(editing.data.integrationId || "")}
                    onChange={(e) =>
                      setEditing({
                        ...editing,
                        data: {
                          ...editing.data,
                          integrationId: e.target.value,
                        },
                      })
                    }
                  >
                    <option value="">Choose a connected application</option>
                    {(data.integrations || []).map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.name}
                      </option>
                    ))}
                  </select>
                </label>
              )}
              {editing.data.executorType === "internal_hvm" && (
                <fieldset>
                  <legend>Registered capabilities</legend>
                  {(data.capabilities || []).map((r) => (
                    <label className="content-check" key={r.id}>
                      <input
                        type="checkbox"
                        checked={(
                          (editing.data.capabilityIds as string[]) || []
                        ).includes(r.id)}
                        onChange={(e) =>
                          setEditing({
                            ...editing,
                            data: {
                              ...editing.data,
                              capabilityIds: e.target.checked
                                ? [
                                    ...((editing.data
                                      .capabilityIds as string[]) || []),
                                    r.id,
                                  ]
                                : (
                                    (editing.data.capabilityIds as string[]) ||
                                    []
                                  ).filter((id) => id !== r.id),
                            },
                          })
                        }
                      />
                      {r.name}
                    </label>
                  ))}
                  <p>Recording a capability does not automatically run it.</p>
                </fieldset>
              )}
            </div>
          )}
          {editing.kind === "effectiveness" && (
            <div className="content-fields">
              {(
                [
                  ["executionId", "execution", "Related assignment"],
                  ["assetId", "asset", "Delivered asset"],
                ] as const
              ).map(([key, kind, title]) => (
                <label key={key}>
                  {title}
                  <select
                    value={String(editing.data[key] || "")}
                    onChange={(e) =>
                      setEditing({
                        ...editing,
                        data: { ...editing.data, [key]: e.target.value },
                      })
                    }
                  >
                    <option value="">None</option>
                    {data.records
                      .filter((r) => r.kind === kind && inBrand(r))
                      .map((r) => (
                        <option key={r.id} value={r.id}>
                          {String(r.data.title)}
                        </option>
                      ))}
                  </select>
                </label>
              ))}
            </div>
          )}
          {editing.kind === "architecture" && (
            <label>
              Upload Markdown
              <input
                type="file"
                accept=".md,.txt"
                disabled={!!busy}
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f)
                    void run("Reading architecture…", async () => {
                      const markdown = await extractContentFile(f);
                      setEditing({
                        ...editing,
                        data: {
                          ...editing.data,
                          title: editing.data.title || f.name,
                          markdown,
                          confirmed: false,
                        },
                      });
                    });
                }}
              />
            </label>
          )}
          {editing.kind === "asset" &&
            Boolean(
              (editing.data.sourceMetadata as Record<string, unknown>)
                ?.executionId,
            ) && (
              <div className="content-fields">
                {(["publication", "publicationDate"] as const).map((key) => (
                  <label key={key}>
                    {label(key)}
                    <input
                      type={key === "publicationDate" ? "date" : "text"}
                      value={String(
                        (
                          editing.data.sourceMetadata as Record<string, unknown>
                        )[key] || "",
                      )}
                      onChange={(e) =>
                        setEditing({
                          ...editing,
                          data: {
                            ...editing.data,
                            sourceMetadata: {
                              ...(editing.data.sourceMetadata as object),
                              [key]: e.target.value,
                            },
                          },
                        })
                      }
                    />
                  </label>
                ))}
                <p>
                  External publication does not grant HVM reuse rights. Record
                  restrictions below before approval.
                </p>
              </div>
            )}
          {editing.kind === "asset" && (
            <div className="content-fields">
              <label>
                Attach or replace original file
                <input
                  type="file"
                  accept=".pdf,.docx,.md,.txt"
                  disabled={!!busy}
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f)
                      void run("Reading returned file…", async () => {
                        const text = await extractContentFile(f);
                        setFile(f);
                        uploadKey.current = crypto.randomUUID();
                        uploadResult.current = undefined;
                        setEditing({
                          ...editing,
                          data: {
                            ...editing.data,
                            text,
                            sourceDocumentId: "",
                            title: editing.data.title || f.name,
                          },
                        });
                      });
                  }}
                />
              </label>
              <label>
                Produced by
                <input
                  value={String(
                    (
                      editing.data.sourceMetadata as
                        Record<string, unknown> | undefined
                    )?.producer ?? "",
                  )}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      data: {
                        ...editing.data,
                        sourceMetadata: {
                          ...((editing.data.sourceMetadata ??
                            initial(
                              schemas.asset.shape.sourceMetadata,
                            )) as object),
                          producer: e.target.value,
                        },
                      },
                    })
                  }
                />
              </label>
            </div>
          )}
          <Fields
            schema={schemas[editing.kind]}
            value={editing.data}
            onChange={(v) =>
              setEditing({ ...editing, data: v as Record<string, unknown> })
            }
          />
          {["asset", "brief"].includes(editing.kind) && (
            <details>
              <summary>Source relationships</summary>
              {data.records
                .filter(
                  (r) =>
                    r.kind === "asset" &&
                    r.id !== editing.record?.id &&
                    (!r.data.archived || ((editing.data.sourceAssetIds as string[]) ?? []).includes(r.id)) &&
                    (r.data.scope as Scope).brandId === scope.brandId,
                )
                .map((r) => (
                  <label className="content-check" key={r.id}>
                    <input
                      type="checkbox"
                      checked={(
                        (editing.data.sourceAssetIds as string[]) ?? []
                      ).includes(r.id)}
                      onChange={(e) =>
                        setEditing({
                          ...editing,
                          data: {
                            ...editing.data,
                            sourceAssetIds: e.target.checked
                              ? [
                                  ...((editing.data
                                    .sourceAssetIds as string[]) ?? []),
                                  r.id,
                                ]
                              : (
                                  (editing.data.sourceAssetIds as string[]) ??
                                  []
                                ).filter((id) => id !== r.id),
                          },
                        })
                      }
                    />
                    {String(r.data.title)}
                  </label>
                ))}
            </details>
          )}
          <div className="content-actions">
            <button
              onClick={() => {
                setEditing(undefined);
                setFile(undefined);
              }}
            >
              Cancel
            </button>
            <button
              className="button"
              disabled={!!busy}
              onClick={() => void run("Saving…", save)}
            >
              Save {names[editing.kind]}
            </button>
          </div>
          {editing.kind === "architecture" && (
            <p>
              Save the source Markdown first, select it below, then interpret
              the recommendations. Confirm the interpretation before using it in
              strategy generation.
            </p>
          )}
        </section>
      )}
      {tab === "Library" && (
        <section className="content-fields" aria-label="Search Library">
          <label>
            Search Library
            <input
              type="search"
              value={librarySearch}
              onChange={(e) => setLibrarySearch(e.target.value)}
            />
          </label>
          <label>
            Asset type
            <select
              value={libraryType}
              onChange={(e) => setLibraryType(e.target.value)}
            >
              <option value="">All types</option>
              {[
                ...new Set(
                  data.records
                    .filter((r) => r.kind === "asset")
                    .map((r) => String(r.data.assetType)),
                ),
              ].map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </label>
          <label>
            Approval status
            <select
              value={libraryStatus}
              onChange={(e) => setLibraryStatus(e.target.value)}
            >
              <option value="">All statuses</option>
              <option value="draft">Draft</option>
              <option value="approved">Approved</option>
            </select>
          </label>
          <label className="content-check">
            <input
              type="checkbox"
              checked={includeArchived}
              onChange={(e) => setIncludeArchived(e.target.checked)}
            />
            Include archived assets
          </label>
        </section>
      )}
      <div className="content-actions">
        <span>
          {visible.length}{" "}
          {tab === "Library"
            ? visible.length === 1
              ? "item"
              : "items"
            : visible.length === 1
              ? "record"
              : "records"}
        </span>
        {selected.length > 0 && (
          <>
            <span>{selected.length} selected for analysis or generation</span>
            {visible.some((r) => selected.includes(r.id)) && (
              <>
                <label>
                  Bulk change (selected visible records)
                  <select
                    value={bulkValue}
                    onChange={(e) => setBulkValue(e.target.value)}
                  >
                    <option value="">Choose change</option>
                    {tab === "Library" ? (
                      <>
                        <option value="core">Classify assets as core</option>
                        <option value="channel">
                          Classify assets as channel
                        </option>
                        <option value="unclassified">
                          Clear asset classification
                        </option>
                      </>
                    ) : tab === "Actions" ? (
                      <>
                        <option value="high">Set high priority</option>
                        <option value="medium">Set medium priority</option>
                        <option value="low">Set low priority</option>
                      </>
                    ) : tab === "Executors" ? (
                      <>
                        <option value="available">Make available</option>
                        <option value="unavailable">Make unavailable</option>
                      </>
                    ) : tab === "Delivery" ? (
                      <>
                        <option value="accepted">Mark accepted</option>
                        <option value="in_progress">Mark in progress</option>
                        <option value="awaiting_input">
                          Mark awaiting input
                        </option>
                        <option value="cancelled">Cancel assignments</option>
                      </>
                    ) : (
                      <option value="review">Create drafts for review</option>
                    )}
                  </select>
                </label>
                <button
                  disabled={!!busy || !bulkValue}
                  onClick={() =>
                    void run("Updating selected records…", async () => {
                      const failed: string[] = [];
                      let updated = 0;
                      for (const r of visible.filter((r) =>
                        selected.includes(r.id),
                      )) {
                        if (tab === "Library" && r.kind !== "asset") continue;
                        try {
                          await api.save(
                            w,
                            {
                              id: r.id,
                              kind: r.kind,
                              expectedVersion: r.version,
                              operation: "save",
                              requestKey: crypto.randomUUID(),
                              data: {
                                ...r.data,
                                ...(r.kind === "asset"
                                  ? { classification: bulkValue }
                                  : r.kind === "action"
                                    ? { priority: bulkValue }
                                    : r.kind === "executor"
                                      ? { available: bulkValue === "available" }
                                      : r.kind === "execution"
                                        ? {
                                            progress: bulkValue,
                                            completedAt: "",
                                          }
                                        : {}),
                              },
                            },
                            signal(),
                          );
                          updated++;
                        } catch {
                          failed.push(String(r.data.title));
                        }
                      }
                      await reload();
                      setNotice(
                        `${updated} ${["Delivery", "Executors"].includes(tab) ? "records updated." : "drafts saved for review."}${failed.length ? ` Could not update: ${failed.join(", ")}. Review their current versions and dependencies.` : ""}`,
                      );
                    })
                  }
                >
                  Apply to selected
                </button>
              </>
            )}
            <button
              disabled={!!busy}
              onClick={() =>
                void run("Removing selected items…", async () => {
                  if (
                    !window.confirm(
                      "Remove selected records visible in this tab from future use? Protected dependencies will be retained.",
                    )
                  )
                    return;
                  const failed = [];
                  for (const r of visible.filter((r) =>
                    selected.includes(r.id),
                  )) {
                    try {
                      await api.save(
                        w,
                        {
                          id: r.id,
                          kind: r.kind,
                          expectedVersion: r.version,
                          operation: "remove",
                          requestKey: crypto.randomUUID(),
                        },
                        signal(),
                      );
                    } catch {
                      failed.push(String(r.data.title));
                    }
                  }
                  await reload();
                  setSelected([]);
                  setNotice(
                    failed.length
                      ? `Some items were retained: ${failed.join(", ")}. Check their dependencies.`
                      : "Selected items removed.",
                  );
                })
              }
            >
              Remove selected
            </button>
          </>
        )}
      </div>
      {!visible.length && (
        <Empty title={`No ${tab.toLowerCase()} records yet`}>
          {tab === "Actions"
            ? "Save a strategy, then add its recommendations to Actions."
            : "Create or import your first record above."}
        </Empty>
      )}
      <div className="content-records">
        {visible.map((r) => (
          <article className="content-record" key={r.id}>
            <header>
              <label className="content-check">
                <input
                  type="checkbox"
                  checked={selected.includes(r.id)}
                  onChange={(e) =>
                    setSelected(
                      e.target.checked
                        ? [...selected, r.id]
                        : selected.filter((id) => id !== r.id),
                    )
                  }
                />
                <h3 id={r.id}>{String(r.data.title)}</h3>
              </label>
              <Status>
                {r.kind === "execution"
                  ? String(r.data.progress).replaceAll("_", " ")
                  : r.kind === "executor"
                    ? r.data.available
                      ? "Available"
                      : "Unavailable"
                    : r.status}
              </Status>
            </header>
            <p>
              {String(
                r.data.description ??
                  r.data.assessment ??
                  r.data.rationale ??
                  r.data.objective ??
                  r.data.value ??
                  "",
              )}
            </p>
            {r.kind === "action" &&
              data.records
                .filter(
                  (n) =>
                    n.kind === "execution" &&
                    data.records.some(
                      (b) =>
                        b.id === n.data.briefId && b.data.actionId === r.id,
                    ),
                )
                .map((n) => (
                  <p key={n.id}>
                    Delivery: {String(n.data.progress).replaceAll("_", " ")} ·{" "}
                    {String(
                      data.records.find((e) => e.id === n.data.executorId)?.data
                        .title || "Executor",
                    )}
                  </p>
                ))}
            {r.actionLibraryId && (
              <p>
                Library draft linked. Refreshing the handoff updates this same
                draft; it does not create execution authority.
              </p>
            )}
            {r.kind === "asset" && (
              <>
                <p>
                  {String(r.data.visibility ?? "private").replaceAll("_", " ")}{" "}
                  · {String(r.data.processingNote ?? "")}
                </p>
                <div className="content-actions">
                  <button
                    disabled={!!busy}
                    onClick={() =>
                      void run("Saving asset status…", async () => {
                        await api.save(
                          w,
                          {
                            id: r.id,
                            kind: "asset",
                            expectedVersion: r.version,
                            operation: "save",
                            requestKey: crypto.randomUUID(),
                            data: { ...r.data, archived: !r.data.archived },
                          },
                          signal(),
                        );
                        setSelected(ids => ids.filter(id => id !== r.id));
                        await reload();
                      })
                    }
                  >
                    {r.data.archived ? "Restore asset" : "Archive asset"}
                  </button>
                </div>
              </>
            )}
            {r.reuseEligibility && (
              <p>
                {r.reuseEligibility.eligible
                  ? "Available for the recorded uses after downstream policy checks."
                  : "Not available for downstream reuse yet."}{" "}
                {r.reuseEligibility.reason}
              </p>
            )}
            {r.needsReview && (
              <p role="status">
                Source material has changed. Review this item before reusing it.
              </p>
            )}
            <small>
              Version {r.version} ·{" "}
              {new Date(r.updatedAt).toLocaleDateString("en-GB")}
              {r.kind === "asset"
                ? ` · ${String(r.data.classification)} · ${String(r.data.analysisStatus).replaceAll("_", " ")}`
                : ""}
            </small>
            <details>
              <summary>View saved details</summary>
              <ReadValues value={r.data} />
            </details>
            {r.data.sourceType === "offer_output" && <section aria-label="Saved offer output"><button disabled={!!busy} onClick={() => void run("Loading offer summary…",async()=>{const full=await api.library.asset(w,r.id,signal());setOutputText(old=>({...old,[r.id]:String(full.data.text)}));})}>Read offer summary</button>{outputText[r.id] && <p className="offer-prose">{outputText[r.id]}</p>}</section>}
            <div className="content-actions">
              {r.data.sourceType === "email_content" ? <a href={window.location.pathname.startsWith("/client")?`/client/email-content?workspace=${w}`:`/queen/clients/${w}/email-content`}>View or edit email draft</a> : r.data.sourceType === "offer_output" ? <a href={`/queen/clients/${w}/offers?product=${encodeURIComponent((r.data.scope as {products:{id:string}[]}).products[0]?.id ?? "")}&offer=${String((r.data.offerOutput as {offerId:string}).offerId)}`}>View or edit source offer</a> : <button
                disabled={!!busy}
                onClick={() => {
                  if (r.kind === "asset" && r.data.contentTextId) {
                    void run("Loading complete asset…", async () => {
                      const full = await api.library.asset(w, r.id, signal());
                      setFile(undefined);
                      uploadResult.current = undefined;
                      setEditing({
                        kind: full.kind,
                        data: full.data,
                        record: full,
                      });
                      if (full.data.scope)
                        setScope(scopeSchema.parse(full.data.scope));
                    });
                    return;
                  }
                  setFile(undefined);
                  uploadResult.current = undefined;
                  setEditing({
                    kind: r.kind,
                    data:
                      r.kind === "action"
                        ? {
                            ...r.data,
                            strategyRevision:
                              data.records.find(
                                (s) => s.id === r.data.strategyId,
                              )?.version ?? r.data.strategyRevision,
                          }
                        : r.data,
                    record: r,
                  });
                  if (r.kind === "action")
                    setNotice(
                      "Review this recommendation against the current strategy before saving.",
                    );
                  if (r.data.scope) setScope(scopeSchema.parse(r.data.scope));
                }}
              >
                Edit
              </button>}
              {!["offer_output","email_content"].includes(String(r.data.sourceType)) && r.status !== "approved" &&
                !["executor", "execution"].includes(r.kind) && (
                  <button
                    disabled={!!busy}
                    onClick={() =>
                      void run("Approving…", () => change(r, "approve"))
                    }
                  >
                    Approve
                  </button>
                )}
              <button
                disabled={!!busy}
                onClick={() =>
                  void run("Loading history…", async () =>
                    setHistory(await api.history(w, r.id, signal())),
                  )
                }
              >
                History
              </button>
              <button
                disabled={!!busy || r.data.sourceType === "email_content"}
                title={r.data.sourceType === "email_content" ? "Remove from Email Content Creation to retain draft history." : undefined}
                onClick={() => void run("Removing…", () => change(r, "remove"))}
              >
                Remove
              </button>
              {r.kind === "asset" && Boolean(r.data.sourceDocumentId) && (
                <button
                  disabled={!!busy}
                  onClick={() =>
                    void run("Downloading original…", async () => {
                      const blob = await api.documents.download(
                        w,
                        { id: String(r.data.sourceDocumentId) },
                        signal(),
                      );
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement("a");
                      a.href = url;
                      a.download = String(
                        r.data.originalFilename ||
                          r.data.title ||
                          "Original file",
                      );
                      a.click();
                      URL.revokeObjectURL(url);
                    })
                  }
                >
                  Download original
                </button>
              )}
              {r.kind === "asset" && (
                <button
                  disabled={!!busy || !data.generationAvailable}
                  onClick={() =>
                    void run("Analysing asset…", () =>
                      generate(
                        "analyse",
                        [r.id],
                        "Analyse this asset against approved business context; preserve its source and identity.",
                      ),
                    )
                  }
                >
                  Analyse content
                </button>
              )}
              {r.kind === "architecture" && (
                <button
                  disabled={!!busy || !data.generationAvailable}
                  onClick={() =>
                    void run("Interpreting architecture…", () =>
                      generate(
                        "architecture",
                        [r.id],
                        "Interpret this content architecture; preserve the original and mark uncertain mappings for review.",
                      ),
                    )
                  }
                >
                  Interpret recommendations
                </button>
              )}
              {r.kind === "action" && (
                <button
                  disabled={!!busy || !data.generationAvailable}
                  onClick={() =>
                    void run("Preparing production brief…", () =>
                      generate(
                        "brief",
                        [r.id, ...(r.data.sourceAssetIds as string[])],
                        "Create a practical production brief for this recommendation, including source evidence and approval constraints.",
                        scopeSchema.parse(
                          data.records.find((s) => s.id === r.data.strategyId)
                            ?.data.scope ?? scope,
                        ),
                      ),
                    )
                  }
                >
                  Create brief
                </button>
              )}
              {r.kind === "strategy" && (
                <button
                  disabled={!!busy}
                  onClick={() =>
                    void run("Adding recommendations…", async () => {
                      let added = 0;
                      for (const item of (r.data.recommendations as Record<
                        string,
                        unknown
                      >[]) ?? []) {
                        if (
                          data.records.some(
                            (a) =>
                              a.kind === "action" &&
                              a.data.strategyId === r.id &&
                              a.data.key === item.key,
                          )
                        )
                          continue;
                        await api.save(
                          w,
                          {
                            kind: "action",
                            expectedVersion: 0,
                            operation: "save",
                            requestKey: crypto.randomUUID(),
                            data: {
                              ...item,
                              strategyId: r.id,
                              strategyRevision: r.version,
                              owner: "",
                              decisionReason: "",
                              progress: "proposed",
                              actionDefinitionId: "",
                            },
                          },
                          signal(),
                        );
                        added++;
                      }
                      await reload();
                      setTab("Actions");
                      setNotice(
                        `${added} recommendations added. Existing decisions preserved.`,
                      );
                    })
                  }
                >
                  Add recommendations to Actions
                </button>
              )}
              {r.kind === "execution" && (
                <>
                  <p>
                    Progress: {String(r.data.progress).replaceAll("_", " ")} ·{" "}
                    {String(
                      data.records.find((n) => n.id === r.data.executorId)?.data
                        .title || "Executor",
                    )}
                  </p>
                  <button
                    onClick={() => {
                      const brief = data.records.find(
                        (n) => n.id === r.data.briefId,
                      );
                      if (!brief) return;
                      setTab("Library");
                      newRecord("asset");
                      setEditing({
                        kind: "asset",
                        data: {
                          ...(initial(schemas.asset) as object),
                          scope: r.data.scope,
                          title: `Delivered: ${String(brief.data.title)}`,
                          sourceAssetIds: brief.data.sourceAssetIds,
                          sourceMetadata: {
                            ...(initial(
                              schemas.asset.shape.sourceMetadata,
                            ) as object),
                            briefId: r.data.briefId,
                            briefVersion: r.data.briefVersion,
                            executionId: r.id,
                            producer: String(
                              data.records.find(
                                (n) => n.id === r.data.executorId,
                              )?.data.title || "",
                            ),
                          },
                        },
                      });
                    }}
                  >
                    Register delivered asset
                  </button>
                  <button
                    onClick={() => {
                      setTab("Effectiveness");
                      newRecord("effectiveness");
                      setEditing({
                        kind: "effectiveness",
                        data: {
                          ...(initial(schemas.effectiveness) as object),
                          scope: r.data.scope,
                          executionId: r.id,
                          observedAt: new Date().toISOString(),
                          title: `Outcome: ${String(r.data.title)}`,
                        },
                      });
                    }}
                  >
                    Record outcome
                  </button>
                </>
              )}
              {r.kind === "brief" && r.status === "approved" && (
                <>
                  {r.data.briefType === "content" && <button className="button" disabled={!!busy || !data.generationAvailable} onClick={() => void run("Writing content from the approved brief…", async () => {
                    const attemptId=`${r.id}:${r.version}`;
                    let attempt=writtenAttempts.current.get(attemptId);
                    if(!attempt){attempt={generate:crypto.randomUUID(),save:crypto.randomUUID()};writtenAttempts.current.set(attemptId,attempt);}
                    const content = await api.generate(w,{task:"write",scope:scopeSchema.parse(r.data.scope),recordIds:[r.id],instruction:"Produce the written deliverable described in this approved brief. Use its evidence and constraints.",requestKey:attempt.generate},signal());
                    const assetDraft = {
                      ...(initial(schemas.asset) as object),scope:r.data.scope,title:content.title,text:content.text,description:content.description,
                      assetType:r.data.format || "written content", channel:r.data.channel || "", sourceAssetIds:r.data.sourceAssetIds,
                      visibility:"private",analysisStatus:"needs_review",gaps:content.evidenceGaps,
                      sourceMetadata:{canonicalUrl:"",headings:[],checkedAt:"",producer:"HVM internal written-content generation",briefId:r.id,briefVersion:r.version,capabilityId:"",integrationId:""}
                    };
                    setEditing({kind:"asset",data:assetDraft}); setTab("Library");
                    const saved = await api.save(w,{kind:"asset",operation:"save",expectedVersion:0,requestKey:attempt.save,data:assetDraft},signal());
                    writtenAttempts.current.delete(attemptId);
                    await reload(); setEditing({kind:"asset",record:saved,data:saved.data});
                    setNotice("Written draft saved to Library. Review and edit it before approving any external use.");
                  })}>Generate written draft</button>}
                  <button
                    disabled={!!busy}
                    onClick={() =>
                      void run("Preparing brief export…", async () =>
                        download(
                          await api.exportBrief(w, r.id, signal()),
                          "hvm-execution-brief.json",
                        ),
                      )
                    }
                  >
                    Export execution brief
                  </button>
                  <button
                    disabled={!!busy}
                    onClick={() =>
                      void run("Copying brief…", async () => {
                        const brief = await api.exportBrief(w, r.id, signal());
                        await navigator.clipboard.writeText(
                          executionBriefText(brief),
                        );
                        setNotice(
                          "Brief copied. Share it through your authorised communication method.",
                        );
                      })
                    }
                  >
                    Copy brief
                  </button>
                  <button
                    onClick={() => {
                      newRecord("execution");
                      setTab("Delivery");
                      setEditing({
                        kind: "execution",
                        data: {
                          ...(initial(schemas.execution) as object),
                          scope: r.data.scope,
                          briefId: r.id,
                          briefVersion: r.version,
                          title: `Delivery: ${String(r.data.title)}`,
                          progress: "assigned",
                        },
                      });
                    }}
                  >
                    Assign brief
                  </button>
                  <button
                    disabled={!!busy}
                    onClick={() => {
                      setScope(scopeSchema.parse(r.data.scope));
                      newRecord("asset");
                      setTab("Library");
                      setEditing({
                        kind: "asset",
                        data: {
                          ...(initial(schemas.asset) as object),
                          scope: r.data.scope,
                          title: `Produced asset: ${String(r.data.title)}`,
                          sourceAssetIds: r.data.sourceAssetIds,
                          sourceMetadata: {
                            canonicalUrl: "",
                            headings: [],
                            checkedAt: "",
                            producer: "manual external production",
                            briefId: r.id,
                            briefVersion: r.version,
                            capabilityId: "",
                            integrationId: "",
                          },
                        },
                      });
                    }}
                  >
                    Register returned asset
                  </button>
                </>
              )}
              {r.kind === "action" && (
                <button
                  disabled={!!busy || !actionType}
                  onClick={() =>
                    void run("Adding to Library…", async () => {
                      const out = await api.handoff(
                        w,
                        r.id,
                        r.version,
                        actionType,
                        signal(),
                      );
                      await reload();
                      setNotice(
                        `Library draft saved: ${out.id}. It has no execution authority.`,
                      );
                    })
                  }
                >
                  Add to Library
                </button>
              )}
            </div>
          </article>
        ))}
      </div>
      {tab === "Library" && selected.length > 0 && (
        <section className="content-section">
          <label htmlFor="content-analysis">
            Instructions for interpretation
          </label>
          <textarea
            id="content-analysis"
            rows={3}
            value={instruction}
            onChange={(e) => setInstruction(e.target.value)}
          />
          <div className="content-actions">
            <button
              disabled={!!busy || !instruction || !data.generationAvailable}
              onClick={() =>
                void run("Analysing the selected asset…", () =>
                  generate("analyse"),
                )
              }
            >
              Analyse selected asset
            </button>
            <button
              disabled={!!busy || !instruction || !data.generationAvailable}
              onClick={() =>
                void run("Interpreting content architecture…", () =>
                  generate("architecture"),
                )
              }
            >
              Interpret architecture
            </button>
          </div>
        </section>
      )}
      {tab === "Actions" && (
        <section className="content-section">
          <h2>Available action types</h2>
          <p>These reusable types describe work such as content production, adaptation and research. Your workspace actions are created from strategy recommendations above; they are not pre-filled campaign tasks. NBA selects authorised actions in campaign context.</p>
          <label>
            Library type
            <select
              value={actionType}
              onChange={(e) => setActionType(e.target.value)}
            >
              <option value="">Select an available type</option>
              {data.actionTypes.map((t) => (
                <option value={t.id} key={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </label>
          {data.catalogueManageable && (
            <button
              disabled={!!busy}
              onClick={() =>
                void run("Enabling content action types…", async () => {
                  await api.initialiseCatalogue(w, signal());
                  await reload();
                })
              }
            >
              Enable content Library types
            </button>
          )}
          {!data.actionTypes.length && (
            <p>
              No published Library types are available yet. An Empress can
              enable the content production, adaptation, research, review and
              external initiative types here.
            </p>
          )}
        </section>
      )}
      {history && (
        <section className="content-section">
          <h2>Version history</h2>
          {history.map((r) => (
            <details key={r.version}>
              <summary>
                Version {r.version} · {r.status}
              </summary>
              <ReadValues value={r.data} />
            </details>
          ))}
        </section>
      )}
      {data.proposals.length > 0 && (
        <details className="content-section">
          <summary>Recent proposals — recover after a refresh</summary>
          {data.proposals.map((p) => (
            <div className="content-actions" key={p.id}>
              <span>
                {p.task} · {new Date(p.createdAt).toLocaleString("en-GB")}
              </span>
              <button
                onClick={() => {
                  if (p.task === "write") {
                    if (!p.scope) { setNotice("This proposal has no saved scope. Reopen its brief before recovering it."); return; }
                    const sourceBrief=data.records.find(r=>r.kind==="brief" && p.sourceRefs?.some(ref=>ref.id===r.id));
                    setScope(p.scope); setTab("Library");
                    setEditing({kind:"asset",data:{...(initial(schemas.asset) as object),scope:p.scope,title:p.result.title,text:p.result.text,description:p.result.description,assetType:sourceBrief?.data.format||"written content",channel:sourceBrief?.data.channel||"",visibility:"private",analysisStatus:"needs_review",gaps:p.result.evidenceGaps,sourceAssetIds:sourceBrief?.data.sourceAssetIds||[],sourceMetadata:{canonicalUrl:"",headings:[],checkedAt:"",producer:"HVM internal written-content generation",briefId:sourceBrief?.id||"",briefVersion:p.sourceRefs?.find(ref=>ref.id===sourceBrief?.id)?.version||0,capabilityId:"",integrationId:""}}});
                    return;
                  }
                  const k =
                    p.task === "context"
                      ? "strategy"
                      : p.task === "analyse"
                        ? "asset"
                        : (p.task as Kind);
                  setEditing({
                    kind: k,
                    data:
                      p.task === "context"
                        ? {
                            ...(initial(schemas.strategy) as object),
                            scope,
                            title: "Content strategy",
                            context: p.result,
                          }
                        : p.result,
                  });
                }}
              >
                Review proposal
              </button>
            </div>
          ))}
        </details>
      )}
    </div>
  );
}
function ReadValues({ value }: { value: unknown }) {
  if (Array.isArray(value))
    return (
      <ul>
        {value.map((v, i) => (
          <li key={i}>
            <ReadValues value={v} />
          </li>
        ))}
      </ul>
    );
  if (value && typeof value === "object")
    return (
      <dl className="content-values">
        {Object.entries(value)
          .filter(
            ([k, v]) =>
              !k.endsWith("Id") &&
              !k.endsWith("Ids") &&
              k !== "scope" &&
              v !== "" &&
              (!Array.isArray(v) || v.length),
          )
          .map(([k, v]) => (
            <div key={k}>
              <dt>{label(k)}</dt>
              <dd>
                <ReadValues value={v} />
              </dd>
            </div>
          ))}
      </dl>
    );
  return <span>{value === null ? "Not specified" : String(value)}</span>;
}
